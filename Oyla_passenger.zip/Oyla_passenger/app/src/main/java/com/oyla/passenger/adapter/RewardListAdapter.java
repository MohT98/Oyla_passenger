package com.oyla.passenger.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.oyla.passenger.R;
import com.oyla.passenger.datamodels.redeemdata.RedeemListData;
import com.oyla.passenger.utilities.Constants;

import java.util.List;

public class RewardListAdapter extends RecyclerView.Adapter<RewardListAdapter.MyViewHolder> {

    private List<RedeemListData> dataSet;
    private Context mCtx;
    private RewardListAdapter.OnItemClickListener mListener;

    public void setOnItemClickListener(RewardListAdapter.OnItemClickListener listener) {
        mListener = listener;
    }

    public RewardListAdapter() {
    }

    public RewardListAdapter(Context mCtx, List<RedeemListData> data) {
        this.dataSet = data;
        this.mCtx = mCtx;
       /* Log.v("bookingId", "data size" + data.size());
        Log.v("bookingId", "data title" + data.get(0).getTitle());*/
    }


    @NonNull
    @Override
    public RewardListAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_reward_list_adapter, parent, false);
        RewardListAdapter.MyViewHolder myViewHolder = new RewardListAdapter.MyViewHolder(view, mListener);

        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RewardListAdapter.MyViewHolder holder, int position) {
        Log.v("bookingId", "title " + dataSet.get(position).getTitle());
        holder.title.setText(dataSet.get(position).getTitle());
        holder.points.setText(dataSet.get(position).getPoints_limit()+" "+mCtx.getResources().getString(R.string.point));
        Glide
                .with(mCtx)
                //.load("http://lead2need.ca/stagingadmin/public/vehicles/gallery/dummy.jpg"
                .load(Constants.ASSETS_BASE_URL +dataSet.get(position).getThumb_image())
               // .centerCrop()
                .placeholder(R.drawable.maskgroup)
                .into(holder.banner);

    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView title,points;
        ImageView banner;


        public MyViewHolder(@NonNull View itemView, final RewardListAdapter.OnItemClickListener listener) {
            super(itemView);
            title = itemView.findViewById(R.id.title);
            points = itemView.findViewById(R.id.points);
            banner = itemView.findViewById(R.id.banner);
            itemView.setOnClickListener(v -> {
                if (listener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onItemClick(position);
                    }
                }
            });
        }
    }
}
