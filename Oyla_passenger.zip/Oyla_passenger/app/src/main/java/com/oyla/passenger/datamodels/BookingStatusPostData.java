package com.oyla.passenger.datamodels;

public class BookingStatusPostData {

    private String passenger_id;
    private String driver_id;
    private String booking_id;

    public BookingStatusPostData(String passenger_id, String driver_id, String booking_id) {
        this.passenger_id = passenger_id;
        this.driver_id = driver_id;
        this.booking_id = booking_id;
    }
}