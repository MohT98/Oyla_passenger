package com.oyla.passenger.datamodels;

import android.os.Parcel;
import android.os.Parcelable;

public class CheckBookingStatusData implements Parcelable {
   private String booking_unique_id;
    private String passenger_id;
    private String booking_id;
    private String driver_id;
    private String pickup_latitude;
    private String pickup_longitude;
    private String dropoff_latitude;
    private String dropoff_longitude;
    private String distance_kilomiters;
    private String estimate_minutes;
    private String vehicle_type;
    private String vehicle_amount;
    private String payment_type;
    private String oyla_wallet_pay;
    private String driver_status;
    private String final_amount;
    private String status;
    private String booking_changes;
    private String peak_factor_rate;
    private String waiting_minuts;
    private String waiting_rate;
    private String ride_cancelled_at;
    private String ride_complete_time;
    private String partner_pickup_rate;
    private String rate_per_kilometer;
    private String rate_per_minute;
    private String tax_percentage;
    private String waiting_price_per_minute;
    private String driver_initial_distance;
    private String min_ride_fares;
    private String vehicle_type_id;
    private String temp_id;
    private int is_skip_dropoff;

    protected CheckBookingStatusData(Parcel in) {
        booking_unique_id = in.readString();
        passenger_id = in.readString();
        booking_id = in.readString();
        driver_id = in.readString();
        pickup_latitude = in.readString();
        pickup_longitude = in.readString();
        dropoff_latitude = in.readString();
        dropoff_longitude = in.readString();
        distance_kilomiters = in.readString();
        estimate_minutes = in.readString();
        vehicle_type = in.readString();
        vehicle_amount = in.readString();
        payment_type = in.readString();
        oyla_wallet_pay = in.readString();
        driver_status = in.readString();
        final_amount = in.readString();
        status = in.readString();
        booking_changes = in.readString();
        peak_factor_rate = in.readString();
        waiting_minuts = in.readString();
        waiting_rate = in.readString();
        ride_cancelled_at = in.readString();
        ride_complete_time = in.readString();
        partner_pickup_rate = in.readString();
        rate_per_kilometer = in.readString();
        rate_per_minute = in.readString();
        tax_percentage = in.readString();
        waiting_price_per_minute = in.readString();
        driver_initial_distance = in.readString();
        min_ride_fares = in.readString();
        vehicle_type_id = in.readString();
        temp_id = in.readString();
        is_skip_dropoff = in.readInt();
    }

    public String getBooking_unique_id() {
        return booking_unique_id;
    }

    public void setBooking_unique_id(String booking_unique_id) {
        this.booking_unique_id = booking_unique_id;
    }

    public String getPassenger_id() {
        return passenger_id;
    }

    public void setPassenger_id(String passenger_id) {
        this.passenger_id = passenger_id;
    }

    public String getBooking_id() {
        return booking_id;
    }

    public void setBooking_id(String booking_id) {
        this.booking_id = booking_id;
    }

    public String getDriver_id() {
        return driver_id;
    }

    public void setDriver_id(String driver_id) {
        this.driver_id = driver_id;
    }

    public String getPickup_latitude() {
        return pickup_latitude;
    }

    public void setPickup_latitude(String pickup_latitude) {
        this.pickup_latitude = pickup_latitude;
    }

    public String getPickup_longitude() {
        return pickup_longitude;
    }

    public void setPickup_longitude(String pickup_longitude) {
        this.pickup_longitude = pickup_longitude;
    }

    public String getDropoff_latitude() {
        return dropoff_latitude;
    }

    public void setDropoff_latitude(String dropoff_latitude) {
        this.dropoff_latitude = dropoff_latitude;
    }

    public String getDropoff_longitude() {
        return dropoff_longitude;
    }

    public void setDropoff_longitude(String dropoff_longitude) {
        this.dropoff_longitude = dropoff_longitude;
    }

    public String getDistance_kilomiters() {
        return distance_kilomiters;
    }

    public void setDistance_kilomiters(String distance_kilomiters) {
        this.distance_kilomiters = distance_kilomiters;
    }

    public String getEstimate_minutes() {
        return estimate_minutes;
    }

    public void setEstimate_minutes(String estimate_minutes) {
        this.estimate_minutes = estimate_minutes;
    }

    public String getVehicle_type() {
        return vehicle_type;
    }

    public void setVehicle_type(String vehicle_type) {
        this.vehicle_type = vehicle_type;
    }

    public String getVehicle_amount() {
        return vehicle_amount;
    }

    public void setVehicle_amount(String vehicle_amount) {
        this.vehicle_amount = vehicle_amount;
    }

    public String getPayment_type() {
        return payment_type;
    }

    public void setPayment_type(String payment_type) {
        this.payment_type = payment_type;
    }

    public String getOyla_wallet_pay() {
        return oyla_wallet_pay;
    }

    public void setOyla_wallet_pay(String oyla_wallet_pay) {
        this.oyla_wallet_pay = oyla_wallet_pay;
    }

    public String getDriver_status() {
        return driver_status;
    }

    public void setDriver_status(String driver_status) {
        this.driver_status = driver_status;
    }

    public String getFinal_amount() {
        return final_amount;
    }

    public void setFinal_amount(String final_amount) {
        this.final_amount = final_amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getBooking_changes() {
        return booking_changes;
    }

    public void setBooking_changes(String booking_changes) {
        this.booking_changes = booking_changes;
    }

    public String getPeak_factor_rate() {
        return peak_factor_rate;
    }

    public void setPeak_factor_rate(String peak_factor_rate) {
        this.peak_factor_rate = peak_factor_rate;
    }

    public String getWaiting_minuts() {
        return waiting_minuts;
    }

    public void setWaiting_minuts(String waiting_minuts) {
        this.waiting_minuts = waiting_minuts;
    }

    public String getWaiting_rate() {
        return waiting_rate;
    }

    public void setWaiting_rate(String waiting_rate) {
        this.waiting_rate = waiting_rate;
    }

    public String getRide_cancelled_at() {
        return ride_cancelled_at;
    }

    public void setRide_cancelled_at(String ride_cancelled_at) {
        this.ride_cancelled_at = ride_cancelled_at;
    }

    public String getRide_complete_time() {
        return ride_complete_time;
    }

    public void setRide_complete_time(String ride_complete_time) {
        this.ride_complete_time = ride_complete_time;
    }

    public String getPartner_pickup_rate() {
        return partner_pickup_rate;
    }

    public void setPartner_pickup_rate(String partner_pickup_rate) {
        this.partner_pickup_rate = partner_pickup_rate;
    }

    public String getRate_per_kilometer() {
        return rate_per_kilometer;
    }

    public void setRate_per_kilometer(String rate_per_kilometer) {
        this.rate_per_kilometer = rate_per_kilometer;
    }

    public String getRate_per_minute() {
        return rate_per_minute;
    }

    public void setRate_per_minute(String rate_per_minute) {
        this.rate_per_minute = rate_per_minute;
    }

    public String getTax_percentage() {
        return tax_percentage;
    }

    public void setTax_percentage(String tax_percentage) {
        this.tax_percentage = tax_percentage;
    }

    public String getWaiting_price_per_minute() {
        return waiting_price_per_minute;
    }

    public void setWaiting_price_per_minute(String waiting_price_per_minute) {
        this.waiting_price_per_minute = waiting_price_per_minute;
    }

    public String getDriver_initial_distance() {
        return driver_initial_distance;
    }

    public void setDriver_initial_distance(String driver_initial_distance) {
        this.driver_initial_distance = driver_initial_distance;
    }

    public String getMin_ride_fares() {
        return min_ride_fares;
    }

    public void setMin_ride_fares(String min_ride_fares) {
        this.min_ride_fares = min_ride_fares;
    }

    public String getVehicle_type_id() {
        return vehicle_type_id;
    }

    public void setVehicle_type_id(String vehicle_type_id) {
        this.vehicle_type_id = vehicle_type_id;
    }

    public String getTemp_id() {
        return temp_id;
    }

    public void setTemp_id(String temp_id) {
        this.temp_id = temp_id;
    }

    public int getIs_skip_dropoff() {
        return is_skip_dropoff;
    }

    public void setIs_skip_dropoff(int is_skip_dropoff) {
        this.is_skip_dropoff = is_skip_dropoff;
    }

    public static Creator<CheckBookingStatusData> getCREATOR() {
        return CREATOR;
    }

    public static final Creator<CheckBookingStatusData> CREATOR = new Creator<CheckBookingStatusData>() {
        @Override
        public CheckBookingStatusData createFromParcel(Parcel in) {
            return new CheckBookingStatusData(in);
        }

        @Override
        public CheckBookingStatusData[] newArray(int size) {
            return new CheckBookingStatusData[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(booking_unique_id);
        dest.writeString(passenger_id);
        dest.writeString(booking_id);
        dest.writeString(driver_id);
        dest.writeString(pickup_latitude);
        dest.writeString(pickup_longitude);
        dest.writeString(dropoff_latitude);
        dest.writeString(dropoff_longitude);
        dest.writeString(distance_kilomiters);
        dest.writeString(estimate_minutes);
        dest.writeString(vehicle_type);
        dest.writeString(vehicle_amount);
        dest.writeString(payment_type);
        dest.writeString(oyla_wallet_pay);
        dest.writeString(driver_status);
        dest.writeString(final_amount);
        dest.writeString(status);
        dest.writeString(booking_changes);
        dest.writeString(peak_factor_rate);
        dest.writeString(waiting_minuts);
        dest.writeString(waiting_rate);
        dest.writeString(ride_cancelled_at);
        dest.writeString(ride_complete_time);
        dest.writeString(partner_pickup_rate);
        dest.writeString(rate_per_kilometer);
        dest.writeString(rate_per_minute);
        dest.writeString(tax_percentage);
        dest.writeString(waiting_price_per_minute);
        dest.writeString(driver_initial_distance);
        dest.writeString(min_ride_fares);
        dest.writeString(vehicle_type_id);
        dest.writeString(temp_id);
        dest.writeInt(is_skip_dropoff);
    }






    /* protected CheckBookingStatusData(Parcel in) {
        booking_unique_id = in.readString();
        passenger_id = in.readString();
        booking_id = in.readString();
        driver_id = in.readString();
        pickup_latitude = in.readString();
        pickup_longitude = in.readString();
        dropoff_latitude = in.readString();
        dropoff_longitude = in.readString();
        distance_kilomiters = in.readString();
        estimate_minutes = in.readString();
        vehicle_type = in.readString();
        vehicle_amount = in.readString();
        payment_type = in.readString();
        oyla_wallet_pay = in.readString();
        driver_status = in.readString();
        final_amount = in.readString();
        status = in.readString();
        booking_changes = in.readString();
        peak_factor_rate = in.readString();
        waiting_minuts = in.readString();
        waiting_rate = in.readString();
        ride_cancelled_at = in.readString();
        ride_complete_time = in.readString();
        partner_pickup_rate = in.readString();
        rate_per_kilometer = in.readString();
        rate_per_minute = in.readString();
        tax_percentage = in.readString();
        waiting_price_per_minute = in.readString();
        driver_initial_distance = in.readString();
        min_ride_fares = in.readString();
    }

    public static final Creator<CheckBookingStatusData> CREATOR = new Creator<CheckBookingStatusData>() {
        @Override
        public CheckBookingStatusData createFromParcel(Parcel in) {
            return new CheckBookingStatusData(in);
        }

        @Override
        public CheckBookingStatusData[] newArray(int size) {
            return new CheckBookingStatusData[size];
        }
    };

    public String getBooking_unique_id() {
        return booking_unique_id;
    }

    public void setBooking_unique_id(String booking_unique_id) {
        this.booking_unique_id = booking_unique_id;
    }

    public String getPassenger_id() {
        return passenger_id;
    }

    public void setPassenger_id(String passenger_id) {
        this.passenger_id = passenger_id;
    }

    public String getBooking_id() {
        return booking_id;
    }

    public void setBooking_id(String booking_id) {
        this.booking_id = booking_id;
    }

    public String getDriver_id() {
        return driver_id;
    }

    public void setDriver_id(String driver_id) {
        this.driver_id = driver_id;
    }

    public String getPickup_latitude() {
        return pickup_latitude;
    }

    public void setPickup_latitude(String pickup_latitude) {
        this.pickup_latitude = pickup_latitude;
    }

    public String getPickup_longitude() {
        return pickup_longitude;
    }

    public void setPickup_longitude(String pickup_longitude) {
        this.pickup_longitude = pickup_longitude;
    }

    public String getDropoff_latitude() {
        return dropoff_latitude;
    }

    public void setDropoff_latitude(String dropoff_latitude) {
        this.dropoff_latitude = dropoff_latitude;
    }

    public String getDropoff_longitude() {
        return dropoff_longitude;
    }

    public void setDropoff_longitude(String dropoff_longitude) {
        this.dropoff_longitude = dropoff_longitude;
    }

    public String getDistance_kilomiters() {
        return distance_kilomiters;
    }

    public void setDistance_kilomiters(String distance_kilomiters) {
        this.distance_kilomiters = distance_kilomiters;
    }

    public String getEstimate_minutes() {
        return estimate_minutes;
    }

    public void setEstimate_minutes(String estimate_minutes) {
        this.estimate_minutes = estimate_minutes;
    }

    public String getVehicle_type() {
        return vehicle_type;
    }

    public void setVehicle_type(String vehicle_type) {
        this.vehicle_type = vehicle_type;
    }

    public String getVehicle_amount() {
        return vehicle_amount;
    }

    public void setVehicle_amount(String vehicle_amount) {
        this.vehicle_amount = vehicle_amount;
    }

    public String getPayment_type() {
        return payment_type;
    }

    public void setPayment_type(String payment_type) {
        this.payment_type = payment_type;
    }

    public String getOyla_wallet_pay() {
        return oyla_wallet_pay;
    }

    public void setOyla_wallet_pay(String oyla_wallet_pay) {
        this.oyla_wallet_pay = oyla_wallet_pay;
    }

    public String getDriver_status() {
        return driver_status;
    }

    public void setDriver_status(String driver_status) {
        this.driver_status = driver_status;
    }

    public String getFinal_amount() {
        return final_amount;
    }

    public void setFinal_amount(String final_amount) {
        this.final_amount = final_amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getBooking_changes() {
        return booking_changes;
    }

    public void setBooking_changes(String booking_changes) {
        this.booking_changes = booking_changes;
    }

    public String getPeak_factor_rate() {
        return peak_factor_rate;
    }

    public void setPeak_factor_rate(String peak_factor_rate) {
        this.peak_factor_rate = peak_factor_rate;
    }

    public String getWaiting_minuts() {
        return waiting_minuts;
    }

    public void setWaiting_minuts(String waiting_minuts) {
        this.waiting_minuts = waiting_minuts;
    }

    public String getWaiting_rate() {
        return waiting_rate;
    }

    public void setWaiting_rate(String waiting_rate) {
        this.waiting_rate = waiting_rate;
    }

    public String getRide_cancelled_at() {
        return ride_cancelled_at;
    }

    public void setRide_cancelled_at(String ride_cancelled_at) {
        this.ride_cancelled_at = ride_cancelled_at;
    }

    public String getRide_complete_time() {
        return ride_complete_time;
    }

    public void setRide_complete_time(String ride_complete_time) {
        this.ride_complete_time = ride_complete_time;
    }

    public String getPartner_pickup_rate() {
        return partner_pickup_rate;
    }

    public void setPartner_pickup_rate(String partner_pickup_rate) {
        this.partner_pickup_rate = partner_pickup_rate;
    }

    public String getRate_per_kilometer() {
        return rate_per_kilometer;
    }

    public void setRate_per_kilometer(String rate_per_kilometer) {
        this.rate_per_kilometer = rate_per_kilometer;
    }

    public String getRate_per_minute() {
        return rate_per_minute;
    }

    public void setRate_per_minute(String rate_per_minute) {
        this.rate_per_minute = rate_per_minute;
    }

    public String getTax_percentage() {
        return tax_percentage;
    }

    public void setTax_percentage(String tax_percentage) {
        this.tax_percentage = tax_percentage;
    }

    public String getWaiting_price_per_minute() {
        return waiting_price_per_minute;
    }

    public void setWaiting_price_per_minute(String waiting_price_per_minute) {
        this.waiting_price_per_minute = waiting_price_per_minute;
    }

    public String getDriver_initial_distance() {
        return driver_initial_distance;
    }

    public void setDriver_initial_distance(String driver_initial_distance) {
        this.driver_initial_distance = driver_initial_distance;
    }

    public String getMin_ride_fares() {
        return min_ride_fares;
    }

    public void setMin_ride_fares(String min_ride_fares) {
        this.min_ride_fares = min_ride_fares;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(booking_unique_id);
        dest.writeString(passenger_id);
        dest.writeString(booking_id);
        dest.writeString(driver_id);
        dest.writeString(pickup_latitude);
        dest.writeString(pickup_longitude);
        dest.writeString(dropoff_latitude);
        dest.writeString(dropoff_longitude);
        dest.writeString(distance_kilomiters);
        dest.writeString(estimate_minutes);
        dest.writeString(vehicle_type);
        dest.writeString(vehicle_amount);
        dest.writeString(payment_type);
        dest.writeString(oyla_wallet_pay);
        dest.writeString(driver_status);
        dest.writeString(final_amount);
        dest.writeString(status);
        dest.writeString(booking_changes);
        dest.writeString(peak_factor_rate);
        dest.writeString(waiting_minuts);
        dest.writeString(waiting_rate);
        dest.writeString(ride_cancelled_at);
        dest.writeString(ride_complete_time);
        dest.writeString(partner_pickup_rate);
        dest.writeString(rate_per_kilometer);
        dest.writeString(rate_per_minute);
        dest.writeString(tax_percentage);
        dest.writeString(waiting_price_per_minute);
        dest.writeString(driver_initial_distance);
        dest.writeString(min_ride_fares);
    }*/
}
