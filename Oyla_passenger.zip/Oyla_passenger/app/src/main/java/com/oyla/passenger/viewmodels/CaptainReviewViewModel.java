package com.oyla.passenger.viewmodels;

import android.app.Application;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;

import com.oyla.passenger.Repository.JsonRepository;
import com.oyla.passenger.datamodels.jsonreponsedatamodel.DataModelObject;

public class CaptainReviewViewModel extends SharedViewModel{

    private MutableLiveData<DataModelObject> mutableLiveData;
    private JsonRepository repository;

    public CaptainReviewViewModel(@NonNull Application application) {
        super(application);
    }
    public void giveDriverRatingRequest(String user_id, String driver_id, String rating, String experience, String booking_id) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.giveDriverRating(user_id,driver_id,rating,experience,booking_id);
    }

    public MutableLiveData<DataModelObject>giveDriverRatingRepose() {
        return mutableLiveData;
    }
}
