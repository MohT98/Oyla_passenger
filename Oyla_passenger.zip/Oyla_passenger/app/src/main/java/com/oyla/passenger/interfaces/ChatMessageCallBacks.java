package com.oyla.passenger.interfaces;

public interface ChatMessageCallBacks {
    void newChatMessage(String message);
}
