package com.oyla.passenger.datamodels;

public class ResendOTPPostData {
    String user_id;
    String mobile_no;
    String device_id;
    String network;

    public ResendOTPPostData(String user_id, String mobile_no, String device_id, String network) {
        this.user_id = user_id;
        this.mobile_no = mobile_no;
        this.device_id = device_id;
        this.network = network;
    }
}
