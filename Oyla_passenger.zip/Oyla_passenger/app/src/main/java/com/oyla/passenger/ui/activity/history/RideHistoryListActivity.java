package com.oyla.passenger.ui.activity.history;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.oyla.passenger.R;
import com.oyla.passenger.adapter.history.RideHistoryListAdapter;
import com.oyla.passenger.databinding.ActivityRideHistoryListActivtyBinding;
import com.oyla.passenger.datamodels.historydata.RideHistoryData;
import com.oyla.passenger.datamodels.usermodel.UserData;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.SharedPrefManager;
import com.oyla.passenger.viewmodels.PayViewModel;

import java.util.List;

public class RideHistoryListActivity extends BaseActivity {
    private ActivityRideHistoryListActivtyBinding binding;
    private RideHistoryListAdapter mAdapter;
    private PayViewModel viewModel;
    //ArrayList<TransactionHistoryData> transactionItems;
    List<RideHistoryData> historyItems;
    private UserData userData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        userData = SharedPrefManager.getInstance(this).getUserInfo();
        hideAppBar(this);
        binding = setContentView(this, R.layout.activity_ride_history_list_activty);
        viewModel = new ViewModelProvider(this).get(PayViewModel.class);
        binding.onBack.setOnClickListener(v -> onBackPressed());

        // ArrayList<TransactionHistoryData> transactionItems = new ArrayList<TransactionHistoryData>();
        binding.recyclerViewTransaction.setHasFixedSize(true);
        binding.recyclerViewTransaction.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerViewTransaction.setItemAnimator(new DefaultItemAnimator());
    }

    @Override
    protected void onResume() {
        super.onResume();
        viewModel.sendRideHistoryRequest(userData.getUserId());
        startLoader();

        viewModel.receiveRideHistoryRepose().observe(this, dataModelObject -> {
            stopLoader();
            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                historyItems = dataModelObject.getData().getBookings();
                mAdapter = new RideHistoryListAdapter(this, historyItems);
                binding.recyclerViewTransaction.setAdapter(mAdapter);
                mAdapter.setOnItemClickListener(position -> {
                    Intent intent = new Intent(RideHistoryListActivity.this, RideDetailActivity.class);
                    intent.putExtra("Item", historyItems.get(position));
                    startActivity(intent);
                });
            } else {
                //showToast(this, dataModelObject.getError().getMessage());
                if(dataModelObject.getError().getMessage()!=null){
                    showToast(RideHistoryListActivity.this, dataModelObject.getError().getMessage());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                }else if(dataModelObject.getError().getMessages()!=null){
                    showToast(RideHistoryListActivity.this, dataModelObject.getError().getMessages().toString());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                }
            }
        });
    }
}