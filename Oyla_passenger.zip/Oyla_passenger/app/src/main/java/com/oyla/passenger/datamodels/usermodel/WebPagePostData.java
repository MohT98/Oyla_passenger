package com.oyla.passenger.datamodels.usermodel;

public class WebPagePostData {

    String page;
    String type;

    public WebPagePostData(String page, String type) {
        this.page = page;
        this.type = type;
    }
}
