package com.oyla.passenger.datamodels;

public class GooglePlaceModel {

    String placeName;

    public String getPlaceName() {
        return placeName;
    }

    public void setPlaceName(String placeName) {
        this.placeName = placeName;
    }

}