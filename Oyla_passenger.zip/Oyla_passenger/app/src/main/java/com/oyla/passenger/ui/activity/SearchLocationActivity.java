package com.oyla.passenger.ui.activity;

import android.location.Address;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.libraries.places.api.Places;
import com.oyla.passenger.MainApp;
import com.oyla.passenger.R;
import com.oyla.passenger.adapter.GooglePlaceAdapter;
import com.oyla.passenger.databinding.ActivitySearchLocationBinding;
import com.oyla.passenger.datamodels.GooglePlaceModel;
import com.oyla.passenger.ui.BaseActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class SearchLocationActivity extends BaseActivity {
    ArrayList<GooglePlaceModel> googlePlaceModels;
    ListView listView;
    private final String PLACES_API_BASE = "https://maps.googleapis.com/maps/api/place";
    private final String TYPE_AUTOCOMPLETE = "/autocomplete";
    private final String OUT_JSON = "/json";
    private String API_KEY;
    private String SESSION_TOKEN;
    private String city;
    private String country;
    ActivitySearchLocationBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = setContentView(this, R.layout.activity_search_location);
        API_KEY = getResources().getString(R.string.maps_api_key);
        Places.initialize(this, API_KEY);
        String uniqueId = UUID.randomUUID().toString();
        SESSION_TOKEN = "&sessiontoken=" + uniqueId;
        hideAppBar(this);
        // List<Address> addressList;
        String message = getIntent().getStringExtra("message");
        //city = getIntent().getStringExtra("city");
        //country= getIntent().getStringExtra("country");
        if (MainApp.getInstance() != null) {
            if (MainApp.getInstance().getUserLocation() != null) {
                if (MainApp.getInstance().getUserLocation().getLocation() != null) {
                    double lat = MainApp.getInstance().getUserLocation().getLocation().getLatitude();
                    double lng = MainApp.getInstance().getUserLocation().getLocation().getLongitude();
                    if(getStringAddress2(lat, lng)!=null){
                        List<Address> addresses = getStringAddress2(lat, lng);
                        if (addresses != null && addresses.get(0) != null && addresses.get(0).getLocality() != null) {
                            city = addresses.get(0).getLocality();
                        }
                        if (addresses != null && addresses.get(0) != null && addresses.get(0).getCountryName() != null) {
                            country = addresses.get(0).getCountryName();
                        }
                    }
                }
            }
        }

        if (city == null || city.isEmpty()) {
            city = "";
        }
        if (country == null || country.isEmpty()) {
            country = "";
        }
        //Log.v("CurrentAdd","CurrentAdd "+city+" -- "+country);
        // Log.v("SeesionStrurl","city "+city);
        // binding.placeSearch.setText(city+" ");
        binding.placeSearch.addTextChangedListener(filterTextWatcher);
        binding.titleMessage.setText(message);
        binding.backButton.setOnClickListener(v -> onBackPressed());
        binding.onMap.setOnClickListener(v -> onBackPressed());


        googlePlaceModels = new ArrayList<>();
        binding.listView.setOnItemClickListener((parent, view, position, id) -> {
            if (!googlePlaceModels.get(position).getPlaceName().equalsIgnoreCase("Not Found")) {
                String place = googlePlaceModels.get(position).getPlaceName();
              /*  Geocoder geocoder = new Geocoder(getApplicationContext());
                try {
                    addressList = geocoder.getFromLocationName(place, 5);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Address location = addressList.get(0);
                Log.v("SearchLocationActivity", "SearchLocationActivity " + location.getAddressLine(0) + "\n" + location.getLatitude() + "\n" + location.getLongitude());
                Toast.makeText(SearchLocationActivity.this, googlePlaceModels.get(position).getPlaceName(), Toast.LENGTH_SHORT).show();*/
                MainApp.getInstance().getSearchLocation().onLocationSelect(place);
                onBackPressed();
            }
        });

    }


    private final TextWatcher filterTextWatcher = new TextWatcher() {
        public void afterTextChanged(Editable s) {
            //if (!s.toString().equals("") ) {
            if (s.toString().length() > 2) {
                // mAutoCompleteAdapter.getFilter().filter(s.toString());
                // new GooglePlaces().execute(String.valueOf(s));
                doSomeTaskAsync(String.valueOf(s));
                //  if (recyclerView.getVisibility() == View.GONE) {recyclerView.setVisibility(View.VISIBLE);}
            } else {
                googlePlaceModels.clear();
                setAdapter();
                // if (recyclerView.getVisibility() == View.VISIBLE) {recyclerView.setVisibility(View.GONE);}
            }
        }

        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }
    };


    public void setAdapter() {
        GooglePlaceAdapter adapter = new GooglePlaceAdapter(SearchLocationActivity.this, googlePlaceModels);
        binding.listView.setAdapter(adapter);
    }

    public void doSomeTaskAsync(String s) {
        HandlerThread ht = new HandlerThread("MyHandlerThread");
        ht.start();
        Handler asyncHandler = new Handler(ht.getLooper()) {
            @Override
            public void handleMessage(@NonNull Message msg) {
                super.handleMessage(msg);
                Object response = msg.obj;
                //if (response.toString() != null || !response.toString().isEmpty()) {
                    doSomethingOnUi(response.toString());
                    //Log.v("doSomethingOnUi", "doSomethingOnUi =" + response.toString());
               // }
            }
        };
        Runnable runnable = () -> {
            // your async code goes here.
            try {
                Thread.sleep(0);
                // create message and pass any object here doesn't matter
                // for a simple example I have used a simple string
                Message message = new Message();
                try {
                    String key = "?key=" + API_KEY;
                    // components type
                    // String components="&components=country:usa";
                    String components = "&";
                    // set input type
                    /* String input = "&input=" + URLEncoder.encode(   city+" ,"+s,"utf8");*/
                    String input = "&input=" + URLEncoder.encode(country + "," + city + " ," + s, "utf8");
                    //String input = "&input=" + URLEncoder.encode(   s, "utf8");
                    String strURL = PLACES_API_BASE + TYPE_AUTOCOMPLETE + OUT_JSON + key + SESSION_TOKEN + components + input;
                    Log.v("SeesionStrurl", strURL);
                    URL url = new URL(strURL);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.connect();
                    if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        InputStreamReader inputStreamReader = new InputStreamReader(conn.getInputStream());
                        BufferedReader reader = new BufferedReader(inputStreamReader);
                        StringBuilder stringBuilder = new StringBuilder();
                        String temp;
                        while ((temp = reader.readLine()) != null) {
                            stringBuilder.append(temp);
                        }
                        message.obj = stringBuilder.toString();
                    } else {
                        message.obj = "error";
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
                asyncHandler.sendMessage(message);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        };
        asyncHandler.post(runnable);
    }

    private void doSomethingOnUi(String response) {
        Handler uiThread = new Handler(Looper.getMainLooper());
        uiThread.post(() -> {
            // now update your UI here
            // cast response to whatever you specified earlier
            googlePlaceModels.clear();
            try {
                JSONObject jsonObj = new JSONObject(response);
                JSONArray jsonArray = jsonObj.getJSONArray("predictions");
                Log.e("response", jsonObj.toString());
                if (jsonObj.getString("status").equalsIgnoreCase("OK")) {
                    for (int i = 0; i < jsonArray.length(); i++) {
                        GooglePlaceModel googlePlaceModel = new GooglePlaceModel();
                        googlePlaceModel.setPlaceName(jsonArray.getJSONObject(i).getString("description"));
                        googlePlaceModels.add(googlePlaceModel);
                    }
                } else if (jsonObj.getString("status").equalsIgnoreCase("OVER_QUERY_LIMIT")) {
                    Toast.makeText(getApplicationContext(), "You have exceeded your daily request quota for this API.", Toast.LENGTH_LONG).show();
                    GooglePlaceModel googlePlaceModel = new GooglePlaceModel();
                    googlePlaceModel.setPlaceName("Not Found");
                    googlePlaceModels.add(googlePlaceModel);
                } else {
                    GooglePlaceModel googlePlaceModel = new GooglePlaceModel();
                    googlePlaceModel.setPlaceName("Not Found");
                    googlePlaceModels.add(googlePlaceModel);
                }
                // set adapter
                setAdapter();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        });
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}