package com.oyla.passenger.viewmodels;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;

import com.oyla.passenger.Repository.JsonRepository;
import com.oyla.passenger.datamodels.jsonreponsedatamodel.DataModelObject;

public class LoginOptionViewModel extends SharedViewModel{
    public LoginOptionViewModel(@NonNull Application application) {
        super(application);
    }

    private MutableLiveData<DataModelObject> mutableLiveData;
    private JsonRepository repository;

    public void registerSocial(String type, String mobile_no, String email, String first_name, String last_name,
                               String provider, String fb_token,String referral_code) {
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.registerSocial(type, mobile_no, email, first_name, last_name, provider, fb_token,referral_code);

    }

    public MutableLiveData<DataModelObject> registerSocialRepose() {
        return mutableLiveData;
    }
}
