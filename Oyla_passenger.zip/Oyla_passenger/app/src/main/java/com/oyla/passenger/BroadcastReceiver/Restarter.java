package com.oyla.passenger.BroadcastReceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;
import android.widget.Toast;

import com.oyla.passenger.services.location.LocationService;
import com.oyla.passenger.ui.activity.dahsboard.DashBoardActivity;
import com.oyla.passenger.utilities.Constants;

public class Restarter extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Log.i("LocationService", "Service tried to stop");
      //  Toast.makeText(context, "Service restarted", Toast.LENGTH_SHORT).show();

        Intent serviceIntent = new Intent(context, LocationService.class);
        serviceIntent.setAction(Constants.ACTION_START_FOREGROUND_SERVICE);
        /* startService(serviceIntent);*/
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent);
        } else {
            context.startService(serviceIntent);
        }

       /* if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(new Intent(context, YourService.class));
        } else {
            context.startService(new Intent(context, YourService.class));
        }*/
    }
}