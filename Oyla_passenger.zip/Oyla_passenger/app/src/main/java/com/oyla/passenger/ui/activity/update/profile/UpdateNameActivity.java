package com.oyla.passenger.ui.activity.update.profile;

import android.os.Bundle;
import android.text.TextUtils;

import androidx.lifecycle.ViewModelProvider;

import com.oyla.passenger.R;
import com.oyla.passenger.databinding.ActivityUpdateNameBinding;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.utilities.Messages;
import com.oyla.passenger.viewmodels.UpdateProfileViewModel;

import java.util.Objects;

public class UpdateNameActivity extends BaseActivity {

    private ActivityUpdateNameBinding binding;
    private UpdateProfileViewModel viewModel;
    // private UserData userData;
    private int errorCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = setContentView(this, R.layout.activity_update_name);
        hideAppBar(this);
        //userData = new UserData();
        viewModel = new ViewModelProvider(this).get(UpdateProfileViewModel.class);
        binding.setViewModel(viewModel);

        binding.updateButtons.customButtonText.setText(getResources().getString(R.string.update_text));

        binding.updateButtons.button.setOnClickListener(v -> updateUserName());
        binding.backButton.setOnClickListener(v -> { onBackPressed(); });

        viewModel.getUserName().observe(this, s -> {
            if (s != null) {
                removeError(binding.userNameTextInput);
                if (TextUtils.isEmpty(s)) {
                    showError(Messages.EmptyMessage, binding.userNameTextInput, binding.userNameEditText);
                    //userData.setUserName(null);
                } else if (viewModel.validateUserName(s)) {
                    if (errorCount > 0) {
                        showError(Messages.userNameShortMessage, binding.userNameTextInput, binding.userNameEditText);
                    }
                    //userData.setUserName(s);
                } else {
                    //userData.setUserName(s);
                }
            } else {

                // userData.setUserName(null);
            }
        });
    }


    private void updateUserName() {
        errorCount = 1;
        if (Objects.requireNonNull(binding.userNameEditText.getText()).toString().trim().isEmpty()) {
            showError(Messages.EmptyMessage, binding.userNameTextInput, binding.userNameEditText);
            return;
        } else if (viewModel.validateUserName(String.valueOf(binding.userNameEditText.getText()))) {
            showError(Messages.userNameShortMessage, binding.userNameTextInput, binding.userNameEditText);
            return;
        }
        showToast(getApplicationContext(), "Proceed");

        //if (!viewModel.getUserName().toString().isEmpty())) {
        //proceed();


        //}

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

}