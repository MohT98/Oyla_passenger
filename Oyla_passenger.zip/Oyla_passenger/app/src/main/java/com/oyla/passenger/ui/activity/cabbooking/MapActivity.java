package com.oyla.passenger.ui.activity.cabbooking;

import android.Manifest;
import android.animation.LayoutTransition;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.android.gms.location.FusedLocationProviderClient;

import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.gson.Gson;
import com.google.maps.GeoApiContext;
import com.google.maps.internal.PolylineEncoding;
import com.oyla.passenger.MainApp;
import com.oyla.passenger.datamodels.GetAppVehicleData;
import com.oyla.passenger.datamodels.SearchCaptainData;
import com.oyla.passenger.datamodels.usermodel.UserData;
import com.oyla.passenger.interfaces.BookingStatusInterface;
import com.oyla.passenger.services.RideBookingStatus;
import com.oyla.passenger.services.location.LocationService;
import com.oyla.passenger.ui.activity.CaptainReviewActivity;
import com.oyla.passenger.ui.activity.SearchLocationActivity;
import com.oyla.passenger.ui.activity.SettingActivity;
import com.oyla.passenger.ui.activity.WebPageActivity;
import com.oyla.passenger.ui.activity.dahsboard.DashBoardActivity;
import com.oyla.passenger.utilities.DialogBoxSingleton;
import com.oyla.passenger.R;
import com.oyla.passenger.adapter.ridetype.SelectRideItemAdapter;
import com.oyla.passenger.databinding.ActivityMapBinding;
import com.oyla.passenger.databinding.MapLayoutBinding;
import com.oyla.passenger.datamodels.CheckBookingStatusData;
import com.oyla.passenger.datamodels.FireBaseDataModelObject;
import com.oyla.passenger.datamodels.NearestDriversData;
import com.oyla.passenger.datamodels.RideTypeData;
import com.oyla.passenger.datamodels.mapmodel.direction.DirectionResult;
import com.oyla.passenger.datamodels.jsonreponsedatamodel.DataList;
import com.oyla.passenger.interfaces.NearestDriver;
import com.oyla.passenger.interfaces.OnCaptainFind;
import com.oyla.passenger.interfaces.SearchLocation;
import com.oyla.passenger.interfaces.ServiceCallbacks;
import com.oyla.passenger.services.location.GetDriverCoordinates;
import com.oyla.passenger.services.location.NearestDriverCoordinates;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.ui.activity.history.RideHistoryListActivity;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.Messages;
import com.oyla.passenger.utilities.SharedPrefManager;
import com.oyla.passenger.viewmodels.RideViewModel;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import static com.oyla.passenger.utilities.Constants.DEFAULT_ZOOM;
import static com.oyla.passenger.utilities.Constants.MAP_VIEW_BUNDLE_KEY;
import static com.oyla.passenger.utilities.Constants.defaultLocation;
import static com.oyla.passenger.utilities.Constants.mLocationPermissionGranted;

public class MapActivity extends BaseActivity implements OnMapReadyCallback, View.OnClickListener
        , OnCaptainFind, ServiceCallbacks, SearchLocation, NearestDriver, BookingStatusInterface {

    private final String TAG = "mapsActivity";
    private Location lastKnownLocation;
    private ActivityMapBinding binding;
    private final ArrayList<LatLng> markerPoints = new ArrayList<>();
    //private final ArrayList<PolylineData> mPolylineData = new ArrayList<>();
    //private boolean isMarkerRotating = false;
    private final ArrayList<LatLng> newMarkerPoints = new ArrayList<>();
    private final ArrayList<LatLng> oldMarkerPoints = new ArrayList<>();


    //map
    private GoogleMap mGoogleMap;
    //private MarkerOptions options;
    private GeoApiContext mGeoApiContext = null;  //  this object helping us to get direction
    private FusedLocationProviderClient mFusedLocationClient;
    boolean TIME_FLAG = true;
    int calculate_Time_counter;
    private LatLng startLatLng, centerLatLng, newLatLng, oldNearDriverLatLng;
    private Boolean routeConfirm = false;
    private Boolean pickUpAddressBol = true;
    private Boolean dropOffAddressBol = false;
    private Boolean showTraffic = false;
    private Boolean typeSatellite = false;
    private MapLayoutBinding mapLayoutBinding;
    private String vehicleType, typeID;
    private SimpleDateFormat formatDate;
    String rideTime;
    boolean RIDE_VIEw_FULL = false;
    boolean SELECTED_RIDE = false;
    boolean CONFIRM_RIDE = false;
    boolean FINDING_CAPTAIN = false;
    boolean RIDE_STARTED = false;
    boolean RIDE_ACCEPTED = false;
    boolean ZOOM_ROUTE = true;
    public static boolean PICK_UP_TRACKING = false;
    private int selectedRidePosition;
    private RideViewModel viewModel;
    List<RideTypeData> appVehicles;
    List<RideTypeData> appVehicles2;
    //List<RideTypeData> allVehicles;
    private double finalDistance1;
    private Marker trackerMarker;
    private Marker rideStartMarker;
    private int finalTime;
    private boolean BOOKING_RESPONSE = false;
    private boolean PICK_UP_ADDRESS = false;
    private boolean DROP_OFF_ADDRESS = false;
    private final long START_TIME_IN_MILLIS = 150000;
    //private final long START_TIME_IN_MILLIS = 20000;
    private CountDownTimer mCountDownTimer;
    private long mTimeLeftInMillis = START_TIME_IN_MILLIS;
    private boolean mTimerRunning;
    private int progressStatus = 0;
    private DataList dataList;
    private String currentLat, currentLng;
    private String trip_one_distance, trip_two_distance, trip_total_distance;
    private String trip_one_price, trip_two_price, total_price;
    private String trip_one_duration, trip_two_duration, trip_total_time;
    /*   private String driverStatus;
       private String rideStatus;*/
    private boolean Resume_Ride_Tracking = false;
    private boolean Driver_Selected_Ride = false;
    private boolean Driver_Start_Ride = false;
    private boolean RideReceived = false;
    private boolean SHOW_FINISH_DIALOG = false;
    private String currentTripDuration = " ";
    private String currentTripTime = " ";
    private CheckBookingStatusData bookingStatusData;
    public static List<NearestDriversData> nearestDriversData;
    //private final Float oldBearing = 0f;
    boolean BEARING_FLAG = true;
    private Handler animateMarkerHandler;
    private final String rideCurrentStatusText = "Ride Info:";
    boolean isRotating = false;
    int walletSum = 0;
    Marker nearestRiderMarker = null;
    Polyline polyLine = null;
    List<LatLng> newDecodedPath;
    private Boolean SHOW_POLYLINE = true;
    private Boolean FIND_CAPTAIN_CANCEL = false;
    private Boolean AFTER_RIDE_CANCEL = false;
    private final Boolean PICK_CLICK = false;
    private final Boolean DROP_CLICK = false;
    private Boolean FIRST_VIEW = false;
    private Animation animEnter, animSlidInRight, animSlideDown, animSlideUp, animFadeIn, animMoveRight, animRestRight, animExit, animBlink;
    private double tempLat = 0;
    private double tempLng = 0;
    private LatLng diverLatLng;
    private Boolean CHANGE_ADDRESS = false;
    public static Double pickupMarkerLat = 0.0;
    public static Double pickupMarkerLng = 0.0;
    private String MAP_KEY;
    private final Handler mHandlerUI = new Handler(Looper.getMainLooper());
    private final String city = "";
    private int SKIP_DROP_OFF = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //formatDate = new SimpleDateFormat("EEE MMM dd hh:mm:ss a");

        MainApp.getInstance().setOnCaptainFind(this);
        MainApp.getInstance().setServiceCallbacks(this);
        MainApp.getInstance().setSearchLocation(this);
        MainApp.getInstance().setNearestDriver(this);
        MainApp.getInstance().setBookingStatusInterface(this);

        viewModel = new ViewModelProvider(this).get(RideViewModel.class);
        animEnter = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.animation_enter);
        animExit = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.animation_leave);
        animSlidInRight = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slide_in_right);
        animSlideDown = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slide_bottom);
        animFadeIn = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fade_in);
        animSlideUp = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slide_up);
        animMoveRight = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.move_to_right);
        animBlink = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.blink);
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        binding = setContentView(this, R.layout.activity_map);
        stopLoader();
        // startLoader();
        hideAppBar(this);
        // UserData userData = SharedPrefManager.getInstance(MapActivity.this).getUserInfo();
        //getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        initView(savedInstanceState);
        //mInterstitialAd.loadAd(new AdRequest.Builder().build());
        binding.mapLayout.emergencyIcon.setOnClickListener(v -> {
            // BaseActivity.getInstance().nextActivity(getActivity(), AddCreditActivity.class);
            binding.mapLayout.emergencyIcon.startAnimation(animBlink);
            DialogBoxSingleton.getInstance().helpLineDialog(MapActivity.this, MapActivity.this);
            //helpLineDialog();
            // Constants.phoneCall(MapActivity.this);
        });
        MAP_KEY = getString(R.string.maps_api_key);
    }

    private void initView(Bundle savedInstanceState) {
        mapLayoutBinding = binding.mapLayout;
      /*  new Handler(Looper.getMainLooper()).post(() -> {
            mapLayoutBinding.topContainerLayoutChild.startAnimation(animEnter);
            mapLayoutBinding.pickupDropOffAddressCardView.startAnimation(animEnter);
            mapLayoutBinding.pickUpMarker.startAnimation(animEnter);
            mapLayoutBinding.pickupButton.startAnimation(animEnter);
                });*/
        mapLayoutBinding.dropOffButton.setOnClickListener(this);
        mapLayoutBinding.skipButton.setOnClickListener(this);
        mapLayoutBinding.pickupButton.setOnClickListener(this);
        mapLayoutBinding.topBackButton.setOnClickListener(this);
        mapLayoutBinding.gpsButton.setOnClickListener(this);
        mapLayoutBinding.trafficButton.setOnClickListener(this);
        mapLayoutBinding.mapTypeButton.setOnClickListener(this);
        mapLayoutBinding.pickUpAddressTextLayout.setOnClickListener(this);
        mapLayoutBinding.dropOffAddressTextLayout.setOnClickListener(this);
        mapLayoutBinding.topContainerLayoutChild.setVisibility(View.GONE);
        mapLayoutBinding.pickupDropOffAddressCardView.setVisibility(View.GONE);
        mapLayoutBinding.pickUpMarker.setVisibility(View.GONE);
        mapLayoutBinding.pickupButton.setVisibility(View.GONE);

        if (MainApp.getInstance().getUserData() != null) {
            if (MainApp.getInstance().getUserData().getProfilePic() != null &&
                    !MainApp.getInstance().getUserData().getProfilePic().isEmpty()) {
                setGlideImage(getApplicationContext(), MainApp.getInstance().getUserData().getProfilePic(),
                        binding.mapNavigationLayout.userImageIcon, Constants.PROFILE_BASE_URL);
                binding.mapNavigationLayout.userNameTextView.setText(MainApp.getInstance().getUserData().getUserFirstName());
            }
        }
        initGoogleMap(savedInstanceState);
    }

    private void initGoogleMap(Bundle savedInstanceState) {
        // *** IMPORTANT ***
        // MapView requires that the Bundle you pass contain _ONLY_ MapView SDK
        // objects or sub-Bundles.
        Bundle mapViewBundle = null;
        if (savedInstanceState != null) {
            mapViewBundle = savedInstanceState.getBundle(MAP_VIEW_BUNDLE_KEY);
        }
        mapLayoutBinding.mapView.onCreate(mapViewBundle);
        mapLayoutBinding.mapView.getMapAsync(this);
        if (mGeoApiContext == null) {
            mGeoApiContext = new GeoApiContext.Builder()
                    //.apiKey(getString(R.string.maps_api_key))
                    .apiKey(MAP_KEY)
                    .build();
        }
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        Bundle mapViewBundle = outState.getBundle(MAP_VIEW_BUNDLE_KEY);
        if (mapViewBundle == null) {
            mapViewBundle = new Bundle();
            outState.putBundle(MAP_VIEW_BUNDLE_KEY, mapViewBundle);
        }
        mapLayoutBinding.mapView.onSaveInstanceState(mapViewBundle);
    }

    @Override
    public void onMapReady(final GoogleMap map) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        mGoogleMap = map;
        // mGoogleMap.setOnPolylineClickListener(this);
        mGoogleMap.getUiSettings().setMapToolbarEnabled(false);
        getDeviceLocation();
        startGetNearestDriverService();


        map.setOnCameraIdleListener(() -> {
            centerLatLng = mGoogleMap.getCameraPosition().target;

            if (!FIRST_VIEW) {
                Log.v("CameraIdle", " false FIRST_VIEW ");
                FIRST_VIEW = true;
                stopLoader();
                mapLayoutBinding.topContainerLayoutChild.setVisibility(View.VISIBLE);
                mapLayoutBinding.pickupDropOffAddressCardView.setVisibility(View.VISIBLE);
                mapLayoutBinding.pickUpMarker.setVisibility(View.VISIBLE);
                mapLayoutBinding.pickupButton.setVisibility(View.VISIBLE);
                /*new Handler(Looper.getMainLooper()).post(() -> {*/
                // mHandlerUI.post(() -> {
                mapLayoutBinding.topContainerLayoutChild.startAnimation(animEnter);
                mapLayoutBinding.pickupDropOffAddressCardView.startAnimation(animEnter);
                mapLayoutBinding.pickUpMarker.startAnimation(animEnter);
                mapLayoutBinding.pickupButton.startAnimation(animEnter);
                // });
            }
            if (centerLatLng == null) {
                return;
            }
            if (!routeConfirm) {
                Log.v("CameraIdle", " false routeConfirm ");
                // String result = getStringAddress(centerLatLng.latitude, centerLatLng.longitude).replaceAll("[-+.^:,،]", "");
                // String result = getStringAddressHandler(centerLatLng.latitude, centerLatLng.longitude).replaceAll("[-+.^:,،]", "");
                getAddressAsync(centerLatLng.latitude, centerLatLng.longitude);
                // mGoogleMap.clear();

                /*if (pickUpAddressBol) {
                    //mGoogleMap.clear();
                    if (oldNearDriverLatLng == null) {
                        oldNearDriverLatLng = centerLatLng;
                    }

                    double radCal = radiusCalculation(centerLatLng.latitude, centerLatLng.longitude, oldNearDriverLatLng.latitude, oldNearDriverLatLng.longitude);
                    if (radCal > 999) {
                        mGoogleMap.clear();
                        oldNearDriverLatLng = null;
                    }
                    mapLayoutBinding.pickupAddressText.setText(result);
                    Log.v("CameraIdle", "pickupAddress " + mapLayoutBinding.pickupAddressText.getText());
                    // mapLayoutBinding.pickupAddressText.setText(getStringAddress(centerLatLng.latitude, centerLatLng.longitude));
                    pickupMarkerLat = centerLatLng.latitude;
                    pickupMarkerLng = centerLatLng.longitude;

                } else if (dropOffAddressBol) {
                    Log.v("CameraIdle", "dropOffAddressBol ");
                    mapLayoutBinding.dropOffAddressText.setText(result);
                }*/
            }
        });
        map.setOnCameraMoveStartedListener(i -> {
            if (i == GoogleMap.OnCameraMoveStartedListener.REASON_GESTURE) {
                if (!routeConfirm) {

                    //  mapLayoutBinding.pickUpMarker.setVisibility(View.VISIBLE);
                    mapLayoutBinding.pickUpMarker.setVisibility(View.VISIBLE);
             /*       if (!firstView) {
                        // mapLayoutBinding.pickupDropoffContainer.setVisibility(View.VISIBLE);
                        if (!animFinish) {
                            //  mapLayoutBinding.pickupDropoffContainer.startAnimation(animFadeIn);
                        }

                    }*/
                }
                //Toast.makeText(getApplicationContext(), "The user gestured on the map.", Toast.LENGTH_SHORT).show();
            } /*else if (i == GoogleMap.OnCameraMoveStartedListener.REASON_API_ANIMATION) {
                 Toast.makeText(getApplicationContext(), "The user tapped something on the map.", Toast.LENGTH_SHORT).show();
            } else if (i == GoogleMap.OnCameraMoveStartedListener.REASON_DEVELOPER_ANIMATION) {
                 Toast.makeText(getApplicationContext(), "The app moved the camera.", Toast.LENGTH_SHORT).show();
            }*/
        });
       /* map.setOnCameraMoveListener(() -> {
            //  Toast.makeText(getApplicationContext(), "The camera is moving.", Toast.LENGTH_SHORT).show();
        });*/
        map.setOnCameraMoveCanceledListener(() -> {
            //Toast.makeText(getApplicationContext(), "Camera movement canceled.", Toast.LENGTH_SHORT).show();
        });
        updateLocationUI();
        Log.v("cameraZoom", "setOnCameraMoveListener: ");
        map.setOnCameraMoveListener(() -> {
            CameraPosition cameraPosition = map.getCameraPosition();
            Log.v("cameraZoom", "Zoom: " + cameraPosition.zoom);
            Constants.TRACK_ZOOM = (int) cameraPosition.zoom;
        });
        //Log.d("testinbooking", "bookingStatusData getDriver_status" + bookingStatusData.getDriver_status());
        // Log.d("testinbooking", "bookingStatusData getStatus" + bookingStatusData.getStatus());

        if (MainApp.getInstance().getDataList() != null && bookingStatusData != null && !bookingStatusData.getDriver_status().equalsIgnoreCase("3")) {
            Log.d("bookingStatusData", "bookingStatusData");
            Log.d("bookingStatusData", "bookingStatusData status" + bookingStatusData.getStatus());
            if (bookingStatusData.getStatus().equalsIgnoreCase("1") || bookingStatusData.getStatus().equalsIgnoreCase("0")) {
                RideReceived = true;
                markerPoints.add(new LatLng(
                        Double.parseDouble(bookingStatusData.getPickup_latitude()),
                        Double.parseDouble(bookingStatusData.getPickup_longitude())));

                markerPoints.add(new LatLng(
                        Double.parseDouble(bookingStatusData.getDropoff_latitude()),
                        Double.parseDouble(bookingStatusData.getDropoff_longitude())));
               /* markerPoints.add(new LatLng(
                        SharedPrefManager.getInstance(MapActivity.this).getPickLat(),
                        SharedPrefManager.getInstance(MapActivity.this).getPickLng()));

                markerPoints.add(new LatLng(
                        SharedPrefManager.getInstance(MapActivity.this).getDropLat(),
                        SharedPrefManager.getInstance(MapActivity.this).getDropLng()));*/
                MainApp.getInstance().setPerKM(Double.parseDouble(bookingStatusData.getRate_per_kilometer()));
                MainApp.getInstance().setPerMint(Double.parseDouble(bookingStatusData.getRate_per_minute()));
                MainApp.getInstance().setVehicleRate(Double.parseDouble(bookingStatusData.getVehicle_amount()));
                MainApp.getInstance().setTax_percentage(bookingStatusData.getTax_percentage());
                MainApp.getInstance().setPeak_factor_rate(bookingStatusData.getPeak_factor_rate());
                Log.v("refreshRide", "resumeRideTracking--");
                SHOW_POLYLINE = true;
                // Constants.FIRE_BASE_NOTIFY = true;
                // resumeRideTracking();
                onResume();
            }
        } else {
            SHOW_FINISH_DIALOG = false;
            RideReceived = false;
            resumeAfterTrackingView();
            SharedPreferences sharedPreferences2 = MapActivity.this.getSharedPreferences("Driver_Info", 0);
            sharedPreferences2.edit().remove("Driver_Info_Object").apply();
            SharedPrefManager.getInstance(MapActivity.this).removeBookingInfo();
        }


    }

    private boolean isGeocoderServiceRunning() {
        ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if ("com.oyla.passenger.services.location.Geocoder".equals(service.service.getClassName())) {
                Log.d("Geocoder", "Geocoder service is already running.");
                return true;
            }
        }
        Log.d("Geocoder", "Geocoder service is not running.");
        return false;
    }


    private void getDeviceLocation() {
        try {
            // if (mLocationPermissionGranted) {
            Log.d("getDeviceLocation", "mLocationPermissionGranted");
            if (MainApp.getInstance().getUserLocation() != null) {
                startLatLng = new LatLng(MainApp.getInstance().getUserLocation().getLocation().getLatitude(), MainApp.getInstance().getUserLocation().getLocation().getLongitude());
                //mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(startLatLng, DEFAULT_ZOOM));
                mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(startLatLng, DEFAULT_ZOOM));
                mLocationPermissionGranted = true;

                Log.d("getDeviceLocation", "if");
            } else {
                Log.d("getDeviceLocation", "else");
                Task<Location> locationResult = mFusedLocationClient.getLastLocation();
                locationResult.addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        // Set the map's camera position to the current location of the device.
                        Log.d("getDeviceLocation", "lastKnownLocation");
                        lastKnownLocation = task.getResult();
                        if (lastKnownLocation != null) {
                            startLatLng = new LatLng(lastKnownLocation.getLatitude(), lastKnownLocation.getLongitude());
                            /*mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(startLatLng, DEFAULT_ZOOM));*/
                            mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(startLatLng, DEFAULT_ZOOM));
                        } else {
                            Log.d("getDeviceLocation", "lastKnownLocation null");
                            //getLocation();
                            mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
                            checkLocationPermission();
                            getDeviceLocation();
                        }
                    } else {
                        Log.d("getDeviceLocation", "Current location is null. Using defaults.");
                        Log.e(TAG, "Exception: %s", task.getException());
                        mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultLocation, DEFAULT_ZOOM));
                        mGoogleMap.getUiSettings().setMyLocationButtonEnabled(false);
                    }
                });
            }
            //  }
        } catch (SecurityException e) {
            Log.e("getDeviceLocation", "Exception: %s " + e.getMessage(), e);
        }
    }

    private void updateLocationUI() {
        if (mGoogleMap == null) {
            return;
        }
        try {
            if (mLocationPermissionGranted) {
                mGoogleMap.setMyLocationEnabled(false);
                mGoogleMap.getUiSettings().setCompassEnabled(false);
                mGoogleMap.getUiSettings().setMyLocationButtonEnabled(false);
            } else {
                mGoogleMap.setMyLocationEnabled(false);
                mGoogleMap.getUiSettings().setMyLocationButtonEnabled(false);
                mGoogleMap.getUiSettings().setCompassEnabled(false);
                lastKnownLocation = null;
                //getLocationPermission();
            }
        } catch (SecurityException e) {
            Log.e("Exception: %s", Objects.requireNonNull(e.getMessage()));
        }
    }

    @Override
    public void onClick(View view) {
        //final Handler handler = new Handler(Looper.getMainLooper());
        if (view == mapLayoutBinding.pickupButton) {
            //double dis=radiusCalculation(centerLatLng.latitude,centerLatLng.longitude,31.498517474969468, 74.33426565262938);
            //  double dis=radiusCalculation(31.515036638212305, 74.34597168915896,31.577293476866394, 74.33628355019306);
            // Log.v("radiusCalculation","radiusCalculation "+dis);
          /*  if( dis>10){
                showCustomErrorToast(MapActivity.this,"No service available at this area");
                return;
            }*/
            markerPoints.clear();
            //drawCircle();
            pickUpButtonClick();

        }
        if (view == mapLayoutBinding.dropOffButton) {
            stopLoader();
            dropOffButtonClick();
            PICK_UP_TRACKING = false;
            routeConfirm = true;
        }
        if (view == mapLayoutBinding.skipButton) {
            stopLoader();
            skipDropOffButtonClick();
            SKIP_DROP_OFF = 1;
            PICK_UP_TRACKING = false;
            routeConfirm = true;
        }
        if (view == mapLayoutBinding.topBackButton) {
            onBackPressed();
        }
        if (view == mapLayoutBinding.gpsButton) {
            if (mGoogleMap != null) {
                if (startLatLng != null) {
                    if (MainApp.getInstance().getUserLocation() != null) {
                        startLatLng = new LatLng(MainApp.getInstance().getUserLocation().getLocation().getLatitude(), MainApp.getInstance().getUserLocation().getLocation().getLongitude());
                        mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(startLatLng, DEFAULT_ZOOM));
                    }
                }
            }

        }
        if (view == mapLayoutBinding.trafficButton) {
            if (mGoogleMap != null) {
                if (showTraffic) {
                    showTraffic = false;
                    mGoogleMap.setTrafficEnabled(false);
                    mapLayoutBinding.trafficButton.setBackground(ContextCompat.getDrawable(this, R.drawable.signal));
                } else {
                    mGoogleMap.setTrafficEnabled(true);
                    mapLayoutBinding.trafficButton.setBackground(ContextCompat.getDrawable(this, R.drawable.signal_click));
                    showTraffic = true;
                }
            }

        }
        if (view == mapLayoutBinding.mapTypeButton) {
            if (mGoogleMap != null) {
                if (typeSatellite) {
                    typeSatellite = false;
                    mGoogleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                    mapLayoutBinding.mapTypeButton.setBackground(ContextCompat.getDrawable(this, R.drawable.world));
                } else {
                    mGoogleMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
                    mapLayoutBinding.mapTypeButton.setBackground(ContextCompat.getDrawable(this, R.drawable.world_click));
                    typeSatellite = true;
                }
            }
        }
        if (view == mapLayoutBinding.pickUpAddressTextLayout) {
           /* List<Address> addresses = getStringAddress2(centerLatLng.latitude, centerLatLng.longitude);
            if (addresses.get(0).getLocality() != null) {
                city = addresses.get(0).getLocality();
            } else {
                city = " ";
            }*/


            if (markerPoints != null) {
                if (markerPoints.size() == 0) {
                    if (!routeConfirm) {
                        Intent i = new Intent(MapActivity.this, SearchLocationActivity.class);
                        i.putExtra("message", getResources().getString(R.string.pickup_message));
                       /* i.putExtra("city", city);
                        i.putExtra("country", addresses.get(0).getCountryName());*/
                        i.putExtra("city", "");
                        i.putExtra("country", "Pakistan");

                        PICK_UP_ADDRESS = true;
                        DROP_OFF_ADDRESS = false;
                        startActivity(i);
                    }
                }
            }
        }
        if (view == mapLayoutBinding.dropOffAddressTextLayout) {
            //List<Address> addresses = getStringAddress2(centerLatLng.latitude, centerLatLng.longitude);
            /*  if (addresses.get(0).getLocality() != null) {*/
            /*if (addresses!=null && addresses.get(0)!=null  && addresses.get(0).getLocality() != null) {
                city = addresses.get(0).getLocality();
            } else {
                city = " ";
            }*/
            if (!routeConfirm) {
                Intent i = new Intent(MapActivity.this, SearchLocationActivity.class);
                i.putExtra("message", getResources().getString(R.string.drop_off_message));
                /* i.putExtra("city", city);*/
                i.putExtra("city", "");
                /* i.putExtra("country", addresses.get(0).getCountryName());*/
                i.putExtra("country", "Pakistan");
                PICK_UP_ADDRESS = false;
                DROP_OFF_ADDRESS = true;
                startActivity(i);
            }
        }
    }

    private void calculateDirectionsURL(List<LatLng> latLngList) {
        Log.d("calculateDirectionsURL", "calculateDirectionsURL");
        String origin = latLngList.get(0).latitude + "," + latLngList.get(0).longitude;
        String dest = latLngList.get(1).latitude + "," + latLngList.get(1).longitude;
        Log.d("calculateDirectionsURL", "origin " + origin);
        Log.d("calculateDirectionsURL", "dest " + dest);
        Log.d("pointRoute", "origin " + origin);
        Log.d("pointRoute", "dest " + dest);
        viewModel.directionResultRequest(origin, dest, "false", "driving", MAP_KEY);
        startLoader();
        viewModel.directionResultRepose().observe(this, directionResult -> {
            //stopLoader();
            //Log.d("calculateDirectionsURL", "directionResultRepose");
            //Log.d("calculateDirectionsURL", "dataModelObject "+dataModelObject .toString());
            stopLoader();
            if (directionResult.getRoutes() != null && directionResult.getRoutes().size() > 0) {
                currentTripDuration = String.valueOf(directionResult.getRoutes().get(0).getLegs().get(0).getDistance().getText());
                currentTripTime = String.valueOf(directionResult.getRoutes().get(0).getLegs().get(0).getDuration().getText());
                //currentTripDuration = String.valueOf(result.routes[0].legs[0].duration);
                // currentTripTime = String.valueOf(result.routes[0].legs[0].distance);
                Log.d("calculateDirectionsURL", "if");
                Log.d("calculateDirectionsURL", "currentTripTime " + currentTripTime);
                Log.d("calculateDirectionsURL", "currentTripDuration " + currentTripDuration);
                addPolyLinesToMap2(directionResult, currentTripTime, currentTripDuration);
                //drawPolyLineOnMap(directionResult.getRoutes().get(0).getLegs());
            } else {
                onBackPressed();
                showToast(MapActivity.this, "Currently NO Partner Available ");
                Log.d("calculateDirectionsURL", "else");
            }
        });
    }

    private void addPolyLinesToMap2(DirectionResult result, String time, String dist) {
         /* if (polyLine != null) {
              polyLine.remove();
          }*/
        Log.d("calculateDirectionsURL", "addPolyLinesToMap2");
        if (result != null) {
            if (result.getRoutes() != null) {
                if (!result.getRoutes().isEmpty()) {
                    if (result.getRoutes().get(0).getLegs() != null) {
                        if (!result.getRoutes().get(0).getLegs().isEmpty()) {
                            if (result.getRoutes().get(0).getLegs().get(0).getSteps() != null) {
                                if (!result.getRoutes().get(0).getLegs().get(0).getSteps().isEmpty()) {
                                    new Handler(Looper.getMainLooper()).post(() -> {
                                        if (newDecodedPath != null) {
                                            newDecodedPath.clear();
                                        }
                                        for (int s = 0; s < result.getRoutes().get(0).getLegs().get(0).getSteps().size(); s++) {
                                            //List<com.google.maps.model.LatLng> decodedPath = PolylineEncoding.decode(result.getRoutes().get(0).getLegs().get(0).getSteps().get(s).getPolyline().getPoints());
                                            List<com.google.maps.model.LatLng> decodedPath = PolylineEncoding.decode(result.getRoutes().get(0).getOverviewPolyLine().getPoints());
                                            Log.d("calculateDirectionsURL", "getOverviewPolyLine " + result.getRoutes().get(0).getOverviewPolyLine().getPoints());
                                            newDecodedPath = new ArrayList<>();
                                            //    Log.i("wayPoints", "rpute:--->>>>>"+OylaApplicationSingleton.getInstance().wayPointString);
                                            for (com.google.maps.model.LatLng latLng : decodedPath) {
                                                newDecodedPath.add(new LatLng(latLng.lat, latLng.lng));
                                            }
                                            if (polyLine != null) {
                                                polyLine.remove();
                                            }
                                            polyLine = mGoogleMap.addPolyline(new PolylineOptions().addAll(newDecodedPath));
                                            polyLine.setColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                                            //polyLine.setClickable(false);
                                            //  mPolylineData.add(new PolylineData(polyLine, route.legs[0]));
                                        }
                                        polylineMarker(polyLine, time, dist);
                                        // onPolylineClick(polyLine)
                                        if (ZOOM_ROUTE) {
                                            zoomRoute(polyLine.getPoints());
                                        }
                                        Log.d("calculateDirectionsURL", "newDecodedPath " + newDecodedPath);
                                    });
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    @SuppressLint("SimpleDateFormat")
    public void polylineMarker(Polyline polyline, String time, String dist) {
        // mGoogleMap.clear();
        Log.d("calculateDirectionsURL", "onPolylineClick ");
        Log.d("calculateDirectionsURL", "onPolylineClick time " + time);
        Log.d("calculateDirectionsURL", "onPolylineClick dist " + dist);
        formatDate = new SimpleDateFormat("hh:mm:ss a");
        // for (PolylineData polylineData : mPolylineData) {
        LatLng startLocation = new LatLng(polyline.getPoints().get(0).latitude, polyline.getPoints().get(0).longitude);
        Log.d("calculateDirectionsURL", "startLocation " + startLocation.latitude + "," + startLocation.longitude);
        //  Log.v("onPolylineClick", "startLocation.latitude" + startLocation.latitude);
        //  Log.v("onPolylineClick", "startLocation.longitude " + startLocation.longitude);
        LatLng endLocation = new LatLng(polyline.getPoints().get(polyline.getPoints().size() - 1).latitude, polyline.getPoints().get(polyline.getPoints().size() - 1).longitude);
        Log.d("calculateDirectionsURL", "endLocation " + endLocation.latitude + "," + endLocation.longitude);
        //Log.v("onPolylineClick", "endLocation.latitude" + endLocation.latitude);
        //  Log.v("onPolylineClick", "endLocation.longitude " + endLocation.longitude);
        // String duration = String.valueOf(polylineData.getLeg().duration);
        String duration = time;
        Log.v("calculateDirectionsURL", "old duration  " + duration);
        String addHours = "0";
        String addMinutes = "0";
        boolean HOUR = false;
        if (duration.contains("hours")) {
            duration = duration.replace("hours", ":");
            HOUR = true;
        } else if (duration.contains("hour")) {
            duration = duration.replace("hour", ":");
            HOUR = true;
        }
        if (duration.contains("mins")) {
            duration = duration.replace("mins", "");
            addMinutes = duration;
        }
        if (HOUR) {
            String[] splitTime = duration.split(":");
            addHours = splitTime[0].trim();
            addMinutes = splitTime[1].trim();
        }
        //float bearing = (float) bearingBetweenLocations(startLocation, endLocation);
        //float bearing = bearingBetweenLatLngs(startLocation, endLocation);
        float bearing = 0;
        Log.v("calculateDirectionsURL", "RIDE_STARTED " + RIDE_STARTED);
        Log.v("calculateDirectionsURL", "RIDE_ACCEPTED " + RIDE_ACCEPTED);
        //rideStartMarker
        if (RIDE_ACCEPTED) {
                   /* if (rideStartMarker != null) {
                        rideStartMarker.remove();
                    }*/
            if (rideStartMarker == null) {
                rideStartMarker = mGoogleMap.addMarker(new MarkerOptions()
                                .position(endLocation)
                                //.title("Trip #" + index)
                                //.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN))
                                .icon(BitmapDescriptorFactory.fromBitmap(createLayoutCustomMarker(MapActivity.this, R.drawable.pickup_icon, " ", true)))
                        //.snippet("Trip Duration: " + polylineData.getLeg().duration)
                );
            } else {
                rideStartMarker.setPosition(new LatLng(endLocation.latitude, endLocation.longitude));
            }
        } else if (RIDE_STARTED) {
            /*if (rideStartMarker != null) {
                rideStartMarker.remove();
            }*/
            if (rideStartMarker == null) {
                rideStartMarker = mGoogleMap.addMarker(new MarkerOptions()
                                .position(endLocation)
                                //.title("Trip #" + index)
                                //.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN))
                                .icon(BitmapDescriptorFactory.fromBitmap(createLayoutCustomMarker(MapActivity.this, R.drawable.drop_off_icon, " ", true)))
                        //.snippet("Trip Duration: " + polylineData.getLeg().duration)
                );
            } else {
                rideStartMarker.setPosition(new LatLng(endLocation.latitude, endLocation.longitude));
            }
        } else {
            Marker markerStart = mGoogleMap.addMarker(new MarkerOptions()
                            .position(startLocation)
                            //.title("Trip #" + index)
                            //.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN))
                            .icon(BitmapDescriptorFactory.fromBitmap(createLayoutCustomMarker(MapActivity.this, R.drawable.pickup_icon, " ", true)))
                    //.snippet("Trip Duration: " + polylineData.getLeg().duration)
            );
            markerStart.showInfoWindow();
        }
                /*Log.v("selectRideType", "addHours  " + addHours);
                Log.v("selectRideType", "addMinutes  " + addMinutes);*/
        // selectRideType(Integer.valueOf( addMinutes),Integer.valueOf( addHours),Integer.valueOf(String.valueOf(polylineData.getLeg().distance)));

        if (PICK_UP_TRACKING) {
                   /* if (trackerMarker != null) {
                        trackerMarker.remove();
                    }*/
                   /* if(MainApp.getInstance().getDriverCoordinate().getBearing()!=null){
                        bearing=Float.parseFloat(MainApp.getInstance().getDriverCoordinate().getBearing());
                    }*/
            //bearing= Float.parseFloat(MainApp.getInstance().getDriverCoordinate().getBearing());
            Log.v("GetDriverCoordinates", " tracking : " + MainApp.getInstance().getBearing());
            bearing = MainApp.getInstance().getBearing();
            // trackerMarker = mGoogleMap.addMarker(new MarkerOptions());
            Log.v("trackerMarker", " startLatLng.latitude : " + startLocation.latitude);
            Log.v("trackerMarker", " startLatLng.longitude : " + startLocation.longitude);
            Log.v("trackerMarker", "-------------- ");
            if (trackerMarker == null) {
                trackerMarker = mGoogleMap.addMarker(new MarkerOptions()
                                .position(startLocation)
                                .anchor(0.5f, 0.5f)
                                .flat(true)
                                .rotation(bearing)
                        //.icon(bitmapDescriptorFromVector(getResources().getDrawable(R.drawable.page_10_car_vertical, null)))
                );
                if (typeID.equalsIgnoreCase("9")) {
                    trackerMarker.setIcon(bitmapDescriptorFromVector(getResources().getDrawable(R.drawable.richshaw, null)));
                } else if (typeID.equalsIgnoreCase("10")) {
                    trackerMarker.setIcon(bitmapDescriptorFromVector(getResources().getDrawable(R.drawable.bike_map, null)));
                } else {
                    trackerMarker.setIcon(bitmapDescriptorFromVector(getResources().getDrawable(R.drawable.aerial_car, null)));
                }
            } else {
                // bearing=MainApp.getInstance().getUserLocation().getLocation().getBearing();
                // Log.v("LocationService", " trackerMarker bearing : " + bearing);
                rotateMarker(trackerMarker, bearing);
                animateMarkerTo(trackerMarker, startLocation.latitude, startLocation.longitude);
                //updateCamera(bearing,endLocation.latitude, endLocation.longitude);
            }
            mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(startLocation, Constants.TRACK_ZOOM));
            //  animateMarkerTo(trackerMarker,endLocation.latitude,endLocation.longitude,bearing);
            //mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(endLocation, DEFAULT_ZOOM));
            //  rotateMarker(rideStartMarker,bearing);
                  /*  mGoogleMap.addMarker(new MarkerOptions()
                            .position(endLocation)
                            .icon(bitmapDescriptorFromVector(getResources().getDrawable(R.drawable.page_10_car_vertical, null)))
                            //.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED))
                            .title("My Location"));*/
        } else {
            //selectRideType(addMinutes, addHours, (String.valueOf(polylineData.getLeg().distance)));

            selectRideType(addMinutes, addHours, dist);
            Marker markerEnd = mGoogleMap.addMarker(new MarkerOptions()
                            .position(endLocation)
                            //.title("Trip #" + index)
                            //.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN))
                            .icon(BitmapDescriptorFactory.fromBitmap(createLayoutCustomMarker(MapActivity.this, R.drawable.button_white, arrivalTime(Integer.parseInt(addHours.trim()), Integer.parseInt(addMinutes.trim())), false)))
                    // .snippet("Trip Duration: " + polylineData.getLeg().duration)
            );
            markerEnd.showInfoWindow();
        }
        if (Resume_Ride_Tracking) {
            Resume_Ride_Tracking = false;
            stopLoader();
        }
        if (RideReceived) {
            captainInfoScreen();
            captainInfoSlider();
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private void selectRideType(String durationMint, String durationHour, String distance) {
        //Log.v("calculateDirectionsURL", "durationMint " + durationMint);
        // Log.v("calculateDirectionsURL", "durationHour " + durationHour);
        // Log.v("calculateDirectionsURL", "distance " + distance);
        //String duration = String.valueOf(polylineData.getLeg().duration);
        // Log.v("selectRideType", "durationMint" + durationMint);
        // Log.v("selectRideType", "durationHour" + durationHour);
        //  Log.v("selectRideType", "distance  " + distance);
        double finalDistance = 0;
        if (distance.contains("km")) {
            distance = distance.replace("km", "");
            distance = distance.replace(" ", "");
            if (distance.contains(",")) {
                distance = distance.replace(",", "");
            }
            finalDistance = Double.parseDouble(distance);
        }
        Log.v("selectRideType", "finalDistance  " + finalDistance);
        durationMint = durationMint.replace(" ", "");
        durationHour = durationHour.replace(" ", "");
        // int finalTotalMint =Integer.valueOf(durationMint);
        int finalTotalHour = Integer.parseInt(durationHour);
        finalTotalHour = finalTotalHour * 60;
        finalTime = Integer.parseInt(durationMint) + finalTotalHour;
        Log.v("selectRideType", "finalTime  " + finalTime);
        finalDistance1 = finalDistance;
        String uid = "";
        Constants.Auth = Constants.Bearer + " " + SharedPrefManager.getInstance(getApplicationContext()).getUserInfo().getAccessToken();
        /*if (MainApp.getInstance().getUserData().getUserId() != null) {
            uid = MainApp.getInstance().getUserData().getUserId();
        }*/
        if (markerPoints.size() > 1) {
            GetAppVehicleData getAppVehicleData;
            if (SKIP_DROP_OFF == 1) {
                getAppVehicleData = new GetAppVehicleData(uid, String.valueOf(markerPoints.get(0).latitude), String.valueOf(markerPoints.get(0).longitude)
                        , city, String.valueOf(markerPoints.get(0).latitude), String.valueOf(markerPoints.get(0).longitude));
            } else {
                getAppVehicleData = new GetAppVehicleData(uid, String.valueOf(markerPoints.get(0).latitude), String.valueOf(markerPoints.get(0).longitude)
                        , city, String.valueOf(markerPoints.get(1).latitude), String.valueOf(markerPoints.get(1).longitude));
            }
           /* GetAppVehicleData getAppVehicleData = new GetAppVehicleData(uid, String.valueOf(markerPoints.get(0).latitude), String.valueOf(markerPoints.get(0).longitude)
                    , city, String.valueOf(markerPoints.get(1).latitude), String.valueOf(markerPoints.get(1).longitude));*/
            viewModel.sendRideTypeRequest(getAppVehicleData);
           /* viewModel.sendRideTypeRequest(uid, String.valueOf(markerPoints.get(0).latitude), String.valueOf(markerPoints.get(0).longitude)
                    , city,String.valueOf(markerPoints.get(1).latitude), String.valueOf(markerPoints.get(1).longitude));*/
        }
        if (!(MapActivity.this).isFinishing()) {
            startLoader();
            //show dialog
        }
        if (viewModel != null) {
            viewModel.receiveRideTypeRepose().observe(this, dataModelObject -> {
                //   stopLoader();
                if (dataModelObject != null && dataModelObject.getStatus() != null && dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                /*if (allVehicles != null) {
                    allVehicles.clear();
                }*/
                    if (appVehicles != null) {
                        appVehicles.clear();
                    }
                    appVehicles = dataModelObject.getData().getAppVehicles();
                    if (appVehicles == null || appVehicles.size() == 0) {
                        stopLoader();
                        onBackPressed();
                        showToast(MapActivity.this, "Currently NO Partner Available ");
                        return;
                    }
                    // Log.v(" appVehicles.size()", " appVehicles.size()" + appVehicles.size());
                    // Log.v(" calculateDirectionsURL", " appVehicles.size()" + appVehicles.size());
                    //appVehicles.size()
                    //allVehicles = dataModelObject.getData().getAppVehicles();
                    // calculateEstTimeURL(finalTime, finalDistance1);
                    //  if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    //calculateEstTime(finalTime, finalDistance1);
                    if (vehicleType == null) {
                        return;
                    }
                    if (vehicleType.equalsIgnoreCase("bike")) {
                        Collections.sort(appVehicles, (o1, o2) -> o1.getVehicleType().compareTo(vehicleType));
                        // Collections.reverse(appVehicles);
                    }
                    setVehicleListAdapter(finalTime, finalDistance1);

                    //estimate calcilation on mobile end
                    // appVehicles2 = new ArrayList<>();
                    //  calculateEstTimeURL2(finalTime, finalDistance1, 0);


                    // startLoader();
                    /*} else {
                        showToast(MapActivity.this, "This Application not support for this Mobile version");
                        stopLoader();
                        onBackPressed();
                    }*/
                } else {
                    stopLoader();
                    onBackPressed();
                    if (dataModelObject != null && dataModelObject.getError() != null) {
                        if (dataModelObject.getError().getMessage() != null) {
                            showToast(MapActivity.this, dataModelObject.getError().getMessage());
                            Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                        } else if (dataModelObject.getError().getMessages() != null) {
                            showToast(MapActivity.this, dataModelObject.getError().getMessages().toString());
                            Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                        }
                    } else {
                        showErrorToast("Server not responding ! Try Again");
                    }

                }
            });
        }
        // finalTotalMint = 10;
        binding.rideTypeLayout.rideType2.startAnimation(animEnter);
        binding.rideTypeLayout.selectRideHeading.startAnimation(animEnter);
        binding.rideTypeLayout.selectRide.startAnimation(animEnter);
        binding.rideTypeLayout.selectRide.setOnClickListener(v -> {
            if (binding.rideTypeLayout.selectRide.getText().toString().equalsIgnoreCase(getResources().getString(R.string.select_ride))) {
                showToast(MapActivity.this, "Select Ride First");
                return;
            }

            SELECTED_RIDE = true;
            binding.rideTypeLayout.rideType2.startAnimation(animExit);
            stopLoader();
            final Handler handler = new Handler(Looper.getMainLooper());
            handler.postDelayed(() -> {
                binding.rideTypeLayout.rideType.setVisibility(View.GONE);
                mapLayoutBinding.pickupDropOffAddressCardView.setVisibility(View.VISIBLE);
                mapLayoutBinding.mapExtraButton.setVisibility(View.GONE);
                contractView();
                Constants.PROMO_ACTIVATE = false;
                confirmRide();
              // snapShot();
            }, 700);
        });
        // mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(startLatLng, 13));
      /*  binding.rideTypeLayout.scrollLayout.setOnScrollChangeListener((NestedScrollView.OnScrollChangeListener) (v, scrollX, scrollY, oldScrollX, oldScrollY) -> {
            Log.i("scrollLayout", "scrollY "+scrollY);
            if (scrollY == 0) {
                Log.i("scrollLayout", "TOP SCROLL");
               // contractView();
                RIDE_VIEw_FULL = false;
            } else {
                Log.i("scrollLayout", "else");
                expandView();
                RIDE_VIEw_FULL = true;
            }
        });*/
        binding.rideTypeLayout.topLayout.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    Log.i("scrollLayout", "ACTION_DOWN");
                    break;
                case MotionEvent.ACTION_MOVE:
                    Log.i("scrollLayout", "ACTION_MOVE");
                    break;
                case MotionEvent.ACTION_UP:
                    Log.i("scrollLayout", "ACTION_UP");
                    Log.i("scrollLayout", "RIDE_VIEw_FULL " + RIDE_VIEw_FULL);
                    if (RIDE_VIEw_FULL) {
                        contractView();
                        RIDE_VIEw_FULL = false;
                    } else {
                        RIDE_VIEw_FULL = true;
                        expandView();
                    }
                    break;
                default:
                    return false;
            }
            return true;
        });

        /*binding.recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                scrolledDistance = dy;
                if (scrolledDistance > HIDE_THRESHOLD && controlsVisible) {
                    // hideViews();
                    RelativeLayout.LayoutParams layout_description = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT , RelativeLayout.LayoutParams.MATCH_PARENT );
                    ((ViewGroup) binding.rideType2).getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
                    // controlsVisible = true;
                    binding.rideType2.setLayoutParams(layout_description);
                    controlsVisible = false;
                } else if (scrolledDistance < -HIDE_THRESHOLD && !controlsVisible) {
                    // showViews();
                    controlsVisible = true;

                    Log.v("scrolledDistance","scrolledDistance "+scrolledDistance);
                    if(scrolledDistance<-30){
                        RelativeLayout.LayoutParams layout_description = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT ,
                                800 );
                        layout_description.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
                        ((ViewGroup) binding.rideType2).getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
                        binding.rideType2.setLayoutParams(layout_description);
                    }
                    Log.v("scrolledDistance","dy "+dy);

                }

            }
        });*/

    }

    @SuppressLint("SetTextI18n")
    private void confirmRide() {
        Log.v("confirmRide", " confirmRide ");
        SharedPrefManager.getInstance(MapActivity.this).setCash(true);
        changeConfirmRideLayoutComponent();
        binding.confirmRideLayout.confirmRide.setVisibility(View.VISIBLE);
        binding.confirmRideLayout.rideTypeText.setText(appVehicles.get(selectedRidePosition).getCarType());
        binding.confirmRideLayout.rideTypePrice.setText(getResources().getString(R.string.currency_text) + " " + appVehicles.get(selectedRidePosition).getFair());
        /* binding.confirmRideLayout.carIcon.setImageResource(appVehicles.get(selectedRidePosition).getIcon());*/
        //binding.confirmRideLayout.carIcon.setImageResource(appVehicles.get(selectedRidePosition).getIcon());

        setGlideImage(MapActivity.this,
                appVehicles.get(selectedRidePosition).getImage_url(),
                binding.confirmRideLayout.carIcon, Constants.ASSETS_BASE_URL);

        binding.confirmRideLayout.reSelectRideLayout.setOnClickListener(v -> {
            binding.confirmRideLayout.confirmRide.setVisibility(View.GONE);
            onBackPressed();
        });
        binding.confirmRideLayout.cashOptionLayout.setOnClickListener(v -> cashOptionDialog());
        binding.confirmRideLayout.discountLayout.setOnClickListener(v -> discountDialog());
        binding.confirmRideLayout.confirmRideButton.setOnClickListener(v -> {
            binding.confirmRideLayout.confirmRide.setVisibility(View.GONE);
            mapLayoutBinding.pickupDropOffAddressCardView.setVisibility(View.GONE);
            /*new Handler(Looper.getMainLooper()).post(() -> findCaptain());*/
            mHandlerUI.post(this::findCaptain);
        });
        //Log.v("confirmRide", "getOylaPay " + SharedPrefManager.getInstance(MapActivity.this).getOylaPay());
        if (SharedPrefManager.getInstance(MapActivity.this) != null) {
            if (SharedPrefManager.getInstance(MapActivity.this).getOylaPay()) {
                int fareAmount = Integer.parseInt(appVehicles.get(selectedRidePosition).getFair());
                walletSum = fareAmount - Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(Constants.WALLET_AMOUNT))));
                if (walletSum <= 0) {
                    binding.confirmRideLayout.payMethodCard.setText(getString(R.string.wallet_text));
                    binding.confirmRideLayout.rideTypePrice.setText(getResources().getString(R.string.currency_text) + " 0");
                } else {
                    binding.confirmRideLayout.payMethodCard.setText(getString(R.string.cash_plus_wallet));
                    binding.confirmRideLayout.rideTypePrice.setText(getResources().getString(R.string.currency_text) + " " + walletSum);
                }
                if (Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(Constants.WALLET_AMOUNT)))) == 0) {
                    SharedPrefManager.getInstance(MapActivity.this).setOylaPay(false);
                    binding.confirmRideLayout.payMethodCard.setText(getString(R.string.cash_text));
                    binding.confirmRideLayout.rideTypePrice.setText(getResources().getString(R.string.currency_text) + " " + appVehicles.get(selectedRidePosition).getFair());
                }
            } else {
                binding.confirmRideLayout.payMethodCard.setText(getString(R.string.cash_text));
                binding.confirmRideLayout.rideTypePrice.setText(getResources().getString(R.string.currency_text) + " " + appVehicles.get(selectedRidePosition).getFair());
            }
        }
    }

    private void findCaptain() {
        String paymentType, routeFare;
        int walletAmountSum = 0;
        if (SKIP_DROP_OFF == 1) {
            binding.findCaptainLayout.dropOffAddressTextLayout.setVisibility(View.GONE);
            binding.findCaptainLayout.dropOffSideImage.setVisibility(View.GONE);
        } else {
            binding.findCaptainLayout.dropOffAddressTextLayout.setVisibility(View.VISIBLE);
            binding.findCaptainLayout.dropOffSideImage.setVisibility(View.VISIBLE);
        }
        //  if(SKIP_DROP_OFF==0){
        walletAmountSum = Integer.parseInt(appVehicles.get(selectedRidePosition).getFair()) - Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(Constants.WALLET_AMOUNT))));
        // }
        Log.v("OYLA_CHECK", "walletAmountSum  " + walletAmountSum);
        routeFare = appVehicles.get(selectedRidePosition).getFair();
        Log.v("OYLA_CHECK", "routeFare  " + routeFare);
        if (markerPoints == null || markerPoints.size() == 0 || markerPoints.size() == 1) {
            return;
        }
        binding.findCaptainLayout.pickupAddressText.setText(getStringAddress(markerPoints.get(0).latitude, markerPoints.get(0).longitude));
        binding.findCaptainLayout.dropOffAddressText.setText(getStringAddress(markerPoints.get(1).latitude, markerPoints.get(1).longitude));
        binding.findCaptainLayout.vehicleSideImage.setImageResource(appVehicles.get(selectedRidePosition).getIcon());
        binding.findCaptainLayout.carTypeText.setText(appVehicles.get(selectedRidePosition).getCarType());
        binding.findCaptainLayout.mainLayout.setVisibility(View.VISIBLE);
        setGlideImage(MapActivity.this,
                appVehicles.get(selectedRidePosition).getImage_url(),
                binding.findCaptainLayout.vehicleSideImage,
                Constants.ASSETS_BASE_URL);
        CONFIRM_RIDE = true;
        FINDING_CAPTAIN = true;
        RideReceived = false;
        Log.v("OYLA_CHECK", "routeFare  " + routeFare);
        binding.findCaptainLayout.cancelRideText.setOnClickListener(v -> {
            FIND_CAPTAIN_CANCEL = true;
            // findCaptainCancelFlagReset();
            cancelReasonDialog(MainApp.getInstance().getUserData().getUserId(), "");
        });
        binding.findCaptainLayout.cancelImage.setOnClickListener(v -> {
            FIND_CAPTAIN_CANCEL = true;
            // findCaptainCancelFlagReset();
            cancelReasonDialog(MainApp.getInstance().getUserData().getUserId(), "");
        });
        Log.v("getDistance", "getDistance  " + finalDistance1);
        boolean OYLA_CHECK = false;
        String OYLA_VALUE = "0";
        if (SharedPrefManager.getInstance(MapActivity.this) != null) {
            OYLA_CHECK = SharedPrefManager.getInstance(MapActivity.this).getOylaPay();
        }
        if (OYLA_CHECK) {
            OYLA_VALUE = "1";
        }
        if (Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(Constants.WALLET_AMOUNT)))) < 0) {
            OYLA_VALUE = "3";
        }
        if (walletAmountSum <= 0) {
            paymentType = "wallet";
        } else {
            if (OYLA_VALUE.equalsIgnoreCase("1")) {
                paymentType = "cash + wallet";
            } else {
                paymentType = "cash";
            }
        }
        if (OYLA_VALUE.equalsIgnoreCase("0")) {
            paymentType = "cash";
        }
        if (Constants.PROMO_ACTIVATE) {
            OYLA_VALUE = "2";
            paymentType = "wallet";
        }
        if (OYLA_VALUE.equalsIgnoreCase("3")) {
            routeFare = String.valueOf(Integer.parseInt(appVehicles.get(selectedRidePosition).getFair()) + Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(Constants.WALLET_AMOUNT)))));
            paymentType = "cash";
        }
        // Log.v("OYLA_CHECK", "Constants.PROMO_ACTIVATE  " + Constants.PROMO_ACTIVATE);
        // Log.v("OYLA_CHECK", "OYLA_VALUE  " + OYLA_VALUE);
        //  Log.v("OYLA_CHECK", "OYLA_CHECK  " + OYLA_CHECK);
        //  Log.v("OYLA_CHECK", "routeFare  " + routeFare);
        //  Log.v("OYLA_CHECK", "paymentType  " + paymentType);
        binding.findCaptainLayout.paymentMethodText.setText(paymentType);
        String fcm_token;
        if (MainApp.getInstance().getFireBaseToken() != null) {
            fcm_token = MainApp.getInstance().getFireBaseToken();
        } else {
            fcm_token = " ";
        }

        if (!(MapActivity.this).isFinishing()) {
            startLoader();
        }
        Constants.Auth = Constants.Bearer + " " + SharedPrefManager.getInstance(getApplicationContext()).getUserInfo().getAccessToken();

        /*calculate fare data on mobile side*/

       /* SearchCaptainData searchCaptainData = new SearchCaptainData(
                appVehicles.get(selectedRidePosition).getId(), MainApp.getInstance().getUserData().getUserId(),
                String.valueOf(markerPoints.get(0).latitude), String.valueOf(markerPoints.get(0).longitude),
                String.valueOf(markerPoints.get(1).latitude), String.valueOf(markerPoints.get(1).longitude),
                String.valueOf(finalDistance1), String.valueOf(finalTime).trim(), routeFare,
                appVehicles.get(selectedRidePosition).getCarType(), appVehicles.get(selectedRidePosition).getVehicleRate(),
                OYLA_VALUE, paymentType, appVehicles.get(selectedRidePosition).getPeak_rate(),
                String.valueOf(getTripDestination(appVehicles.get(selectedRidePosition).getPartner_pickup_distance())),
                appVehicles.get(selectedRidePosition).getMin_ride_fares(),
                getStringAddress(markerPoints.get(0).latitude, markerPoints.get(0).longitude).replaceAll("[-+.^:,،]", ""),
                getStringAddress(markerPoints.get(1).latitude, markerPoints.get(1).longitude).replaceAll("[-+.^:,،]", ""), SKIP_DROP_OFF,fcm_token);
*/

        /*calculate fare data from API*/

        SearchCaptainData searchCaptainData = new SearchCaptainData(
                appVehicles.get(selectedRidePosition).getId(), MainApp.getInstance().getUserData().getUserId(),
                String.valueOf(markerPoints.get(0).latitude), String.valueOf(markerPoints.get(0).longitude),
                String.valueOf(markerPoints.get(1).latitude), String.valueOf(markerPoints.get(1).longitude),
                appVehicles.get(selectedRidePosition).getDistance(), appVehicles.get(selectedRidePosition).getTimeFare2(),
                routeFare, appVehicles.get(selectedRidePosition).getCarType(), appVehicles.get(selectedRidePosition).getVehicleRate(),
                OYLA_VALUE, paymentType, appVehicles.get(selectedRidePosition).getPeak_rate(),
                appVehicles.get(selectedRidePosition).getPartner_pickup_distance(),
                appVehicles.get(selectedRidePosition).getMin_ride_fares(),
                getStringAddress(markerPoints.get(0).latitude, markerPoints.get(0).longitude).replaceAll("[-+.^:,،]", ""),
                getStringAddress(markerPoints.get(1).latitude, markerPoints.get(1).longitude).replaceAll("[-+.^:,،]", ""), SKIP_DROP_OFF, fcm_token);

        viewModel.findCaptainRequest2(searchCaptainData);
  /*      viewModel.findCaptainRequest(
                appVehicles.get(selectedRidePosition).getId(),
                MainApp.getInstance().getUserData().getUserId(),
                String.valueOf(markerPoints.get(0).latitude), String.valueOf(markerPoints.get(0).longitude),
                String.valueOf(markerPoints.get(1).latitude), String.valueOf(markerPoints.get(1).longitude),
                String.valueOf(finalDistance1),
                String.valueOf(finalTime).trim(),
                routeFare,
                appVehicles.get(selectedRidePosition).getCarType(),
                appVehicles.get(selectedRidePosition).getVehicleRate(),
                OYLA_VALUE, p aymentType,
                appVehicles.get(selectedRidePosition).getPeak_rate(),
                String.valueOf(getTripDestination(appVehicles.get(selectedRidePosition).getPartner_pickup_distance())),
                appVehicles.get(selectedRidePosition).getMin_ride_fares(),
                //String result = getStringAddress(centerLatLng.latitude, centerLatLng.longitude).replaceAll("[-+.^:,،]","");
                getStringAddress(markerPoints.get(0).latitude, markerPoints.get(0).longitude).replaceAll("[-+.^:,،]", ""),
                getStringAddress(markerPoints.get(1).latitude, markerPoints.get(1).longitude).replaceAll("[-+.^:,،]", ""),
                SKIP_DROP_OFF
        );*/
        viewModel.findCaptainRepose().observe(this, dataModelObject -> {
            stopLoader();
            if (dataModelObject != null && dataModelObject.getStatus() != null &&
                    dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                binding.findCaptainLayout.findCaptainProgressBar.setMax(Integer.parseInt(String.valueOf(START_TIME_IN_MILLIS)));
                progressStatus = 0;
                startTimer();
                binding.findCaptainLayout.mainLayout.setVisibility(View.VISIBLE);
                MainApp.getInstance().Booking_REQUEST = true;
                BOOKING_RESPONSE = true;
                Log.v("findCaptainRepose", "findCaptainRepose " + dataModelObject.getData().getBooking_data().getTemp_id());
                Gson gson = new Gson();
                String json = gson.toJson(dataModelObject.getData().getBooking_data());
                SharedPrefManager.getInstance(MapActivity.this).setBookingInfo(json);
                json = SharedPrefManager.getInstance(MapActivity.this).getBookingInfo();
                MainApp.getInstance().setBookingInfoData(dataModelObject.getData().getBooking_data());
                Log.v("findCaptainRepose", "captainInfoScreen " + json);
                Log.v("typeID", " find captain BOOKING_RESPONSE " + BOOKING_RESPONSE);
                typeID = appVehicles.get(selectedRidePosition).getId();
                startRideBookingStatusService();
            } else if (dataModelObject != null && dataModelObject.getStatus() != null &&
                    dataModelObject.getStatus().equalsIgnoreCase("420")) {
                if (dataModelObject.getError() != null && dataModelObject.getError().getMessage() != null) {
                    showToast(MapActivity.this, dataModelObject.getError().getMessage());
                }
                finish();
            } else {
                Log.v("findCaptainRepose", "else ");
                FINDING_CAPTAIN = false;
                pauseTimer();
                onBackPressed();
                //showToast(MapActivity.this, dataModelObject.getError().getMessage());
                if (dataModelObject != null && dataModelObject.getError() != null) {
                    DialogBoxSingleton.getInstance().showErrorPopup(MapActivity.this, dataModelObject.getError());
                    if (dataModelObject.getError().getMessage() != null) {
                        //   showToast(MapActivity.this, dataModelObject.getError().getMessage());
                        Log.v("findCaptainRequest", "getErrorMessage " + dataModelObject.getError().getMessage());
                    } else if (dataModelObject.getError().getMessages() != null) {
                        //  showToast(MapActivity.this, dataModelObject.getError().getMessages().toString());
                        Log.v("findCaptainRequest", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                    }
                }
                // Log.v("findCaptainRepose", "captainInfoScreen " + dataModelObject.getError().getMessage());
            }
        });
        /*PICK_UP_TRACKING=true;
        startGetDriverCoordinatesService();*/
    }

    private void findCaptainCancelFlagReset() {
        FINDING_CAPTAIN = false;
        pauseTimer();
        resetTimer();
        if (!(MapActivity.this).isFinishing()) {
            startLoader();
        }
        RideReceived = false;
    }

    @Override
    public void onRideRecieved(String json) {
        runOnUiThread(() -> {
            stopLoader();
            pauseTimer();
            resetTimer();
            FINDING_CAPTAIN = false;
            rideInfoFromSharedPreferences(json);
        });
    }

    private void rideInfoFromSharedPreferences(String json) {
        if (json != null) {
            hideView();
            binding.findCaptainLayout.mainLayout.setVisibility(View.GONE);
            SharedPreferences sharedPreferences = MapActivity.this.getSharedPreferences("Driver_Info", 0);
            String json2, Status, notificationType;
            json2 = sharedPreferences.getString("Driver_Info_Object", "");
            Gson gson = new Gson();
            FireBaseDataModelObject fireBaseDataModelObject = gson.fromJson(json2, FireBaseDataModelObject.class);
            notificationType = fireBaseDataModelObject.getNotification_type();

            //startTrackigActivity();

            if (notificationType != null) {
                // routeConfirm=true;
                if (notificationType.equalsIgnoreCase("1")) {
                    viewModel.bookingStatusRequest(MainApp.getInstance().getUserData().getUserId());
                    viewModel.bookingStatusRepose().observe(this, dataModelObject -> {
                        stopLoader();
                        if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                            bookingStatusData = dataModelObject.getData().getBookingInfo();
                            SKIP_DROP_OFF = bookingStatusData.getIs_skip_dropoff();
                            typeID = dataModelObject.getData().getBookingInfo().getVehicle_type_id();
                            startTrackigActivity();
                        } else {
                            if (dataModelObject.getError().getMessage() != null) {
                                Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                            } else if (dataModelObject.getError().getMessages() != null) {
                                Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                            }
                        }
                    });

                } else if (notificationType.equalsIgnoreCase("0")) {
                    stopLoader();
                    if (fireBaseDataModelObject.getMsg() != null) {
                        //showToast(MapActivity.this, fireBaseDataModelObject.getMsg());
                        Constants.FIRE_BASE_NOTIFY = false;
                        showCustomWarningToast(MapActivity.this, fireBaseDataModelObject.getMsg());
                    }

                    rideCancelByPartner();
                }
            }
        } else {
            //resetRideFlowTag(false, false, false);
            // resetRideStatusTag(false, false, false);
                /*Intent myService = new Intent(MapActivity.this, RideBookingStatus.class);
                myService.setAction(Constants.ACTION_STOP_FOREGROUND_SERVICE);
                stopService(myService);*/
            stopRideBookingStatusService();
        }
    }


    private void rideCancelByPartner() {
        stopRideBookingStatusService();
        //resetRideFlowTag(false, false, false);
        // resetRideStatusTag(false, false, false);
        AFTER_RIDE_CANCEL = false;
        FIND_CAPTAIN_CANCEL = false;
        SHOW_POLYLINE = false;
        FINDING_CAPTAIN = false;
        if (trackerMarker != null) {
            trackerMarker = null;
        }
        if (animateMarkerHandler != null) {
            animateMarkerHandler.removeCallbacksAndMessages(null);
        }
        RIDE_ACCEPTED = false;
        RIDE_STARTED = false;
        routeConfirm = false;
        Driver_Selected_Ride = false;
        Driver_Start_Ride = false;
        RideReceived = false;
        Resume_Ride_Tracking = false;
        PICK_UP_TRACKING = false;
        MainApp.getInstance().Booking_REQUEST = false;
        CONFIRM_RIDE = false;
        SELECTED_RIDE = false;
        if (markerPoints != null) {
            markerPoints.clear();
        }
        binding.captainInfoLayout.captainInfo1.setVisibility(View.GONE);
        if (MainApp.getInstance() != null) {
            MainApp.getInstance().setDriverCoordinate(null);
        }
        Intent myService = new Intent(MapActivity.this, GetDriverCoordinates.class);
        myService.setAction(Constants.ACTION_STOP_FOREGROUND_SERVICE);
        stopService(myService);
        SharedPreferences sharedPreferences2 = MapActivity.this.getSharedPreferences("Driver_Info", 0);
        sharedPreferences2.edit().remove("Driver_Info_Object").apply();
        SharedPrefManager.getInstance(MapActivity.this).removeBookingInfo();
        binding.captainInfoLayout.totalFairText.setText("");
        dataList = null;
        //startgetNearestDriverService();
        onBackPressed();
    }

    @Override
    public void doTracking() {
        /*  *//*  new Handler(Looper.getMainLooper()).post(() -> {*//*
        mapLayoutBinding.pickUpMarker.setVisibility(View.GONE);
        //  mGoogleMap.clear();
        Log.v("SHOW_POLYLINE", "doTracking SHOW_POLYLINE " + SHOW_POLYLINE);
        Log.v("SHOW_POLYLINE", "SKIP_DROP_OFF " + SKIP_DROP_OFF);
        Log.v("SHOW_POLYLINE", "RIDE_STARTED " + RIDE_STARTED);
        if (SKIP_DROP_OFF == 1 && RIDE_STARTED) {
            SHOW_POLYLINE = false;
            binding.captainInfoLayout.totalDistanceText.setText("");
            binding.captainInfoLayout.expectedTimeText.setText("");
            stopLoader();
        }
        if (SHOW_POLYLINE) {
            //newTrackingRoute();
            trackingPolylineRoute();
            //  SHOW_POLYLINE=false;
        } else {
            if (polyLine != null) {
                Log.v("SHOW_POLYLINE", "polyLine ");
                polyLine.remove();
                polyLine = null;
                if (rideStartMarker != null) {
                    Log.v("SHOW_POLYLINE", "rideStartMarker ");
                    rideStartMarker.remove();
                    rideStartMarker = null;
                }
            }
            trackingNonPolylineRoute();
        }*/
        //});
    }

    private void trackingPolylineRoute() {
        Log.v("SHOW_POLYLINE", "trackingRoute ");
        // LatLng diverLatLng;
        ArrayList<LatLng> trackingMarkerPoints = new ArrayList<>();
        Log.v("newToken", "BOOKING_RESPONSE " + BOOKING_RESPONSE);
        Log.v("doTracking", "doTracking ");
        Log.v("doTracking", "BOOKING_RESPONSE " + BOOKING_RESPONSE);
        if (BOOKING_RESPONSE) {
            BOOKING_RESPONSE = false;
            diverLatLng = new LatLng(Double.parseDouble(dataList.getCaptain_info_data().getDriver_lat()), Double.parseDouble(dataList.getCaptain_info_data().getDriver_long()));
            Log.d("captainInfoData", "captainInfoData getBooking_id " + dataList.getCaptain_info_data().getBooking_id());
            trackingMarkerPoints.add(diverLatLng);
            trackingMarkerPoints.add(new LatLng(markerPoints.get(0).latitude, markerPoints.get(0).longitude));
            //calculateDirections(trackingMarkerPoints);
            calculateDirectionsURL(trackingMarkerPoints);
            if (Driver_Start_Ride) {
                Driver_Start_Ride = false;
                stopLoader();
            }
            if (Driver_Selected_Ride) {
                Driver_Selected_Ride = false;
                stopLoader();
            }
            //  }
        } else {
            if (MainApp.getInstance().getDriverCoordinate() != null) {
                //stopLoader();
                if (Driver_Start_Ride) {
                    Driver_Start_Ride = false;
                    stopLoader();
                }
                if (Driver_Selected_Ride) {
                    Driver_Selected_Ride = false;
                    stopLoader();
                }
                // Log.d("GetDriverCoordinates", "MainApp.getInstance().getDriverCoordinate().getLat() " + MainApp.getInstance().getDriverCoordinate().getLat());
                //  Log.d("GetDriverCoordinates", "MainApp.getInstance().getDriverCoordinate().getLng() " + MainApp.getInstance().getDriverCoordinate().getLng());
                //MainApp.getInstance().getDriverCoordinate().getLng();
                diverLatLng = new LatLng(Double.parseDouble(MainApp.getInstance().getDriverCoordinate().getLat()), Double.parseDouble(MainApp.getInstance().getDriverCoordinate().getLng()));
                trackingMarkerPoints.add(diverLatLng);
                //  Log.d("GetDriverCoordinates", "PICK_UP_TRACKING " + PICK_UP_TRACKING);
                // showToast(MapActivity.this, getStringAddress(diverLatLng.latitude, diverLatLng.longitude));
                if (markerPoints == null) {
                    return;
                }
                if (RIDE_STARTED) {
                    if (markerPoints.size() < 2) {
                        return;
                    }
                    trackingMarkerPoints.add(new LatLng(markerPoints.get(1).latitude, markerPoints.get(1).longitude));
                    // trackingMarkerPoints.add(new LatLng(31.50967734630642,74.31757159320492));
                } else {
                    if (markerPoints.size() < 1) {
                        return;
                    }
                    PICK_UP_TRACKING = true;
                    trackingMarkerPoints.add(new LatLng(markerPoints.get(0).latitude, markerPoints.get(0).longitude));
                    // trackingMarkerPoints.add(new LatLng(31.50967734630642,74.31757159320492));
                }
                SHOW_POLYLINE = false;
                //calculateDirections(trackingMarkerPoints);
                calculateDirectionsURL(trackingMarkerPoints);
            }
        }
        trackingMarkerPoints = null;
    }

    private void trackingNonPolylineRoute() {
        Log.v("SHOW_POLYLINE", "trackingRoute2 ");
        ArrayList<LatLng> trackingMarkerPoints = new ArrayList<>();
        Log.v("newToken", "BOOKING_RESPONSE " + BOOKING_RESPONSE);
        Log.v("doTracking", "doTracking ");
        Log.v("doTracking", "BOOKING_RESPONSE " + BOOKING_RESPONSE);
        if (BOOKING_RESPONSE) {
            BOOKING_RESPONSE = false;
            diverLatLng = new LatLng(
                    Double.parseDouble(dataList.getCaptain_info_data().getDriver_lat()),
                    Double.parseDouble(dataList.getCaptain_info_data().getDriver_long())
            );
            Log.d("captainInfoData", "captainInfoData getBooking_id " + dataList.getCaptain_info_data().getBooking_id());
            trackingMarkerPoints.add(diverLatLng);
            trackingMarkerPoints.add(new LatLng(markerPoints.get(0).latitude, markerPoints.get(0).longitude));
            //calculateDirections(trackingMarkerPoints);
            trackMarkerOnRoute(trackingMarkerPoints);
            if (Driver_Start_Ride) {
                Driver_Start_Ride = false;
                stopLoader();
            }
            if (Driver_Selected_Ride) {
                Driver_Selected_Ride = false;
                stopLoader();
            }
            //  }
        } else {
            if (MainApp.getInstance().getDriverCoordinate() != null) {
                //stopLoader();
                if (Driver_Start_Ride) {
                    Driver_Start_Ride = false;
                    stopLoader();
                }
                if (Driver_Selected_Ride) {
                    Driver_Selected_Ride = false;
                    stopLoader();
                }
                Log.d("GetDriverCoordinates", "MainApp.getInstance().getDriverCoordinate().getLat() " + MainApp.getInstance().getDriverCoordinate().getLat());
                Log.d("GetDriverCoordinates", "MainApp.getInstance().getDriverCoordinate().getLng() " + MainApp.getInstance().getDriverCoordinate().getLng());
                //MainApp.getInstance().getDriverCoordinate().getLng();
                diverLatLng = new LatLng(Double.parseDouble(MainApp.getInstance().getDriverCoordinate().getLat()),
                        Double.parseDouble(MainApp.getInstance().getDriverCoordinate().getLng()));
                trackingMarkerPoints.add(diverLatLng);
                Log.d("GetDriverCoordinates", "PICK_UP_TRACKING " + PICK_UP_TRACKING);
                 /*showToastLong(MapActivity.this, diverLatLng.latitude+","+ diverLatLng.longitude+
                         "\n"+ getStringAddress(diverLatLng.latitude, diverLatLng.longitude));*/
                if (markerPoints == null) {
                    return;
                }
                if (RIDE_STARTED) {
                    if (markerPoints.size() < 2) {
                        return;
                    }
                    trackingMarkerPoints.add(new LatLng(markerPoints.get(1).latitude, markerPoints.get(1).longitude));
                    // trackingMarkerPoints.add(new LatLng(31.50967734630642,74.31757159320492));
                } else {
                    if (markerPoints.size() < 1) {
                        return;
                    }
                    PICK_UP_TRACKING = true;
                    trackingMarkerPoints.add(new LatLng(markerPoints.get(0).latitude, markerPoints.get(0).longitude));
                    // trackingMarkerPoints.add(new LatLng(31.50967734630642,74.31757159320492));
                }
                //calculateDirections(trackingMarkerPoints);
                trackMarkerOnRoute(trackingMarkerPoints);
            }
        }
        trackingMarkerPoints = null;

    }

    private void trackMarkerOnRoute(List<LatLng> latLngList) {

        Log.v("newTrackingRoute", "trackingRoute ELSE");
        /*new Handler(Looper.getMainLooper()).post(() -> {*/
        mHandlerUI.post(() -> {
            LatLng startLocation = new LatLng(
                    latLngList.get(0).latitude, latLngList.get(0).longitude);

            if (tempLat == 0) {
                tempLat = latLngList.get(0).latitude;
            }
            if (tempLat == 0) {
                tempLng = latLngList.get(0).longitude;
            }
          /*  double d = SphericalUtil.computeDistanceBetween(oldPos, newPos);
            if (d < 10) {
                return;
            }*/
            if (PICK_UP_TRACKING) {
                float bearing = MainApp.getInstance().getBearing();
                // trackerMarker = mGoogleMap.addMarker(new MarkerOptions());
                Log.v("trackMarkerOnRoute", " startLatLng.latitude : " + startLocation.latitude);
                Log.v("trackMarkerOnRoute", " startLatLng.longitude : " + startLocation.longitude);
                Log.v("trackMarkerOnRoute", "-------------- ");

                if (trackerMarker == null) {
                    trackerMarker = mGoogleMap.addMarker(new MarkerOptions()
                                    .position(startLocation)
                                    .flat(true)
                                    .rotation(bearing)
                            //.icon(bitmapDescriptorFromVector(getResources().getDrawable(R.drawable.page_10_car_vertical, null)))
                    );
                    if (typeID.equalsIgnoreCase("9")) {
                        //trackerMarker.setIcon(bitmapDescriptorFromVector(ResourcesCompat.getDrawable(null, R.drawable.aerial_car, null)));
                        trackerMarker.setIcon(bitmapDescriptorFromVector(getResources().getDrawable(R.drawable.richshaw, null)));
                    } else if (typeID.equalsIgnoreCase("10")) {
                        trackerMarker.setIcon(bitmapDescriptorFromVector(getResources().getDrawable(R.drawable.bike_map, null)));
                        //trackerMarker.setIcon(bitmapDescriptorFromVector(ResourcesCompat.getDrawable(null, R.drawable.bike_map, null)));
                    } else {
                        trackerMarker.setIcon(bitmapDescriptorFromVector(getResources().getDrawable(R.drawable.aerial_car, null)));
                        // trackerMarker.setIcon(bitmapDescriptorFromVector(ResourcesCompat.getDrawable(null, R.drawable.aerial_car, null)));
                    }
                } else {
                 /*   showToast(MapActivity.this, startLocation.latitude+","+ startLocation.longitude+
                            "\n"+ getStringAddress(startLocation.latitude, startLocation.longitude));*/
                    //` Log.v("newToken", " trackerMarker bearing : " + bearing);
                    Log.d("rotateMarker", "bearing: " + bearing);
                    //bearing=MainApp.getInstance().getUserLocation().getLocation().getBearing();
                    // Log.v("LocationService", " trackerMarker bearing : " + bearing);
                    rotateMarker(trackerMarker, bearing);
                    animateMarkerTo(trackerMarker, startLocation.latitude, startLocation.longitude);
                    //updateCamera(bearing,endLocation.latitude, endLocation.longitude);
                }
                // float bearing2 = mGoogleMap.getMyLocation().getBearing();
              /*  CameraPosition newCamPos = new CameraPosition(startLocation,
                        Constants.TRACK_ZOOM,
                        0,
                        bearing);*/
                mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(startLocation, Constants.TRACK_ZOOM));
                //mGoogleMap.animateCamera(CameraUpdateFactory.newCameraPosition(newCamPos));
            }

            LatLng endLocation = new LatLng(
                    latLngList.get(1).latitude, latLngList.get(1).longitude);
            Log.d("newTrackingRoute", "lat long " + endLocation.latitude + "," + endLocation.longitude);
            //Log.d("newTrackingRoute", getStringAddress(endLocation.latitude, endLocation.longitude));
            Log.d("newTrackingRoute", "---------------");
            if (RIDE_ACCEPTED) {
                if (rideStartMarker == null) {
                    rideStartMarker = mGoogleMap.addMarker(new MarkerOptions()
                                    .position(endLocation)
                                    //.title("Trip #" + index)
                                    //.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN))
                                    .icon(BitmapDescriptorFactory.fromBitmap(createLayoutCustomMarker(MapActivity.this, R.drawable.pickup_icon, " ", true)))
                            //.snippet("Trip Duration: " + polylineData.getLeg().duration)
                    );
                } else {
                    rideStartMarker.setPosition(new LatLng(endLocation.latitude, endLocation.longitude));
                    //animateMarkerTo(rideStartMarker, endLocation.latitude, endLocation.longitude);
                }
            } else if (RIDE_STARTED) {
                if (SKIP_DROP_OFF == 1) {
                    if (rideStartMarker != null) {
                        rideStartMarker.remove();
                    }
                    return;
                }
                if (rideStartMarker == null) {
                    rideStartMarker = mGoogleMap.addMarker(new MarkerOptions()
                            .position(endLocation)
                            //.title("Trip #" + index)
                            //.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN))
                            .icon(BitmapDescriptorFactory.fromBitmap(
                                    createLayoutCustomMarker(MapActivity.this, R.drawable.drop_off_icon, " ", true)))
                    );
                } else {
                    rideStartMarker.setPosition(new LatLng(endLocation.latitude, endLocation.longitude));
                    // animateMarkerTo(rideStartMarker, endLocation.latitude, endLocation.longitude);
                }
            }
            if (Resume_Ride_Tracking) {
                Resume_Ride_Tracking = false;
                stopLoader();
            }
            if (RideReceived) {
                captainInfoScreen();
                captainInfoSlider();
            }
            startLocation = null;
        });
    }

    @SuppressLint("SetTextI18n")
    private void finishRideDialog() {
        Log.v("refreshRide", "finishRideDialog");
        /*if (mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();
        } else {
            Log.d("TAG", "The interstitial wasn't loaded yet.");
        }*/
        //final Dialog dialog = new Dialog(MapActivity.this, R.style.full_screen_dialog);
        final Dialog dialog = new Dialog(MapActivity.this);
        //dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.finsh_and_review_ride_dialog);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(true);
        // EditText enterVoucherEdiText = dialog.findViewById(R.id.enterPromoEdiText);
        // TextInputLayout enterVoucherTextInput = dialog.findViewById(R.id.enterPromoTextInput);
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        dialog.findViewById(R.id.complete).setOnClickListener(v -> {
            dialog.dismiss();
          /*  Intent i = new Intent(MapActivity.this, DashBoardActivity.class);
            startActivity(i);
            finish();*/
            ((TextView) dialog.findViewById(R.id.totalFareText)).setText("");
            ((TextView) dialog.findViewById(R.id.totalDistanceText)).setText("");
            ((TextView) dialog.findViewById(R.id.expectedTimeText)).setText("");


            Log.v("captainInfoScreen", "dataList " + dataList);
            Intent i = new Intent(MapActivity.this, CaptainReviewActivity.class);
            i.putExtra("bookingId", bookingStatusData.getBooking_id());
            i.putExtra("passengerId", bookingStatusData.getPassenger_id());
            i.putExtra("driverId", bookingStatusData.getDriver_id());
            startActivity(i);
            finish();
        });

        dialog.findViewById(R.id.nextReview).setOnClickListener(v -> {
            dialog.dismiss();
            Intent i = new Intent(MapActivity.this, CaptainReviewActivity.class);
            i.putExtra("bookingId", bookingStatusData.getBooking_id());
            i.putExtra("passengerId", bookingStatusData.getPassenger_id());
            i.putExtra("driverId", bookingStatusData.getDriver_id());
            startActivity(i);
            finish();
        });
                /*  Gson gson = new Gson();
                  String json = SharedPrefManager.getInstance(MapActivity.this).getBookingInfo();
                  BookingInfoData bookingInfoData = gson.fromJson(json, BookingInfoData.class);*/
                /* ((TextView) dialog.findViewById(R.id.totalFareText)).setText(getResources().getString(R.string.currency) + " " + bookingInfoData.getAmount());
                 ((TextView) dialog.findViewById(R.id.totalDistanceText)).setText(bookingInfoData.getDistance_kilomiters() + " " + getResources().getString(R.string.km));
                 ((TextView) dialog.findViewById(R.id.expectedTimeText)).setText(bookingInfoData.getEstimate_minutes() + " " + getResources().getString(R.string.min));*/
        // ((TextView) dialog.findViewById(R.id.totalFareText)).setText(getResources().getString(R.string.currency) + " " + bookingStatusData.getFinal_amount());
        String final_amount;
        String final_distance;
        String final_time;

        if (dataList != null) {
            if (dataList.getCaptain_info_data() != null && dataList.getCaptain_info_data().getFinal_amount() != null
                    && dataList.getCaptain_info_data().getFinal_time() != null) {
                Log.v("refreshRide", "finishRideDialog if");
                final_distance = dataList.getCaptain_info_data().getFinal_distance();
                final_amount = String.valueOf(Math.round(Double.parseDouble(dataList.getCaptain_info_data().getFinal_amount())));
                final_time = dataList.getCaptain_info_data().getFinal_time();
            } else {
                Log.v("refreshRide", "finishRideDialog else");
                final_distance = bookingStatusData.getDistance_kilomiters();
                final_amount = String.valueOf(Math.round(Double.parseDouble(bookingStatusData.getFinal_amount())));
                final_time = bookingStatusData.getRide_complete_time();
            }
        } else {
            Log.v("refreshRide", "finishRideDialog 2nd else");
            final_distance = bookingStatusData.getDistance_kilomiters();
            final_amount = String.valueOf(Math.round(Double.parseDouble(bookingStatusData.getFinal_amount())));
            final_time = bookingStatusData.getRide_complete_time();
        }
        double value = Double.parseDouble(final_distance);
        final_distance = String.valueOf(Double.parseDouble(new DecimalFormat("##.##").format(value)));
        ((TextView) dialog.findViewById(R.id.totalFareText)).setText(getResources().getString(R.string.currency) + " " + final_amount);
        ((TextView) dialog.findViewById(R.id.totalDistanceText)).setText(final_distance + " " + getResources().getString(R.string.km));
        ((TextView) dialog.findViewById(R.id.expectedTimeText)).setText(final_time + " " + getResources().getString(R.string.min));
        /*((TextView) dialog.findViewById(R.id.totalFareText)).setText(getResources().getString(R.string.currency) + " " + Math.round(Double.parseDouble(bookingStatusData.getFinal_amount())));
        ((TextView) dialog.findViewById(R.id.totalDistanceText)).setText(bookingStatusData.getDistance_kilomiters() + " " + getResources().getString(R.string.km));
        ((TextView) dialog.findViewById(R.id.expectedTimeText)).setText(bookingStatusData.getEstimate_minutes() + " " + getResources().getString(R.string.min));*/
        SharedPreferences sharedPreferences = MapActivity.this.getSharedPreferences("Driver_Info", 0);
        sharedPreferences.edit().remove("Driver_Info_Object").apply();
        SharedPrefManager.getInstance(MapActivity.this).removeBookingInfo();
        if (!(MapActivity.this).isFinishing()) {
            //show dialog
            dialog.show();
        }
        Window window = dialog.getWindow();
        assert window != null;
        window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        window.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.colorTransparent2)));
        window.setGravity(Gravity.CENTER);
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void captainInfoSlider() {
        binding.captainInfoLayout.topLayout.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    Log.i("scrollLayout", "ACTION_DOWN");
                    break;
                case MotionEvent.ACTION_MOVE:
                    Log.i("scrollLayout", "ACTION_MOVE");
                    break;
                case MotionEvent.ACTION_UP:
                    Log.i("scrollLayout", "ACTION_UP");
                    Log.i("scrollLayout", "RIDE_VIEw_FULL " + RIDE_VIEw_FULL);
                    if (RIDE_VIEw_FULL) {
                        contractView2();
                        RIDE_VIEw_FULL = false;
                    } else {
                        RIDE_VIEw_FULL = true;
                        expandView2();
                    }
                    break;
                default:
                    return false;
            }
            return true;
        });
    }

    @SuppressLint("SetTextI18n")
    private void captainInfoScreen() {
        int minusWalletAmount = 0;
        int plusWalletAmount = 0;
        double routeAmount = 0;
        Log.v("refreshRide", "captainInfoScreen SKIP_DROP_OFF" + SKIP_DROP_OFF);
        if (dataList == null && MainApp.getInstance().getDataList() != null) {
            dataList = MainApp.getInstance().getDataList();
        }
        if (dataList != null) {
            binding.captainInfoLayout.confirmDropOff.setVisibility(View.GONE);
            binding.captainInfoLayout.cancelDropOff.setVisibility(View.GONE);
            binding.captainInfoLayout.captainInfo1.setVisibility(View.VISIBLE);
            binding.captainInfoLayout.changeAddressText.setText(getStringAddress(centerLatLng.latitude, centerLatLng.longitude));
            //binding.captainInfoLayout.totalFairText.setText(getResources().getString(R.string.currency) + " " + bookingInfoData.getAmount());
            if (bookingStatusData == null) {
                checkBookingStatus();
            } else {
                // binding.captainInfoLayout.changeDropOffButton.setVisibility(View.GONE);
                //binding.captainInfoLayout.totalFairText.setText(getResources().getString(R.string.currency) + " " + bookingStatusData.getFinal_amount());
                if (Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(Constants.WALLET_AMOUNT)))) > 0 && SharedPrefManager.getInstance(MapActivity.this).getOylaPay()) {
                  /*  if (appVehicles != null) {
                        minusWalletAmount = Integer.parseInt(appVehicles.get(selectedRidePosition).getFair()) + Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(Constants.WALLET_AMOUNT))));
                    }else {*/
                    plusWalletAmount = -(Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(Constants.WALLET_AMOUNT)))));
                    routeAmount = Double.parseDouble(bookingStatusData.getFinal_amount());
                    routeAmount = routeAmount + plusWalletAmount;
                    if (routeAmount < 1) {
                        routeAmount = 0;
                    }
                    Log.v("fareAmount", " if routeAmount " + routeAmount);
                    //  }
                } else if (Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(Constants.WALLET_AMOUNT)))) < 0) {
                  /*  if (appVehicles != null) {
                        minusWalletAmount = Integer.parseInt(appVehicles.get(selectedRidePosition).getFair()) + Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(Constants.WALLET_AMOUNT))));
                    }else {*/
                    minusWalletAmount = -(Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(Constants.WALLET_AMOUNT)))));
                    routeAmount = Double.parseDouble(bookingStatusData.getFinal_amount());
                    //showToast(MapActivity.this,String.valueOf(routeAmount));
                    routeAmount = routeAmount + minusWalletAmount;
                    plusWalletAmount = 0;
                    //  }
                    //showToast(MapActivity.this,String.valueOf(minusWalletAmount));
                    Log.v("fareAmount", " else if routeAmount " + routeAmount);
                } else {
                    routeAmount = Double.parseDouble(bookingStatusData.getFinal_amount());
                    Log.v("fareAmount", " else routeAmount " + routeAmount);
                }
                /*binding.captainInfoLayout.totalFairText.setText(getResources().getString(R.string.currency) + " " +
                        Math.round(
                                Double.parseDouble(bookingStatusData.getFinal_amount()) + minusWalletAmount+plusWalletAmount
                        )
                );*/
                binding.captainInfoLayout.totalFairText.setText(getResources().getString(R.string.currency) + " " + Math.round(routeAmount));
                Log.v("minusWalletAmount", "minusWalletAmount " + minusWalletAmount);
                Log.v("fareAmount", "routeAmount " + routeAmount);
           /* binding.captainInfoLayout.totalDistanceText.setText(bookingInfoData.getDistance_kilomiters() + " " + getResources().getString(R.string.km));
            binding.captainInfoLayout.expectedTimeText.setText(bookingInfoData.getEstimate_minutes() + " " + getResources().getString(R.string.min));*/
                Log.v("newToken", "currentTripTime " + currentTripTime);
                Log.v("newToken", "currentTripDuration " + currentTripDuration);
                binding.captainInfoLayout.rideCurrentStatusText.setText(rideCurrentStatusText);
                binding.captainInfoLayout.totalDistanceText.setText(currentTripDuration);
                binding.captainInfoLayout.expectedTimeText.setText(currentTripTime);
                Log.v("captainInfoScreen", "dataList " + dataList);
                if (dataList.getCaptain_info_data() == null) {
                    return;
                }
                // SharedPreferences sharedPreferences = MapActivity.this.getSharedPreferences("Driver_Info", 0);
                // if (sharedPreferences.contains("Driver_Info_Object")) {
                //    gson = new Gson();
                //     json = sharedPreferences.getString("Driver_Info_Object", "");
                //      CaptainInfoData captainInfoData = gson.fromJson(json, CaptainInfoData.class);
                Log.v("captainInfoScreen", "getBooking_id " + dataList.getCaptain_info_data().getBooking_id());
                Log.v("captainInfoScreen", "getContact_no " + dataList.getCaptain_info_data().getContact_no());
                binding.captainInfoLayout.captainName.setText(dataList.getCaptain_info_data().getDriver_name());
                binding.captainInfoLayout.contactNumber.setText(dataList.getCaptain_info_data().getContact_no());
                binding.captainInfoLayout.carNumber.setText(dataList.getCaptain_info_data().getVehicle_number());
                //binding.captainInfoLayout.carType.setText(bookingInfoData.getVehicle_type() + "( " + dataList.getCaptain_info_data().getVehicle_name() + " )");
                if (dataList.getCaptain_info_data().getVehicle_name() == null || dataList.getCaptain_info_data().getVehicle_name().isEmpty()) {
                    binding.captainInfoLayout.carType.setText(bookingStatusData.getVehicle_type());
                } else {
                    binding.captainInfoLayout.carType.setText(bookingStatusData.getVehicle_type() + "(" + dataList.getCaptain_info_data().getVehicle_name() + ")");
                }

                binding.captainInfoLayout.ratingtext.setText(getResources().getString(R.string.rating_text) + ": " + Math.round(Double.parseDouble(dataList.getCaptain_info_data().getDriver_ratings())));
                Log.v("newToken", "bookingStatusData.getBooking_changes " + bookingStatusData.getBooking_changes());
                binding.captainInfoLayout.contactLayout.setOnClickListener(v -> {
                    ClipboardManager clipboard = (ClipboardManager) MapActivity.this.getSystemService(CLIPBOARD_SERVICE);
                    ClipData clip = ClipData.newPlainText("label", dataList.getCaptain_info_data().getContact_no());
                    clipboard.setPrimaryClip(clip);
                    BaseActivity.getInstance().showToast(MapActivity.this, "Phone Number Copy");

                });
                binding.captainInfoLayout.phoneCall.setOnClickListener((v -> {
                    //stopLoader();
                    try {
                        if (dataList.getCaptain_info_data().getContact_no() != null || dataList.getCaptain_info_data().getContact_no().isEmpty())
                            call("+" + dataList.getCaptain_info_data().getContact_no());
                    } catch (Exception ex) {
                        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, 1
                        );
                    }
                }));
                /*setGlideImage(
                        MapActivity.this,
                        appVehicles.get(selectedRidePosition).getImage_url(),
                        binding.captainInfoLayout.carTypeIcon,
                        Constants.ASSETS_BASE_URL);*/
                if (bookingStatusData != null && bookingStatusData.getVehicle_type_id() != null) {
                    if (bookingStatusData.getVehicle_type_id().equalsIgnoreCase("1")) {
                        binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.gomini);
                    } else if (bookingStatusData.getVehicle_type_id().equalsIgnoreCase("2")) {
                        binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.go);
                    } else if (bookingStatusData.getVehicle_type_id().equalsIgnoreCase("3")) {
                        binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.go_plus);
                    } else if (bookingStatusData.getVehicle_type_id().equalsIgnoreCase("4")) {
                        binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.business);
                    } else if (bookingStatusData.getVehicle_type_id().equalsIgnoreCase("5")) {
                        binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.royal);
                    } else if (bookingStatusData.getVehicle_type_id().equalsIgnoreCase("6")) {
                        binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.dabba);
                    } else if (bookingStatusData.getVehicle_type_id().equalsIgnoreCase("7")) {
                        binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.pickup);
                    } else if (bookingStatusData.getVehicle_type_id().equalsIgnoreCase("8")) {
                        binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.agro);
                    } else if (bookingStatusData.getVehicle_type_id().equalsIgnoreCase("9")) {
                        binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.riksha);
                    } else if (bookingStatusData.getVehicle_type_id().equalsIgnoreCase("10")) {
                        binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.bike);
                    } else {
                        binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.go_plus);
                    }
                } else {
                    binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.go_plus);
                }


                /*if (bookingStatusData.getVehicle_type().equalsIgnoreCase("Smart")) {
                    binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.go);
                } else if (bookingStatusData.getVehicle_type().equalsIgnoreCase("Oyla Tiny")) {
                    binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.gomini);
                } else if (bookingStatusData.getVehicle_type().equalsIgnoreCase("Smart+")) {
                    binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.go_plus);
                } else if (bookingStatusData.getVehicle_type().equalsIgnoreCase("Business")) {
                    binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.business);
                } else if (bookingStatusData.getVehicle_type().equalsIgnoreCase("Smart Auto")) {
                    binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.riksha);
                } else if (bookingStatusData.getVehicle_type().equalsIgnoreCase("Smart Bike")) {
                    binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.bike);
                } else {
                    binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.go);
                }*/

                if (dataList.getCaptain_info_data().getProfile_picture() != null) {
                    setGlideImage(getApplicationContext(), dataList.getCaptain_info_data().getProfile_picture(),
                            binding.captainInfoLayout.captainProfile, Constants.PROFILE_BASE_URL);
                }

                binding.captainInfoLayout.shareInfo.setOnClickListener(v -> {
                    Intent intent = new Intent(android.content.Intent.ACTION_SEND);
                    // StringBuilder sb = new StringBuilder();
                    /*This will be the actual content you wish you share.*/
                    String shareBody = "Oyla Driver info  Share by :" + MainApp.getInstance().getUserData().getUserFirstName();
                    shareBody = shareBody + "\n" + "Driver name: " + dataList.getCaptain_info_data().getDriver_name();
                    shareBody = shareBody + "\n" + "Vehicle name: " + dataList.getCaptain_info_data().getVehicle_name();
                    shareBody = shareBody + "\n" + "Vehicle number: " + dataList.getCaptain_info_data().getVehicle_number();
                    if (diverLatLng != null) {
                        /*String uri = "geo:" + diverLatLng.longitude + ","
                                +diverLatLng.longitude + "?q=" + diverLatLng.longitude
                                + "," + diverLatLng.longitude;*/
                        String uri = "https://www.google.com/maps/?q=" + diverLatLng.latitude + "," + diverLatLng.longitude;
                        //shareBody = shareBody + "\n" + "Current Location: " + diverLatLng.longitude+","+diverLatLng.longitude;
                        shareBody = shareBody + "\n" + "Current Location: " + uri;
                    }

                    /*The type of the content is text, obviously.*/
                    intent.setType("text/plain");
                    /*Applying information Subject and Body.*/
                    intent.putExtra(android.content.Intent.EXTRA_SUBJECT, getString(R.string.oyla_captain_info));
                    intent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
                    /*Fire!*/
                    startActivity(Intent.createChooser(intent, getString(R.string.share_using)));
                });

                binding.captainInfoLayout.cancelRideButton.setOnClickListener(v -> cancelReasonDialog(MainApp.getInstance().getUserData().getUserId(), dataList.getCaptain_info_data().getBooking_id()));

                if (!RIDE_STARTED) {
                    binding.captainInfoLayout.cancelRideButton.setVisibility(View.VISIBLE);
                    binding.captainInfoLayout.changeDropOffButton.setVisibility(View.GONE);
                    binding.captainInfoLayout.confirmDropOff.setVisibility(View.GONE);
                } else {
                    binding.captainInfoLayout.cancelRideButton.setVisibility(View.GONE);
                    if (bookingStatusData.getBooking_changes() == null) {
                        if (SKIP_DROP_OFF == 0) {
                            binding.captainInfoLayout.changeDropOffButton.setVisibility(View.VISIBLE);
                        } else {
                            binding.captainInfoLayout.changeDropOffButton.setVisibility(View.GONE);
                        }
                    } else {
                        binding.captainInfoLayout.changeDropOffButton.setVisibility(View.GONE);
                    }
                    //binding.captainInfoLayout.confirmDropOff.setVisibility(View.VISIBLE);
                }
                binding.captainInfoLayout.changeDropOffButton.setOnClickListener(v -> {
                    CHANGE_ADDRESS = true;
                    binding.captainInfoLayout.changeAddressCardView.setVisibility(View.VISIBLE);
                    binding.captainInfoLayout.captainInfo2.setVisibility(View.GONE);
                    binding.captainInfoLayout.confirmDropOff.setVisibility(View.VISIBLE);
                    binding.captainInfoLayout.cancelDropOff.setVisibility(View.VISIBLE);
                    contractView2();
                    currentLat = MainApp.getInstance().getDriverCoordinate().getLat();
                    currentLng = MainApp.getInstance().getDriverCoordinate().getLng();
                    Log.d("TimeAndDistance", "currentLng " + currentLng);
                    Log.d("TimeAndDistance", "currentLat " + currentLat);
                    // if(isGetDriverCoordinatesServiceRunning()){
                    Intent myService = new Intent(MapActivity.this, GetDriverCoordinates.class);
                    myService.setAction(Constants.ACTION_STOP_FOREGROUND_SERVICE);
                    stopService(myService);
                    // }
                    final Handler handler = new Handler(Looper.getMainLooper());
                    handler.postDelayed(() -> {
                        //Do something after 100ms
                        mapLayoutBinding.dropOffMarker.setVisibility(View.VISIBLE);
                        routeConfirm = false;
                        dropOffAddressBol = true;
                        // mapLayoutBinding.dropOffAddressTextLayout.setVisibility(View.VISIBLE);
                        mGoogleMap.clear();
                        binding.captainInfoLayout.confirmDropOff.setVisibility(View.VISIBLE);
                        binding.captainInfoLayout.cancelDropOff.setVisibility(View.VISIBLE);
                        CHANGE_ADDRESS = true;
                    }, 200);

                });

                binding.captainInfoLayout.changeAddressCardView.setOnClickListener(v -> {
                    //SHOW_POLYLINE=true;
                    if (rideStartMarker != null) {
                        rideStartMarker = null;
                    }
                    CHANGE_ADDRESS = true;
                    Intent i = new Intent(MapActivity.this, SearchLocationActivity.class);
                    i.putExtra("message", getResources().getString(R.string.drop_off_message));
                    PICK_UP_ADDRESS = false;
                    DROP_OFF_ADDRESS = false;
                    startActivity(i);
                });
                binding.captainInfoLayout.confirmDropOff.setOnClickListener(v -> {
                    binding.captainInfoLayout.changeAddressCardView.setVisibility(View.GONE);
                    binding.captainInfoLayout.captainInfo2.setVisibility(View.VISIBLE);
                    binding.captainInfoLayout.cancelDropOff.setVisibility(View.GONE);
                    binding.captainInfoLayout.confirmDropOff.setVisibility(View.GONE);
                    binding.captainInfoLayout.changeDropOffButton.setVisibility(View.GONE);
                    contractView2();
                    mapLayoutBinding.dropOffMarker.setVisibility(View.GONE);
                    routeConfirm = true;
                    dropOffAddressBol = false;
                    mapLayoutBinding.dropOffAddressTextLayout.setVisibility(View.GONE);
                    newLatLng = new LatLng(Double.parseDouble(currentLat), Double.parseDouble(currentLng));
                    oldMarkerPoints.add(new LatLng(markerPoints.get(0).latitude, markerPoints.get(0).longitude));
                    oldMarkerPoints.add(newLatLng);
                    Log.d("newToken", "TimeAndDistance: calculating directions.");
                    SHOW_POLYLINE = true;
                    trip_one_duration = "";
                    trip_two_duration = "";
                    trip_one_distance = "";
                    trip_two_distance = "";
                    trip_one_price = "";
                    trip_two_price = "";
                    CHANGE_ADDRESS = false;
                    //calculateTimeAndDistance(oldMarkerPoints, true);
                    calculateTimeAndDistanceURL(oldMarkerPoints, true);
                });

                binding.captainInfoLayout.cancelDropOff.setOnClickListener(v -> {
                    binding.captainInfoLayout.changeAddressCardView.setVisibility(View.GONE);
                    binding.captainInfoLayout.captainInfo2.setVisibility(View.VISIBLE);
                    binding.captainInfoLayout.cancelDropOff.setVisibility(View.GONE);
                    binding.captainInfoLayout.confirmDropOff.setVisibility(View.GONE);
                    mapLayoutBinding.dropOffMarker.setVisibility(View.GONE);
                    CHANGE_ADDRESS = false;
                    if (trackerMarker != null) {
                        trackerMarker = null;
                    }
                    routeConfirm = true;
                    dropOffAddressBol = false;
                    mapLayoutBinding.dropOffAddressTextLayout.setVisibility(View.GONE);
                    SHOW_POLYLINE = false;
                    if (rideStartMarker != null) {
                        rideStartMarker = null;
                    }

                    startGetDriverCoordinatesService();
                });
                //  stopLoader();

                // }
       /* } else {
            //stopLoader();
        }*/
            }

        }
    }

    private void call(String number) {
        Log.v("callUser", "number " + number);
        Intent intent = new Intent(Intent.ACTION_CALL);
        intent.setData(Uri.parse("tel:" + number));
        startActivity(intent);
        final Handler handler = new Handler(Looper.getMainLooper());
        //Do something after 100ms
        handler.postDelayed(this::stopLoader, 100);

    }

    private void afterRideAcceptCancelFlag() {
        if (!(MapActivity.this).isFinishing()) {
            startLoader();
        }
        if (trackerMarker != null) {
            trackerMarker = null;
        }
        if (rideStartMarker != null) {
            rideStartMarker = null;
        }
        if (animateMarkerHandler != null) {
            animateMarkerHandler.removeCallbacksAndMessages(null);
        }
        FINDING_CAPTAIN = false;
        RideReceived = false;
        PICK_UP_TRACKING = false;
        MainApp.getInstance().Booking_REQUEST = false;
        CONFIRM_RIDE = false;
        SELECTED_RIDE = false;
        // markerPoints.remove(markerPoints.get(markerPoints.size() - 1));
        markerPoints.clear();
        routeConfirm = false;
        Driver_Selected_Ride = false;
        Driver_Start_Ride = false;
        RIDE_ACCEPTED = false;
        RIDE_STARTED = false;
        Resume_Ride_Tracking = false;
        binding.captainInfoLayout.captainInfo1.setVisibility(View.GONE);
        mGoogleMap.clear();
        pauseTimer();
        resetTimer();
        contractView2();
    }

    @SuppressLint("SetTextI18n")
    private void calculateEstTimeURL2(int finalTime, double finalDistance1, int counter) {
        // startLoader();
        Log.d("calculateEstTimeURL", "calculateEstTimeURL ");
        calculate_Time_counter = counter;

        Log.d("calculateEstTimeURL", "appVehicles " + appVehicles.size());
        Log.d("calculateEstTimeURL", "calculate_Time_counter " + calculate_Time_counter);

        /*if (appVehicles.size() == calculate_Time_counter) {

            //setVehicleListAdapter( finalTime, finalDistance1);
        }*/
        if (appVehicles.get(calculate_Time_counter).getLat() == null || appVehicles.get(calculate_Time_counter).getLng() == null ||
                appVehicles.get(calculate_Time_counter).getLat().equals("0") || appVehicles.get(calculate_Time_counter).getLng().equals("0")) {
            calculate_Time_counter++;
            if (calculate_Time_counter < appVehicles.size()) {

                Log.d("calculateEstTimeURL", "calculate_Time_counter " + calculate_Time_counter);
                calculateEstTimeURL2(finalTime, finalDistance1, calculate_Time_counter);
            } else {
                setVehicleListAdapter(finalTime, finalDistance1);
            }
            return;
        }
        Log.d("calculateEstTimeURL", "lat=== " + appVehicles.get(calculate_Time_counter).getLat());
        Log.d("calculateEstTimeURL", "lng== " + appVehicles.get(calculate_Time_counter).getLng());
        if (markerPoints.size() < 1) {
            return;
        }
        appVehicles2.add(appVehicles.get(calculate_Time_counter));
        String origin = markerPoints.get(0).latitude + "," + markerPoints.get(0).longitude;
        String dest = appVehicles2.get(calculate_Time_counter).getLat() + "," + appVehicles2.get(calculate_Time_counter).getLng();
        Log.d("calculateEstTimeURL", "origin " + origin);
        Log.d("calculateEstTimeURL", "dest " + dest);
        viewModel.directionResultRequest(origin, dest, "false", "driving", MAP_KEY);
        TIME_FLAG = false;
        viewModel.directionResultRepose().observe(this, directionResult -> {
            //  stopLoader();
            //Log.d("calculateDirectionsURL", "directionResultRepose");
            // Log.d("calculateDirectionsURL", "dataModelObject "+dataModelObject .toString());

            if (directionResult.getRoutes() != null) {
                //currentTripDuration = String.valueOf(directionResult.getRoutes().get(0).getLegs().get(0).getDistance().getText());
                // currentTripTime   = String.valueOf(directionResult.getRoutes().get(0).getLegs().get(0).getDuration().getText());
                //currentTripDuration = String.valueOf(result.routes[0].legs[0].duration);
                // currentTripTime = String.valueOf(result.routes[0].legs[0].distance);
                Log.d("calculateEstTimeURL", "if");
                //  Log.d("calculateEstTimeURL", "currentTripTime " + directionResult.getRoutes().get(0).getLegs().get(0).getDuration().getText());
                Log.d("calculateEstTimeURL", "currentTripDuration " + directionResult.getRoutes().get(0).getLegs().get(0).getDistance().getText());
                rideTime = String.valueOf(directionResult.getRoutes().get(0).getLegs().get(0).getDuration().getText());
                Log.d("calculateEstTimeURL", "rideTime " + rideTime);
                Log.d("calculateEstTimeURL", "calculate_Time_counter " + calculate_Time_counter);
                Log.d("calculateEstTimeURL", "appVehicles 2 size = " + appVehicles2.size());

                appVehicles2.get(calculate_Time_counter).setTime(rideTime);
                appVehicles2.get(calculate_Time_counter).setPartner_pickup_distance(
                        String.valueOf(directionResult.getRoutes().get(0).getLegs().get(0).getDistance().getText())
                );
                calculate_Time_counter++;
                if (calculate_Time_counter < appVehicles.size()) {

                    Log.d("calculateEstTimeURL", "calculate_Time_counter " + calculate_Time_counter);
                    calculateEstTimeURL2(finalTime, finalDistance1, calculate_Time_counter);
                } else {
                    setVehicleListAdapter(finalTime, finalDistance1);
                }
            } else {
                Log.d("calculateEstTimeURL", "else");
            }
        });
    }

    private void setVehicleListAdapter(int finalTime, double finalDistance1) {

        if (appVehicles == null) {
            SELECTED_RIDE = false;
            onBackPressed();
            stopLoader();
            showToast(MapActivity.this, "Currently No Partner available");
            return;
        }
       /* appVehicles.clear();
        appVehicles = appVehicles2;*/
        // binding.rideTypeLayout.recyclerView.startAnimation(animEnter);
        SelectRideItemAdapter mAdapter = new SelectRideItemAdapter(MapActivity.this, appVehicles, finalTime, finalDistance1, mGeoApiContext,
                markerPoints.get(0).latitude, markerPoints.get(0).longitude, vehicleType, SKIP_DROP_OFF);
        binding.rideTypeLayout.recyclerView.setAdapter(mAdapter);
      //  SELECTED_RIDE = true;
        binding.rideTypeLayout.recyclerView.setHasFixedSize(true);
        binding.rideTypeLayout.recyclerView.setLayoutManager(new LinearLayoutManager(MapActivity.this));
        binding.rideTypeLayout.rideType.setVisibility(View.VISIBLE);
        // Prepare the View for the animation
        stopLoader();
        mAdapter.setRideItemClickListener(position -> {
            Log.v("setRideItemClick", "getDiscount " + appVehicles.get(position).getDiscount());
            Log.v("setRideItemClick", "setRideItemClickListener " + appVehicles.get(position).getCarType());
            MainApp.getInstance().setPerKM(Double.parseDouble(appVehicles.get(position).getRate_per_kilometer()));
            MainApp.getInstance().setPerMint(Double.parseDouble(appVehicles.get(position).getRate_per_minute()));
            MainApp.getInstance().setVehicleRate(Double.parseDouble(appVehicles.get(position).getVehicleRate()));
            MainApp.getInstance().setTax_percentage(appVehicles.get(position).getTax_percentage());
            MainApp.getInstance().setPeak_factor_rate(appVehicles.get(position).getPeak_rate());
            MainApp.getInstance().setPeak_factor_rate(appVehicles.get(position).getMin_ride_fares());
            //if (appVehicles.get(position).getId().equalsIgnoreCase("1")) {
            binding.rideTypeLayout.selectRide.setText(String.format("Select %s", appVehicles.get(position).getCarType()));
            selectedRidePosition = position;
        });
    }


    @SuppressLint("NonConstantResourceId")
    public void navigationClick(View view) {
        Intent i;
        switch (view.getId()) {
            case R.id.navigation_button:
               /* binFding.drawerLayout.postDelayed(new Runnable() {
                    @Override
                    public void run() {*/
                // binding.drawerLayout.getLayoutTransition().enableTransitionType(LayoutTransition.APPEARING);

                //binding.mapNavigationLayout.navigationParentLayout.startAnimation(animSlidInRight);
                // binding.navigationView.startAnimation(animSlidInRight);
                binding.drawerLayout.openDrawer(GravityCompat.END);
              /*       }
               }, 300);*/

                Log.v("getUserFirstName", "getUserFirstName " + MainApp.getInstance().getUserData().getUserFirstName());
                if (MainApp.getInstance().getUserData() != null) {
                    binding.mapNavigationLayout.userNameTextView.setText(MainApp.getInstance().getUserData().getUserFirstName());
                }
                break;
            case R.id.your_rides:
                i = new Intent(MapActivity.this, RideHistoryListActivity.class);
                startActivity(i);
                finish();
                break;
            case R.id.setting:
                i = new Intent(MapActivity.this, SettingActivity.class);
                startActivity(i);
                finish();
                break;
            case R.id.oylaPay:
                binding.drawerLayout.closeDrawers();
                i = new Intent(MapActivity.this, DashBoardActivity.class);
                startActivity(i);
                finish();
                break;
            case R.id.help:
                binding.drawerLayout.closeDrawers();
                i = new Intent(MapActivity.this, WebPageActivity.class);
                i.putExtra("pageName", "getHelp");
                startActivity(i);
                break;
            case R.id.oylaPackages:
                binding.drawerLayout.closeDrawers();
                i = new Intent(MapActivity.this, WebPageActivity.class);
                i.putExtra("pageName", "reward");
                startActivity(i);
                break;
            default:
                break;
        }
    }

    public void zoomRoute(List<LatLng> lstLatLngRoute) {

        if (mGoogleMap == null || lstLatLngRoute == null || lstLatLngRoute.isEmpty()) return;
        LatLngBounds.Builder boundsBuilder = new LatLngBounds.Builder();
        for (LatLng latLngPoint : lstLatLngRoute) boundsBuilder.include(latLngPoint);
        /* int routePadding = 120;*/
        // int routePadding = 220;
        int routePadding = 220;
        LatLngBounds latLngBounds = boundsBuilder.build();
        // mGoogleMap.setLatLngBoundsForCameraTarget(latLngBounds);
        mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngBounds(latLngBounds, routePadding), 1500, null
        );
    }

    public static Bitmap createLayoutCustomMarker(Context context, @DrawableRes int resource, String time, Boolean bol) {
        @SuppressLint("InflateParams") View marker = ((LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.custom_marker_layout, null);
        ImageView markerImage;
        if (bol) {
            markerImage = marker.findViewById(R.id.pickUp);
            markerImage.setImageResource(resource);
            TextView waitTime = marker.findViewById(R.id.waitTime);
            waitTime.setText(time);
            //marker.findViewById(R.id.pickUpMarkerLayout).setVisibility(View.GONE);
            // marker.findViewById(R.id.arrivalImage).setVisibility(View.GONE);
            //marker.findViewById(R.id.arrivalTime).setVisibility(View.GONE);
            marker.findViewById(R.id.dropOffDurationLayout).setVisibility(View.GONE);

        } else {
            markerImage = marker.findViewById(R.id.arrivalImage);
            markerImage.setImageResource(resource);
            TextView arrivalTime = marker.findViewById(R.id.arrivalTime);
            arrivalTime.setText(time);
        }
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((Activity) context).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        marker.setLayoutParams(new ViewGroup.LayoutParams(52, ViewGroup.LayoutParams.WRAP_CONTENT));
        marker.measure(displayMetrics.widthPixels, displayMetrics.heightPixels);
        marker.layout(0, 0, displayMetrics.widthPixels, displayMetrics.heightPixels);
        marker.buildDrawingCache();
        Bitmap bitmap = Bitmap.createBitmap(marker.getMeasuredWidth(), marker.getMeasuredHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        marker.draw(canvas);
        return bitmap;
    }

    public String arrivalTime(int addHour, int addMinute) {
        Calendar now = Calendar.getInstance();
        Calendar tmp = (Calendar) now.clone();
        tmp.add(Calendar.HOUR_OF_DAY, addHour);
        tmp.add(Calendar.MINUTE, addMinute);
        String approxArrivalTime = formatDate.format(tmp.getTime());
        return formatDate.format(tmp.getTime());
    }

    private void cashOptionDialog() {
        boolean OYLA_PAY = SharedPrefManager.getInstance(MapActivity.this).getOylaPay();
        SharedPrefManager.getInstance(MapActivity.this).setCash(true);
        boolean CASH = SharedPrefManager.getInstance(MapActivity.this).getCash();
        int fareAmount = Integer.parseInt(appVehicles.get(selectedRidePosition).getFair());
        Log.v("CASH", "CASH " + CASH);
        // boolean CARD = SharedPrefManager.getInstance(MapActivity.this).getCard();
        final Dialog dialog = new Dialog(MapActivity.this, R.style.full_screen_dialog);
        //final Dialog dialog = new Dialog(AddCreditActivity.this);
        //dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.payment_method_dialog);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;

        SwitchCompat switchOylaPay = dialog.findViewById(R.id.switchOylaPay);
        TextView oylaCurrencyText = dialog.findViewById(R.id.oylaCurrencyText);
        TextView oylaPayText = dialog.findViewById(R.id.oylaPayText);
        ImageView oylaPayIcon = dialog.findViewById(R.id.oylaPayIcon);
        ImageView cashIcon = dialog.findViewById(R.id.cashIcon);
        ImageView cardIcon = dialog.findViewById(R.id.cardIcon);
        RadioGroup rGroup = dialog.findViewById(R.id.radioGroupPayOption);
        int d = Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(Constants.WALLET_AMOUNT))));
        if (d < 1) {
            oylaCurrencyText.setText("0");
        } else {
            oylaCurrencyText.setText(String.valueOf(Math.round(Double.parseDouble(Constants.WALLET_AMOUNT))));
        }
        //oylaCurrencyText.setText(String.valueOf(Math.round(Double.parseDouble(Constants.WALLET_AMOUNT))));
        switchOylaPay.setChecked(OYLA_PAY);
        if (OYLA_PAY) {
            changeOylaPayComponentColor(oylaCurrencyText, oylaPayText, oylaPayIcon, getResources().getColor(R.color.colorPrimary), R.color.colorPrimary);
        } else {
            changeOylaPayComponentColor(oylaCurrencyText, oylaPayText, oylaPayIcon, getResources().getColor(R.color.colorBlack3), R.color.colorBlack3);
        }
        if (CASH) {
            rGroup.check(R.id.radio_one);
            changeRadioGroupComponentColor(cashIcon, cardIcon);
        } else {
            rGroup.check(R.id.radio_two);
            changeRadioGroupComponentColor(cardIcon, cashIcon);
        }
        if (!(MapActivity.this).isFinishing()) {
            //show dialog
            dialog.show();
        }
        Window window = dialog.getWindow();
        assert window != null;
        //window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        //window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setGravity(Gravity.BOTTOM);
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        switchOylaPay.setOnCheckedChangeListener((buttonView, isChecked) -> {

            if (Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(Constants.WALLET_AMOUNT)))) == 0) {
                SharedPrefManager.getInstance(MapActivity.this).setOylaPay(false);
                switchOylaPay.setChecked(false);
                changeOylaPayComponentColor(oylaCurrencyText, oylaPayText, oylaPayIcon, getResources().getColor(R.color.colorBlack3), R.color.colorBlack3);
                binding.confirmRideLayout.payMethodCard.setText(getString(R.string.cash_text));
                binding.confirmRideLayout.rideTypePrice.setText(String.format("%s %s", getResources().getString(R.string.currency_text), appVehicles.get(selectedRidePosition).getFair()));
                return;
            }
            if (isChecked) {
                walletSum = fareAmount - Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(Constants.WALLET_AMOUNT))));
                Log.v("walletLOG", "walletSum " + walletSum);
                if (walletSum <= 0) {
                    Log.v("walletLOG", "Wallet ");
                    binding.confirmRideLayout.payMethodCard.setText(getString(R.string.wallet_text));
                    binding.confirmRideLayout.rideTypePrice.setText(String.format("%s 0", getResources().getString(R.string.currency_text)));
                } else {
                    binding.confirmRideLayout.payMethodCard.setText(getString(R.string.cash_plus_wallet));
                    binding.confirmRideLayout.rideTypePrice.setText(getResources().getString(R.string.currency_text) + " " + walletSum);
                    Log.v("walletLOG", "Wallet + Cash ");
                }

                changeOylaPayComponentColor(oylaCurrencyText, oylaPayText, oylaPayIcon, getResources().getColor(R.color.colorPrimary), R.color.colorPrimary);
            } else {
                Log.v("walletLOG", "Cash ");
                binding.confirmRideLayout.payMethodCard.setText(getString(R.string.cash_text));
                binding.confirmRideLayout.rideTypePrice.setText(String.format("%s %s", getResources().getString(R.string.currency_text), appVehicles.get(selectedRidePosition).getFair()));
                changeOylaPayComponentColor(oylaCurrencyText, oylaPayText, oylaPayIcon, getResources().getColor(R.color.colorBlack3), R.color.colorBlack3);
            }
            SharedPrefManager.getInstance(MapActivity.this).setOylaPay(isChecked);
        });

        rGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.radio_one) {
                SharedPrefManager.getInstance(MapActivity.this).setCash(true);
                changeRadioGroupComponentColor(cashIcon, cardIcon);
                //changeConfirmRideLayoutComponent();
            } else {
                changeRadioGroupComponentColor(cardIcon, cashIcon);
                SharedPrefManager.getInstance(MapActivity.this).setCash(false);
                //changeConfirmRideLayoutComponent();
            }
            changeConfirmRideLayoutComponent();
        });
    }

    private void changeConfirmRideLayoutComponent() {
        if (SharedPrefManager.getInstance(MapActivity.this).getCash()) {
            binding.confirmRideLayout.payMethodIcon.setBackground(ContextCompat.getDrawable(this, R.drawable.cash));
            binding.confirmRideLayout.payMethodCard.setText(getString(R.string.cash_text));
        } else {
            binding.confirmRideLayout.payMethodIcon.setBackground(ContextCompat.getDrawable(this, R.drawable.card_vocher));
            binding.confirmRideLayout.payMethodCard.setText(getString(R.string.card));
        }
    }

    public BitmapDescriptor bitmapDescriptorFromVector(Drawable drawable) {
        Canvas canvas = new Canvas();
        Log.v("bitmapDescriptor", "getIntrinsicWidth " + drawable.getIntrinsicWidth());
        Log.v("bitmapDescriptor", "getIntrinsicHeight " + drawable.getIntrinsicHeight());
        //  Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Bitmap bitmap = Bitmap.createBitmap(120, 120, Bitmap.Config.ARGB_8888);
        canvas.setBitmap(bitmap);
        //  drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
        drawable.setBounds(0, 0, 120, 120);
        drawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

    private void startGetDriverCoordinatesService() {
        if (!isGetDriverCoordinatesServiceRunning()) {
            Intent serviceIntent = new Intent(this, GetDriverCoordinates.class);
            serviceIntent.setAction(Constants.ACTION_START_FOREGROUND_SERVICE);
           /* if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                MapActivity.this.startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }*/
            // startService(serviceIntent);
        }
    }

    private boolean isGetDriverCoordinatesServiceRunning() {
        ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if ("com.oyla.passenger.services.location.GetDriverCoordinates".equals(service.service.getClassName())) {
                Log.d("GetDriverCoordinates", "GetDriverCoordinates service is already running.");
                return true;
            }
        }
        Log.d("GetDriverCoordinates", "GetDriverCoordinates: location service is not running.");
        return false;
    }

    private void discountDialog() {
        // final int[] error_count = {0};
        final Dialog dialog = new Dialog(MapActivity.this, R.style.full_screen_dialog);
        //final Dialog dialog = new Dialog(AddCreditActivity.this);
        //dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.add_promo_dialog);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        EditText enterVoucherEdiText = dialog.findViewById(R.id.enterPromoEdiText);
        TextInputLayout enterVoucherTextInput = dialog.findViewById(R.id.enterPromoTextInput);
        dialog.findViewById(R.id.cancelButton).setOnClickListener(v -> dialog.dismiss());
        dialog.findViewById(R.id.activateCode).setOnClickListener(V -> {
            //  error_count[0] = 1;
            if (enterVoucherEdiText.getText().toString().isEmpty()) {
                showError(Messages.EmptyMessage, enterVoucherTextInput, enterVoucherEdiText);
                // userData.setUserPassword(null);
            } else {
                viewModel.promoRequest(enterVoucherEdiText.getText().toString().trim());
                startLoader();
                viewModel.promoRepose().observe(this, dataModelObject -> {
                    stopLoader();
                    if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                        //Toast.makeText(getApplicationContext(), "Promo Activate Success fully " + dataModelObject.getData().getDiscount(), Toast.LENGTH_SHORT).show();
                        /*showPopup(MapActivity.this, "Promo Activate Successfully of " + dataModelObject.getData().getDiscount()
                                + " " + getResources().getString(R.string.currency_text));*/
                        DialogBoxSingleton.getInstance().showPopup(MapActivity.this, "Promo Activate Successfully of " + dataModelObject.getData().getDiscount()
                                + " " + getResources().getString(R.string.currency_text), true);
                        Constants.PROMO_ACTIVATE = true;
                        if (Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(Constants.WALLET_AMOUNT)))) < 0) {
                            int discount = Integer.parseInt(dataModelObject.getData().getDiscount());
                            int newWalletAmount = discount + Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(Constants.WALLET_AMOUNT))));
                            Constants.WALLET_AMOUNT = String.valueOf(newWalletAmount);
                        }
                        Log.v("OYLA_CHECK", "promo response Constants.PROMO_ACTIVATE  " + Constants.PROMO_ACTIVATE);
                    } else {
                        Constants.PROMO_ACTIVATE = false;
                        DialogBoxSingleton.getInstance().showErrorPopup(MapActivity.this, dataModelObject.getError());
                        if (dataModelObject.getError().getMessage() != null) {
                            // Toast.makeText(this, dataModelObject.getError().getMessage(),Toast.LENGTH_SHORT).show();
                            //  showToast(MapActivity.this, dataModelObject.getError().getMessage());
                            Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                        } else if (dataModelObject.getError().getMessages() != null) {
                            //showToast(MapActivity.this, dataModelObject.getError().getMessages().toString());
                            Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                        }
                    }
                    dialog.dismiss();
                });
            }
        });
        enterVoucherEdiText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s != null) {
                    removeError(enterVoucherTextInput);
                }
                Log.v("countcount", "count " + count);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        if (!(MapActivity.this).isFinishing()) {
            //show dialog
            dialog.show();
        }
        Window window = dialog.getWindow();
        assert window != null;
        //window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        //window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setGravity(Gravity.BOTTOM);
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    @Override
    public void onBackPressed() {
        Log.v("cancelBackPressed", "onBackPressed");
        Log.v("cancelBackPressed", "onBackPressed size " + markerPoints.size());
        Log.v("OPEN_RIDE_SHEET", "OPEN_RIDE_SHEET " + Constants.OPEN_RIDE_SHEET);
        if (binding.drawerLayout.isDrawerVisible(GravityCompat.END)) {
            binding.drawerLayout.closeDrawer(GravityCompat.END);
            Log.v("cancelBackPressed", "if");
        } else {
            Log.v("cancelBackPressed", "else");
            Log.v("drawer", "close ");
            if (!FINDING_CAPTAIN) {
                if (RideReceived) {
                    Intent myService = new Intent(MapActivity.this, GetDriverCoordinates.class);
                    myService.setAction(Constants.ACTION_STOP_FOREGROUND_SERVICE);
                    stopService(myService);
                    RideReceived = false;
                    super.onBackPressed();
                    finish();

                } else if (PICK_UP_TRACKING) {
                    mGoogleMap.clear();
                    MainApp.getInstance().Booking_REQUEST = false;
                    PICK_UP_TRACKING = false;
                    Intent myService = new Intent(MapActivity.this, GetDriverCoordinates.class);
                    myService.setAction(Constants.ACTION_STOP_FOREGROUND_SERVICE);
                    stopService(myService);
                    binding.captainInfoLayout.captainInfo1.setVisibility(View.GONE);
                } else if (CONFIRM_RIDE) {
                    binding.confirmRideLayout.confirmRide.setVisibility(View.VISIBLE);
                    mapLayoutBinding.pickupDropOffAddressCardView.setVisibility(View.VISIBLE);
                    binding.findCaptainLayout.mainLayout.setVisibility(View.GONE);
                    CONFIRM_RIDE = false;
                } else if (SELECTED_RIDE) {
                    SELECTED_RIDE = false;
                    binding.confirmRideLayout.confirmRide.setVisibility(View.GONE);
                    binding.rideTypeLayout.rideType2.startAnimation(animSlidInRight);
                    binding.rideTypeLayout.rideType.setVisibility(View.VISIBLE);
                    mapLayoutBinding.pickupDropOffAddressCardView.setVisibility(View.GONE);
                } else {
                    Log.v("cancelBackPressed", "mark point check");
                    if (markerPoints.size() > 1) {
                        Log.v("cancelBackPressed", "mark point size 2");
                        //markerPoints.clear();
                        // appVehicles.clear();
                        if (startLatLng != null) {
                            mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(markerPoints.get(1), DEFAULT_ZOOM));
                        }
                        mGoogleMap.clear();
                        markerPoints.remove(markerPoints.get(markerPoints.size() - 1));
                        // mGoogleMap.addMarker(options.position((LatLng) markerPoints.get(0)));
                        routeConfirm = false;
                        mapLayoutBinding.pickUpMarker.setVisibility(View.GONE);
                        mapLayoutBinding.dropOffMarker.setVisibility(View.VISIBLE);
                        mapLayoutBinding.pickupDropOffAddressCardView.setVisibility(View.VISIBLE);
                        mapLayoutBinding.pickupButton.setVisibility(View.GONE);
                        // mapLayoutBinding.pickupDropOffAddressCardView.startAnimation(animSlidInRight);
                        mapLayoutBinding.dropOffButton.startAnimation(animSlidInRight);
                        mapLayoutBinding.skipButton.startAnimation(animSlidInRight);
                        mapLayoutBinding.dropOffButton.setVisibility(View.VISIBLE);
                        mapLayoutBinding.skipButton.setVisibility(View.VISIBLE);
                        mapLayoutBinding.pickupDropOffMessage.setVisibility(View.VISIBLE);
                        mapLayoutBinding.dropOffAddressTextLayout.setVisibility(View.VISIBLE);
                        mapLayoutBinding.dropOffSideImage.setVisibility(View.VISIBLE);
                        mapLayoutBinding.pickupDropOffMessage.setText(getResources().getString(R.string.drop_off_message));
                   /* if (startLatLng != null) {
                        mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(startLatLng, DEFAULT_ZOOM));
                    }*/
                        binding.rideTypeLayout.rideType.setVisibility(View.GONE);
                    } else if (markerPoints.size() > 0) {
                        Log.v("cancelBackPressed", "mark point size 1");
                        mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(markerPoints.get(0), DEFAULT_ZOOM));
                        markerPoints.clear();
                        mGoogleMap.clear();
                        routeConfirm = false;
                        mapLayoutBinding.pickupDropOffMessage.setVisibility(View.VISIBLE);
                        mapLayoutBinding.mapExtraButton.setVisibility(View.VISIBLE);
                        mapLayoutBinding.pickUpMarker.setVisibility(View.VISIBLE);
                        mapLayoutBinding.dropOffMarker.setVisibility(View.GONE);
                        mapLayoutBinding.pickupButton.setVisibility(View.VISIBLE);
                        mapLayoutBinding.pickupDropOffAddressCardView.setVisibility(View.VISIBLE);
                        // mapLayoutBinding.pickupButton.startAnimation(animSlidInRight);
                        mapLayoutBinding.pickupButton.setVisibility(View.VISIBLE);
                        mapLayoutBinding.dropOffButton.setVisibility(View.GONE);
                        mapLayoutBinding.skipButton.setVisibility(View.GONE);
                        mapLayoutBinding.pickupDropOffMessage.setText(getResources().getString(R.string.pickup_message));
                        mapLayoutBinding.topBackButtonImage.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.page_9_close));
                 /*   if (startLatLng != null) {
                        mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(startLatLng, DEFAULT_ZOOM));

                    }*/
                        mapLayoutBinding.dropOffAddressTextLayout.setVisibility(View.GONE);
                        mapLayoutBinding.dropOffSideImage.setVisibility(View.GONE);
                        mapLayoutBinding.pickUpSideImage.setVisibility(View.VISIBLE);
                        pickUpAddressBol = true;
                        dropOffAddressBol = false;
                        startGetNearestDriverService();
                        outstandingBalance();
                    } else {
                        Log.v("cancelBackPressed", "mark point size 0");
                   /* if (binding.drawerLayout.isDrawerOpen(GravityCompat.START)) {
                        binding.drawerLayout.closeDrawer(GravityCompat.START);
                    }*/// else {
                        Intent myService = new Intent(MapActivity.this, NearestDriverCoordinates.class);
                        myService.setAction(Constants.ACTION_STOP_FOREGROUND_SERVICE);
                        stopService(myService);
                        if (nearestRiderMarker != null) {
                            nearestRiderMarker = null;
                        }
                        finish();
                        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
                        //   super.onBackPressed();
                        // }
                    }
                }
            } else {
                Log.v("cancelBackPressed", "cancelRideApiResponse else");
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        // outstandingBalance();
        mapLayoutBinding.mapView.onResume();
        bookingStatusData = getIntent().getParcelableExtra("bookingStatusData");
        vehicleType = getIntent().getStringExtra("vehicleType");
        //resetRideFlowTag(false, false, false);
        typeID = getIntent().getStringExtra("typeID");
       /* Log.v("typeID", "typeID " + typeID);
        Log.v("refreshRide", "FINDING_CAPTAIN " + FINDING_CAPTAIN);
        Log.v("refreshRide", "RideReceived " + RideReceived);*/
       /* driverStatus = getIntent().getStringExtra("driverStatus");
        rideStatus = getIntent().getStringExtra("rideStatus");*/
     /*   m_gpsChangeReceiver = new GpsChangeReceiver();
        this.registerReceiver(m_gpsChangeReceiver, new IntentFilter(LocationManager.PROVIDERS_CHANGED_ACTION));*/
        if (MainApp.getInstance().getUserData() == null || MainApp.getInstance().getUserData().getUserId() == null) {
            Constants.Auth = Constants.Bearer + " " + SharedPrefManager.getInstance(getApplicationContext()).getUserInfo().getAccessToken();
            Log.v("refreshRide", "user model null ");
            UserData userData = SharedPrefManager.getInstance(getApplicationContext()).getUserInfo();
            viewModel.sendRefreshTokenRequest(userData.getUserId());
            startLoader();
            viewModel.receiveRefreshTokenRepose().observe(this, dataModelObject -> {
                stopLoader();
                if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                    MainApp.getInstance().setUserData(dataModelObject.getData().getUser());
                } else {
                    if (dataModelObject.getError().getMessage() != null) {
                        // showToast(SettingActivity.this, dataModelObject.getError().getMessage());
                        Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                    } else if (dataModelObject.getError().getMessages() != null) {
                        // showToast(SettingActivity.this, dataModelObject.getError().getMessages().toString());
                        Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                    }
                }
                onResume();
            });
        } else {
            refreshTracking();
        }
    }

    private void refreshTracking() {
        if (FINDING_CAPTAIN || RideReceived) {
            // Gson gson = new Gson();
            Log.v("RideBookingService", " refreshRide ");
            // startRideBookingStatusService();
            Log.v("refreshRide", " if FINDING_CAPTAIN " + FINDING_CAPTAIN);
            Log.v("refreshRide", " if RideReceived " + RideReceived);
            Log.v("refreshRide", " CHANGE_ADDRESS " + CHANGE_ADDRESS);
            Log.v("refreshRide", " SHOW_FINISH_DIALOG " + SHOW_FINISH_DIALOG);

            viewModel.bookingStatusRequest(MainApp.getInstance().getUserData().getUserId());
            viewModel.bookingStatusRepose().observe(this, dataModelObject -> {
                if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                    if (!CHANGE_ADDRESS) {
                        //Log.v("refreshRide", "if CHANGE_ADDRESS " + CHANGE_ADDRESS);
                        bookingStatusData = dataModelObject.getData().getBookingInfo();
                        SKIP_DROP_OFF = bookingStatusData.getIs_skip_dropoff();
                        //String fdis = String.valueOf(Math.round(Double.parseDouble(bookingStatusData.getFinal_amount())));
                        Log.v("refreshRide", "if SKIP_DROP_OFF " + SKIP_DROP_OFF);
                        //  Log.v("refreshRide", "if fdis " + fdis);
                        // Log.v("refreshRide", "if getTemp_id " + bookingStatusData.getTemp_id());
                        typeID = dataModelObject.getData().getBookingInfo().getVehicle_type_id();
                        MainApp.getInstance().setDataList(dataModelObject.getData());
                        mGoogleMap.clear();
                        /* startRideBookingStatusService();*/
                        if (FINDING_CAPTAIN) {
                            //  Log.v("refreshRide","if bookingStatusData.getTemp_id() "+bookingStatusData.getTemp_id());
                            //  Log.v("refreshRide","MainApp.getInstance().getBookingInfoData().getTemp_id() "+MainApp.getInstance().getBookingInfoData().getTemp_id());
                            if (bookingStatusData.getTemp_id() != null && bookingStatusData.getTemp_id().equalsIgnoreCase(MainApp.getInstance().getBookingInfoData().getTemp_id())) {
                                pauseTimer();
                                Log.v("refreshRide", " inner FINDING_CAPTAIN " + FINDING_CAPTAIN);
                                //resumeRideTracking();
                                startTrackigActivity();
                            }
                        } else if (RideReceived) {
                            pauseTimer();
                            resetTimer();
                            SHOW_FINISH_DIALOG = true;
                            Log.v("refreshRide", "inner SHOW_FINISH_DIALOG " + RideReceived);
                            //resumeRideTracking();
                            startTrackigActivity();

                        }
                    }
                } else {
                    // ((BaseActivity) getActivity()).showToast(getActivity(), dataModelObject.getError().getMessage());
                    // Log.v("bookingStatusRepose", "error " + dataModelObject.getError().getMessage());
                    if (dataModelObject.getError().getMessage() != null) {
                        //  showToast(MapActivity.this, dataModelObject.getError().getMessage());
                        Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                    } else if (dataModelObject.getError().getMessages() != null) {
                        //  showToast(MapActivity.this, dataModelObject.getError().getMessages().toString());
                        Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                    }
                }
            });
        } else {
            outstandingBalance();
        }
    }

    private void cancelRideApiResponse() {
        ZOOM_ROUTE = true;
        Constants.TRACK_ZOOM = DEFAULT_ZOOM;
        Log.v("cancelRideApiResponse", "cancelRideApiResponse ");
        viewModel.receiveCancelRideRepose().observe(this, dataModelObject -> {
            stopLoader();
            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                SHOW_POLYLINE = false;
                //if(isGetDriverCoordinatesServiceRunning()){
                Intent myService = new Intent(MapActivity.this, GetDriverCoordinates.class);
                myService.setAction(Constants.ACTION_STOP_FOREGROUND_SERVICE);
                stopService(myService);
                //  }
                Log.v("cancelRideApiResponse", "cancelRideApiResponse 1 ");
                SharedPreferences sharedPreferences2 = MapActivity.this.getSharedPreferences("Driver_Info", 0);
                sharedPreferences2.edit().remove("Driver_Info_Object").apply();
                SharedPrefManager.getInstance(MapActivity.this).removeBookingInfo();
                Log.v("cancelRideApiResponse", "cancelRideApiResponse 2");
                if (MainApp.getInstance() != null) {
                    MainApp.getInstance().setDriverCoordinate(null);
                }
                showToastLong(MapActivity.this, "Ride has been Cancel");
                AFTER_RIDE_CANCEL = false;
                FIND_CAPTAIN_CANCEL = false;
                RideReceived = false;
                FINDING_CAPTAIN = false;
                SHOW_FINISH_DIALOG = false;
                dataList = null;
                Constants.FIRE_BASE_NOTIFY = false;
                MainApp.getInstance().setDataList(null);
                onBackPressed();
            } else {
                if (dataModelObject.getError().getMessage() != null) {
                    showToast(MapActivity.this, dataModelObject.getError().getMessage());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                } else if (dataModelObject.getError().getMessages() != null) {
                    showToast(MapActivity.this, dataModelObject.getError().getMessages().toString());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                }
                // showToast(MapActivity.this, dataModelObject.getError().getMessage());
            }
        });
    }

    @Override
    public void onLocationSelect(String place) {
        Log.v("onLocationSelect", "onLocationSelect " + place);
        Log.v("onLocationSelect", "DROP_OFF_ADDRESS " + DROP_OFF_ADDRESS);
        Log.v("onLocationSelect", "PICK_UP_ADDRESS " + PICK_UP_ADDRESS);
        if (PICK_UP_ADDRESS) {
            mapLayoutBinding.pickupAddressText.setText(place);
        } else {
            mapLayoutBinding.dropOffAddressText.setText(place);
        }
        List<Address> addressList;
        try {
            Geocoder geocoder = new Geocoder(getApplicationContext());
            addressList = geocoder.getFromLocationName(place, 5);
            Address location = addressList.get(0);
            Log.v("onLocationSelect", "location.getLatitude() " + location.getLatitude());
            Log.v("onLocationSelect", "location.getLongitude() " + location.getLongitude());
            LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
            mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, DEFAULT_ZOOM));

        } catch (Exception e) {
            e.printStackTrace();
        }
        // Address location = addressList.get(0);
        // Log.v("SearchLocationActivity", "SearchLocationActivity " + location.getAddressLine(0) + "\n" + location.getLatitude() + "\n" + location.getLongitude());
    }

    private void startTimer() {
        mCountDownTimer = new CountDownTimer(mTimeLeftInMillis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                mTimeLeftInMillis = millisUntilFinished;
                progressStatus += 1000;
                //binding.findCaptainLayout.findCaptainProgressBar.setProgress(progressStatus);
                Log.v("mTimeLeftInMillis", "mTimeLeftInMillis " + mTimeLeftInMillis);
                Log.v("mTimeLeftInMillis", "millisUntilFinished " + millisUntilFinished);
                Log.v("mTimeLeftInMillis", "startTimer Constants.FIRE_BASE_NOTIFY " + Constants.FIRE_BASE_NOTIFY);
                //  binding.findCaptainLayout.findCaptainProgressBar.setProgress(mTimeLeftInMillis);
               /* new Thread(new Runnable() {
                    @Override
                    public void run() {
                        while(progressStatus < 100){
                            // Update the progress status
                            progressStatus +=1;

                            // Try to sleep the thread for 20 milliseconds
                            try{
                                Thread.sleep(20);
                            }catch(InterruptedException e){
                                e.printStackTrace();
                            }

                            // Update the progress bar
                            handler.post(() -> {
                                binding.findCaptainLayout.findCaptainProgressBar.setProgress(progressStatus);
                                // Show the progress on TextView
                            });
                        }
                    }
                }).start();*/
            }

            @Override
            public void onFinish() {
                Log.v("mTimeLeftInMillis", "onFinish Constants.FIRE_BASE_NOTIFY " + Constants.FIRE_BASE_NOTIFY);
                if (!Constants.FIRE_BASE_NOTIFY) {
                    Log.v("mTimeLeftInMillis", "onFinish ");
                    mTimerRunning = false;
                    showToast(MapActivity.this, "No captain Found");
                    viewModel.sendCancelRideRequest(MainApp.getInstance().getUserData().getUserId(), "", "time out", "empty");
                    pauseTimer();
                    RideReceived = false;
                    // CONFIRM_RIDE=false;
                    FINDING_CAPTAIN = false;
                    PICK_UP_TRACKING = false;
                    //Log.v("refreshRide", "onFinish FINDING_CAPTAIN " + FINDING_CAPTAIN);
                    //  Log.v("refreshRide", "onFinish RideReceived " + RideReceived);
                    resetTimer();
                    if (!(MapActivity.this).isFinishing()) {
                        startLoader();
                        //show dialog
                    }
                    cancelRideApiResponse();
                }

                // mTimeLeftInMillis = START_TIME_IN_MILLIS;
                //nextActivity(NumberVerificationActivity.this, SignUpActivity.class);
               /* mButtonStartPause.setText("Start");
                mButtonStartPause.setVisibility(View.INVISIBLE);
                mButtonReset.setVisibility(View.VISIBLE);*/
            }
        }.start();
        mTimerRunning = true;
      /*  mButtonStartPause.setText("pause");
        mButtonReset.setVisibility(View.INVISIBLE);*/
    }

    private void pauseTimer() {
        mTimeLeftInMillis = START_TIME_IN_MILLIS;
        if (mCountDownTimer != null) {
            mCountDownTimer.cancel();
            mTimerRunning = false;
        }
    }

    private void resetTimer() {
        mTimeLeftInMillis = START_TIME_IN_MILLIS;
    }

    private void calculateTimeAndDistanceURL(List<LatLng> latLngList, boolean trip) {
        String origin = latLngList.get(0).latitude + "," + latLngList.get(0).longitude;
        String dest = latLngList.get(1).latitude + "," + latLngList.get(1).longitude;
        viewModel.directionResultRequest(origin, dest, "false", "driving", MAP_KEY);
        viewModel.directionResultRepose().observe(this, directionResult -> {
            //   stopLoader();
            //Log.d("calculateDirectionsURL", "directionResultRepose");
            // Log.d("calculateDirectionsURL", "dataModelObject "+dataModelObject .toString());

            if (directionResult.getRoutes() != null) {
                //currentTripDuration = String.valueOf(result.routes[0].legs[0].duration);
                // currentTripTime = String.valueOf(result.routes[0].legs[0].distance);
                Log.d("ChangedropOff", "if");
               /* currentTripDuration = String.valueOf(directionResult.getRoutes().get(0).getLegs().get(0).getDistance().getText());
                currentTripTime = String.valueOf(directionResult.getRoutes().get(0).getLegs().get(0).getDuration().getText());*/
                if (trip) {
                    trip_one_distance = String.valueOf(directionResult.getRoutes().get(0).getLegs().get(0).getDistance().getText());
                    trip_one_duration = String.valueOf(directionResult.getRoutes().get(0).getLegs().get(0).getDuration().getText());
                    Log.d("changeDropOff", "calculateTimeAndDistance: duration: trip_one_distance " + trip_one_distance);
                    Log.d("changeDropOff", "calculateTimeAndDistance: distance: trip_one_duration " + trip_one_duration);
                    markerPoints.remove(markerPoints.get(markerPoints.size() - 1));
                    markerPoints.add(centerLatLng);
                    //SharedPrefManager.getInstance(MapActivity.this).setDropLat(centerLatLng.latitude);
                    // SharedPrefManager.getInstance(MapActivity.this).setDropLng(centerLatLng.longitude);
                    newMarkerPoints.add(newLatLng);
                    newMarkerPoints.add(centerLatLng);
                    calculateTimeAndDistanceURL(newMarkerPoints, false);
                    //  directionsApiRequest.cancel();
                } else {
                    trip_two_distance = String.valueOf(directionResult.getRoutes().get(0).getLegs().get(0).getDistance().getText());
                    trip_two_duration = String.valueOf(directionResult.getRoutes().get(0).getLegs().get(0).getDuration().getText());
                    //trip_two_distance = String.valueOf(result.routes[0].legs[0].distance).trim();
                    // trip_two_duration = String.valueOf(result.routes[0].legs[0].duration).trim();
                    Log.d("changeDropOff", "calculateTimeAndDistance: duration: trip_two_distance " + trip_two_distance);
                    Log.d("changeDropOff", "calculateTimeAndDistance: distance: trip_two_duration " + trip_two_duration);
                    // directionsApiRequest.cancel();
                    ChangeDestination();
                }
                //drawPolyLineOnMap(directionResult.getRoutes().get(0).getLegs());
            } else {
                Log.d("calculateDirectionsURL", "else");
            }
        });
    }

    private void pickUpButtonClick() {
        if (mapLayoutBinding.pickupAddressText.getText().toString().equalsIgnoreCase("Finding Address...") || mapLayoutBinding.pickupAddressText.getText().toString().isEmpty()) {
            return;
        }
        if (centerLatLng == null) {
            return;
        }
        if (isgetNearestDriverServiceRunning()) {
            Intent myService = new Intent(MapActivity.this, NearestDriverCoordinates.class);
            myService.setAction(Constants.ACTION_STOP_FOREGROUND_SERVICE);
            stopService(myService);
            if (nearestRiderMarker != null) {
                nearestRiderMarker = null;
            }
        }
        mGoogleMap.clear();
        // markerPoints.clear();
        mapLayoutBinding.pickupButton.setVisibility(View.GONE);
        //  mapLayoutBinding.pickupButton.startAnimation(animRestRight);
        mapLayoutBinding.dropOffButton.setVisibility(View.VISIBLE);
        mapLayoutBinding.skipButton.setVisibility(View.VISIBLE);
        // SharedPrefManager.getInstance(MapActivity.this).setPickLat(centerLatLng.latitude);
        //  SharedPrefManager.getInstance(MapActivity.this).setPickLng(centerLatLng.longitude);
        // Log.d("pointRoute", "centerLatLng PickUp " + centerLatLng.latitude + "," + centerLatLng.longitude);
        markerPoints.add(centerLatLng);
        // Log.d("pointRoute", " markerPoints PickUp " + markerPoints.get(0).latitude + "," + markerPoints.get(0).longitude);
        mapLayoutBinding.pickUpMarker.setVisibility(View.GONE);
        mapLayoutBinding.dropOffMarker.setVisibility(View.VISIBLE);
        if (startLatLng != null) {
            // if(startLatLng.latitude!=null && startLatLng.longitude !=null){
            mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(startLatLng, DEFAULT_ZOOM));
            //mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(startLatLng, DEFAULT_ZOOM));
            // }
        }
        //drawCircle();
        mapLayoutBinding.pickupDropOffMessage.setText(getResources().getString(R.string.drop_off_message));
        //slideDown(mapLayoutBinding.parentAddressLayout);
        mapLayoutBinding.dropOffAddressTextLayout.setVisibility(View.VISIBLE);
        mapLayoutBinding.dropOffAddressTextLayout.startAnimation(animEnter);
        mapLayoutBinding.dropOffSideImage.setVisibility(View.VISIBLE);
        mapLayoutBinding.pickUpSideImage.setVisibility(View.GONE);
        mapLayoutBinding.topBackButtonImage.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.page12_back));
        //findViewById(R.id.top_back_button_image).setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.page12_back));
        pickUpAddressBol = false;
        dropOffAddressBol = true;
        mapLayoutBinding.outstandingBalance.setVisibility(View.GONE);
    }

    private void dropOffButtonClick() {
        mapLayoutBinding.dropOffAddressTextLayout.setVisibility(View.VISIBLE);
        mapLayoutBinding.dropOffSideImage.setVisibility(View.VISIBLE);
        if (mapLayoutBinding.dropOffAddressText.getText().toString().equalsIgnoreCase("Finding Address...") || mapLayoutBinding.dropOffAddressText.getText().toString().isEmpty()) {
            mapLayoutBinding.dropOffAddressText.setText(getStringAddress(centerLatLng.latitude, centerLatLng.longitude));
            //  Log.d(" dropOffButtonClick", "______________________ ");
            // Log.d(" dropOffButtonClick", "______________________1111 ");
            return;
        }
        if (isgetNearestDriverServiceRunning()) {
            Intent myService = new Intent(MapActivity.this, NearestDriverCoordinates.class);
            myService.setAction(Constants.ACTION_STOP_FOREGROUND_SERVICE);
            stopService(myService);
            if (nearestRiderMarker != null) {
                nearestRiderMarker = null;
            }
        }
        routeConfirm = true;
        mapLayoutBinding.dropOffButton.setVisibility(View.GONE);
        mapLayoutBinding.skipButton.setVisibility(View.GONE);
        // SharedPrefManager.getInstance(MapActivity.this).setDropLat(centerLatLng.latitude);
        // SharedPrefManager.getInstance(MapActivity.this).setDropLng(centerLatLng.longitude);
        // Log.d("pointRoute", "centerLatLng DropOff " + centerLatLng.latitude + "," + centerLatLng.longitude);
        //Log.d("pointRoute", "______________________ ");
        markerPoints.add(centerLatLng);
        mapLayoutBinding.pickUpMarker.setVisibility(View.GONE);
        mapLayoutBinding.dropOffMarker.setVisibility(View.GONE);
        mapLayoutBinding.pickupDropOffMessage.setVisibility(View.GONE);
        mapLayoutBinding.pickupDropOffAddressCardView.setVisibility(View.GONE);
        // calculateDirections(markerPoints);

        Log.d("pointRoute", "markerPoints origin " + markerPoints.get(0).latitude + "," + markerPoints.get(0).longitude);
        Log.d("pointRoute", "markerPoints dest " + markerPoints.get(1).latitude + "," + markerPoints.get(1).longitude);
        Log.d("pointRoute", "______________________ ");
        //List<Address> addresses = getStringAddress2(centerLatLng.latitude, centerLatLng.longitude);
        //city = addresses.get(0).getLocality();
        SKIP_DROP_OFF = 0;
        PICK_UP_TRACKING = false;
        RIDE_ACCEPTED = false;
        calculateDirectionsURL(markerPoints);
    }

    private void skipDropOffButtonClick() {
        if (isgetNearestDriverServiceRunning()) {
            Intent myService = new Intent(MapActivity.this, NearestDriverCoordinates.class);
            myService.setAction(Constants.ACTION_STOP_FOREGROUND_SERVICE);
            stopService(myService);
            if (nearestRiderMarker != null) {
                nearestRiderMarker = null;
            }
        }
        mapLayoutBinding.dropOffAddressTextLayout.setVisibility(View.GONE);
        mapLayoutBinding.dropOffSideImage.setVisibility(View.GONE);
        mapLayoutBinding.dropOffButton.setVisibility(View.GONE);
        mapLayoutBinding.skipButton.setVisibility(View.GONE);
        mapLayoutBinding.pickUpMarker.setVisibility(View.GONE);
        mapLayoutBinding.dropOffMarker.setVisibility(View.GONE);
        mapLayoutBinding.pickupDropOffMessage.setVisibility(View.GONE);
        mapLayoutBinding.pickupDropOffAddressCardView.setVisibility(View.GONE);
        binding.mapLayout.pickUpSideImage.setVisibility(View.VISIBLE);
        markerPoints.add(centerLatLng);
        //  List<Address> addresses = getStringAddress2(centerLatLng.latitude, centerLatLng.longitude);
        // city = addresses.get(0).getLocality();
        SKIP_DROP_OFF = 1;
        selectRideType("0", "0", "0");
        //calculateDirectionsURL(markerPoints);
    }

    private void startTrackigActivity() {
        Intent myService = new Intent(MapActivity.this, RideBookingStatus.class);
        myService.setAction(Constants.ACTION_STOP_FOREGROUND_SERVICE);
        stopService(myService);
        if (isgetNearestDriverServiceRunning()) {
            myService = new Intent(MapActivity.this, NearestDriverCoordinates.class);
            myService.setAction(Constants.ACTION_STOP_FOREGROUND_SERVICE);
            stopService(myService);
            if (nearestRiderMarker != null) {
                nearestRiderMarker = null;
            }
        }
        Intent i = new Intent(MapActivity.this, TrackingActivity.class);
        i.putExtra("bookingStatusData", bookingStatusData);
        i.putExtra("vehicleType", "car");
        i.putExtra("typeID", typeID);
        //getActivity().overridePendingTransition(R.anim.animation_leave,R.anim.animation_enter);
        // i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(i);
        finish();
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }


    private void resumeAfterTrackingView() {
        RideReceived = false;
        routeConfirm = false;
        Resume_Ride_Tracking = false;
        mapLayoutBinding.mapExtraButton.setVisibility(View.VISIBLE);
        mapLayoutBinding.pickupDropOffMessage.setVisibility(View.VISIBLE);
        mapLayoutBinding.pickupDropOffAddressCardView.setVisibility(View.VISIBLE);
        mapLayoutBinding.pickUpMarker.setVisibility(View.VISIBLE);
        mapLayoutBinding.pickupButton.setVisibility(View.VISIBLE);
    }

    private void checkBookingStatus() {
        //startLoader();
        viewModel.bookingStatusRequest(MainApp.getInstance().getUserData().getUserId());
        viewModel.bookingStatusRepose().observe(this, dataModelObject -> {
            //  stopLoader();
            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                bookingStatusData = dataModelObject.getData().getBookingInfo();
                captainInfoScreen();
            } else {
                // ((BaseActivity) getActivity()).showToast(getActivity(), dataModelObject.getError().getMessage());
                //Log.v("bookingStatusRepose", "error " + dataModelObject.getError().getMessage());
                if (dataModelObject.getError().getMessage() != null) {
                    //showToast(MapActivity.this, dataModelObject.getError().getMessage());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                } else if (dataModelObject.getError().getMessages() != null) {
                    //showToast(MapActivity.this, dataModelObject.getError().getMessages().toString());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                }
            }
        });
    }

    private void animateMarkerTo(final Marker marker, final double lat, final double lng) {
        animateMarkerHandler = new Handler(Looper.getMainLooper());
        //animateMarkerHandler = new Handler();
        final long start = SystemClock.uptimeMillis();
        final long DURATION_MS = 5000;
        //final long DURATION_MS = 30000;
        final Interpolator interpolator = new AccelerateDecelerateInterpolator();
        final LatLng startPosition = marker.getPosition();
        BEARING_FLAG = true;
        animateMarkerHandler.post(new Runnable() {
            @Override
            public void run() {
                float elapsed = SystemClock.uptimeMillis() - start;
                float t = elapsed / DURATION_MS;
                float v = interpolator.getInterpolation(t);
                double currentLat = (lat - startPosition.latitude) * v + startPosition.latitude;
                double currentLng = (lng - startPosition.longitude) * v + startPosition.longitude;
                marker.setPosition(new LatLng(currentLat, currentLng));
                marker.setFlat(true);
                marker.setAnchor(0.5f, 0.5f);
                // if animation is not finished yet, repeat
                if (t < 1) {
                    animateMarkerHandler.postDelayed(this, 16);
                }
            }
        });
    }

    @Override
    public void getNearestDriver() {
        Log.v("NearestDriverCoordinate", "getNearestDriver  ");
        nearDriver();
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    private void nearDriver() {
        float bearingNearCar = 0;
        if (nearestDriversData == null) {
            mGoogleMap.clear();
            return;
        }

        if (nearestDriversData.size() > 0) {
            Log.v("NearestDriverCoordinate", "Total nearest " + nearestDriversData.size());
            Log.v("NearestDriverCoordinate", "-------------------------------- ");
            if (mGoogleMap != null) {
                mGoogleMap.clear();
                nearestRiderMarker = null;
            }
           /* if (animateMarkerHandler != null) {
                animateMarkerHandler = null;
            }*/
            // nearDriverAnimateMarker();
            showKmOnMarker();
            for (int j = 0; j < nearestDriversData.size(); j++) {
                // dataModelObject.getData().getDrivers();
                Log.v("NearestDriverCoordinate", "getDriver_id " + nearestDriversData.get(j).getDriver_id());
                Log.v("NearestDriverCoordinate", "getStatus " + nearestDriversData.get(j).getStatus());
                Log.v("NearestDriverCoordinate", "getBearing " + nearestDriversData.get(j).getBearing());


                LatLng driverMarker;
                driverMarker = new LatLng(Double.parseDouble(nearestDriversData.get(j).getLat()), Double.parseDouble(nearestDriversData.get(j).getLng()));

                if (mGoogleMap == null) {
                    return;
                }
               /* if(!nearestDriversData.get(j).getDriver_id().equals("11479")){
                   return;
                }*/
                if (nearestDriversData.get(j).getBearing() != null && !nearestDriversData.get(j).getBearing().isEmpty()) {
                    // Log.v("NearestDriverCoordinate", " bearing " + nearestDriversData.get(j).getBearing());
                    bearingNearCar = Float.parseFloat(nearestDriversData.get(j).getBearing());
                }
                // if (nearestRiderMarker == null) {
                // Log.v("NearestDriverCoordinate", "nearestRiderMarker null ");

                nearestRiderMarker = mGoogleMap.addMarker(new MarkerOptions()
                        .position(driverMarker)
                        //.title(nearestDriversData.get(j).getDriver_id())
                        //.flat(true)
                        // .anchor(100.5f, 100.5f)
                        .rotation(bearingNearCar));
                   if(typeID==null){
                       typeID="10";
                   }

                if (nearestDriversData.get(j).getVehicle_cat_id().equalsIgnoreCase("10")) {
                    if (typeID.equalsIgnoreCase("10")) {
                        nearestRiderMarker.setIcon(bitmapDescriptorFromVector(getResources().getDrawable(R.drawable.bike_map, null)));
                    } else {
                        nearestRiderMarker.remove();
                    }

                } else {
                    if (typeID.equalsIgnoreCase("1")) {
                        nearestRiderMarker.setIcon(bitmapDescriptorFromVector(getResources().getDrawable(R.drawable.aerial_car, null)));
                    } else {
                        nearestRiderMarker.remove();
                    }
                }
                //}else{
                //   rotateMarker(nearestRiderMarker, bearingNearCar);
                //   Log.v("NearestDriverCoordinate", "nearestRiderMarker  not null ");
                // }

                Log.v("NearestDriverCoordinate", "-------------------------------- ");
                Log.v("NearestDriverCoordinate", "-------------------------------- ");
            }

            nearestDriversData.clear();
        } else {
            mGoogleMap.clear();
            nearestRiderMarker = null;
        }
    }

    private void startRideBookingStatusService() {
        // Log.v("newToken", "startgetNearestDriverService  ");
        Log.v("RideBookingService", "isRideBookingStatusServiceRunning()  " + isRideBookingStatusServiceRunning());
        if (!isRideBookingStatusServiceRunning()) {
            Intent serviceIntent = new Intent(this, RideBookingStatus.class);
            serviceIntent.setAction(Constants.ACTION_START_FOREGROUND_SERVICE);
            startService(serviceIntent);

            /*if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                MapActivity.this.startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }*/
        }
    }

    private boolean isRideBookingStatusServiceRunning() {
        ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if ("com.oyla.passenger.services.RideBookingStatus".equals(service.service.getClassName())) {
                Log.d("RideBookingService", "RideBookingStatusService service is already running.");
                return true;
            }
        }
        Log.d("RideBookingService", "RideBookingStatusService:  service is not running.");
        return false;
    }

    private void startGetNearestDriverService() {
        // Log.v("newToken", "startgetNearestDriverService  ");
        Log.v("newToken", "isgetNearestDriverServiceRunning()  " + isgetNearestDriverServiceRunning());
        if (!isgetNearestDriverServiceRunning()) {
            Intent serviceIntent = new Intent(this, NearestDriverCoordinates.class);
            serviceIntent.setAction(Constants.ACTION_START_FOREGROUND_SERVICE);
            startService(serviceIntent);
            /*if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                MapActivity.this.startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }*/
        }
    }

    private boolean isgetNearestDriverServiceRunning() {
        ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if ("com.oyla.passenger.services.location.NearestDriverCoordinates".equals(service.service.getClassName())) {
                Log.d("NearestDriver", "NearestDriverCoordinates service is already running.");
                return true;
            }
        }
        Log.d("NearestDriver", "NearestDriverCoordinates: location service is not running.");
        return false;
    }

    public void rotateMarker(final Marker marker, final float toRotation) {
        Log.d("rotateMarker", "rotateMarker: " + toRotation);
        if (!isRotating) {
            isRotating = true;
            //final Handler handler = new Handler();
            final Handler handler = new Handler(Looper.getMainLooper());
            final long start = SystemClock.uptimeMillis();
            final float startRotation = marker.getRotation();
            final long duration = 1000;
            float deltaRotation = Math.abs(toRotation - startRotation) % 360;
            final float rotation = (deltaRotation > 180 ? 360 - deltaRotation : deltaRotation) *
                    ((toRotation - startRotation >= 0 && toRotation - startRotation <= 180) ||
                            (toRotation - startRotation <= -180 && toRotation - startRotation >= -360) ? 1 : -1);

            final LinearInterpolator interpolator = new LinearInterpolator();
            handler.post(new Runnable() {
                @Override
                public void run() {
                    long elapsed = SystemClock.uptimeMillis() - start;
                    float t = interpolator.getInterpolation((float) elapsed / duration);
                    marker.setRotation((startRotation + t * rotation) % 360);
                    if (t < 1.0) {
                        // Post again 16ms later.
                        handler.postDelayed(this, 16);
                    } else {
                        isRotating = false;
                    }
                }
            });
        }
    }


    private void hideView() {
        binding.confirmRideLayout.confirmRide.setVisibility(View.GONE);
        binding.rideTypeLayout.rideType.setVisibility(View.GONE);
        mapLayoutBinding.mapExtraButton.setVisibility(View.GONE);
        mapLayoutBinding.pickupDropOffMessage.setVisibility(View.GONE);
        mapLayoutBinding.pickupDropOffAddressCardView.setVisibility(View.GONE);
        mapLayoutBinding.pickUpMarker.setVisibility(View.GONE);
        mapLayoutBinding.dropOffMarker.setVisibility(View.GONE);
        mapLayoutBinding.pickupButton.setVisibility(View.GONE);
    }

    private void cancelReasonDialog(String userId, String bookingId) {
        Log.v("cancelReasonDialog", "cancelReasonDialog");
        final Dialog dialog = new Dialog(MapActivity.this);
        dialog.setContentView(R.layout.cancel_reason_dialog);
        RadioGroup rGroup = dialog.findViewById(R.id.radioGroup);

        rGroup.setOnCheckedChangeListener((group, checkedId) -> {
            RadioButton checkedRadioButton = group.findViewById(checkedId);
            RideReceived = false;
            if (FIND_CAPTAIN_CANCEL) {
                findCaptainCancelFlagReset();
            } else {
                afterRideAcceptCancelFlag();
            }
            viewModel.sendCancelRideRequest(userId, bookingId, checkedRadioButton.getText().toString(), "empty");
            dialog.dismiss();
            cancelRideApiResponse();
        });
        dialog.show();
        dialog.setCancelable(true);
        Window window = dialog.getWindow();
        assert window != null;
        window.setGravity(Gravity.BOTTOM);
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    @Override
    protected void onPause() {
        // pauseTimer();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        stopLoader();
        //Constants.PROMO_ACTIVATE = false;
      /*  Intent myService = new Intent(MapActivity.this, RideBookingStatus.class);
        myService.setAction(Constants.ACTION_STOP_FOREGROUND_SERVICE);
        stopService(myService);*/
        stopRideBookingStatusService();
        /*if (RideReceived) {
            Intent broadcastIntent = new Intent();
            broadcastIntent.setAction("restartservice");
            broadcastIntent.setClass(this, Restarter.class);
            this.sendBroadcast(broadcastIntent);
        }*/

        super.onDestroy();
    }

    @Override
    public void onStart() {
        super.onStart();
        mapLayoutBinding.mapView.onStart();
        checkLocationPermission();
    }

    @Override
    public void onStop() {
        super.onStop();
        mapLayoutBinding.mapView.onStop();

        //  Log.d("TAG1", "onStop: Count d");
        if (!Constants.FIRE_BASE_NOTIFY) {
            Intent myService = new Intent(MapActivity.this, LocationService.class);
            myService.setAction(Constants.ACTION_STOP_FOREGROUND_SERVICE);
            stopService(myService);
        }

    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapLayoutBinding.mapView.onLowMemory();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int action = event.getAction();
        int keyCode = event.getKeyCode();
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (action == KeyEvent.ACTION_DOWN) {
                Log.v("OPEN_RIDE_SHEET", "Back button pressed.");
                onBackPressed();
                return true;
            }
        }
        return false;
    }

    @SuppressLint("SetTextI18n")
    private void outstandingBalance() {
        //int d = Integer.parseInt(Constants.WALLET_AMOUNT);
        int d = Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(Constants.WALLET_AMOUNT))));
        if (d < 0) {
            mapLayoutBinding.outstandingBalance.setVisibility(View.VISIBLE);
            mapLayoutBinding.outstandingBalanceText.setText(
                    MapActivity.this.getResources().getString(R.string.currency) + " " +
                            d + " " +
                            MapActivity.this.getResources().getString(R.string.outstanding_balance));
        } else {
            mapLayoutBinding.outstandingBalance.setVisibility(View.GONE);
        }
    }

    @Override
    public void getBookingStatus() {
       /* stopLoader();
        if(!RIDE_FLOW_0 && !RIDE_FLOW_1 && !RIDE_FLOW_2){

        }else if(RIDE_FLOW_0 && !RIDE_FLOW_1 && !RIDE_FLOW_2){

        }
        else if(RIDE_FLOW_0 && RIDE_FLOW_1 && !RIDE_FLOW_2) {
        }*/

        refreshTracking();
    }

    private void stopRideBookingStatusService() {
        Log.v("stopRideBooking", " stopRideBookingStatusService  ");
        Intent myService = new Intent(MapActivity.this, RideBookingStatus.class);
        myService.setAction(Constants.ACTION_STOP_FOREGROUND_SERVICE);
        stopService(myService);
    }

    @SuppressLint("SetTextI18n")
    private void ChangeDestination() {
        if (trackerMarker != null) {
            trackerMarker = null;
        }
        startGetDriverCoordinatesService();
        Log.d("changeDropOff", "ChangeDestination ");
        double trip_one_dist = getTripDestination(trip_one_distance);
        double trip_two_dist = getTripDestination(trip_two_distance);
        trip_total_distance = String.valueOf(trip_one_dist + trip_two_dist);
        trip_total_distance = String.valueOf(Math.round(Double.parseDouble(trip_total_distance)));
        Log.d("changeDropOff", "ChangeDestination 2 ");
        int trip_one_durat = getTripTime(trip_one_duration);
        int trip_two_durat = getTripTime(trip_two_duration);
        trip_total_time = String.valueOf(trip_one_durat + trip_two_durat);
        Log.d("changeDropOff", "ChangeDestination 3 ");
        Log.d("changeDropOff", "trip_one_dist " + trip_one_dist);
        Log.d("changeDropOff", "trip_one_durat " + trip_one_durat);
        Log.d("changeDropOff", "---- ");
        trip_one_price = tripFareCalculation(trip_one_durat, trip_one_dist);
        Log.d("changeDropOff", "ChangeDestination 4 ");
        trip_two_price = tripFareCalculation(trip_two_durat, trip_two_dist);
        Log.d("changeDropOff", "ChangeDestination 5");
        total_price = String.valueOf(Integer.parseInt(trip_one_price) + Integer.parseInt(trip_two_price));
        runOnUiThread(() -> {
            binding.captainInfoLayout.totalFairText.setText(getResources().getString(R.string.currency) + " " + total_price);
            binding.captainInfoLayout.totalDistanceText.setText(trip_two_distance);
            binding.captainInfoLayout.expectedTimeText.setText(trip_two_duration);
            currentTripDuration = trip_two_distance;
            currentTripTime = trip_two_duration;
            //stopLoader();
            if (!(MapActivity.this).isFinishing()) {
                startLoader();
                //show dialog
            }
            //startLoader();

            viewModel.passengerChangeDestinationRequest(
                    dataList.getCaptain_info_data().getBooking_id(), currentLat, currentLng
                    , String.valueOf(markerPoints.get(1).latitude), String.valueOf(markerPoints.get(1).longitude)
                    , String.valueOf(trip_one_dist), String.valueOf(trip_two_dist)
                    , trip_total_distance, trip_one_price, trip_two_price, total_price, trip_total_time);

            viewModel.passengerChangeDestinationRepose().observe(this, dataModelObject -> {
                stopLoader();
                if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                   /* SharedPrefManager.getInstance(MapActivity.this).removeBookingInfo();
                    Gson gson = new Gson();
                    String json = gson.toJson(dataModelObject.getData().getBooking_data());
                    SharedPrefManager.getInstance(MapActivity.this).setBookingInfo(json);*/
                    // binding.captainInfoLayout.totalFairText.setText(getResources().getString(R.string.currency) + " " + total_price);
                    if (trackerMarker != null) {
                        trackerMarker = null;
                    }
                    if (rideStartMarker != null) {
                        rideStartMarker.remove();
                        rideStartMarker = null;
                    }
                    checkBookingStatus();
                    binding.captainInfoLayout.confirmDropOff.setVisibility(View.GONE);
                } else {
                    if (dataModelObject.getError().getMessage() != null) {
                        showToast(MapActivity.this, dataModelObject.getError().getMessage());
                        Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                    } else if (dataModelObject.getError().getMessages() != null) {
                        showToast(MapActivity.this, dataModelObject.getError().getMessages().toString());
                        Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                    }
                    //showToast(MapActivity.this, dataModelObject.getError().getMessage());
                }
            });
        });
    }

    private double getTripDestination(String distance) {
        double finalDistance = 0;
        if (distance.contains("km")) {
            distance = distance.replace("km", "");
            distance = distance.replace(" ", "");
            if (distance.contains(",")) {
                distance = distance.replace(",", "");
            }
            finalDistance = Double.parseDouble(distance);
        } else if (distance.contains("m")) {
            Log.v("fareCalculation", "Distance in meter");
            distance = distance.replace("m", "");
            distance = distance.replace(" ", "");
            if (distance.contains(",")) {
                distance = distance.replace(",", "");
            }
            finalDistance = Double.parseDouble(distance);
            finalDistance = finalDistance / 1000;
        }

        return finalDistance;
    }

    private int getTripTime(String duration) {
        String addHours = "0";
        String addMinutes = "0";
        boolean HOUR = false;
        if (duration.contains("hours")) {
            duration = duration.replace("hours", ":");
            HOUR = true;

        } else if (duration.contains("hour")) {
            duration = duration.replace("hour", ":");
            HOUR = true;
        }

        if (duration.contains("mins")) {
            duration = duration.replace("mins", "");
            addMinutes = duration;
        }
        if (HOUR) {
            String[] splitTime = duration.split(":");
            addHours = splitTime[0].trim();
            addMinutes = splitTime[1].trim();
        }
        //  Log.v("selectRideType", "finalDistance  " + finalDistance);
        addHours = addHours.replace(" ", "");
        addMinutes = addMinutes.replace(" ", "");
        // int finalTotalMint =Integer.valueOf(durationMint);
        int finalTotalHour = Integer.parseInt(addHours);
        finalTotalHour = finalTotalHour * 60;
        int tripTime = Integer.parseInt(addMinutes) + finalTotalHour;
        Log.v("selectRideType", "tripTime  " + tripTime);
        // double tripTimeDistance1 = finalDistance;
        return tripTime;
    }

    private String tripFareCalculation(int totalMint, double totalDistance) {
        double perKM = MainApp.getInstance().getPerKM();
        Log.d("changeDropOff", "perKM " + perKM);
        double perMint = MainApp.getInstance().getPerMint();
        Log.d("changeDropOff", "perKM " + perKM);
        double vehicleRate = MainApp.getInstance().getVehicleRate();
        Log.d("changeDropOff", "vehicleRate " + vehicleRate);
        Log.d("changeDropOff", "tax_percentage " + MainApp.getInstance().getTax_percentage().trim());
        double tax_percentage = Double.parseDouble(MainApp.getInstance().getTax_percentage().trim());
        Log.d("changeDropOff", "tax_percentage2 " + tax_percentage);
       /* Log.v("selectRideType", "vehicleRate  " + vehicleRate);
        Log.v("calculateTime", "totalDistance  " + totalDistance);*/
        double d = (perKM * totalDistance) + (perMint * totalMint) + vehicleRate;
        //int fair = (int) d;
        double fair = (int) d;
        double taxPrice = (tax_percentage / 100) * fair;
        double totalPrice = fair + taxPrice;
        // dataSet.get(i).setFair(String.valueOf(fair));
        return String.valueOf(Math.round(totalPrice));
        // return String.valueOf(totalPrice);
    }

    private void expandView() {
        RelativeLayout.LayoutParams layout_description;
        if (appVehicles.size() == 1) {
            layout_description = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, 800);
        } else {
            layout_description = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        }
        layout_description.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        binding.rideTypeLayout.rideType2.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
        binding.rideTypeLayout.rideType2.setLayoutParams(layout_description);
    }

    private void contractView() {
        RelativeLayout.LayoutParams layout_description = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, 1000);
        layout_description.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        binding.rideTypeLayout.rideType2.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
        binding.rideTypeLayout.rideType2.setLayoutParams(layout_description);
    }

    private void expandView2() {
        RelativeLayout.LayoutParams layout_description = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        layout_description.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        binding.captainInfoLayout.secondLayout.setVisibility(View.VISIBLE);
        binding.captainInfoLayout.captainInfo2.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
        binding.captainInfoLayout.secondLayout.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
        binding.captainInfoLayout.captainInfo2.setLayoutParams(layout_description);
    }

    private void contractView2() {
        RelativeLayout.LayoutParams layout_description = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        layout_description.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        binding.captainInfoLayout.secondLayout.setVisibility(View.GONE);
        binding.captainInfoLayout.secondLayout.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
        binding.captainInfoLayout.captainInfo2.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
        binding.captainInfoLayout.captainInfo2.setLayoutParams(layout_description);
    }

    private void changeOylaPayComponentColor(@NonNull TextView textView1, @NonNull TextView textView2, @NonNull ImageView imageView, int color, int color2) {
        textView1.setTextColor(color);
        textView2.setTextColor(color);
        imageView.setBackgroundTintList(ContextCompat.getColorStateList(MapActivity.this, color2));
    }

    private void changeRadioGroupComponentColor(@NonNull ImageView imageView, @NonNull ImageView imageView2) {
        imageView.setBackgroundTintList(ContextCompat.getColorStateList(MapActivity.this, R.color.colorPrimary));
        imageView2.setBackgroundTintList(ContextCompat.getColorStateList(MapActivity.this, R.color.colorBlack3));
    }

    private void drawCircle() {
        mGoogleMap.addCircle(new CircleOptions()
                .center(new LatLng(startLatLng.latitude, startLatLng.longitude))
                .radius(3000)
                .strokeWidth(5f)
                .fillColor(getResources().getColor(R.color.blue3)));
        /*.fillColor(0x550000FF));*/
    }

    public void drawPolyLineOnMap(List<LatLng> list) {
        //testingPoints.add(   new LatLng(30.1939183, 71.4548033));
        // testingPoints.add(    new LatLng(30.189055, 71.4512217));
        //testingPoints.add(   new LatLng(30.194006, 71.454564));
        //testingPoints.add(    new LatLng(30.189055, 71.4512217));

        PolylineOptions polyOptions = new PolylineOptions();
        polyOptions.color(Color.RED);
        polyOptions.width(5);
        polyOptions.addAll(list);

        mGoogleMap.clear();
        mGoogleMap.addPolyline(polyOptions);

        LatLngBounds.Builder builder = new LatLngBounds.Builder();
        for (LatLng latLng : list) {
            builder.include(latLng);
        }

        final LatLngBounds bounds = builder.build();

        //BOUND_PADDING is an int to specify padding of bound.. try 100.
        CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, 15);
        mGoogleMap.animateCamera(cu);
    }

    public void getAddressAsync(double latitude, double longitude) {
        HandlerThread ht = new HandlerThread("MyHandlerThread");
        ht.start();
        Handler asyncHandler = new Handler(ht.getLooper()) {
            @Override
            public void handleMessage(@NonNull Message msg) {
                super.handleMessage(msg);
                Object response = msg.obj;
                //if (response.toString() != null || !response.toString().isEmpty()) {
                showAddressOnUi(response.toString());
                //Log.v("doSomethingOnUi", "doSomethingOnUi =" + response.toString());
                // }
            }
        };
        Runnable runnable = () -> {
            // your async code goes here.
            try {
                Thread.sleep(0);
                // create message and pass any object here doesn't matter
                // for a simple example I have used a simple string
                Message message = new Message();
                Geocoder geocoder;
                List<Address> addresses;
                geocoder = new Geocoder(this, Locale.getDefault());
                Log.v("LatLoggetStringAddress", "latitude " + latitude);
                Log.v("LatLoggetStringAddress", "longitude " + longitude);

                if (latitude != 0.0 && longitude != 0.0) {
                    String address;
                    try {
                        Log.v("LatLoggetStringAddress", "try ");
                        if (geocoder.getFromLocation(latitude, longitude, 1) != null) {
                            addresses = geocoder.getFromLocation(latitude, longitude, 1);
                            if (!addresses.isEmpty()) {
                                address = addresses.get(0).getAddressLine(0);
                                message.obj = address;
                            } else {
                                message.obj = "Finding Address...";
                            }
                        } else {
                            message.obj = "Finding Address...";
                        }

                    } catch (IOException e) {
                        Log.v("LatLoggetStringAddress", "catch " + e);
                        e.printStackTrace();
                        message.obj = "Finding Address...";
                    }
                } else {
                    message.obj = "Finding Address...";
                }
                asyncHandler.sendMessage(message);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        };
        asyncHandler.post(runnable);
    }

    private void showAddressOnUi(String result) {

        Handler uiThread = new Handler(Looper.getMainLooper());
        uiThread.post(() -> {
            String finalResult = result.replaceAll("[-+.^:,،]", "");
            Log.v("doSomethingOnUi", " response " + finalResult);
            if (pickUpAddressBol) {
                //mGoogleMap.clear();
                if (oldNearDriverLatLng == null) {
                    oldNearDriverLatLng = centerLatLng;
                }

               /* double radCal = radiusCalculation(centerLatLng.latitude, centerLatLng.longitude, oldNearDriverLatLng.latitude, oldNearDriverLatLng.longitude);
                if (radCal > 2999) {
                  //  mGoogleMap.clear();
                    oldNearDriverLatLng = null;
                }*/
                mapLayoutBinding.pickupAddressText.setText(finalResult);
                Log.v("CameraIdle", "pickupAddress " + mapLayoutBinding.pickupAddressText.getText());
                // mapLayoutBinding.pickupAddressText.setText(getStringAddress(centerLatLng.latitude, centerLatLng.longitude));
                pickupMarkerLat = centerLatLng.latitude;
                pickupMarkerLng = centerLatLng.longitude;
                showKmOnMarker();
            } else if (dropOffAddressBol) {
                Log.v("CameraIdle", "dropOffAddressBol ");
                mapLayoutBinding.dropOffAddressText.setText(finalResult);
            }
        });
    }

    private double radiusCalculation(double latA, double lngA, double latB, double lngB) {
        Location startPoint = new Location("locationA");
        startPoint.setLatitude(latA);
        startPoint.setLongitude(lngA);
        Log.v("radius", "latA " + latA);
        Log.v("radius", "lngA " + lngA);
        Location endPoint = new Location("locationB");
        endPoint.setLatitude(latB);
        endPoint.setLongitude(lngB);
        Log.v("radius", "latA " + latB);
        Log.v("radius", "lngA " + lngB);
        double distance = startPoint.distanceTo(endPoint);// in meters
        //double distance = startPoint.distanceTo(endPoint) / 1000;// in Km
        Log.v("radius", "radius " + distance);
        //  showToast(MapActivity.this,String.valueOf(distance));
        return distance;
    }

    public String getTimeTaken(double latA, double lngA, double latB, double lngB) {

        Location source = new Location("locationA");
        source.setLatitude(latA);
        source.setLongitude(lngA);
        Log.v("radius", "latA " + latA);
        Log.v("radius", "lngA " + lngA);
        Location dest = new Location("locationB");
        dest.setLatitude(latB);
        dest.setLongitude(lngB);
        double meter = source.distanceTo(dest);
        double kms = meter / 1000;
        double kms_per_min = 0.5;
        double mins_taken = kms / kms_per_min;
        int totalMinutes = (int) mins_taken;
        Log.d("ResponseT", "meter :" + meter + " kms : " + kms + " mins :" + mins_taken);
        if (totalMinutes < 60) {
            return "" + totalMinutes + " mins";
        } else {
            String minutes = Integer.toString(totalMinutes % 60);
            minutes = minutes.length() == 1 ? "0" + minutes : minutes;
            return (totalMinutes / 60) + " hour " + minutes + "mins";

        }
    }
    private void showKmOnMarker(){
        /*if (nearestDriversData != null && nearestDriversData.size() > 0) {
            double radCal = radiusCalculation(centerLatLng.latitude, centerLatLng.longitude, Double.parseDouble(nearestDriversData.get(0).getLat()), Double.parseDouble(nearestDriversData.get(0).getLng()));
            radCal = radCal / 1000;
            DecimalFormat df = new DecimalFormat("#.#");
            df.format(radCal);
            //getTimeTaken(pickupMarkerLat, pickupMarkerLng, Double.parseDouble(nearestDriversData.get(0).getLat()), Double.parseDouble(nearestDriversData.get(0).getLng()));
            binding.mapLayout.waitTime.setText(df.format(radCal) + "\n" + " km");
        } else {
            binding.mapLayout.waitTime.setText("");
        }*/
    }
    public void snapShot(){

        GoogleMap.SnapshotReadyCallback callback=new GoogleMap.SnapshotReadyCallback () {
            Bitmap bitmap;
            @Override
            public void onSnapshotReady(Bitmap snapshot) {
                bitmap=snapshot;

                try{
                    File file=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"map.png");
                    FileOutputStream fout=new FileOutputStream (file);
                    bitmap.compress (Bitmap.CompressFormat.PNG,90,fout);
                    Toast.makeText (MapActivity.this, "Capture", Toast.LENGTH_SHORT).show ();

                }catch (Exception e){
                    e.printStackTrace ();
                    Toast.makeText (MapActivity.this, "Not Capture", Toast.LENGTH_SHORT).show ();
                }


            }
        };mGoogleMap.snapshot (callback);
    }
}