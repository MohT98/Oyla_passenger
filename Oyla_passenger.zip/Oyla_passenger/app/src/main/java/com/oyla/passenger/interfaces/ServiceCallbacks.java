package com.oyla.passenger.interfaces;

public interface ServiceCallbacks {
    void doTracking();
}
