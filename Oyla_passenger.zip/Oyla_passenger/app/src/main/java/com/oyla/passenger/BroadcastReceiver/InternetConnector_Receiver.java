package com.oyla.passenger.BroadcastReceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import com.oyla.passenger.MainApp;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.utilities.Constants;

public class InternetConnector_Receiver extends BroadcastReceiver {
    boolean flag=true;
    int count =0;

    @Override
    public void onReceive(final Context context, final Intent intent) {
        final Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (haveNetworkConnection(context)) {
                    Log.v("InternetConnector","if FLAG "+flag);
                    //Log.v("InternetConnector","if count "+count);
                    // Toast.makeText(context, "Network Available Do operations", Toast.LENGTH_SHORT).show();
                    flag=true;
                    // count =0;
                    Constants.WIFI_DIALOG=true;
                }else {
                    //  count++;
                    // Log.v("InternetConnector","else count "+count);
                    Log.v("InternetConnector","else FLAG "+flag);
                    if(flag){
                        flag=false;
                        Toast.makeText(context, "NO Network Available ", Toast.LENGTH_SHORT).show();
                        Log.v("InternetConnector","else if  FLAG "+flag);
                        Constants.WIFI_DIALOG=false;
                        //BaseActivity.getInstance().buildAlertMessageNoInterNet();
                    }
                }
            }
        }, 500);

    }

    private boolean haveNetworkConnection(Context context) {
        boolean haveConnectedWifi = false;
        boolean haveConnectedMobile = false;

        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo[] netInfo = cm.getAllNetworkInfo();
        for (NetworkInfo ni : netInfo) {
            if (ni.getTypeName().equalsIgnoreCase("WIFI"))
                if (ni.isConnected())
                    haveConnectedWifi = true;
            if (ni.getTypeName().equalsIgnoreCase("MOBILE"))
                if (ni.isConnected())
                    haveConnectedMobile = true;
        }
        return haveConnectedWifi || haveConnectedMobile;
    }
}
