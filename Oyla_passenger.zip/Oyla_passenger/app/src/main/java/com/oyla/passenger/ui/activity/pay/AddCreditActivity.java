package com.oyla.passenger.ui.activity.pay;

import android.app.Dialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.Window;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.google.android.material.textfield.TextInputLayout;
import com.oyla.passenger.R;
import com.oyla.passenger.databinding.ActivityAddCreditBinding;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.utilities.Messages;

public class AddCreditActivity extends BaseActivity {
    ActivityAddCreditBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        hideAppBar(this);
        binding=setContentView(this,R.layout.activity_add_credit);
        binding.onBack.setOnClickListener(v->{onBackPressed();});

        binding.cardLayout.setOnClickListener(v->{nextActivity(this,EnterCardAmountActivity.class);});
        binding.voucherLayout.setOnClickListener(v->{showVoucherDialog();});

    }
    private void showVoucherDialog(){
        final int[] error_count = {0};
        final Dialog dialog = new Dialog(AddCreditActivity.this,R.style.full_screen_dialog);
       //final Dialog dialog = new Dialog(AddCreditActivity.this);
        //dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.voucher_dialog);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);


        EditText enterVoucherEdiText= dialog.findViewById(R.id.enterVoucherEdiText);
        TextInputLayout enterVoucherTextInput= dialog.findViewById(R.id.enterVoucherTextInput);
        dialog.findViewById(R.id.cancelButton).setOnClickListener(v -> dialog.dismiss());

        dialog.findViewById(R.id.addVoucherLayout).setOnClickListener(V->{
            error_count[0] =1;
            if (enterVoucherEdiText.getText().toString().isEmpty()) {
                showError(Messages.EmptyMessage,enterVoucherTextInput, enterVoucherEdiText);
                // userData.setUserPassword(null);
                return;
            }
            dialog.dismiss();
        });
        enterVoucherEdiText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(s!=null){
                    removeError(enterVoucherTextInput);
                }
                Log.v("countcount","count "+count);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        dialog.show();
        Window window = dialog.getWindow();
        assert window != null;
        //window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        //window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setGravity(Gravity.BOTTOM);
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }
}