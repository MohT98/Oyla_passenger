package com.oyla.passenger.datamodels.usermodel;

import java.util.List;

public class ErrorList {


    private List<String> messages;
    private String message;

    public List<String> getMessages() {
        return messages;
    }

    public String getMessage() {
        return message;
    }



}
