package com.oyla.passenger.ui.activity.update.profile;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;

import androidx.lifecycle.ViewModelProvider;

import com.oyla.passenger.R;
import com.oyla.passenger.databinding.ActivityUpdateEmailBinding;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.utilities.Messages;
import com.oyla.passenger.viewmodels.UpdateProfileViewModel;

import java.util.Objects;

public class UpdateEmailActivity extends BaseActivity {

    private ActivityUpdateEmailBinding binding;
    private UpdateProfileViewModel viewModel;
    private int errorCount = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding=setContentView(this,R.layout.activity_update_email);
        hideAppBar(this);
        //userData = new UserData();
        viewModel = new ViewModelProvider(this).get(UpdateProfileViewModel.class);
        binding.setViewModel(viewModel);

        binding.updateButtons.customButtonText.setText(getResources().getString(R.string.update_text));

        viewModel.getUserEmail().observe(this, s -> {
            if (s != null) {
                removeError(binding.userEmailTextInput);
                if (TextUtils.isEmpty(s)) {
                    showError(Messages.EmptyMessage, binding.userEmailTextInput, binding.userEmailEditText);
                    //userData.setUserName(null);
                }
                else if (!viewModel.validateUserEmail(s)) {
                    if (errorCount > 0) {
                        showError(Messages.emailValidMessage, binding.userEmailTextInput, binding.userEmailEditText);
                    }
                    //userData.setUserName(s);
                }
                else {
                    //userData.setUserName(s);
                }
            } else {

                // userData.setUserName(null);
            }
        });

        binding.updateButtons.button.setOnClickListener(v -> updateUserEmail());
        binding.backButton.setOnClickListener(v -> { onBackPressed(); });
    }

    private void updateUserEmail() {
        Log.v("userNameEditText","email  "+ Objects.requireNonNull(viewModel.validateUserEmail(binding.userEmailEditText.getText().toString())));
        errorCount = 1;
        if (Objects.requireNonNull(binding.userEmailEditText.getText()).toString().trim().isEmpty()) {
            showError(Messages.EmptyMessage, binding.userEmailTextInput, binding.userEmailEditText);
            return;
        } else if (!viewModel.validateUserEmail(binding.userEmailEditText.getText().toString())) {
            showError(Messages.emailValidMessage, binding.userEmailTextInput, binding.userEmailEditText);
            return;
        }
        //if (!viewModel.getUserName().toString().isEmpty())) {
        //proceed();
        showToast(getApplicationContext(),"Proceed");


        //}

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}