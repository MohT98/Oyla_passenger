package com.oyla.passenger.viewmodels;

import android.app.Application;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;

import com.oyla.passenger.Repository.JsonRepository;
import com.oyla.passenger.datamodels.jsonreponsedatamodel.DataModelObject;

public class PayViewModel extends SharedViewModel{
    private MutableLiveData<DataModelObject> mutableLiveData;
    private JsonRepository repository;

    public PayViewModel(@NonNull Application application) {
        super(application);
    }

    public void sendRideHistoryRequest(String user_id) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.getRideHistory(user_id);
    }

    public MutableLiveData<DataModelObject> receiveRideHistoryRepose() {
        return mutableLiveData;
    }


    public void sendTransactionHistoryRequest(String user_id) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.getTransactionHistory(user_id);
    }

    public MutableLiveData<DataModelObject> receiveTransactionHistoryRepose() {
        return mutableLiveData;
    }
}
