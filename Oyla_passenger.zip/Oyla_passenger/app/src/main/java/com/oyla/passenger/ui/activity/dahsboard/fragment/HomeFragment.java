package com.oyla.passenger.ui.activity.dahsboard.fragment;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.work.BackoffPolicy;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkInfo;
import androidx.work.WorkManager;

import com.oyla.passenger.BroadcastReceiver.Restarter;
import com.oyla.passenger.MainApp;
import com.oyla.passenger.R;
import com.oyla.passenger.adapter.DashboardAdapter;
import com.oyla.passenger.databinding.FragmentHomeBinding;
import com.oyla.passenger.datamodels.CheckBookingStatusData;
import com.oyla.passenger.datamodels.DashboardContentData;
import com.oyla.passenger.datamodels.DummyDistanceTracker;
import com.oyla.passenger.datamodels.usermodel.UserData;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.ui.activity.SplashActivity;
import com.oyla.passenger.ui.activity.cabbooking.MapActivity;
import com.oyla.passenger.ui.activity.cabbooking.TrackingActivity;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.DialogBoxSingleton;
import com.oyla.passenger.utilities.SharedPrefManager;
import com.oyla.passenger.viewmodels.HomeFragViewModel;
import com.oyla.passenger.workmanager.NotificationWorker;

import org.jetbrains.annotations.NotNull;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import static com.facebook.FacebookSdk.getApplicationContext;
import static com.oyla.passenger.utilities.Constants.mLocationPermissionGranted;

public class HomeFragment extends Fragment implements View.OnClickListener {

    /*driver_status	=	0=pickup, 1=reached pickup,2=start ride,3=complete ride
 status	=	0=ride request,1=onway,2=user cancelled,3=system cancelled,4=completed,5=driver cancelled*/
    LocationManager manager;
    // private LinearLayout car_layout;
    private FragmentHomeBinding binding;
    private String driverStatus = "3";
    private String rideStatus = "4";
    //private final int handlerDelay = 50;
    CheckBookingStatusData bookingStatusData;
    /*    private DashBoardViewModel viewModel;
        private String driverStatus = "0";
        private String rideStatus = "0";*/
    private HomeFragViewModel viewModel;
    private Animation animBlink;
    private String vehicle_type_id;
    private List<DashboardContentData> dashboardContentData;
    private UserData userData;
    private Boolean RideReceived = false;
    private List<DummyDistanceTracker> DummyDistanceTrackerList;

    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //MainApp.getInstance().setOnCaptainFind(this);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        /*View view=inflater.inflate(R.layout.fragment_home, container, false);*/
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_home, container, false);
        manager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
        View view = binding.getRoot();
        binding.carLayout.setOnClickListener(this);
        binding.bikeLayout.setOnClickListener(this);
        binding.trackRideButton.setOnClickListener(this);
        binding.rentCarLayout.setOnClickListener(this);
        binding.longTripLayout.setOnClickListener(this);
        binding.workshopLayout.setOnClickListener(this);
        binding.shareTripLayout.setOnClickListener(this);
        binding.promotionCard.setOnClickListener(this);
        binding.emergencyIcon.setOnClickListener(this);
        binding.pointsText.setOnClickListener(this);

        Animation animEnter = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.animation_enter);
        Animation animExit = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slide_in_right);
        Animation animSlideUp = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slide_in_up);
        // Animation animSlideDown = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slide_in_down);
        Animation animFade = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fade_in);
        animBlink = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.blink);
        // binding.carLayout.post(() -> {
        binding.dashBoardRecycle.setHasFixedSize(true);
        binding.dashBoardRecycle.setLayoutManager(new GridLayoutManager(getActivity(), 3));
        binding.dashBoardRecycle.setItemAnimator(new DefaultItemAnimator());

        // new Handler(Looper.getMainLooper()).post(() -> {
        binding.carLayout.startAnimation(animEnter);
        binding.bikeLayout.startAnimation(animFade);
        binding.rentCarLayout.startAnimation(animEnter);
        binding.longTripLayout.startAnimation(animExit);
        binding.shareTripLayout.startAnimation(animFade);
        binding.workshopLayout.startAnimation(animExit);
        binding.trackRideCard.startAnimation(animSlideUp);
        binding.promotionCard.startAnimation(animSlideUp);
        binding.topBarLayout.startAnimation(animFade);
        // });
        // });
        viewModel = new ViewModelProvider(requireActivity()).get(HomeFragViewModel.class);

        //

        return view;
    }


    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View view) {
        // final Handler handler = new Handler(Looper.getMainLooper());
        Intent i;
        switch (view.getId()) {

            case R.id.car_layout:
                //binding.carLayout.startAnimation(animBlink);
                openSmartCab();
                break;
            case R.id.trackRideButton:
                if (mLocationPermissionGranted && !manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                    buildAlertMessageNoGps();
                    return;
                }

                binding.trackRideButton.startAnimation(animBlink);
                if (vehicle_type_id == null || vehicle_type_id.isEmpty()) {
                    vehicle_type_id = "1";
                }

                if (MainApp.getInstance().getDataList() == null) {
                    hideTrackButton();
                    BaseActivity.getInstance().showToast(getActivity(), "No Ride Available for tracking");
                } else {
                    Log.v("typeID", "typeID home frag" + vehicle_type_id);
                    i = new Intent(getActivity(), TrackingActivity.class);
                    i.putExtra("bookingStatusData", bookingStatusData);
                    i.putExtra("vehicleType", "car");
                    i.putExtra("typeID", vehicle_type_id);
                    //getActivity().overridePendingTransition(R.anim.animation_leave,R.anim.animation_enter);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NO_ANIMATION);

              /*  i.putExtra("rideStatus", MainApp.getInstance().getRideStatus());
                i.putExtra("driverStatus", MainApp.getInstance().getDriverStatus());*/
                    startActivity(i);
                    requireActivity().overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
                }
                // BaseActivity.getInstance().finish();

                break;
            case R.id.bike_layout:
                openSmartBike();
                //  binding.bikeLayout.startAnimation(animBlink);
                break;
                /*  i.putExtra("rideStatus", MainApp.getInstance().getRideStatus());
                i.putExtra("driverStatus", MainApp.getInstance().getDriverStatus());*/
            case R.id.rentCarLayout:
                // binding.rentCarLayout.startAnimation(animBlink);
                DialogBoxSingleton.getInstance().showPopup(getActivity(), "Coming Soon....", true);
                openComingSoonPopUP();
                //trackingActivity();
                break;

            case R.id.pointsText:
                openRedeemPoint();
                break;
            case R.id.workshopLayout:
                // binding.workshopLayout.startAnimation(animBlink);
                //DialogBoxSingleton.getInstance().showPopup(getActivity(), "Coming Soon....", true);
                //openComingSoonPopUP();

                openWorkShop();
                break;
            case R.id.longTripLayout:
                openCityToCity();
                break;
            case R.id.shareTripLayout:
                // binding.shareTripLayout.startAnimation(animBlink);
                //DialogBoxSingleton.getInstance().showPopup(getActivity(), "Coming Soon....", true);
                openComingSoonPopUP();
                break;
            case R.id.promotionCard:
                binding.workshopLayout.startAnimation(animBlink);
                // showPromoPopup(getActivity(), "Coming Soon....",true);
                DialogBoxSingleton.getInstance().showPromoPopup(getActivity(), "", true);
                break;
            case R.id.emergencyIcon:
                binding.emergencyIcon.startAnimation(animBlink);
                // Log.v("emergencyIcon","homeFragment");
                DialogBoxSingleton.getInstance().helpLineDialog(getActivity(), getActivity());
                // BaseActivity.getInstance().helpLineDialog();
                // Constants.phoneCall(getActivity());
                break;
            default:
                break;
        }
    }

    private void openSmartCab() {

        Log.v("PermissionGranted", "mLocationPermissionGranted " + mLocationPermissionGranted);
        Log.v("PermissionGranted", " Constants.GPS_DIALOG " + Constants.GPS_DIALOG);
        //  if (!mLocationPermissionGranted) {
           /* Intent intent = new Intent();
            intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            Uri uri = Uri.fromParts("package", getActivity().getPackageName(), null);
            intent.setData(uri);
            startActivity(intent);
            BaseActivity.getInstance().showToast(getActivity(), "Give Location permission to use this app");*/
        // } else {
        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            buildAlertMessageNoGps();
            return;
        }


        if (vehicle_type_id == null || vehicle_type_id.isEmpty()) {
            vehicle_type_id = "1";
        }
        Log.v("typeID", "typeID home frag" + vehicle_type_id);
        Intent i = new Intent(getActivity(), MapActivity.class);
        i.putExtra("bookingStatusData", bookingStatusData);
        // Log.d("testinbooking", "frag getStatus" + bookingStatusData.getStatus());
        //Log.d("testinbooking", "frag getDriver_status" + bookingStatusData.getDriver_status());
        i.putExtra("vehicleType", "car");
        i.putExtra("typeID", vehicle_type_id);
        //getActivity().overridePendingTransition(R.anim.animation_leave,R.anim.animation_enter);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NO_ANIMATION);

              /*  i.putExtra("rideStatus", MainApp.getInstance().getRideStatus());
                i.putExtra("driverStatus", MainApp.getInstance().getDriverStatus());*/
        // startActivity(i);
        //handler.postDelayed(() -> {
        startActivity(i);
        requireActivity().overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        // BaseActivity.getInstance().finish();
        /* }, handlerDelay);*/
        // }

    }

    private void openSmartBike() {
        Log.v("PermissionGranted", "mLocationPermissionGranted " + mLocationPermissionGranted);
        // if (!mLocationPermissionGranted) {
           /* Intent intent = new Intent();
            intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            Uri uri = Uri.fromParts("package", getActivity().getPackageName(), null);
            intent.setData(uri);
            startActivity(intent);
            BaseActivity.getInstance().showToast(getActivity(), "Give Location permission to use this app");*/
        //} else {
        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            buildAlertMessageNoGps();
            return;
        }
        if (vehicle_type_id == null || vehicle_type_id.isEmpty()) {
            vehicle_type_id = "10";
        }
        Log.v("typeID", "typeID home frag" + vehicle_type_id);
        Intent i = new Intent(getActivity(), MapActivity.class);


        i.putExtra("bookingStatusData", bookingStatusData);
        i.putExtra("vehicleType", "bike");
        i.putExtra("typeID", vehicle_type_id);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(i);
        requireActivity().overridePendingTransition(R.anim.fade_in, R.anim.fade_out);

        // }

    }

    private void openRedeemPoint() {
       /* Intent i = new Intent(getActivity(), RewardListActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(i);*/
        /*Intent ii = new Intent(getActivity(), ChatActivity.class);
        ii.putExtra("bookingStatusData", bookingStatusData);
        startActivity(ii);*/
    }

    private void openCityToCity() {
        DialogBoxSingleton.getInstance().cityToCityDialog(getActivity(), getActivity());
    }

    private void openWorkShop() {
      //  workManagerExp();
        DialogBoxSingleton.getInstance().workShopDialog(getActivity(), getActivity());
    }

    private void openComingSoonPopUP() {
        DialogBoxSingleton.getInstance().showPopup(getActivity(), "Coming Soon....", true);
    }

    @Override
    public void onResume() {
        super.onResume();
        vehicle_type_id = null;
        userData = SharedPrefManager.getInstance(getActivity()).getUserInfo();
        Constants.Auth = Constants.Bearer + " " + SharedPrefManager.getInstance(getApplicationContext()).getUserInfo().getAccessToken();
        //   new Handler(Looper.getMainLooper()).post(() -> {
        if (MainApp.getInstance().getUserData() == null || MainApp.getInstance().getUserData().getUserId() == null) {
            Log.v("refreshRide", "user model null on home frag ");
            viewModel.sendRefreshTokenRequest(userData.getUserId());
            BaseActivity.getInstance().startLoader();
            viewModel.receiveRefreshTokenRepose().observe(this, dataModelObject -> {
                BaseActivity.getInstance().stopLoader();
                if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                    MainApp.getInstance().setUserData(dataModelObject.getData().getUser());
                } else {
                    if (dataModelObject.getError().getMessage() != null) {
                        // showToast(SettingActivity.this, dataModelObject.getError().getMessage());
                        Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                    } else if (dataModelObject.getError().getMessages() != null) {
                        // showToast(SettingActivity.this, dataModelObject.getError().getMessages().toString());
                        Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                    }
                }
                onResume();
            });
            /*} else if (mLocationPermissionGranted) {*/
        } else {
            bookingStatus();
            passengerLedgers();
            passengerPoints();
        }
        dashBoardViewData();
        /*});*/

        //0  dateTesting();
       /* AudioManager am =
                (AudioManager) getActivity().getSystemService(Context.AUDIO_SERVICE);

        am.setStreamVolume(
                AudioManager.STREAM_MUSIC,
                am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
                , 0);*/
    }


    private void bookingStatus() {
        viewModel.bookingStatusRequest(userData.getUserId());
        viewModel.bookingStatusRepose().observe(requireActivity(), dataModelObject -> {
            //  ((BaseActivity) getActivity()).stopLoader();
            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                driverStatus = dataModelObject.getData().getBookingInfo().getDriver_status();
                rideStatus = dataModelObject.getData().getBookingInfo().getStatus();
                bookingStatusData = dataModelObject.getData().getBookingInfo();
                MainApp.getInstance().setDataList(dataModelObject.getData());
                vehicle_type_id = dataModelObject.getData().getBookingInfo().getVehicle_type_id();
                //Log.v("bookingStatusRepose", "driverStatus " + driverStatus);
                // Log.v("bookingStatusRepose", "driverStatus " + rideStatus);
                MainApp.getInstance().setDriverStatus(driverStatus);
                MainApp.getInstance().setRideStatus(rideStatus);
        /*      MainApp.getInstance().setRidePickup_latitude(Double.parseDouble(dataModelObject.getData().getBookingInfo().getPickup_latitude()));
                MainApp.getInstance().setRidePickup_longitude(Double.parseDouble(dataModelObject.getData().getBookingInfo().getPickup_latitude()));
                MainApp.getInstance().setRideDropOff_latitude();
                MainApp.getInstance().setRideDropOff_longitude();*/

                if (bookingStatusData != null && bookingStatusData.getStatus() != null) {
                    Log.v("StatusDataStatusData", "StatusData bookingStatusData " + bookingStatusData.getStatus());
                    if (bookingStatusData.getStatus().equalsIgnoreCase("1") ||
                            bookingStatusData.getStatus().equalsIgnoreCase("0")) {

                        // if(getActivity().getSharedPreferences("Driver_Info", Context.MODE_PRIVATE)!=null){
                        //  SharedPreferences sharedPreferences = getActivity().getSharedPreferences("Driver_Info", Context.MODE_PRIVATE);
                        //  String json2 = sharedPreferences.getString("Driver_Info_Object", "");
                        //   if (json2 != null && !json2.isEmpty()) {
                        showTrackButton();
                        //   }
                        //  }
                     /*   SharedPreferences sharedPreferences = getActivity().getSharedPreferences("Driver_Info", 0);
                        String json2 = sharedPreferences.getString("Driver_Info_Object", "");
                        if (json2 != null && !json2.isEmpty()) {
                            binding.trackRideCard.setVisibility(View.VISIBLE);
                        } else {
                            binding.trackRideCard.setVisibility(View.GONE);
                        }*/
                    } else {
                        hideTrackButton();
                        vehicle_type_id = null;
                        MainApp.getInstance().setDataList(null);
                       /* SharedPreferences sharedPreferences2 = getActivity().getSharedPreferences("Driver_Info", 0);
                        sharedPreferences2.edit().remove("Driver_Info_Object").apply();
                        SharedPrefManager.getInstance(getActivity()).removeBookingInfo();*/
                    }
                    if (bookingStatusData.getDriver_status().equalsIgnoreCase("3")) {
                        hideTrackButton();
                        MainApp.getInstance().setDataList(null);
                        vehicle_type_id = null;
                       /* SharedPreferences sharedPreferences2 = getActivity().getSharedPreferences("Driver_Info", 0);
                        sharedPreferences2.edit().remove("Driver_Info_Object").apply();
                        SharedPrefManager.getInstance(getActivity()).removeBookingInfo();*/
                    }
                }
            } else {
                MainApp.getInstance().setDataList(null);
                MainApp.getInstance().setDriverStatus(driverStatus);
                MainApp.getInstance().setRideStatus(rideStatus);
                //binding.trackRideCardHeadingText.setText(getString(R.string.no_ongoing_ride));
                hideTrackButton();
                vehicle_type_id = null;
                // ((BaseActivity) getActivity()).showToast(getActivity(), dataModelObject.getError().getMessage());
                // Log.v("bookingStatusRepose", "error " + dataModelObject.getError().getMessage());
                //MySingleton.getInstance().showErrorPopup(getActivity(),dataModelObject.getError());
                if (dataModelObject.getError().getMessage() != null) {
                    // ((BaseActivity) getActivity()).showToast(getActivity(), dataModelObject.getError().getMessage());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                } else if (dataModelObject.getError().getMessages() != null) {
                    // ((BaseActivity) getActivity()).showToast(getActivity(), dataModelObject.getError().getMessages().toString());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                }
            }
        });
    }

    private void passengerLedgers() {
        viewModel.passengerLedgersRequest(userData.getUserId());
        viewModel.passengerLedgersRepose().observe(requireActivity(), dataModelObject -> {

            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                if (dataModelObject.getData() != null && dataModelObject.getData().getTotalBalance() != null) {
                    Log.v("TotalBalance", "TotalBalance frag " + dataModelObject.getData().getTotalBalance());
                    MainApp.getInstance().getOylaWallet().passengerLedgers(dataModelObject.getData().getTotalBalance());
                    Constants.WALLET_AMOUNT = dataModelObject.getData().getTotalBalance();
                }
            } else {
                if (dataModelObject.getError().getMessage() != null) {
                    //showToast(MapActivity.this, dataModelObject.getError().getMessage());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                } else if (dataModelObject.getError().getMessages() != null) {
                    //showToast(MapActivity.this, dataModelObject.getError().getMessages().toString());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                }
            }
        });
    }

    @SuppressLint("SetTextI18n")
    private void passengerPoints() {
        viewModel.passengerPointsRequest(userData.getUserId());
        viewModel.passengerPointsRepose().observe(requireActivity(), dataModelObject -> {

            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                if (dataModelObject.getData() != null) {
                    if (dataModelObject.getData().getTotalPoints() != null) {
                        Log.v("TotalPoints", "TotalPoints frag " + dataModelObject.getData().getTotalPoints());
                        Constants.TOTAL_POINTS = dataModelObject.getData().getTotalPoints();
                        binding.pointsText.setText(Constants.TOTAL_POINTS + " " + "pts");
                    }
                }

            } else {
                if (dataModelObject.getError().getMessage() != null) {
                    //showToast(MapActivity.this, dataModelObject.getError().getMessage());
                    Log.v("TotalPoints", "getErrorMessage " + dataModelObject.getError().getMessage());
                } else if (dataModelObject.getError().getMessages() != null) {
                    //showToast(MapActivity.this, dataModelObject.getError().getMessages().toString());
                    Log.v("TotalPoints", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                }
            }
        });
    }

    private void dashBoardViewData() {
        if (Constants.SPLASH) {
            viewModel.passengerDashboardRequest();
            String language = SharedPrefManager.getInstance(getActivity()).getLanguage();

            viewModel.passengerDashboardRepose().observe(requireActivity(), dataModelObject -> {
                if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                    if (dataModelObject.getData() != null && dataModelObject.getData().getDashboardContent() != null) {
                        // Log.v("getModule_name", "getModule_name frag " + dataModelObject.getData().getDashboardContent().get(0).getModule_name());
                        dashboardContentData = dataModelObject.getData().getDashboardContent();
                        for (int i = 0; i < dashboardContentData.size(); i++) {
                            if (Integer.parseInt(dashboardContentData.get(i).getStatus()) == 0) {
                                dashboardContentData.remove(i);
                            }
                        }

                        Collections.sort(
                                dashboardContentData, (o1, o2) ->
                                        o1.getSerial_no().compareToIgnoreCase(o2.getSerial_no())
                        );
                   /*
                    mAdapter = new DashboardAdapter(getActivity(), dashboardContentData);
                    binding.dashBoardRecycle.setAdapter(mAdapter);*/
                        if (language != null && language.equalsIgnoreCase("اردو")) {
                            return;
                        }
                        setDashBoardAdapter();
                        Constants.SPLASH = false;
                    }

                } else {
                    if (dataModelObject.getError().getMessage() != null) {
                        //showToast(MapActivity.this, dataModelObject.getError().getMessage());
                        Log.v("TotalPoints", "getErrorMessage " + dataModelObject.getError().getMessage());
                    } else if (dataModelObject.getError().getMessages() != null) {
                        //showToast(MapActivity.this, dataModelObject.getError().getMessages().toString());
                        Log.v("TotalPoints", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                    }
                }
            });
        } else {
           /* if(dashboardContentData!=null && dashboardContentData.size()>0){
                mAdapter = new DashboardAdapter(getActivity(), dashboardContentData);
                binding.dashBoardRecycle.setAdapter(mAdapter);
            }*/
            setDashBoardAdapter();
        }
    }

    private void setDashBoardAdapter() {
        if (dashboardContentData != null && dashboardContentData.size() > 0) {
            DashboardAdapter mAdapter = new DashboardAdapter(getActivity(), dashboardContentData);
            binding.dashBoardRecycle.setAdapter(mAdapter);
            binding.section1.setVisibility(View.GONE);
            binding.section2.setVisibility(View.GONE);
            mAdapter.setOnItemClickListener(position -> {
                int serialNO = Integer.parseInt(dashboardContentData.get(position).getSerial_no());
                if (serialNO == 1) {
                    openSmartCab();
                } else if (serialNO == 2) {
                    openSmartBike();
                } else if (serialNO == 3) {
                    openCityToCity();
                } else if (serialNO == 4) {
                    //trackingActivity();
                    openComingSoonPopUP();
                } else if (serialNO == 6) {
                    openWorkShop();
                } else {
                    openComingSoonPopUP();
                }
            });
        } else {
            binding.section1.setVisibility(View.VISIBLE);
            binding.section2.setVisibility(View.VISIBLE);
        }
    }

    private void hideTrackButton() {
        RideReceived = false;
        Constants.FIRE_BASE_NOTIFY = false;
        binding.trackRideButton.setVisibility(View.GONE);
        binding.trackRideCardHeadingText.setVisibility(View.GONE);
        binding.trackRideCardHeadingText2.setVisibility(View.VISIBLE);
        binding.trackRideCardSubHeadingText.setVisibility(View.GONE);
    }

    private void showTrackButton() {
        RideReceived = true;
        Constants.FIRE_BASE_NOTIFY = true;
        binding.trackRideButton.setVisibility(View.VISIBLE);
        // binding.trackRideCardHeadingText.setText(getString(R.string.ongoing_ride));
        binding.trackRideCardSubHeadingText.setVisibility(View.VISIBLE);
        binding.trackRideCardHeadingText2.setVisibility(View.GONE);
        binding.trackRideCardHeadingText.setVisibility(View.VISIBLE);
    }

    private void trackingActivity() {
        Intent i = new Intent(getActivity(), TrackingActivity.class);
        startActivity(i);
    }
    /*public void showPromoPopup(Context context, String message,Boolean bol) {
        final Dialog dialog = new Dialog(context);
        dialog.setContentView(R.layout.promotion_popup);
        dialog.setCancelable(true);
       // dialog.setCancelable(bol);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        dialog.findViewById(R.id.cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        *//*okay.setOnClickListener(v -> dialog.dismiss());*//*
        dialog.show();
        Window window = dialog.getWindow();
        assert window != null;
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }*/

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (RideReceived) {
            Intent broadcastIntent = new Intent();
            broadcastIntent.setAction("restartservice");
            broadcastIntent.setClass(getActivity(), Restarter.class);
            requireActivity().sendBroadcast(broadcastIntent);
        }
    }

    /*    @Override
        public void onRideRecieved(String json) {
            Log.v("homefragonRideRecieved", "homefrag onRideRecieved ---" );
            if (json != null) {
                SharedPreferences sharedPreferences = getActivity().getSharedPreferences("Driver_Info", 0);
                String json2, Status, notificationType;
                json2 = sharedPreferences.getString("Driver_Info_Object", "");
                Gson gson = new Gson();
                FireBaseDataModelObject fireBaseDataModelObject = gson.fromJson(json2, FireBaseDataModelObject.class);
                notificationType = fireBaseDataModelObject.getNotification_type();
                if (notificationType != null) {

                    DataList  dataList = gson.fromJson(fireBaseDataModelObject.getData(), DataList.class);
                    if(dataList.getCaptain_info_data()!=null &&
                            dataList.getCaptain_info_data().getDriver_status()!=null){
                        Log.v("homefragonRideRecieved", " onRideRecieved notificationType " + notificationType);
                        Status = dataList.getCaptain_info_data().getDriver_status();
                        if (Status.equalsIgnoreCase("3")) {
                            getActivity().runOnUiThread(() -> {

                                binding.trackRideButton.setVisibility(View.GONE);
                                binding.trackRideCardHeadingText.setVisibility(View.GONE);
                                binding.trackRideCardHeadingText2.setVisibility(View.VISIBLE);
                                binding.trackRideCardSubHeadingText.setVisibility(View.GONE);
                            });

                           // hideTrackButton();
                            vehicle_type_id=null;
                            MainApp.getInstance().setDataList(null);
                        }
                    }

                }
            }

        }*/
  /*  @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            MainApp.getInstance().setOnCaptainFind(this);
        } catch (Exception e)
        {

        }
    }*/
    private void dateTesting() {
        Calendar calendar = Calendar.getInstance();
        Log.v("Current Week", String.valueOf(calendar.get(Calendar.WEEK_OF_YEAR)));
        int current_week = calendar.get(Calendar.WEEK_OF_YEAR);
        int week_start_day = calendar.getFirstDayOfWeek(); // this will get the starting day os week in integer format i-e 1 if monday
        //   Toast.makeText(getContext(),"Current Week is"+current_week +"Start Day is"+week_start_day,Toast.LENGTH_SHORT).show();


        // get the starting and ending date
        // Set the calendar to sunday of the current week
        calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        System.out.println("Current week = " + Calendar.DAY_OF_WEEK);

        // Print dates of the current week starting on Sunday
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        String startDate = "", endDate = "";

        startDate = df.format(calendar.getTime());
        calendar.add(Calendar.DATE, 6);
        endDate = df.format(calendar.getTime());

        System.out.println("Start Date = " + startDate);
        System.out.println("End Date = " + endDate);
        Log.v("dateTesting", startDate + " to " + endDate);
    }

    private void buildAlertMessageNoGps() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage("Your GPS seems to be disabled, do you want to enable it?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(@SuppressWarnings("unused") final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        dialog.cancel();
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }

    public double CalculationByDistance(List<DummyDistanceTracker> DummyDistanceTrackerList) {
        int Radius = 6371;// radius of earth in Km
        double lat1 = DummyDistanceTrackerList.get(0).getLat();
        double lat2 = DummyDistanceTrackerList.get(1).getLat();
        double lon1 = DummyDistanceTrackerList.get(0).getLng();
        double lon2 = DummyDistanceTrackerList.get(1).getLng();
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1))
                * Math.cos(Math.toRadians(lat2)) * Math.sin(dLon / 2)
                * Math.sin(dLon / 2);
        double c = 2 * Math.asin(Math.sqrt(a));
        double valueResult = Radius * c;
        double km = valueResult / 1;
        DecimalFormat newFormat = new DecimalFormat("####");
        int kmInDec = Integer.valueOf(newFormat.format(km));
        double meter = valueResult % 1000;
        int meterInDec = Integer.valueOf(newFormat.format(meter));
        Log.i("RadiusValue", "" + valueResult + "   KM  " + kmInDec
                + " Meter   " + meterInDec);

        return Radius * c;
    }


    private void workManagerExp() {
        Log.v("workManagerExp", "workManagerExp ");
        final WorkManager mWorkManager = WorkManager.getInstance();

        Constraints constraints = new Constraints.Builder()

                .setRequiresCharging(true)
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .setRequiresBatteryNotLow(true)
                .setRequiresStorageNotLow(false)
                .build();


        //final OneTimeWorkRequest mRequest = new OneTimeWorkRequest.Builder(NotificationWorker.class).build();
        final PeriodicWorkRequest mRequest = new PeriodicWorkRequest.Builder(NotificationWorker.class, 5, TimeUnit.SECONDS)
                // setting a backoff on case the work needs to retry
                .setConstraints(constraints)
                .build();
        /*mWorkManager.enqueueUniquePeriodicWork("SYNC_DATA_WORK_NAME", ExistingPeriodicWorkPolicy.KEEP, //Existing Periodic Work policy
                refreshCpnWork   //work request
        );*/
       /* mWorkManager.enqueue(mRequest);*/
        WorkManager.getInstance().enqueue(mRequest);

       mWorkManager.getWorkInfoByIdLiveData(mRequest.getId()).observe(this, new Observer<WorkInfo>() {
            @Override
            public void onChanged(@Nullable WorkInfo workInfo) {
                if (workInfo != null) {
                    WorkInfo.State state = workInfo.getState();
                    // tvStatus.append(state.toString() + "\n");
                    Log.v("workManagerExp", "workManagerExp " + state.toString() + "\n");
                }
            }
        });
    }

}

    /*DummyDistanceTrackerList   = new ArrayList<>();
        DummyDistanceTrackerList.add(new DummyDistanceTracker(31.506143703358312,74.31993535583885));
        DummyDistanceTrackerList.add(new DummyDistanceTracker(31.50597006296345,74.31908366199858));
        DummyDistanceTrackerList.add(new DummyDistanceTracker(31.506143703358312,74.31993535583885));
        DummyDistanceTrackerList.add(new DummyDistanceTracker(31.506143703358312,74.31993535583885));
        double d=CalculationByDistance(DummyDistanceTrackerList);
        Log.v("Locationdistance", "RadiusValue " + d);*/
/*
        Location startPoint=new Location("locationA");
        startPoint.setLatitude(DummyDistanceTrackerList.get(0).getLat());
        startPoint.setLongitude(DummyDistanceTrackerList.get(0).getLng());

        Location endPoint=new Location("locationB");
        endPoint.setLatitude(DummyDistanceTrackerList.get(1).getLat());
        endPoint.setLongitude(DummyDistanceTrackerList.get(1).getLng());

        double distance=startPoint.distanceTo(endPoint);
        Log.v("Locationdistance", "Locationdistance " + distance);*/
