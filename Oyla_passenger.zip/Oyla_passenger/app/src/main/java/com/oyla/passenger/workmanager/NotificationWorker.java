package com.oyla.passenger.workmanager;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.work.Data;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.oyla.passenger.MainApp;
import com.oyla.passenger.R;
import com.oyla.passenger.datamodels.usermodel.UserLocation;
import com.oyla.passenger.services.location.LocationService;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.SharedPrefManager;

public class NotificationWorker extends Worker {
    private static final String TAG = "workManagerExp";
    private static final String WORK_RESULT = "work_result";
    private FusedLocationProviderClient mFusedLocationClient;
    private final static long UPDATE_INTERVAL = 6 * 1000;  /* 60 secs */
    private final static long FASTEST_INTERVAL = 5 * 1000;
    Context applicationContext;

    public NotificationWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        Log.v("workManagerExp", "doWork ");
        applicationContext = getApplicationContext();
        //showNotification("WorkManager", taskDataString != null ? taskDataString : "Message has been Sent");
        // Data outputData = new Data.Builder().putString(WORK_RESULT, "Jobs Finished").build();
        //  return Result.success(outputData);
     /*   Intent serviceIntent = new Intent(applicationContext, LocationService.class);
        serviceIntent.setAction(Constants.ACTION_START_FOREGROUND_SERVICE);
        Log.d("getDeviceLocation", "(android.os.Build.VERSION.SDK_INT "+android.os.Build.VERSION.SDK_INT);
        Log.d("getDeviceLocation", "(android.os.Build.VERSION.SDK_INT "+android.os.Build.VERSION_CODES.O);
        applicationContext.startService(serviceIntent);*/
        //getLocation();
        return Result.success();
    }
}