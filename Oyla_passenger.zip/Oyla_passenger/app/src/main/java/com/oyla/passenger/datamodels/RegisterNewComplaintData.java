package com.oyla.passenger.datamodels;

public class RegisterNewComplaintData {
    String userId;
    String bookingId;
    String image;
    String detail;
    String  complaintTypeId;
    public RegisterNewComplaintData(){

    }

    public RegisterNewComplaintData(String userId, String bookingId, String image, String detail, String complaintTypeId) {
        this.userId = userId;
        this.bookingId = bookingId;
        this.image = image;
        this.detail = detail;
        this.complaintTypeId = complaintTypeId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getBookingId() {
        return bookingId;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getComplaintTypeId() {
        return complaintTypeId;
    }

    public void setComplaintTypeId(String complaintTypeId) {
        this.complaintTypeId = complaintTypeId;
    }
}
