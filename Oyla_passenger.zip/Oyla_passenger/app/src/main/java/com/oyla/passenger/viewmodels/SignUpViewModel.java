package com.oyla.passenger.viewmodels;

import android.app.Application;
import android.text.Editable;
import android.text.TextWatcher;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;

import com.oyla.passenger.Repository.JsonRepository;
import com.oyla.passenger.datamodels.jsonreponsedatamodel.DataModelObject;
import com.oyla.passenger.datamodels.usermodel.UserData;

public class SignUpViewModel extends SharedViewModel {

    private MutableLiveData<String> Password = new MutableLiveData<>();
    private MutableLiveData<String> UserName = new MutableLiveData<>();
    private MutableLiveData<DataModelObject> mutableLiveData;
    private JsonRepository repository;

    public SignUpViewModel(@NonNull Application application) {
        super(application);
    }

    public MutableLiveData<String> getPassword() {
        return Password;
    }

    public MutableLiveData<String> getUserName() {
        return UserName;
    }

    public boolean validatePassword(String str) {
        return str.length() < 8;
    }

    public boolean validateUserName(String str) {
        return str.length() < 3;
    }

    public boolean isModel(UserData userData) {
        if (userData.getUserFirstName() == null) {
            UserName.setValue(null);
            return false;
        } else if (userData.getUserFirstName().isEmpty()) {
            UserName.setValue(null);
            return false;
        } else if (validateUserName((userData.getUserFirstName()))) {
            UserName.setValue(userData.getUserFirstName());
            return false;
        } else if (userData.getUserPassword() == null) {
            Password.setValue(null);
            return false;
        } else if (userData.getUserPassword().isEmpty()) {
            Password.setValue(null);
            return false;
        } else if (validatePassword((userData.getUserPassword()))) {
            Password.setValue(userData.getUserPassword());
            return false;
        } else {
            return true;
        }
    }

    public TextWatcher onPasswordChanged = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void afterTextChanged(Editable s) {
            Password.setValue(s.toString());
        }
    };

    public TextWatcher onUserNameChanged = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void afterTextChanged(Editable s) {
            UserName.setValue(s.toString());
        }
    };

    public void sendSignUpData(String userId, String firstName, String lastName, String password) {
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.registerUser(userId, firstName, lastName, password);
    }

    public MutableLiveData<DataModelObject> receiveOtpRepose() {
        return mutableLiveData;
    }
}
