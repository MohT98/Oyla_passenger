package com.oyla.passenger.datamodels;

public class ExceptionErrorClass {
    private String message;
    private String general_message;
    private String detailed_message;
    private int code;


    public ExceptionErrorClass(String message, String general_message, String detailed_message, int code) {
        this.message = message;
        this.general_message = general_message;
        this.detailed_message = detailed_message;
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getGeneral_message() {
        return general_message;
    }

    public void setGeneral_message(String general_message) {
        this.general_message = general_message;
    }

    public String getDetailed_message() {
        return detailed_message;
    }

    public void setDetailed_message(String detailed_message) {
        this.detailed_message = detailed_message;
    }
}
