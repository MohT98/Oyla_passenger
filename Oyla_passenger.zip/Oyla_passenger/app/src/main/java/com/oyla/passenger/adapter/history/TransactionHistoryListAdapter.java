package com.oyla.passenger.adapter.history;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.oyla.passenger.R;
import com.oyla.passenger.datamodels.historydata.TransactionHistoryData;

import java.util.List;

public class TransactionHistoryListAdapter extends RecyclerView.Adapter<TransactionHistoryListAdapter.MyViewHolder> {

    //  private ArrayList<TransactionHistoryData> dataSet;
    private final List<TransactionHistoryData> dataSet;
    private final Context mCtx;
    private OnItemClickListener mListener;
    String amount;
    String currency;


    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    public TransactionHistoryListAdapter(Context mCtx, List<TransactionHistoryData> data) {
        this.dataSet = data;
        this.mCtx = mCtx;
    }


    @NonNull
    @Override
    public TransactionHistoryListAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.transaction_history_list_item, parent, false);
        return new MyViewHolder(view, mListener);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(final TransactionHistoryListAdapter.MyViewHolder holder, final int listPosition) {


        String currentString =dataSet.get(listPosition).getCreated_at();
        String[] separated = currentString.split("T");
        holder.dataTime.setText(separated[0]);
       // String date=separated[0];

        //holder.dataTime.setText(dataSet.get(listPosition).getUpdated_at());

        if(dataSet.get(listPosition).getCurrency()!=null && dataSet.get(listPosition).getCurrency().isEmpty() ){
            currency =mCtx.getResources().getString(R.string.currency_text);
        }else {
            currency =dataSet.get(listPosition).getCurrency();
        }
        holder.amountType.setText( toTitleCase(dataSet.get(listPosition).getPayment_type()));
        amount=dataSet.get(listPosition).getAmount();
        if(amount.contains(".")){
            String[] separatedAmount = amount.split("\\.");
            Log.v("separatedAmount","separatedAmount "+separatedAmount[0]);
           // amount=separatedAmount[0];
            holder.amount.setText(currency +" "+separatedAmount[0]);
        }else {
            holder.amount.setText(currency +" "+amount);
        }

        holder.description.setText(toTitleCase(dataSet.get(listPosition).getDescription()));
        if(dataSet.get(listPosition).getType().equalsIgnoreCase("credit")){
            holder.amount.setTextColor(mCtx.getResources().getColor(R.color.green));
        }else {
            holder.amount.setTextColor(mCtx.getResources().getColor(R.color.red));
        }


            //Log.v("bas64","question "+ dtoQuestion.getHTML());
           /* String questionOption=  aa.replace("data:image/png;base64,", "");
            try {
                holder.amount.setText(Html.fromHtml(questionOption, source -> {
                    byte[] data = Base64.decode(source, Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
                    Drawable drawable = new BitmapDrawable(mCtx.getResources(), bitmap);
                    drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
                    return drawable;
                }, null));
            }catch (Exception ex)
            {
                //((TextView) findViewById(R.id.aasdadsdas)).setText(Html.fromHtml(aa));
                holder.amount.setText(Html.fromHtml(aa));
            }*/

    }


    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView  dataTime, amount,amountType, description;
        CardView transactionCardView;
        public MyViewHolder(@NonNull View itemView, final OnItemClickListener listener) {
            super(itemView);
            dataTime = itemView.findViewById(R.id.dataTime);
            amount = itemView.findViewById(R.id.amount);
            amountType = itemView.findViewById(R.id.amountType);
            description = itemView.findViewById(R.id.description);
            transactionCardView = itemView.findViewById(R.id.transactionCardView);

          /*  itemView.setOnClickListener(v -> {
                if (listener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onItemClick(position);
                    }
                }
            });*/
        }
    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }
    public static String toTitleCase(String string) {

        // Check if String is null
        if (string == null) {

            return null;
        }

        boolean whiteSpace = true;

        StringBuilder builder = new StringBuilder(string); // String builder to store string
        final int builderLength = builder.length();

        // Loop through builder
        for (int i = 0; i < builderLength; ++i) {

            char c = builder.charAt(i); // Get character at builders position

            if (whiteSpace) {

                // Check if character is not white space
                if (!Character.isWhitespace(c)) {

                    // Convert to title case and leave whitespace mode.
                    builder.setCharAt(i, Character.toTitleCase(c));
                    whiteSpace = false;
                }
            } else if (Character.isWhitespace(c)) {

                whiteSpace = true; // Set character is white space

            } else {

                builder.setCharAt(i, Character.toLowerCase(c)); // Set character to lowercase
            }
        }

        return builder.toString(); // Return builders text
    }
}

