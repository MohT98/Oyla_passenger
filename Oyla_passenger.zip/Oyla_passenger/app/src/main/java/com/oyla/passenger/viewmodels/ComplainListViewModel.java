package com.oyla.passenger.viewmodels;

import android.app.Application;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;

import com.oyla.passenger.Repository.JsonRepository;
import com.oyla.passenger.datamodels.jsonreponsedatamodel.DataModelObject;

public class ComplainListViewModel extends SharedViewModel{
    private MutableLiveData<DataModelObject> mutableLiveData;
    private JsonRepository repository;

    public ComplainListViewModel(@NonNull Application application) {
        super(application);
    }

    public void sendComplaintTypesRequest(String user_id) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.getComplaintTypes(user_id);
    }

    public MutableLiveData<DataModelObject> receiveComplaintTypesRepose() {
        return mutableLiveData;
    }
}