package com.oyla.passenger.datamodels.historydata;

import android.os.Parcel;
import android.os.Parcelable;

public class RideHistoryData implements Parcelable {
    private String id;
    private String booking_unique_id;
    private String passenger_id;
    private String driver_id;
    private String pickup_latitude;
    private String pickup_longitude;
    private String dropoff_latitude;
    private String dropoff_longitude;
    private String distance_kilomiters;
    private String estimate_minutes;
    private String vehicle_type;
    private String vehicle_amount;
    private String oyla_wallet_pay;
    private String driver_status;
    private String pickup_time;
    private String ride_complete_time;
    private String waiting_rate;
    private String waiting_minuts;
    private String estimated_amount;
    private String final_amount;
    private String vehicle_name;
    private String vehicle_number;
    private String vehicle_model_year;
    private String vehicle_img_front;
    private String driver_name;
    private String driver_profile_picture;
    private String driver_avg_rating;
    private String booking_rating;
    private String updated_at;
    private String created_at;
    private String fine_user_type;
    private String cancel_fine_amount;
    private String status;
    private String driver_initial_distance;
    private String payment_type;
    private String wallet_pay_amount;
    private String promo_discount;
    private String passenger_cash_paid;


    protected RideHistoryData(Parcel in) {
        id = in.readString();
        booking_unique_id = in.readString();
        passenger_id = in.readString();
        driver_id = in.readString();
        pickup_latitude = in.readString();
        pickup_longitude = in.readString();
        dropoff_latitude = in.readString();
        dropoff_longitude = in.readString();
        distance_kilomiters = in.readString();
        estimate_minutes = in.readString();
        vehicle_type = in.readString();
        vehicle_amount = in.readString();
        oyla_wallet_pay = in.readString();
        driver_status = in.readString();
        pickup_time = in.readString();
        ride_complete_time = in.readString();
        waiting_rate = in.readString();
        waiting_minuts = in.readString();
        estimated_amount = in.readString();
        final_amount = in.readString();
        vehicle_name = in.readString();
        vehicle_number = in.readString();
        vehicle_model_year = in.readString();
        vehicle_img_front = in.readString();
        driver_name = in.readString();
        driver_profile_picture = in.readString();
        driver_avg_rating = in.readString();
        booking_rating = in.readString();
        updated_at = in.readString();
        created_at = in.readString();
        fine_user_type = in.readString();
        cancel_fine_amount = in.readString();
        status = in.readString();
        driver_initial_distance = in.readString();
        payment_type = in.readString();
        wallet_pay_amount = in.readString();
        promo_discount = in.readString();
        passenger_cash_paid = in.readString();
    }

    public static final Creator<RideHistoryData> CREATOR = new Creator<RideHistoryData>() {
        @Override
        public RideHistoryData createFromParcel(Parcel in) {
            return new RideHistoryData(in);
        }

        @Override
        public RideHistoryData[] newArray(int size) {
            return new RideHistoryData[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBooking_unique_id() {
        return booking_unique_id;
    }

    public void setBooking_unique_id(String booking_unique_id) {
        this.booking_unique_id = booking_unique_id;
    }

    public String getPassenger_id() {
        return passenger_id;
    }

    public void setPassenger_id(String passenger_id) {
        this.passenger_id = passenger_id;
    }

    public String getDriver_id() {
        return driver_id;
    }

    public void setDriver_id(String driver_id) {
        this.driver_id = driver_id;
    }

    public String getPickup_latitude() {
        return pickup_latitude;
    }

    public void setPickup_latitude(String pickup_latitude) {
        this.pickup_latitude = pickup_latitude;
    }

    public String getPickup_longitude() {
        return pickup_longitude;
    }

    public void setPickup_longitude(String pickup_longitude) {
        this.pickup_longitude = pickup_longitude;
    }

    public String getDropoff_latitude() {
        return dropoff_latitude;
    }

    public void setDropoff_latitude(String dropoff_latitude) {
        this.dropoff_latitude = dropoff_latitude;
    }

    public String getDropoff_longitude() {
        return dropoff_longitude;
    }

    public void setDropoff_longitude(String dropoff_longitude) {
        this.dropoff_longitude = dropoff_longitude;
    }

    public String getDistance_kilomiters() {
        return distance_kilomiters;
    }

    public void setDistance_kilomiters(String distance_kilomiters) {
        this.distance_kilomiters = distance_kilomiters;
    }

    public String getEstimate_minutes() {
        return estimate_minutes;
    }

    public void setEstimate_minutes(String estimate_minutes) {
        this.estimate_minutes = estimate_minutes;
    }

    public String getVehicle_type() {
        return vehicle_type;
    }

    public void setVehicle_type(String vehicle_type) {
        this.vehicle_type = vehicle_type;
    }

    public String getVehicle_amount() {
        return vehicle_amount;
    }

    public void setVehicle_amount(String vehicle_amount) {
        this.vehicle_amount = vehicle_amount;
    }

    public String getOyla_wallet_pay() {
        return oyla_wallet_pay;
    }

    public void setOyla_wallet_pay(String oyla_wallet_pay) {
        this.oyla_wallet_pay = oyla_wallet_pay;
    }

    public String getDriver_status() {
        return driver_status;
    }

    public void setDriver_status(String driver_status) {
        this.driver_status = driver_status;
    }

    public String getPickup_time() {
        return pickup_time;
    }

    public void setPickup_time(String pickup_time) {
        this.pickup_time = pickup_time;
    }

    public String getRide_complete_time() {
        return ride_complete_time;
    }

    public void setRide_complete_time(String ride_complete_time) {
        this.ride_complete_time = ride_complete_time;
    }

    public String getWaiting_rate() {
        return waiting_rate;
    }

    public void setWaiting_rate(String waiting_rate) {
        this.waiting_rate = waiting_rate;
    }

    public String getWaiting_minuts() {
        return waiting_minuts;
    }

    public void setWaiting_minuts(String waiting_minuts) {
        this.waiting_minuts = waiting_minuts;
    }

    public String getEstimated_amount() {
        return estimated_amount;
    }

    public void setEstimated_amount(String estimated_amount) {
        this.estimated_amount = estimated_amount;
    }

    public String getFinal_amount() {
        return final_amount;
    }

    public void setFinal_amount(String final_amount) {
        this.final_amount = final_amount;
    }

    public String getVehicle_name() {
        return vehicle_name;
    }

    public void setVehicle_name(String vehicle_name) {
        this.vehicle_name = vehicle_name;
    }

    public String getVehicle_number() {
        return vehicle_number;
    }

    public void setVehicle_number(String vehicle_number) {
        this.vehicle_number = vehicle_number;
    }

    public String getVehicle_model_year() {
        return vehicle_model_year;
    }

    public void setVehicle_model_year(String vehicle_model_year) {
        this.vehicle_model_year = vehicle_model_year;
    }

    public String getVehicle_img_front() {
        return vehicle_img_front;
    }

    public void setVehicle_img_front(String vehicle_img_front) {
        this.vehicle_img_front = vehicle_img_front;
    }

    public String getDriver_name() {
        return driver_name;
    }

    public void setDriver_name(String driver_name) {
        this.driver_name = driver_name;
    }

    public String getDriver_profile_picture() {
        return driver_profile_picture;
    }

    public void setDriver_profile_picture(String driver_profile_picture) {
        this.driver_profile_picture = driver_profile_picture;
    }

    public String getDriver_avg_rating() {
        return driver_avg_rating;
    }

    public void setDriver_avg_rating(String driver_avg_rating) {
        this.driver_avg_rating = driver_avg_rating;
    }

    public String getBooking_rating() {
        return booking_rating;
    }

    public void setBooking_rating(String booking_rating) {
        this.booking_rating = booking_rating;
    }

    public String getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(String updated_at) {
        this.updated_at = updated_at;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getFine_user_type() {
        return fine_user_type;
    }

    public void setFine_user_type(String fine_user_type) {
        this.fine_user_type = fine_user_type;
    }

    public String getCancel_fine_amount() {
        return cancel_fine_amount;
    }

    public void setCancel_fine_amount(String cancel_fine_amount) {
        this.cancel_fine_amount = cancel_fine_amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDriver_initial_distance() {
        return driver_initial_distance;
    }

    public void setDriver_initial_distance(String driver_initial_distance) {
        this.driver_initial_distance = driver_initial_distance;
    }

    public String getPayment_type() {
        return payment_type;
    }

    public void setPayment_type(String payment_type) {
        this.payment_type = payment_type;
    }

    public String getWallet_pay_amount() {
        return wallet_pay_amount;
    }

    public void setWallet_pay_amount(String wallet_pay_amount) {
        this.wallet_pay_amount = wallet_pay_amount;
    }

    public String getPromo_discount() {
        return promo_discount;
    }

    public void setPromo_discount(String promo_discount) {
        this.promo_discount = promo_discount;
    }

    public String getPassenger_cash_paid() {
        return passenger_cash_paid;
    }

    public void setPassenger_cash_paid(String passenger_cash_paid) {
        this.passenger_cash_paid = passenger_cash_paid;
    }

    public static Creator<RideHistoryData> getCREATOR() {
        return CREATOR;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(booking_unique_id);
        dest.writeString(passenger_id);
        dest.writeString(driver_id);
        dest.writeString(pickup_latitude);
        dest.writeString(pickup_longitude);
        dest.writeString(dropoff_latitude);
        dest.writeString(dropoff_longitude);
        dest.writeString(distance_kilomiters);
        dest.writeString(estimate_minutes);
        dest.writeString(vehicle_type);
        dest.writeString(vehicle_amount);
        dest.writeString(oyla_wallet_pay);
        dest.writeString(driver_status);
        dest.writeString(pickup_time);
        dest.writeString(ride_complete_time);
        dest.writeString(waiting_rate);
        dest.writeString(waiting_minuts);
        dest.writeString(estimated_amount);
        dest.writeString(final_amount);
        dest.writeString(vehicle_name);
        dest.writeString(vehicle_number);
        dest.writeString(vehicle_model_year);
        dest.writeString(vehicle_img_front);
        dest.writeString(driver_name);
        dest.writeString(driver_profile_picture);
        dest.writeString(driver_avg_rating);
        dest.writeString(booking_rating);
        dest.writeString(updated_at);
        dest.writeString(created_at);
        dest.writeString(fine_user_type);
        dest.writeString(cancel_fine_amount);
        dest.writeString(status);
        dest.writeString(driver_initial_distance);
        dest.writeString(payment_type);
        dest.writeString(wallet_pay_amount);
        dest.writeString(promo_discount);
        dest.writeString(passenger_cash_paid);
    }
}
