package com.oyla.passenger.interfaces;

public interface OnCaptainFind {
    void onRideRecieved(String json);
}
