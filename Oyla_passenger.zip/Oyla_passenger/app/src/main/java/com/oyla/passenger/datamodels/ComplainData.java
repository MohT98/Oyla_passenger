package com.oyla.passenger.datamodels;

import android.os.Parcel;
import android.os.Parcelable;

public class ComplainData implements Parcelable {
    private String id;
    private String name;

    public ComplainData(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    protected ComplainData(Parcel in) {
        id = in.readString();
        name = in.readString();
    }

    public static final Creator<ComplainData> CREATOR = new Creator<ComplainData>() {
        @Override
        public ComplainData createFromParcel(Parcel in) {
            return new ComplainData(in);
        }

        @Override
        public ComplainData[] newArray(int size) {
            return new ComplainData[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(name);
    }
}
