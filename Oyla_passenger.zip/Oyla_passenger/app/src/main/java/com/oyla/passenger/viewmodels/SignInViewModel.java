package com.oyla.passenger.viewmodels;

import android.app.Application;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;

import com.oyla.passenger.Repository.JsonRepository;
import com.oyla.passenger.datamodels.jsonreponsedatamodel.DataModelObject;


public class SignInViewModel extends SharedViewModel {
    private MutableLiveData<String> UserPhoneNumber = new MutableLiveData<>();
    /* private MutableLiveData<List<UserData>> mutableLiveData;*/
    private MutableLiveData<DataModelObject> mutableLiveData;
    private JsonRepository repository;

    public SignInViewModel(@NonNull Application application) {
        super(application);
    }

    public MutableLiveData<String> getUserPhoneNumber() {
        if (UserPhoneNumber == null) {
            UserPhoneNumber = new MutableLiveData<>();
        }
        return UserPhoneNumber;
    }

    public TextWatcher onUserPhoneNumberChanged = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
           /* if(charSequence.length() >=10){
                continueButton.setBackground(ContextCompat.getDrawable(SignInActivity.this, R.drawable.button));
            }
            if(charSequence.length() < 10){
                continueButton.setBackground(ContextCompat.getDrawable(SignInActivity.this,R.drawable.button_light));
            }*/

        }

        @Override
        public void afterTextChanged(Editable s) {

            if (s.toString().length() == 1 && s.toString().startsWith("0")) {
                s.clear();
            }
            UserPhoneNumber.setValue(s.toString());
        }
    };


    public boolean validateUserEmail(String str) {
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
        return str.matches(emailPattern);
    }


    public void sendMob(String value, String fb_token, String referral_code, String identity) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.sendMobNumber(value, fb_token, referral_code, identity);
    }

    public MutableLiveData<DataModelObject> mobApiResponse() {
        return mutableLiveData;
    }

    public void sendOtp(String userId, String otpCode) {
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();

        }
        repository = new JsonRepository();
        mutableLiveData = repository.verifyOTP(userId, otpCode);

    }

    public MutableLiveData<DataModelObject> receiveOtpRepose() {
        return mutableLiveData;
    }

    public void resendOTP(String userId, String mobNumber,String network) {
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();

        }
        repository = new JsonRepository();
        mutableLiveData = repository.resendOTP(userId, mobNumber,network);

    }

    public MutableLiveData<DataModelObject> resendOTPRepose() {
        return mutableLiveData;
    }

    /*public MutableLiveData<DataModelObject> receiveNewOTP() {
        return mutableLiveData;
    }*/

    public void registerSocial(String type, String mobile_no, String email, String first_name, String last_name,
                               String provider, String fb_token,String referral_code) {
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.registerSocial(type, mobile_no, email, first_name, last_name, provider, fb_token,referral_code);

    }

    public MutableLiveData<DataModelObject> registerSocialRepose() {
        return mutableLiveData;
    }


}
