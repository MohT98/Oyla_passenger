package com.oyla.passenger.ui.activity.update.profile;

import android.app.Dialog;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.gms.auth.api.phone.SmsRetriever;
import com.google.android.gms.auth.api.phone.SmsRetrieverClient;
import com.google.android.gms.tasks.Task;
import com.oyla.passenger.BroadcastReceiver.SmsBroadcastReceiver;
import com.oyla.passenger.MainApp;
import com.oyla.passenger.R;
import com.oyla.passenger.databinding.ActivityUpdateMobileNumberBinding;
import com.oyla.passenger.interfaces.OtpReceivedInterface;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.DialogBoxSingleton;
import com.oyla.passenger.utilities.Messages;
import com.oyla.passenger.utilities.SharedPrefManager;
import com.oyla.passenger.viewmodels.UpdateProfileViewModel;

import java.util.Locale;
import java.util.Objects;

public class UpdateMobNumberActivity extends BaseActivity implements OtpReceivedInterface, View.OnKeyListener {

    private ActivityUpdateMobileNumberBinding binding;
    private UpdateProfileViewModel viewModel;
    private int errorCount = 0;
    private String user_id;
    private int backCount = 0;
    private final long START_TIME_IN_MILLIS = 60000;
   /* private final long START_TIME_IN_MILLIS = 10000;*/
    private CountDownTimer mCountDownTimer;
    private long mTimeLeftInMillis = START_TIME_IN_MILLIS;
    private boolean mTimerRunning;
    private String countryCode = "";
    private String otpCode, accessToken, value, networkText, userMobileNumber;
    private SmsBroadcastReceiver mSmsBroadcastReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        hideAppBar(this);
        binding = setContentView(this, R.layout.activity_update_mobile_number);
        viewModel = new ViewModelProvider(this).get(UpdateProfileViewModel.class);
        binding.setViewModel(viewModel);
        //initCountryList();
        networkText = "Mobilink";
        userMobileNumber = getIntent().getStringExtra("userMobileNumber");
        user_id = SharedPrefManager.getInstance(UpdateMobNumberActivity.this).getUserInfo().getUserId();
        binding.updateButtons.customButtonText.setText(getResources().getString(R.string.continue_text));
        binding.ccp.registerPhoneNumberTextView(binding.phoneNumberEditText);
        // binding.ccp.getSelectedCountryCode();
       /* Log.v("UpdateMobActivity", "hint Length " + binding.phoneNumberEditText.getHint().length());
        Log.v("UpdateMobActivity", "hint text " + binding.phoneNumberEditText.getHint().toString());
        Log.v("UpdateMobActivity", "getSelectedCountryCode " + binding.ccp.getSelectedCountryCode());
        Log.v("UpdateMobActivity", "getSelectedCountryCode length " + binding.ccp.getSelectedCountryCode().length());*/
        countryCode = binding.ccp.getSelectedCountryNameCode();
        binding.updateButtons.button.setOnClickListener(v -> {
            if (binding.updateButtons.customButtonText.getText().toString().equalsIgnoreCase(getResources().getString(R.string.continue_text))) {
                updateMobileNumber();
            }
            if (binding.updateButtons.customButtonText.getText().toString().equalsIgnoreCase(getResources().getString(R.string.resend_text))) {
                resetTimer();
                pauseTimer();
                sendMob();
            }
        });
        binding.backButton.setOnClickListener(v -> {
            backFlow();
        });

        viewModel.getUserPhoneNumber().observe(this, s -> {
            if (s != null) {
                Log.v("hintLength", "s number length " + s.length());
                removeError(binding.phoneNumberTextInput);
                if (TextUtils.isEmpty(s)) {
                    showError(Messages.EmptyMessage, binding.phoneNumberTextInput, binding.phoneNumberEditText);
                    //userData.setUserName(null);
                } else if (s.length() < 10) {
                    if (errorCount > 0) {
                        showError(Messages.phoneNumberValidMessage, binding.phoneNumberTextInput, binding.phoneNumberEditText);
                    }
                    //userData.setUserName(s);
                } else {
                    //userData.setUserName(s);
                }


            } else {
                //showError(Messages.EmptyMessage, binding.uNameTextInput, binding.usame);
                //model.setUserName(null);
            }
        });

        binding.networkTextLayout.setOnClickListener(v -> networkDialog());

        userMobileNumber = userMobileNumber.replace(binding.ccp.getSelectedCountryCode(), "");
        binding.phoneNumberEditText.setText(userMobileNumber);

        binding.codeOne.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() == 1) {
                    binding.codeTwo.requestFocus();
                }
            }
        });

        binding.codeTwo.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() == 1) {
                    binding.codeThree.requestFocus();
                }
               /* if (s.length() == 0) {
                    // binding.codeOne.requestFocus();
                    //moveBack();
                }*/
            }
        });

        binding.codeThree.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() == 1) {
                    binding.codeFour.requestFocus();
                }
                /*if (s.length() == 0) {
                    // binding.codeTwo.requestFocus();
                    //moveBack();
                }*/
            }
        });

        binding.codeFour.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                Log.v("codeFour", "codeFour " + s.length());
                /*if (s.length() == 0) {
                    // binding.codeThree.requestFocus();
                    // moveBack();
                }*/
            }
        });

        binding.codeOne.setOnKeyListener(this);
        binding.codeTwo.setOnKeyListener(this);
        binding.codeThree.setOnKeyListener(this);
        binding.codeFour.setOnKeyListener(this);
    }

    private void updateMobileNumber() {
        errorCount = 1;
        if (Objects.requireNonNull(binding.phoneNumberEditText.getText()).toString().trim().isEmpty()) {
            showError(Messages.EmptyMessage, binding.phoneNumberTextInput, binding.phoneNumberEditText);
            return;
        } else if (String.valueOf(binding.phoneNumberEditText.getText()).length() < 10) {
            showError(Messages.phoneNumberValidMessage, binding.phoneNumberTextInput, binding.phoneNumberEditText);
            return;
        }
       /* viewModel.updateProfileRequest(user_id,
                "mobile_no",
                binding.phoneNumberEditText.getText().toString().trim(),
                UpdateMobNumberActivity.this);
        updateProfile();*/
        backCount++;
        if (backCount == 1) {
            startSMSListener();
            mSmsBroadcastReceiver = new SmsBroadcastReceiver();
            mSmsBroadcastReceiver.setOnOtpListeners(this);
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction(SmsRetriever.SMS_RETRIEVED_ACTION);
            getApplicationContext().registerReceiver(mSmsBroadcastReceiver, intentFilter);
            numberEditDialog();
        }
        if (backCount == 2) {
            pauseTimer();
            resetTimer();
            verifyOTP();
        }
        //showToast(getApplicationContext(), "Proceed");
    }

    private void numberEditDialog() {
        final Dialog dialog = new Dialog(UpdateMobNumberActivity.this);
        dialog.setContentView(R.layout.custom_dialog);
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        value = binding.ccp.getSelectedCountryCodeWithPlus() + "" + binding.phoneNumberEditText.getText();
        ((TextView) dialog.findViewById(R.id.textPhoneNumber)).setText(value);
        // if button is clicked, close the custom dialog
        dialog.findViewById(R.id.ok).setOnClickListener(v -> {
            sendMob();
            dialog.dismiss();
        });
        dialog.findViewById(R.id.edit).setOnClickListener(v -> {
            dialog.dismiss();
            backCount = 0;
        });
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private void sendMob() {
        viewModel.resendOTP(user_id, binding.ccp.getSelectedCountryCode() + binding.phoneNumberEditText.getText().toString().trim(), Constants.NETWORK);
        startLoader();
        viewModel.resendOTPRepose().observe(this, dataModelObject -> {
            stopLoader();
            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                binding.editPhoneNumberLayout.setVisibility(View.GONE);
                binding.otpLayout.setVisibility(View.VISIBLE);
                startTimer();
                binding.updateButtons.customButtonText.setText(getResources().getString(R.string.continue_text));
            } else {
                backCount--;
                DialogBoxSingleton.getInstance().showErrorPopup(UpdateMobNumberActivity.this, dataModelObject.getError());
            }
        });
     /*   Log.v("newToken ", "sendMob FireBaseToken  " + LatestFirebaseMessagingService.getToken(this));
        if (LatestFirebaseMessagingService.getToken(this).equalsIgnoreCase("empty") || LatestFirebaseMessagingService.getToken(this) == null) {
            showToast(this, "Please try Again");
        } else {
            // MainApp.getInstance().getFireBaseToken();
            startLoader();
            viewModel.sendMob(value, LatestFirebaseMessagingService.getToken(this), referral_code, "mobile_no");
            mobileApiResponse();
        }*/
    }


    @Override
    public void onOtpReceived(String otp) {
        String[] separated = otp.split(":");
        String code = separated[1] = separated[1].trim();
        char[] minArray = code.toCharArray();
        Log.v("messageText", "messageText " + otp);
        Log.v("messageText", "minArray " + minArray.length);
        binding.codeOne.setText(String.valueOf(minArray[0]));
        binding.codeTwo.setText(String.valueOf(minArray[1]));
        binding.codeThree.setText(String.valueOf(minArray[2]));
        binding.codeFour.setText(String.valueOf(minArray[3]));

        verifyOTP();
    }

    private void verifyOTP() {
        //nextActivity(NumberVerificationActivity.this, SignUpActivity.class);
        otpCode = binding.codeOne.getText().toString() + binding.codeTwo.getText().toString() + binding.codeThree.getText().toString() + binding.codeFour.getText().toString();
        // Constants.Auth = Constants.Bearer + " " + Constants.Token;
        // Log.v("onChanged","Mob number "+dataModelObject.getData().getUser().getUserPhoneNumber());
        Log.v("otpCode.length()", "otpCode.length() " + otpCode.length());
        if (otpCode.isEmpty() || otpCode.length() < 4) {
            showToast(UpdateMobNumberActivity.this, "Please Enter OTP Code");
        } else {
            if (!isFinishing()) {
                startLoader();
            }
            Log.v("mobileApiResponse", "accessToken " + accessToken);
            accessToken = SharedPrefManager.getInstance(UpdateMobNumberActivity.this).getUserInfo().getAccessToken();
            // Constants.Auth = Constants.Bearer + " " +  SharedPrefManager.getInstance(getApplicationContext()).getUserInfo().getAccessToken();
            Constants.Auth = Constants.Bearer + " " + accessToken;
            viewModel.verifyOtpUpdateMobile(user_id, binding.ccp.getSelectedCountryCode() + binding.phoneNumberEditText.getText().toString().trim(), Constants.NETWORK, otpCode);
            // showToast(NumberVerificationActivity.this,"Wait for user verification");
            otpRepose();
        }
    }

    private void otpRepose() {

        viewModel.verifyOtpUpdateMobileRepose().observe(this, dataModelObject -> {
            Log.v("otpRepose", "otpRepose " + dataModelObject.getStatus());
            stopLoader();
            pauseTimer();
            resetTimer();
            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                MainApp.getInstance().setUserData(dataModelObject.getData().getUser());
                showToast(UpdateMobNumberActivity.this, "Profile Update SuccessFully");
                finish();
            } else {
                backCount--;
                //showToast(NumberVerificationActivity.this, dataModelObject.getError().getMessage());
                //  showToast(NumberVerificationActivity.this, "Invalid OTP code.");
                DialogBoxSingleton.getInstance().showErrorPopup(UpdateMobNumberActivity.this, dataModelObject.getError());
                if (dataModelObject.getError().getMessage() != null) {
                    // showToast(NumberVerificationActivity.this, dataModelObject.getError().getMessage());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                } else if (dataModelObject.getError().getMessages() != null) {
                    // showToast(NumberVerificationActivity.this, dataModelObject.getError().getMessages().toString());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                }

            }
        });
    }

    @Override
    public void onOtpTimeout() {
    }
    public void startSMSListener() {
        SmsRetrieverClient mClient = SmsRetriever.getClient(this);
        Task<Void> mTask = mClient.startSmsRetriever();
        mTask.addOnSuccessListener(aVoid -> {
            // layoutInput.setVisibility(View.GONE);
            //  layoutVerify.setVisibility(View.VISIBLE);
            //Toast.makeText(SignInActivity.this, "SMS Retriever starts", Toast.LENGTH_LONG).show();
        });
        mTask.addOnFailureListener(e -> {
            //Toast.makeText(SignInActivity.this, "Error", Toast.LENGTH_LONG).show();
        });
    }

    private void startTimer() {
        mCountDownTimer = new CountDownTimer(mTimeLeftInMillis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                mTimeLeftInMillis = millisUntilFinished;
                updateCountDownText();
            }
            @Override
            public void onFinish() {
                mTimerRunning = false;
                binding.updateButtons.customButtonText.setText(getResources().getString(R.string.resend_text));
            }
        }.start();
        mTimerRunning = true;
      /*  mButtonStartPause.setText("pause");
        mButtonReset.setVisibility(View.INVISIBLE);*/
    }

    private void pauseTimer() {
        if(mCountDownTimer!=null){
            mCountDownTimer.cancel();
            mTimerRunning = false;
        }
    }

    private void resetTimer() {
        mTimeLeftInMillis = START_TIME_IN_MILLIS;
        updateCountDownText();
       /* mButtonReset.setVisibility(View.INVISIBLE);
        mButtonStartPause.setVisibility(View.VISIBLE);*/
    }

    private void updateCountDownText() {
        int minutes = (int) (mTimeLeftInMillis / 1000) / 60;
        int seconds = (int) (mTimeLeftInMillis / 1000) % 60;
        String timeLeftFormatted = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
        Log.v("timeLeftFormatted", "timeLeftFormatted " + timeLeftFormatted);
        binding.timerTextOne.setText(timeLeftFormatted);
        binding.timerTextTwo.setText(timeLeftFormatted);
    }

    @Override
    public void onBackPressed() {
        backFlow();
    }

    private void backFlow() {
        if (backCount == 1) {
            backCount--;
            binding.editPhoneNumberLayout.setVisibility(View.VISIBLE);
            binding.otpLayout.setVisibility(View.GONE);
            pauseTimer();
            resetTimer();
            binding.codeOne.setText("");
            binding.codeTwo.setText("");
            binding.codeThree.setText("");
            binding.codeFour.setText("");
            binding.updateButtons.customButtonText.setText(getResources().getString(R.string.continue_text));
        } else if (backCount == 2) {
            backCount--;
            binding.editPhoneNumberLayout.setVisibility(View.GONE);
            binding.otpLayout.setVisibility(View.VISIBLE);

        } else {
            super.onBackPressed();
        }
    }

    private void networkDialog() {
        //final Dialog dialog = new Dialog(SignInActivity.this, R.style.full_screen_dialog);
        final Dialog dialog = new Dialog(UpdateMobNumberActivity.this);
        //dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.network_dialog);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        dialog.findViewById(R.id.jazzLayout).setOnClickListener(V -> {
            //Constants.NETWORK=((TextView)dialog.findViewById(R.id.jazzText)).getText().toString().toLowerCase();
            Constants.NETWORK = "Mobilink";
            changeNetWork(Constants.NETWORK, R.drawable.jazz);
            dialog.dismiss();
        });
        dialog.findViewById(R.id.telenorLayout).setOnClickListener(V -> {
            Constants.NETWORK = ((TextView) dialog.findViewById(R.id.telenorText)).getText().toString();
            changeNetWork(Constants.NETWORK, R.drawable.telenor);
            dialog.dismiss();
        });
        dialog.findViewById(R.id.ufoneLayout).setOnClickListener(V -> {
            Constants.NETWORK = ((TextView) dialog.findViewById(R.id.ufoneText)).getText().toString();
            changeNetWork(Constants.NETWORK, R.drawable.ufone);
            dialog.dismiss();
        });
        dialog.findViewById(R.id.zongLayout).setOnClickListener(V -> {
            Constants.NETWORK = ((TextView) dialog.findViewById(R.id.zongText)).getText().toString();
            changeNetWork(Constants.NETWORK, R.drawable.zong);
            dialog.dismiss();
        });
        if (!isFinishing()) {
            //show dialog
            dialog.show();
        }

        Window window = dialog.getWindow();
        assert window != null;
        window.setGravity(Gravity.CENTER);
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private void changeNetWork(String network, int drawable) {
        binding.networkText.setText(network);
        binding.simLogo.setBackground(ContextCompat.getDrawable(this, drawable));
        // binding.simbinding.setImageDrawable(ContextCompat.getDrawable(this, drawable));
    }

    @Override
    public boolean onKey(View v, int keyCode, KeyEvent event) {
        Log.v("moveBack2", "keyCode = " + keyCode);
        if (event.getAction() == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DEL) {
            Log.v("moveBack2", "ACTION_DOWN ");
            Log.v("moveBack2", "KEYCODE_1 ");
            moveBack(v);

        }
        return false;
    }

    private void moveBack(View view) {

        if (view == binding.codeFour) {
            Log.v("moveBack2", " moveBack3 codeFour ");
            Log.v("moveBack2", "moveBack3 codeFour length " + binding.codeFour.length());
            if (binding.codeFour.length() == 0) {
                binding.codeThree.requestFocus();
            }

        } else if (view == binding.codeThree) {
            Log.v("moveBack2", "moveBack3 codeThree ");
            Log.v("moveBack2", "moveBack3 codeFour length " + binding.codeThree.length());
            if (binding.codeThree.length() == 0) {
                binding.codeTwo.requestFocus();
            }
        } else if (view == binding.codeTwo) {
            Log.v("moveBack2", "moveBack3 codeTwo  ");
            Log.v("moveBack2", "moveBack3 codeFour length " + binding.codeTwo.length());
            if (binding.codeTwo.length() == 0) {
                binding.codeOne.requestFocus();
            }
            //  binding.codeOne.requestFocus();
        }

    }
}