package com.oyla.passenger.viewmodels;

import android.app.Application;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;

import com.oyla.passenger.Repository.JsonRepository;
import com.oyla.passenger.datamodels.jsonreponsedatamodel.DataModelObject;
import com.oyla.passenger.datamodels.JazzCashData;

public class JazzCashViewModel extends SharedViewModel{
    private MutableLiveData<String> userPhoneNumber = new MutableLiveData<>();
    private MutableLiveData<String> userName = new MutableLiveData<>();
    private MutableLiveData<String> userCNIC = new MutableLiveData<>();
    private MutableLiveData<String> userAmount = new MutableLiveData<>();

    private MutableLiveData<DataModelObject> mutableLiveData;
    private JsonRepository repository;

    public JazzCashViewModel(@NonNull Application application) {
        super(application);
    }

    public MutableLiveData<String> getUserPhoneNumber() {
        return userPhoneNumber;
    }

    public MutableLiveData<String> getUserName() {
        return userName;
    }

    public MutableLiveData<String> getUserCNIC() {
        return userCNIC;
    }

    public MutableLiveData<String> getUserAmount() {
        return userAmount;
    }


    public boolean validateUserName(String str) {
        return str.length() < 1;
    }

    public TextWatcher onUserNameChanged = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void afterTextChanged(Editable s) {
            userName.setValue(s.toString());
        }
    };

    public TextWatcher onNumberChanged = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void afterTextChanged(Editable s) {
            userPhoneNumber.setValue(s.toString());
        }
    };

    public TextWatcher onCNICChanged = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void afterTextChanged(Editable s) {
            userCNIC.setValue(s.toString());
        }
    };

    public TextWatcher onAmountChanged = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void afterTextChanged(Editable s) {
            userAmount.setValue(s.toString());
        }
    };
   
    public void jazzCashPayRequest( JazzCashData jazzCashData) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.jazzCashPay(jazzCashData);
    }

    public MutableLiveData<DataModelObject>jazzCashPayRepose() {
        return mutableLiveData;
    }

}
