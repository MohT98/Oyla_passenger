package com.oyla.passenger;

import android.app.Application;
import android.util.Log;

import com.google.firebase.FirebaseApp;
import com.oyla.passenger.datamodels.CaptainInfoData;
import com.oyla.passenger.datamodels.NearestDriversData;
import com.oyla.passenger.datamodels.usermodel.BookingInfoData;
import com.oyla.passenger.datamodels.jsonreponsedatamodel.DataList;
import com.oyla.passenger.datamodels.usermodel.DriverCoordinate;
import com.oyla.passenger.datamodels.usermodel.UserData;
import com.oyla.passenger.datamodels.usermodel.UserLocation;
import com.oyla.passenger.interfaces.BookingStatusInterface;
import com.oyla.passenger.interfaces.ChatMessageCallBacks;
import com.oyla.passenger.interfaces.NearestDriver;
import com.oyla.passenger.interfaces.OnCaptainFind;
import com.oyla.passenger.interfaces.OylaWallet;
import com.oyla.passenger.interfaces.SearchLocation;
import com.oyla.passenger.interfaces.ServiceCallbacks;
import com.oyla.passenger.services.LatestFirebaseMessagingService;
import com.oyla.passenger.utilities.AppSignatureHelper;

import java.util.List;

public class MainApp  extends Application {
    private static MainApp mInstance;
    private UserData userData;
    private String fireBaseToken;
    private OnCaptainFind onCaptainFind;
    private ServiceCallbacks serviceCallbacks;
    private OylaWallet oylaWallet;
    private SearchLocation searchLocation;
    public boolean Booking_REQUEST=false;
    private UserLocation userLocation;
    private DataList dataList;
    private CaptainInfoData captainInfoData;
    DriverCoordinate driverCoordinate;
    private float bearing;
    private double perKM;
    private double perMint;
    private double vehicleRate;
    private String tax_percentage;
    private String peak_factor_rate;
    private String driverStatus ;
    private String rideStatus ;
    private double ridePickup_latitude ;
    private double ridePickup_longitude ;
    private double rideDropOff_latitude ;
    private double rideDropOff_longitude ;
    private NearestDriver nearestDriver;
    private String hashKey;
    private String min_ride_fares;
    private BookingInfoData bookingInfoData;
    private BookingStatusInterface bookingStatusInterface;
    private ChatMessageCallBacks chatMessageCallBacks;

    public ChatMessageCallBacks getChatMessageCallBacks() {
        return chatMessageCallBacks;
    }



    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
        /*Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));*/
      /*  InternetConnector_Receiver internetConnector_receiver = new InternetConnector_Receiver();
        IntentFilter filter = new IntentFilter();
        filter.addAction(getResources().getString(R.string.action_connectivity_change));
        registerReceiver(internetConnector_receiver, filter);*/

        FirebaseApp.initializeApp(this);
        AppSignatureHelper appSignatureHelper = new AppSignatureHelper(this);
        hashKey=appSignatureHelper.getAppSignatures().get(0);
        setHashKey(hashKey);

        //Log.v("SmsBroadcastReceiver ","hashKey "+  appSignatureHelper.getAppSignatures().get(0));
       // LatestFirebaseMessagingService.getToken(this);
        MainApp.getInstance().setFireBaseToken(LatestFirebaseMessagingService.getToken(this));
        Log.v("newToken ","FireBaseToken MainApp "+LatestFirebaseMessagingService.getToken(this));

      /*  Task<InstallationTokenResult> task = FirebaseInstallations.getInstance().getToken(false);
        task.addOnSuccessListener(installationTokenResult -> {
            String mToken = installationTokenResult.getToken();
            MainApp.getInstance().setFireBaseToken(mToken);
            Log.v("newToken ","FireBaseToken MainApp "+mToken);
            // Toast.makeText(MainApp.this, mToken, Toast.LENGTH_SHORT).show();
        });*/
       // FirebaseInstallations.getInstance().getToken(true);
       // sharedPreferences = getSharedPreferences(Constants.USERPreference, MODE_PRIVATE);
    }

    public static synchronized MainApp getInstance() {
        return mInstance;
    }


    public void setChatMessageCallBacks(ChatMessageCallBacks chatMessageCallBacks) {
        this.chatMessageCallBacks = chatMessageCallBacks;
    }

    public BookingStatusInterface getBookingStatusInterface() {
        return bookingStatusInterface;
    }

    public void setBookingStatusInterface(BookingStatusInterface bookingStatusInterface) {
        this.bookingStatusInterface = bookingStatusInterface;
    }

    public BookingInfoData getBookingInfoData() {
        return bookingInfoData;
    }

    public void setBookingInfoData(BookingInfoData bookingInfoData) {
        this.bookingInfoData = bookingInfoData;
    }

    public DataList getDataList() {
        return dataList;
    }

    public void setDataList(DataList dataList) {
        this.dataList = dataList;
    }

    public OylaWallet getOylaWallet() {
        return oylaWallet;
    }

    public void setOylaWallet(OylaWallet oylaWallet) {
        this.oylaWallet = oylaWallet;
    }

    public String getMin_ride_fares() {
        return min_ride_fares;
    }

    public void setMin_ride_fares(String min_ride_fares) {
        this.min_ride_fares = min_ride_fares;
    }

    public String getHashKey() {
        return hashKey;
    }

    public void setHashKey(String hashKey) {
        this.hashKey = hashKey;
    }

    public static List<NearestDriversData> nearestDriversData;

    public String getPeak_factor_rate() {
        return peak_factor_rate;
    }

    public void setPeak_factor_rate(String peak_factor_rate) {
        this.peak_factor_rate = peak_factor_rate;
    }

    public static List<NearestDriversData> getNearestDriversData() {
        return nearestDriversData;
    }

    public static void setNearestDriversData(List<NearestDriversData> nearestDriversData) {
        MainApp.nearestDriversData = nearestDriversData;
    }

    public NearestDriver getNearestDriver() {
        return nearestDriver;
    }

    public void setNearestDriver(NearestDriver nearestDriver) {
        this.nearestDriver = nearestDriver;
    }

    public double getRidePickup_latitude() {
        return ridePickup_latitude;
    }

    public void setRidePickup_latitude(double ridePickup_latitude) {
        this.ridePickup_latitude = ridePickup_latitude;
    }

    public double getRidePickup_longitude() {
        return ridePickup_longitude;
    }

    public void setRidePickup_longitude(double ridePickup_longitude) {
        this.ridePickup_longitude = ridePickup_longitude;
    }

    public double getRideDropOff_latitude() {
        return rideDropOff_latitude;
    }

    public void setRideDropOff_latitude(double rideDropOff_latitude) {
        this.rideDropOff_latitude = rideDropOff_latitude;
    }

    public double getRideDropOff_longitude() {
        return rideDropOff_longitude;
    }

    public void setRideDropOff_longitude(double rideDropOff_longitude) {
        this.rideDropOff_longitude = rideDropOff_longitude;
    }

    public String getDriverStatus() {
        return driverStatus;
    }

    public void setDriverStatus(String driverStatus) {
        this.driverStatus = driverStatus;
    }

    public String getRideStatus() {
        return rideStatus;
    }

    public void setRideStatus(String rideStatus) {
        this.rideStatus = rideStatus;
    }

    public String getTax_percentage() {
        return tax_percentage;
    }

    public void setTax_percentage(String tax_percentage) {
        this.tax_percentage = tax_percentage;
    }

    public double getVehicleRate() {
        return vehicleRate;
    }

    public void setVehicleRate(double vehicleRate) {
        this.vehicleRate = vehicleRate;
    }

    public double getPerKM() {
        return perKM;
    }

    public void setPerKM(double perKM) {
        this.perKM = perKM;
    }

    public double getPerMint() {
        return perMint;
    }

    public void setPerMint(double perMint) {
        this.perMint = perMint;
    }

    public float getBearing() {
        return bearing;
    }

    public void setBearing(float bearing) {
        this.bearing = bearing;
    }

    public ServiceCallbacks getServiceCallbacks() {
        return serviceCallbacks;
    }

    public void setServiceCallbacks(ServiceCallbacks serviceCallbacks) {
        this.serviceCallbacks = serviceCallbacks;
    }

    public SearchLocation getSearchLocation() {
        return searchLocation;
    }

    public void setSearchLocation(SearchLocation searchLocation) {
        this.searchLocation = searchLocation;
    }



    public DriverCoordinate getDriverCoordinate() {
        return driverCoordinate;
    }

    public void setDriverCoordinate(DriverCoordinate driverCoordinate) {
        this.driverCoordinate = driverCoordinate;
    }

    public CaptainInfoData getCaptainInfoData() {
        return captainInfoData;
    }

    public void setCaptainInfoData(CaptainInfoData captainInfoData) {
        this.captainInfoData = captainInfoData;
    }

    public UserLocation getUserLocation() {
        return userLocation;
    }

    public void setUserLocation(UserLocation userLocation) {
        this.userLocation = userLocation;
    }

    public OnCaptainFind getOnCaptainFind() {
        return onCaptainFind;
    }

    public void setOnCaptainFind(OnCaptainFind onCaptainFind) {
        this.onCaptainFind = onCaptainFind;
    }

    public String getFireBaseToken() {
        return fireBaseToken;
    }

    public void setFireBaseToken(String fireBaseToken) {
        this.fireBaseToken = fireBaseToken;
    }

    public UserData getUserData() {
        return userData;
    }

    public void setUserData(UserData userData) {
        this.userData = userData;
    }

}
