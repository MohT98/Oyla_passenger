package com.oyla.passenger.interfaces;

public interface RideTimeCal {
    void onCalReceive(String rideTime);
}
