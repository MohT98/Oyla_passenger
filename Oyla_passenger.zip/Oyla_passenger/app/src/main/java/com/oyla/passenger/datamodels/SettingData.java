package com.oyla.passenger.datamodels;

public class SettingData {
    private String language;
    private String gender;
    private boolean OYLA_PAY = false;
    private boolean USE_CASH = true;
    private boolean USE_CARD = false;
    private String bookingInfo;
    private double KEY_PICK_UP_LAT;
    private double KEY_PICK_UP_LNG;
    private double KEY_DROP_OFF_LAT;
    private double KEY_DROP_OFF_LNG;
    private boolean FIRST_LOGIN=false;
    private boolean AUTO_START = false;

    public boolean isAUTO_START() {
        return AUTO_START;
    }

    public void setAUTO_START(boolean AUTO_START) {
        this.AUTO_START = AUTO_START;
    }

    public boolean isFIRST_LOGIN() {
        return FIRST_LOGIN;
    }

    public void setFIRST_LOGIN(boolean FIRST_LOGIN) {
        this.FIRST_LOGIN = FIRST_LOGIN;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public boolean isOYLA_PAY() {
        return OYLA_PAY;
    }

    public void setOYLA_PAY(boolean OYLA_PAY) {
        this.OYLA_PAY = OYLA_PAY;
    }

    public boolean isUSE_CASH() {
        return USE_CASH;
    }

    public void setUSE_CASH(boolean USE_CASH) {
        this.USE_CASH = USE_CASH;
    }

    public boolean isUSE_CARD() {
        return USE_CARD;
    }

    public void setUSE_CARD(boolean USE_CARD) {
        this.USE_CARD = USE_CARD;
    }

    public String getBookingInfo() {
        return bookingInfo;
    }

    public void setBookingInfo(String bookingInfo) {
        this.bookingInfo = bookingInfo;
    }

    public double getKEY_PICK_UP_LAT() {
        return KEY_PICK_UP_LAT;
    }

    public void setKEY_PICK_UP_LAT(double KEY_PICK_UP_LAT) {
        this.KEY_PICK_UP_LAT = KEY_PICK_UP_LAT;
    }

    public double getKEY_PICK_UP_LNG() {
        return KEY_PICK_UP_LNG;
    }

    public void setKEY_PICK_UP_LNG(double KEY_PICK_UP_LNG) {
        this.KEY_PICK_UP_LNG = KEY_PICK_UP_LNG;
    }

    public double getKEY_DROP_OFF_LAT() {
        return KEY_DROP_OFF_LAT;
    }

    public void setKEY_DROP_OFF_LAT(double KEY_DROP_OFF_LAT) {
        this.KEY_DROP_OFF_LAT = KEY_DROP_OFF_LAT;
    }

    public double getKEY_DROP_OFF_LNG() {
        return KEY_DROP_OFF_LNG;
    }

    public void setKEY_DROP_OFF_LNG(double KEY_DROP_OFF_LNG) {
        this.KEY_DROP_OFF_LNG = KEY_DROP_OFF_LNG;
    }
}
