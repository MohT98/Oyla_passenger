package com.oyla.passenger.services.location;

import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.lifecycle.MutableLiveData;

import com.google.gson.Gson;
import com.oyla.passenger.MainApp;
import com.oyla.passenger.Repository.JsonRepository;
import com.oyla.passenger.datamodels.FireBaseDataModelObject;
import com.oyla.passenger.datamodels.jsonreponsedatamodel.DataList;
import com.oyla.passenger.datamodels.jsonreponsedatamodel.DataModelObject;
import com.oyla.passenger.interfaces.ServiceCallbacks;
import com.oyla.passenger.services.retrofit.Api;
import com.oyla.passenger.services.retrofit.ApiClient;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.SharedPrefManager;

import static com.oyla.passenger.ui.activity.cabbooking.MapActivity.PICK_UP_TRACKING;

public class GetDriverCoordinates extends Service {
    private static final String TAG = "GetDriverCoordinates";
    //private static final int LOCATION_UPDATE_INTERVAL = 3* 1000;  /* 3 secs */
    // private static int LOCATION_UPDATE_INTERVAL = 60* 1000;  /* 60 secs */
    private  int LOCATION_UPDATE_INTERVAL = 5 * 1000;  /* 5 secs */
    private ServiceCallbacks serviceCallbacks;
    //rivate Handler mHandler = new Handler();
    private final Handler mHandler = new Handler(Looper.getMainLooper());
    private Runnable mRunnable;
    private MutableLiveData<DataModelObject> mutableLiveData;
    private JsonRepository repository;
    public static boolean LOCATION_GET = true;
    SharedPreferences sharedPreferences;
    Gson gson;
    String json;
    // CaptainInfoData captainInfoData;
    // DataModelObject dataModelObject;
    //UserData userData;
    FireBaseDataModelObject fireBaseDataModelObject;
    DataList dataList;
    Api api;
    String DriverID;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public GetDriverCoordinates() {
        api = ApiClient.createService(Api.class);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        /*if (Build.VERSION.SDK_INT >= 26) {
            String CHANNEL_ID = "my_channel_01";
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "My Channel",
                    NotificationManager.IMPORTANCE_DEFAULT);

            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(channel);

            Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setContentTitle("")
                    .setContentText("").build();

            startForeground(1, notification);
        }*/
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "onStartCommand: called.");
        if (intent.getAction().equals(Constants.ACTION_START_FOREGROUND_SERVICE)) {
            Log.i("GetDriverCoordinates", "Received Start Foreground Intent ");
            // your start service code
            getDriverLocation();
        } else if (intent.getAction().equals(Constants.ACTION_STOP_FOREGROUND_SERVICE)) {
            Log.i("GetDriverCoordinates", "Received Stop Foreground Intent");
            //your end servce code
            stopForeground(true);
            stopSelfResult(startId);
            PICK_UP_TRACKING = false;
        }
        return START_NOT_STICKY;
    }

    private void getDriverLocation() {
        sharedPreferences = GetDriverCoordinates.this.getSharedPreferences("Driver_Info", 0);
        if (sharedPreferences.contains("Driver_Info_Object")) {
            gson = new Gson();
            json = sharedPreferences.getString("Driver_Info_Object", "");
            //captainInfoData = gson.fromJson(json, CaptainInfoData.class);
            //    dataModelObject= gson.fromJson(json, DataModelObject.class);
            fireBaseDataModelObject = gson.fromJson(json, FireBaseDataModelObject.class);
            dataList = gson.fromJson(fireBaseDataModelObject.getData(), DataList.class);
            /*dataModelObject.getData().getCaptain_info_data().getDriver_status()*/
        }
        //  userData = SharedPrefManager.getInstance(getApplicationContext()).getUserInfo();
        mHandler.postDelayed(mRunnable = () -> {
            if (LOCATION_GET) {
                retrieveCaptainLocations();
            }
            mHandler.postDelayed(mRunnable, LOCATION_UPDATE_INTERVAL);
        }, LOCATION_UPDATE_INTERVAL);
    }

    private void retrieveCaptainLocations() {
        Log.v("GetDriverCoordinates", "LOCATION_UPDATE_INTERVAL " + LOCATION_UPDATE_INTERVAL);
        //LOCATION_UPDATE_INTERVAL = 30* 1000;
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        sharedPreferences = GetDriverCoordinates.this.getSharedPreferences("Driver_Info", 0);
        LOCATION_GET = false;
        repository = new JsonRepository();
        // Log.v("getAccessToken", "getAccessToken " + userData.getFcm_token());
        // Log.v("GetDriverCoordinates", "getDriver_id " + dataList.getCaptain_info_data().getDriver_id());
        //Log.v("GetDriverCoordinates", "getDriver_name " + dataList.getCaptain_info_data().getDriver_name());
        Constants.Auth = Constants.Bearer + " " + SharedPrefManager.getInstance(getApplicationContext()).getUserInfo().getAccessToken();
        if (dataList == null || dataList.getCaptain_info_data() == null) {
            dataList = MainApp.getInstance().getDataList();
            Log.v("GetDriverCoordinates", "dataList ");
            //DriverID=MainApp.getInstance().getCaptainInfoData().getDriver_id();
        }/*else {
            DriverID=dataList.getCaptain_info_data().getDriver_id();
        }*/
        DriverID = dataList.getCaptain_info_data().getDriver_id();
        Log.v("GetDriverCoordinates", "getDriver_id " + DriverID);
        mutableLiveData = repository.getDriverCoordinates(DriverID);
        //MainApp.getInstance().getServiceCallbacks().doTracking();
    }
    @Override
    public void onDestroy() {
        Log.i("GetDriverCoordinates", "onCreate() , service stopped...");
        mHandler.removeCallbacks(mRunnable);
        // disposable.dispose();
    }
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        Log.i("GetDriverCoordinates", "onTaskRemoved called ");
        super.onTaskRemoved(rootIntent);
        //do something you want
        //stop service
        this.stopSelf();
    }
}