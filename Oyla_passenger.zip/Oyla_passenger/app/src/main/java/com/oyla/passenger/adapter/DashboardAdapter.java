package com.oyla.passenger.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.oyla.passenger.R;
import com.oyla.passenger.datamodels.DashboardContentData;
import com.oyla.passenger.utilities.Constants;

import java.util.List;

public class DashboardAdapter extends RecyclerView.Adapter<DashboardAdapter.MyViewHolder> {

    private List<DashboardContentData> dataSet;
    private Context mCtx;
    private DashboardAdapter.OnItemClickListener mListener;

    public void setOnItemClickListener(DashboardAdapter.OnItemClickListener listener) {
        mListener = listener;
    }

    public DashboardAdapter() {
    }

    public DashboardAdapter(Context mCtx, List<DashboardContentData> data) {
        this.dataSet = data;
        this.mCtx = mCtx;
       /* Log.v("bookingId", "data size" + data.size());
        Log.v("bookingId", "data title" + data.get(0).getTitle());*/
    }


    @NonNull
    @Override
    public DashboardAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_dashboard_list_adapter, parent, false);
        DashboardAdapter.MyViewHolder myViewHolder = new DashboardAdapter.MyViewHolder(view, mListener);

        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull DashboardAdapter.MyViewHolder holder, int position) {
        if(Integer.parseInt(dataSet.get(position).getStatus())==0){
           // holder.mainLayout.setVisibility(View.GONE);
          //  holder.itemView.setVisibility(View.GONE);
           // holder.itemView.setLayoutParams(new RecyclerView.LayoutParams(0, 0));
            holder.itemView.setVisibility(View.GONE);
            ViewGroup.LayoutParams params = holder.itemView.getLayoutParams();
            params.height = 0;
            params.width = 0;
            holder.itemView.setLayoutParams(params);

        }else {
            holder.mainLayout.setVisibility(View.VISIBLE);
            holder.title.setText(dataSet.get(position).getModule_name());

            Glide
                    .with(mCtx)
                    //.load("http://lead2need.ca/stagingadmin/public/vehicles/gallery/dummy.jpg"
                    .load(Constants.ASSETS_BASE_URL +dataSet.get(position).getImage_url())
                    // .centerCrop()
                    // .placeholder(R.drawable.car)
                    .transition(DrawableTransitionOptions.withCrossFade())
                    .into(holder.banner);
        }
    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView title,points;
        ImageView banner;
        RelativeLayout mainLayout;


        public MyViewHolder(@NonNull View itemView, final DashboardAdapter.OnItemClickListener listener) {
            super(itemView);
            title = itemView.findViewById(R.id.title);
            points = itemView.findViewById(R.id.points);
            banner = itemView.findViewById(R.id.banner);
            mainLayout = itemView.findViewById(R.id.mainLayout);
            itemView.setOnClickListener(v -> {
                if (listener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onItemClick(position);
                    }
                }
            });
        }
    }
}

