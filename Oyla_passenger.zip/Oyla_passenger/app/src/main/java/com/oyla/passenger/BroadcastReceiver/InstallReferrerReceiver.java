package com.oyla.passenger.BroadcastReceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.oyla.passenger.utilities.Constants;

public class InstallReferrerReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction() != null) {
            if (intent.getAction().equals("com.android.vending.INSTALL_REFERRER")) {

                Bundle extras = intent.getExtras();
                if (extras != null) {
                    Constants.referral_code = extras.getString("referrer");
                    Log.v("InstallReferrerReceiver","InstallReferrerReceiver "+ Constants.referral_code);
                    //Log.w("TAG", "Install</code><code class="language-java"> R</code><code class="language-java">eferrer</code><code class="language-java"> is: " + referrerString);
                }
            }
        }
    }
}
