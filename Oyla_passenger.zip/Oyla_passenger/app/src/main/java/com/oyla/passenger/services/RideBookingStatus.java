package com.oyla.passenger.services;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.Nullable;

import com.oyla.passenger.MainApp;
import com.oyla.passenger.utilities.Constants;

public class RideBookingStatus  extends Service {
    private static final String TAG = "RideBookingService";
    private Handler mHandler =new Handler(Looper.getMainLooper());
    private Runnable mRunnable;
    private static  int LOCATION_UPDATE_INTERVAL = 5 * 1000;
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, " RideBookingStatus onStartCommand: called.");

        if (intent.getAction().equals(Constants.ACTION_START_FOREGROUND_SERVICE)) {
            Log.i(TAG, "RideBookingStatusStart Foreground Intent ");
            // your start service code
            getDriverLocation();
        } else if (intent.getAction().equals(Constants.ACTION_STOP_FOREGROUND_SERVICE)) {
            Log.i(TAG, "RideBookingStatus Stop Foreground Intent");
            //your end servce code
            stopForeground(true);
            stopSelfResult(startId);
        }
        return START_NOT_STICKY;
    }
    private void getDriverLocation() {

        mHandler.postDelayed(mRunnable = () -> {

            MainApp.getInstance().getBookingStatusInterface().getBookingStatus();


            mHandler.postDelayed(mRunnable, LOCATION_UPDATE_INTERVAL);
        }, LOCATION_UPDATE_INTERVAL);
      /*  if(LOCATION_UPDATE_INTERVAL== 1 * 1000){
            LOCATION_UPDATE_INTERVAL= 3 * 1000;
        }
        if(LOCATION_UPDATE_INTERVAL== 3 * 1000){
            LOCATION_UPDATE_INTERVAL= 5 * 1000;
        }*/
    }
    @Override
    public void onDestroy() {
        Log.i(TAG, "RideBookingStatus onCreate() , service stopped...");
        mHandler.removeCallbacks(mRunnable);
        // disposable.dispose();
    }


    @Override
    public void onTaskRemoved(Intent rootIntent) {
        Log.i(TAG, "RideBookingStatus onTaskRemoved called ");
        super.onTaskRemoved(rootIntent);
        //do something you want
        //stop service
        this.stopSelf();
    }
}
