package com.oyla.passenger.datamodels.usermodel;

public class DriverCoordinate {
    private  String lat;
    private  String lng;
    private  String city;
    private  String area_name;
    private  String bearing;
    private  String decode_path;
    private  String current_arrival_time;
    private  String current_distance;

    public DriverCoordinate(String lat, String lng, String city, String area_name, String bearing, String decode_path, String current_arrival_time, String current_distance) {
        this.lat = lat;
        this.lng = lng;
        this.city = city;
        this.area_name = area_name;
        this.bearing = bearing;
        this.decode_path = decode_path;
        this.current_arrival_time = current_arrival_time;
        this.current_distance = current_distance;
    }

    public DriverCoordinate(String lat, String lng) {
        this.lat = lat;
        this.lng = lng;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getArea_name() {
        return area_name;
    }

    public void setArea_name(String area_name) {
        this.area_name = area_name;
    }

    public String getBearing() {
        return bearing;
    }

    public void setBearing(String bearing) {
        this.bearing = bearing;
    }

    public String getDecode_path() {
        return decode_path;
    }

    public void setDecode_path(String decode_path) {
        this.decode_path = decode_path;
    }

    public String getCurrent_arrival_time() {
        return current_arrival_time;
    }

    public void setCurrent_arrival_time(String current_arrival_time) {
        this.current_arrival_time = current_arrival_time;
    }

    public String getCurrent_distance() {
        return current_distance;
    }

    public void setCurrent_distance(String current_distance) {
        this.current_distance = current_distance;
    }
}
