package com.oyla.passenger.datamodels.usermodel;

import android.location.Location;
import android.os.Parcel;
import android.os.Parcelable;

public class UserLocation implements Parcelable {
    private UserData userData;
    private Location location;

    public UserLocation() {

    }

    public UserLocation(UserData userData, Location location) {
        this.userData = userData;
        this.location = location;
    }

    protected UserLocation(Parcel in) {
        location = in.readParcelable(Location.class.getClassLoader());
    }

    public static final Creator<UserLocation> CREATOR = new Creator<UserLocation>() {
        @Override
        public UserLocation createFromParcel(Parcel in) {
            return new UserLocation(in);
        }

        @Override
        public UserLocation[] newArray(int size) {
            return new UserLocation[size];
        }
    };

    public UserData getUserData() {
        return userData;
    }

    public void setUserData(UserData userData) {
        this.userData = userData;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(location, flags);
    }
}
