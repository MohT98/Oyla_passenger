package com.oyla.passenger.datamodels;

public class PostData {
    private String otp_code;
    private String user_id;
    private String passenger_id;
    private String first_name;
    private String last_name;
    private String password;
    private String dummy;
    private String mobile_no;
    private String type;
    private String provider;
    private String email;
    private String lat;
    private String lng;
    private String city;
    private String area_name;
    private String fcm_token;


    private String pickup_latitude;
    private String pickup_longitude;
    private String dropoff_latitude;
    private String dropoff_longitude;

    private String distance_kilomiters;
    private String estimate_minutes;
    private String amount;
    private String vehicle_type;
    private String vehicle_amount;
    private String oyla_pay;
    String vehicle_type_id;
    private String bearing;
    private String payment_type;
    private String   peak_factor_rate;
    private String referral_code;
    private String driver_initial_distance;
    private String min_ride_fares;
    private String device_id;
    private String pickup_address;
    private String  dropoff_address;
    private String network;





    public String getOtp_code() {
        return otp_code;
    }

    public String getUser_id() {
        return user_id;
    }

    public PostData(){

    }
    //booking info
    public PostData(String vehicle_type_id,String user_id, String pickup_latitude, String pickup_longitude,
                    String dropoff_latitude, String dropoff_longitude, String distance_kilomiters,
                    String estimate_minutes, String amount, String vehicle_type, String vehicle_amount,
                    String oyla_pay,String payment_type,String peak_factor_rate,String driver_initial_distance,String min_ride_fares,
                    String pickup_address, String dropoff_address) {
        this.user_id = user_id;
        this.pickup_latitude = pickup_latitude;
        this.pickup_longitude = pickup_longitude;
        this.dropoff_latitude = dropoff_latitude;
        this.dropoff_longitude = dropoff_longitude;
        this.distance_kilomiters = distance_kilomiters;
        this.estimate_minutes = estimate_minutes;
        this.amount = amount;
        this.vehicle_type = vehicle_type;
        this.vehicle_amount = vehicle_amount;
        this.oyla_pay = oyla_pay;
        this.vehicle_type_id=vehicle_type_id;
        this.payment_type=payment_type;
        this.peak_factor_rate=peak_factor_rate;
        this.driver_initial_distance=driver_initial_distance;
        this.min_ride_fares=min_ride_fares;
        this.pickup_address=pickup_address;
        this.dropoff_address=dropoff_address;

    }

    public PostData(String otp_code, String user_id) {
        this.otp_code = otp_code;
        this.user_id = user_id;


    }

    public PostData(String user_id, String mobile_no,String device_id) {
        this.mobile_no = mobile_no;
        this.user_id = user_id;
        this.device_id=device_id;


    }

    public PostData(String user_id, String lat, String lng,String dummy) {
        this.user_id = user_id;
        this.lat = lat;
        this.lng = lng;
    }

    public PostData(String user_id, String first_name, String last_name, String password,String fcm_token,String dummy,String dummy2) {
        this.user_id = user_id;
        this.first_name = first_name;
        this.last_name = last_name;
        this.password = password;
        this.fcm_token = fcm_token;
    }

    public PostData(String type, String mobile_no,String email,String first_name, String last_name,
                    String provider,String fcm_token,String dummy,String referral_code) {
        this.mobile_no = mobile_no;
        this.first_name = first_name;
        this.last_name = last_name;
        this.type = type;
        this.email = email;
        this.provider = provider;
        this.fcm_token = fcm_token;
        this.referral_code=referral_code;
    }

//setPassengerCoordinates
    public PostData(String user_id, String lat, String lng, String city,String area_name,String bearing) {
        this.user_id = user_id;
        this.lat = lat;
        this.lng = lng;
        this.city = city;
        this.area_name=area_name;
        this.bearing=bearing;
    }
    public PostData( String user_id) {
        this.user_id = user_id;
    }



}
