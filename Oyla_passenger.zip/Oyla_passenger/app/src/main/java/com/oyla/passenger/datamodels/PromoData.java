package com.oyla.passenger.datamodels;

public class PromoData {
    private String promo_code;
    private String city;

    public PromoData(String promo_code, String city) {
        this.promo_code = promo_code;
        this.city = city;
    }
}
