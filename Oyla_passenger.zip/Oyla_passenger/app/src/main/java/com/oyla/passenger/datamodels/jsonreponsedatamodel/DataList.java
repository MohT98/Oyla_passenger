package com.oyla.passenger.datamodels.jsonreponsedatamodel;

import com.oyla.passenger.datamodels.CaptainInfoData;
import com.oyla.passenger.datamodels.CheckBookingStatusData;
import com.oyla.passenger.datamodels.ComplainData;
import com.oyla.passenger.datamodels.DashboardContentData;
import com.oyla.passenger.datamodels.NearestDriversData;
import com.oyla.passenger.datamodels.PageContent;
import com.oyla.passenger.datamodels.packages.PackagesList;
import com.oyla.passenger.datamodels.redeemdata.RedeemListData;
import com.oyla.passenger.datamodels.historydata.RideHistoryData;
import com.oyla.passenger.datamodels.RideTypeData;
import com.oyla.passenger.datamodels.historydata.TransactionHistoryData;
import com.oyla.passenger.datamodels.mapmodel.direction.DirectionResult;
import com.oyla.passenger.datamodels.usermodel.BookingInfoData;
import com.oyla.passenger.datamodels.usermodel.DriverCoordinate;
import com.oyla.passenger.datamodels.usermodel.UserData;

import java.util.List;

public class DataList {

    private UserData user;
    private DriverCoordinate coordinates;
    private List<RideTypeData> appVehicles;
    private List<NearestDriversData> drivers;
    private BookingInfoData booking_data;
    private CaptainInfoData captain_info_data;
    private List<RideHistoryData> bookings;
    private List<RedeemListData> redeemAward;
    private CheckBookingStatusData bookingInfo;
    private String totalBalance;
    private String discount;
    private PageContent pagecontent;
    private String totalPoints;
    private List<DashboardContentData> dashboardContent;
    private List<TransactionHistoryData> NonCashTransaction;
    private List<ComplainData> ComplaintTypes;
    private List<PackagesList> packages;


    public List<PackagesList> getPackages() {
        return packages;
    }
    public List<ComplainData> getComplaintTypes() {
        return ComplaintTypes;
    }

    public List<TransactionHistoryData> getNonCashTransaction() {
        return NonCashTransaction;
    }

    public List<DashboardContentData> getDashboardContent() {
        return dashboardContent;
    }

    public List<RedeemListData> getRedeemAward() {
        return redeemAward;
    }

    public PageContent getPagecontent() {
        return pagecontent;
    }

    public String getDiscount() {
        return discount;
    }

    private DirectionResult directionResult;

    public DirectionResult getDirectionResult() {
        return directionResult;
    }

    public String getTotalBalance() {
        return totalBalance;
    }

    public String getTotalPoints() {
        return totalPoints;
    }

    public CheckBookingStatusData getBookingInfo() {
        return bookingInfo;
    }

    public List<RideHistoryData> getBookings() {
        return bookings;
    }

    public CaptainInfoData getCaptain_info_data() {
        return captain_info_data;
    }

    public BookingInfoData getBooking_data() {
        return booking_data;
    }

    public DriverCoordinate getCoordinates() {
        return coordinates;
    }

    public UserData getUser() {
        return user;
    }


    public List<RideTypeData> getAppVehicles() {
        return appVehicles;
    }

    public List<NearestDriversData> getDrivers() {
        return drivers;
    }
}
