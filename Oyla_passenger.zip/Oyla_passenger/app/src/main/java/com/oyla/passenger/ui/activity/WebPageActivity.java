package com.oyla.passenger.ui.activity;

import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;
import android.text.Html;
import android.util.Log;

import com.oyla.passenger.R;
import com.oyla.passenger.databinding.ActivityWebPageBinding;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.DialogBoxSingleton;
import com.oyla.passenger.viewmodels.WebPageViewModel;

public class WebPageActivity extends BaseActivity {

    private ActivityWebPageBinding binding;
    private WebPageViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_web_page);
        hideAppBar(this);
        binding = setContentView(this, R.layout.activity_web_page);
        viewModel = new ViewModelProvider(this).get(WebPageViewModel.class);

        viewModel.webPageRequest(getIntent().getStringExtra("pageName"),"1");
        startLoader();
        viewModel.webPageRepose().observe(this, dataModelObject -> {
            stopLoader();
            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                if(dataModelObject.getData().getPagecontent().getContent()!=null){
                    Log.v("htmlPage","htmlPage "+dataModelObject.getData().getPagecontent());
                    binding.htmlContent.setText(Html.fromHtml(dataModelObject.getData().getPagecontent().getContent()));
                }

                //setText(Html.fromHtml(getText().toString()));
            }else {
                DialogBoxSingleton.getInstance().showErrorPopup(WebPageActivity.this,dataModelObject.getError());
                if(dataModelObject.getError().getMessage()!=null){
                    // showToast(SignInActivity.this, dataModelObject.getError().getMessage());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                }else if(dataModelObject.getError().getMessages()!=null){
                    //showToast(SignInActivity.this, dataModelObject.getError().getMessages().toString());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                }
            }
        });
    }
}