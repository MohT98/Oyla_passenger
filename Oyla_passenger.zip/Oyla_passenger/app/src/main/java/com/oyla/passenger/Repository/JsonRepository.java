package com.oyla.passenger.Repository;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.oyla.passenger.BuildConfig;
import com.oyla.passenger.MainApp;
import com.oyla.passenger.datamodels.BookingStatusPostData;
import com.oyla.passenger.datamodels.ChangeDestinationData;
import com.oyla.passenger.datamodels.ExceptionErrorClass;
import com.oyla.passenger.datamodels.GetAppVehicleData;
import com.oyla.passenger.datamodels.JazzCashData;
import com.oyla.passenger.datamodels.PostData;
import com.oyla.passenger.datamodels.PromoData;
import com.oyla.passenger.datamodels.RatingPostModel;
import com.oyla.passenger.datamodels.RegisterNewComplaintData;
import com.oyla.passenger.datamodels.redeemdata.RedeemPostData;
import com.oyla.passenger.datamodels.RefreshTokenPostData;
import com.oyla.passenger.datamodels.ResendOTPPostData;
import com.oyla.passenger.datamodels.RideCancelData;
import com.oyla.passenger.datamodels.SearchCaptainData;
import com.oyla.passenger.datamodels.SocialLoginData;
import com.oyla.passenger.datamodels.UpdateMobPostData;
import com.oyla.passenger.datamodels.mapmodel.direction.DirectionResult;
import com.oyla.passenger.datamodels.jsonreponsedatamodel.DataModelObject;
import com.oyla.passenger.datamodels.usermodel.UpdateData;
import com.oyla.passenger.datamodels.usermodel.WebPagePostData;
import com.oyla.passenger.services.retrofit.Api;
import com.oyla.passenger.services.retrofit.ApiClient;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.utilities.Constants;
import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import static com.oyla.passenger.services.location.GetDriverCoordinates.LOCATION_GET;
import static com.oyla.passenger.services.location.LocationService.LOCATION_DATA_SAVED;
import static com.oyla.passenger.services.location.NearestDriverCoordinates.NEAREST_LOCATION_GET;
import static com.oyla.passenger.ui.BaseActivity.loggingInterceptor;
import static com.oyla.passenger.ui.activity.cabbooking.MapActivity.nearestDriversData;


public class JsonRepository {

    /*private MutableLiveData<DataModelObject> UserData;*/
    private MutableLiveData<DataModelObject> jsonData;
    private MutableLiveData<DirectionResult> DirectionData;
    private final Api api;
    public JsonRepository() {
        api = ApiClient.createService(Api.class);
    }

    public MutableLiveData<DataModelObject> sendMobNumber(String value, String fb_token, String referral_code, String identity) {
        jsonData = new MutableLiveData<>();
        Map<String, String> fields = new HashMap<>();
        //fields.put("mobile_no", mobileNumber);
        fields.put("identity", identity);
        fields.put(identity, value);
        fields.put("type", "1");
        //fields.put("fcm_token", MainApp.getInstance().getFireBaseToken());
        fields.put("fcm_token", fb_token);
        fields.put("referral_code", referral_code);
        fields.put("countryName", Constants.COUNTRY_NAME);
        fields.put("countryCode", Constants.PHONE_CODE);
        fields.put("device_id", MainApp.getInstance().getHashKey());
        fields.put("network", Constants.NETWORK);
        /*fields.put("app_version", "1.2");*/
        fields.put("version_code", String.valueOf(BuildConfig.VERSION_CODE));
        fields.put("app_version", BuildConfig.VERSION_NAME);
        fields.put("operating_system", "1");

        api.registerMobile(fields).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NonNull Call<DataModelObject> call, @NonNull Response<DataModelObject> response) {
                Log.v("onResponse", "Code: " + response.code());
               // DataModelObject hh = response.body();
                if (!response.isSuccessful()) {
                    Log.v("onResponse", "Code: " + response.code());
                    Log.v("onResponse", "message: " + response.message());
                   /* if (response.code() == 429) {
                        // sendMobNumber(mobileNumber);
                    }*/
                    saveError("","passenger App error"," Api name :user_authentication Api \n"+ "Error Body:"+  response.errorBody()  +"\n"+ "Code :"+  response.code(), response.code());
                    BaseActivity.getInstance().stopLoader();
                    BaseActivity.getInstance().showErrorToast("Try Again");

                    return;
                }
                jsonData.setValue(response.body());
                Log.v("onResponse", "Code Success: " + response.code());
                Log.v("onResponse", " message : " + response.message());
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
                Log.v("onResponse", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> verifyOTP(String userId, String otpCode) {
        jsonData = new MutableLiveData<>();
        PostData postData = new PostData(otpCode, userId);
        /* Constants.Auth = Constants.Bearer + " " +  SharedPrefManager.getInstance(getApplicationContext()).getUserInfo().getAccessToken();*/
        api.verifyOTP(Constants.Auth, postData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {
                if (!response.isSuccessful()) {
                    Log.v("onResponse", "Code: " + response.code());
                    // Log.v("onResponse", "errorBody: " + response.errorBody());
                    /*if (response.code() == 429) {

                        //verifyOTP(userId,otpCode);
                    }*/
                    saveError("","passenger App error"," Api name :verifyCode Api \n"+ "Error Body:"+  response.errorBody()  +"\n"+ "Code :"+  response.code(), response.code());
                    BaseActivity.getInstance().stopLoader();
                    BaseActivity.getInstance().showErrorToast("Try Again");
                    return;
                }

                jsonData.setValue(response.body());


                Log.v("onResponse", "Code Success: " + response.code());
                Log.v("onResponse", " message : " + response.message());
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
                Log.v("onResponse", "getMessage: " + t.getMessage());
                Log.v("onResponse", "toString: " + t.toString());
                Log.v("onResponse", "getCause: " + t.getCause());
                Log.v("onResponse", "getLocalizedMessage: " + t.getLocalizedMessage());
                Log.v("onResponse", "jsonData: " + t.getLocalizedMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;

    }

    public MutableLiveData<DataModelObject> resendOTP(String userId, String mobileNumber, String network) {
        jsonData = new MutableLiveData<>();
        Log.v("resendOTP","mobileNumber "+mobileNumber);
        // PostData postData = new PostData(userId, mobileNumber, MainApp.getInstance().getHashKey());
        ResendOTPPostData resendOTPPostData = new ResendOTPPostData(userId, mobileNumber, MainApp.getInstance().getHashKey(), network);

        api.reSendOTP(Constants.Auth, resendOTPPostData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {
                if (!response.isSuccessful()) {
                    Log.v("onResponse", "Code: " + response.code());
                   /* if (response.code() == 429) {
                        //resendOTP(userId,mobileNumber);
                    }*/
                    saveError("","passenger App error"," Api name :resendOTP Api \n"+ "Error Body:"+  response.errorBody()  +"\n"+ "Code :"+  response.code(), response.code());
                    BaseActivity.getInstance().stopLoader();
                    BaseActivity.getInstance().showErrorToast("Try Again");
                    return;
                }
                jsonData.setValue(response.body());
                Log.v("onResponse", "Code Success: " + response.code());
                Log.v("onResponse", " message : " + response.message());
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
                Log.v("onResponse", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;

    }

    public MutableLiveData<DataModelObject> verifyOtpUpdateMobile (String userId, String mobileNumber, String network,String otp_code) {
        jsonData = new MutableLiveData<>();
        // PostData postData = new PostData(userId, mobileNumber, MainApp.getInstance().getHashKey());
        UpdateMobPostData updateMobPostData = new UpdateMobPostData(userId, mobileNumber, network,otp_code);

        api.verifyOtpUpdateMobile (Constants.Auth, updateMobPostData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {
                if (!response.isSuccessful()) {
                    Log.v("onResponse", "Code: " + response.code());
                    /*if (response.code() == 429) {
                        //resendOTP(userId,mobileNumber);
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    BaseActivity.getInstance().showErrorToast("Try Again");
                    saveError("","passenger App error"," Api name :verifyOtpUpdateMobile Api \n"+ "Error Body:"+  response.errorBody()  +"\n"+ "Code :"+  response.code(), response.code());
                    return;
                }
                jsonData.setValue(response.body());
                Log.v("onResponse", "Code Success: " + response.code());
                Log.v("onResponse", " message : " + response.message());
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
                Log.v("onResponse", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;

    }

    public MutableLiveData<DataModelObject> registerUser(String userId, String firstName, String lastName, String password) {
        jsonData = new MutableLiveData<>();
        PostData postData = new PostData(userId, firstName, lastName, password, MainApp.getInstance().getFireBaseToken(), "", "");

        api.signUp(Constants.Auth, postData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {
                if (!response.isSuccessful()) {
                    Log.v("onResponse", "Code: " + response.code());
                    /*if (response.code() == 429) {
                        //registerUser(userId, firstName, lastName,password);
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    BaseActivity.getInstance().showErrorToast("Try Again");
                    saveError("","passenger App error"," Api name :updateUser Api \n"+ "Error Body:"+  response.errorBody()  +"\n"+ "Code :"+  response.code(), response.code());
                    return;
                }
                jsonData.setValue(response.body());
                Log.v("onResponse", "Code Success: " + response.code());
                Log.v("onResponse", " message : " + response.message());

            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
                Log.v("onResponse", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> registerSocial(String type, String mobile_no, String email, String first_name,
                                                           String last_name, String provider, String fb_token, String referral_code) {
        jsonData = new MutableLiveData<>();
        PostData postData = new PostData(type, mobile_no, email, first_name, last_name, provider, fb_token, "", referral_code);

        SocialLoginData socialLoginData =new SocialLoginData(type, mobile_no, email, first_name, last_name, provider, fb_token, referral_code
                ,Constants.COUNTRY_NAME, Constants.PHONE_CODE,MainApp.getInstance().getHashKey(),"social",String.valueOf(BuildConfig.VERSION_CODE),BuildConfig.VERSION_NAME,"1");
        api.socialLogin(Constants.Auth, socialLoginData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {
                if (!response.isSuccessful()) {
                    Log.v("onResponse", "Code: " + response.code());
                    /*if (response.code() == 429) {
                        //registerSocial(type, mobile_no, email,first_name,last_name,provider);
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    BaseActivity.getInstance().showErrorToast("Try Again");
                    saveError("","passenger App error"," Api name :social_login_mobile Api \n"+ "Error Body:"+  response.errorBody()  +"\n"+ "Code :"+  response.code(), response.code());
                    return;
                }
                jsonData.setValue(response.body());
                Log.v("onResponse", "Code Success: " + response.code());
                Log.v("onResponse", " message : " + response.message());
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
                Log.v("onResponse", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> setPassengerCoordinates(String user_id, String lat, String lng, String city,
                                                                    String area_name, String bearing) {
        jsonData = new MutableLiveData<>();
        PostData postData = new PostData(user_id, lat, lng, city, area_name, bearing);
        api.setPassengerCoordinates(Constants.Auth, postData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {
                LOCATION_DATA_SAVED = true;
                if (!response.isSuccessful()) {
                    Log.v("LocationService", "Code: " + response.code());
                   /* if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();
                        //BaseActivity.getInstance().showErrorToast("Try Again");
                        //setPassengerCoordinates(user_id, lat, lng,city,area_name);
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    //BaseActivity.getInstance().showErrorToast("Try Again");
                    saveError("","passenger App error"," Api name :setPassengerCoordinates Api \n"+ "Error Body:"+  response.errorBody()  +"\n"+ "Code :"+  response.code(), response.code());
                    return;
                }
                jsonData.setValue(response.body());
                Log.v("LocationService", "Code Success: " + response.code());
                Log.v("LocationService", " message : " + response.message());
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
                LOCATION_DATA_SAVED = true;
                Log.v("LocationService", "onFailure: " + t.getMessage());
                // BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> getDriverCoordinates(String user_id) {
        jsonData = new MutableLiveData<>();
        PostData postData = new PostData(user_id);
        Log.v("GetDriverCoordinates", "user_id " + user_id);
        Log.v("GetDriverCoordinates", "Constants.Auth: " + Constants.Auth);
        api.getDriverCoordinates(Constants.Auth, postData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NonNull Call<DataModelObject> call, @NonNull Response<DataModelObject> response) {

                if (!response.isSuccessful()) {
                    Log.v("GetDriverCoordinates", "Code: " + response.code());
                  /*  if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();
                        //BaseActivity.getInstance().showErrorToast("Try Again");
                        //getDriverCoordinates(user_id);
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    // BaseActivity.getInstance().showErrorToast("Try Again");
                    saveError("","passenger App error"," Api name :getDriverCoordinates Api \n"+ "Error Body:"+  response.errorBody()  +"\n"+ "Code :"+  response.code(), response.code());
                    return;
                }
                LOCATION_GET = true;
                jsonData.setValue(response.body());
                /*Log.v("GetDriverCoordinates","Lat  "+dataModelObject.getData().getCoordinates().getLat());
                Log.v("GetDriverCoordinates","Log  "+dataModelObject.getData().getCoordinates().getLng());*/
                if (response.body() != null && response.body().getData() != null) {
                    if (response.body().getData().getCoordinates() != null) {
                        MainApp.getInstance().setDriverCoordinate(response.body().getData().getCoordinates());
                            /*Log.v("GetDriverCoordinates", "getLng " + response.body().getData().getCoordinates().getLng());
                            // Log.v("GetDriverCoordinates", "getBearing " + response.body().getData().getCoordinates().getBearing());
                            Log.v("GetDriverCoordinates", "Code Success: " + response.code());
                            Log.v("GetDriverCoordinates", " message : " + response.message());
                            Log.v("GetDriverCoordinates", " getCity : " +  MainApp.getInstance().getDriverCoordinate().getCity());
                            Log.v("GetDriverCoordinates", " getBearing : " +  MainApp.getInstance().getDriverCoordinate().getBearing());*/
                        MainApp.getInstance().getServiceCallbacks().doTracking();
                        if (MainApp.getInstance().getDriverCoordinate().getBearing() != null &&
                                !MainApp.getInstance().getDriverCoordinate().getBearing().isEmpty()) {
                            MainApp.getInstance().setBearing(Float.parseFloat(MainApp.getInstance().getDriverCoordinate().getBearing()));
                        }
                    }
                }
            }
            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
                LOCATION_GET = true;
                Log.v("LocationService", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> getNearestDrivers(String lat, String lng) {
        jsonData = new MutableLiveData<>();
        PostData postData = new PostData("", lat, lng, "");
        api.getNearestDrivers(Constants.Auth, postData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {
                NEAREST_LOCATION_GET = true;
                if (!response.isSuccessful()) {
                    //  Log.v("newToken", "Code: " + response.code());
                   /* if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();
                        //BaseActivity.getInstance().showErrorToast("Try Again");
                        //getNearestDrivers( lat, lng);
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    //  BaseActivity.getInstance().showErrorToast("Try Again");
                    saveError("","passenger App error"," Api name :getNearestDrivers Api \n"+ "Error Body:"+  response.errorBody()  +"\n"+ "Code :"+  response.code(), response.code());
                    return;
                }
                jsonData.setValue(response.body());
                //nearestDriversData=dataModelObject.getData().getDrivers();
                // Log.v("newToken", "Code Success: " + response.code());
                // Log.v("newToken", " message : " + response.message());
                if (response.body() != null) {
                    if (response.body().getData() != null) {
                        if (response.body().getData().getDrivers() != null) {


                            // Log.v("newToken", " getArea_name : " +response.body().getData().getDrivers().get(0).getArea_name());
                            if (nearestDriversData != null) {
                                nearestDriversData.clear();
                            }
                            nearestDriversData = response.body().getData().getDrivers();
                        }
                        // Log.v("newToken", " nearestDriversData size : " +response.body().getData().getDrivers().size());
                    } else {
                        Log.v("newToken", " dataModelObject.getData() null ");
                    }
                }
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
                NEAREST_LOCATION_GET = true;
                Log.v("getRideType", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> getRideType(GetAppVehicleData getAppVehicleData) {
        jsonData = new MutableLiveData<>();
        //PostData postData = new PostData(user_id, lat, lng, "");
       // GetAppVehicleData getAppVehicleData = new GetAppVehicleData(user_id,lat, lng, city_name,dropoff_lat,dropoff_lng);
        api.getVehicleType(Constants.Auth, getAppVehicleData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {

                if (!response.isSuccessful()) {
                    Log.v("getRideType", "Code: " + response.code());
                    if (response.code() == 429) {
                        // getRideType(user_id, lat, lng);
                    }
                    BaseActivity.getInstance().stopLoader();
                    //BaseActivity.getInstance().showErrorToast("Click on back button ! Try Again");
                    saveError("","passenger App error"," Api name :getAppVehicle Api \n"+ "Error Body:"+  response.errorBody()  +"\n"+ "Code :"+  response.code(), response.code());
                   /* BaseActivity.getInstance().showErrorToast("Server not responding ! Try Again");*/
                   // return;
                }
                jsonData.setValue(response.body());
                Log.v("getRideType", "Code Success: " + response.code());
                Log.v("getRideType", " message : " + response.message());
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
               // BaseActivity.getInstance().showErrorToast( t.getMessage());
                Log.v("getRideType", "onFailure: " + t.getMessage());
                Log.v("getRideType", "onFailure: " + t);
                Log.v("getRideType", "onFailure: " + t.getCause());

                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> searchCaptain(String vehicle_type_id, String user_id, String pickup_latitude, String pickup_longitude, String dropoff_latitude, String dropoff_longitude, String distance_kilomiters,
                                                          String estimate_minutes, String amount, String vehicle_type,
                                                          String vehicle_amount, String oyla_pay, String payment_type,
                                                          String peak_factor_rate, String driver_initial_distance, String min_ride_fares,
                                                          String pickup_address, String dropoff_address,int is_skip_dropoff) {
        jsonData = new MutableLiveData<>();
        SearchCaptainData searchCaptainData = new SearchCaptainData(vehicle_type_id, user_id, pickup_latitude, pickup_longitude, dropoff_latitude,
                dropoff_longitude, distance_kilomiters, estimate_minutes, amount, vehicle_type, vehicle_amount,
                oyla_pay, payment_type, peak_factor_rate, driver_initial_distance, min_ride_fares, pickup_address, dropoff_address,is_skip_dropoff,"");
        api.searchCaptain(Constants.Auth, searchCaptainData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {

                if (!response.isSuccessful()) {
                    Log.v("getRideType", "Code: " + response.code());
                    /*if (response.code() == 429) {
                        //searchCaptain(vehicle_type_id,user_id,  pickup_latitude,  pickup_longitude,  dropoff_latitude,  dropoff_longitude,  distance_kilomiters,  estimate_minutes,  amount,  vehicle_type,  vehicle_amount, oyla_pay);
                    }*/
                    //BaseActivity.getInstance().stopLoader();

                    BaseActivity.getInstance().showErrorToast(response.message()+"Try Again");
                    //jsonData.setValue(response.body());
                    saveError("","passenger App error"," Api name :saveTempRideInfo Api \n"+ "Error Body:"+  response.errorBody()  +"\n"+ "Code :"+  response.code(), response.code());
                    return;
                }
                jsonData.setValue(response.body());
                Log.v("getRideType", "Code Success: " + response.code());
                Log.v("getRideType", " message : " + response.message());
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {

                Log.v("getRideType", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }
    public MutableLiveData<DataModelObject> searchCaptain2( SearchCaptainData searchCaptainData) {
        jsonData = new MutableLiveData<>();
        /*SearchCaptainData searchCaptainData = new SearchCaptainData(vehicle_type_id, user_id, pickup_latitude, pickup_longitude, dropoff_latitude,
                dropoff_longitude, distance_kilomiters, estimate_minutes, amount, vehicle_type, vehicle_amount,
                oyla_pay, payment_type, peak_factor_rate, driver_initial_distance, min_ride_fares, pickup_address, dropoff_address,is_skip_dropoff);*/
        api.searchCaptain(Constants.Auth, searchCaptainData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {

                if (!response.isSuccessful()) {
                    Log.v("getRideType", "Code: " + response.code());
                    /*if (response.code() == 429) {
                        //searchCaptain(vehicle_type_id,user_id,  pickup_latitude,  pickup_longitude,  dropoff_latitude,  dropoff_longitude,  distance_kilomiters,  estimate_minutes,  amount,  vehicle_type,  vehicle_amount, oyla_pay);
                    }*/
                    //BaseActivity.getInstance().stopLoader();
                    //BaseActivity.getInstance().showErrorToast("Try Again");
                    //response.
                    BaseActivity.getInstance().showErrorToast(response.message()+" Try Again "+"\n");
                    saveError("","passenger App error"," Api name :saveTempRideInfo Api \n"+ "Error Body:"+  response.errorBody()  +"\n"+ "Code :"+  response.code(), response.code());
                   // jsonData.setValue(response.body());
                    return;
                }



                jsonData.setValue(response.body());
                Log.v("getRideType", "Code Success: " + response.code());
                Log.v("getRideType", " message : " + response.message());
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {

                Log.v("getRideType", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> setLogout(String user_id) {
        jsonData = new MutableLiveData<>();
        PostData postData = new PostData(user_id);
        api.logout(Constants.Auth, postData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {

                if (!response.isSuccessful()) {
                    Log.v("onResponse", "Code: " + response.code());
                   /* if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();
                        // setLogout(user_id);
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    BaseActivity.getInstance().showErrorToast("Try Again");
                    saveError("","passenger App error"," Api name :logout Api \n"+ "Error Body:"+  response.errorBody()  +"\n"+ "Code :"+  response.code(), response.code());
                    return;
                }
                jsonData.setValue(response.body());
                Log.v("onResponse", "Code Success: " + response.code());
                Log.v("onResponse", " message : " + response.message());
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {

                Log.v("onResponse", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> refreshToken(String user_id) {
        jsonData = new MutableLiveData<>();
        //PostData postData = new PostData(user_id);
        RefreshTokenPostData refreshTokenPostData = new RefreshTokenPostData(user_id, Build.VERSION.SDK_INT, android.os.Build.MODEL,
                Build.MANUFACTURER, Build.BRAND, Build.VERSION.RELEASE, "", BuildConfig.VERSION_NAME);
        api.refreshToken(Constants.Auth, refreshTokenPostData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {

                if (!response.isSuccessful()) {
                    Log.v("onResponse", "Code: " + response.code());
                    //BaseActivity.getInstance().showToast(BaseActivity.getInstance(),String.valueOf(response.code()));
                   /* if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();

                    }*/
                   /* if (response.code() == 500 || response.code() == 401) {
                        SharedPrefManager.getInstance(BaseActivity.getInstance()).logout();
                    } else {*/
                     //   refreshToken(user_id);
                    //}

                    saveError("","passenger App error"," Api name :userRefreshToken Api \n"+ "Error Body:"+  response.errorBody()  +"\n"+ "Code :"+  response.code(), response.code());
                    return;
                }
                jsonData.setValue(response.body());
                Log.v("onResponse", "Code Success: " + response.code());
                Log.v("onResponse", " message : " + response.message());
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
               // SharedPrefManager.getInstance(BaseActivity.getInstance()).logout();
                Log.v("refreshToken", "onFailure: " + t.getMessage());
               // BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> updateProfile(String user_id, String attribute, String value) {
        jsonData = new MutableLiveData<>();
        UpdateData updateData = new UpdateData(user_id, attribute, value);
        api.updateProfile(Constants.Auth, updateData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {

                if (!response.isSuccessful()) {
                    Log.v("onResponse", "Code: " + response.code());
                    // BaseActivity.getInstance().showToast(BaseActivity.getInstance(),String.valueOf(response.code()));
                   /* if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();
                        //updateProfile(user_id,attribute,value);
                    }*/

                    BaseActivity.getInstance().stopLoader();
                    BaseActivity.getInstance().showErrorToast("Try Again");
                    saveError("","passenger App error"," Api name :setProfile Api \n"+ "Error Body:"+  response.errorBody()  +"\n"+ "Code :"+  response.code(), response.code());
                    return;
                }
                jsonData.setValue(response.body());
                Log.v("onResponse", "Code Success: " + response.code());
                Log.v("onResponse", " message : " + response.message());
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
                // SharedPrefManager.getInstance(BaseActivity.getInstance()).logout();
                Log.v("onResponse", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> updateProfileImage(String user_id, String stringImage, String imageName) {
        jsonData = new MutableLiveData<>();

        MultipartBody.Part body = makePart(stringImage, "profile_picture");
        Map<String, RequestBody> map = new HashMap<>();
        map.put("user_id", toRequestBody(user_id));

        api.updateProfileImage(Constants.Auth, map, body).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {

                if (!response.isSuccessful()) {
                    Log.v("onResponse", "Code: " + response.code());
                  /*  if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();
                        //updateProfileImage(user_id,stringImage,imageName);
                        // BaseActivity.getInstance().stopLoader();

                    }*/
                    BaseActivity.getInstance().stopLoader();
                    BaseActivity.getInstance().showErrorToast("Try Again");
                    saveError("","passenger App error"," Api name :setProfile Api \n"+ "Error Body:"+  response.errorBody()  +"\n"+ "Code :"+  response.code(), response.code());
                    return;
                }
                jsonData.setValue(response.body());
                Log.v("onResponse", "Code Success: " + response.code());
                Log.v("onResponse", " message : " + response.message());
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {

                Log.v("onResponse", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> registerNewComplaint( RegisterNewComplaintData registerNewComplaintData) {
        //RegisterNewComplaintData registerNewComplaintData=new RegisterNewComplaintData();
        Log.v("registerNewComplain", "bid: " + registerNewComplaintData.getBookingId());
        Log.v("registerNewComplain", "image: " + registerNewComplaintData.getImage());
        Log.v("registerNewComplain", "detail: " + registerNewComplaintData.getDetail());
        Log.v("registerNewComplain", "cTID: " + registerNewComplaintData.getComplaintTypeId());
        Log.v("registerNewComplain", "userid: " + registerNewComplaintData.getUserId());
        jsonData = new MutableLiveData<>();

        MultipartBody.Part body = makePart(registerNewComplaintData.getImage(), "image");
        Map<String, RequestBody> map = new HashMap<>();
        map.put("userId", toRequestBody(registerNewComplaintData.getUserId()));
        map.put("booking_id", toRequestBody(registerNewComplaintData.getBookingId()));
        map.put("detail", toRequestBody(registerNewComplaintData.getDetail()));
        map.put("complaintTypeId", toRequestBody(registerNewComplaintData.getComplaintTypeId()));


        api.registerNewComplaint(Constants.Auth, map, body).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {

                if (!response.isSuccessful()) {
                    Log.v("registerNewComplain", "Code: " + response.code());
                    BaseActivity.getInstance().stopLoader();
                    BaseActivity.getInstance().showErrorToast("Try Again");
                    saveError("","passenger App error"," Api name :registerNewComplaint Api \n"+ "Error Body:"+  response.errorBody()  +"\n"+ "Code :"+  response.code(), response.code());
                    return;
                }
                jsonData.setValue(response.body());
                Log.v("registerNewComplain", "Code Success: " + response.code());
                Log.v("registerNewComplain", " message : " + response.message());
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {

                Log.v("registerNewComplain", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> cancelRide(String user_id, String booking_id, String descriptions,String chatMessages) {
        jsonData = new MutableLiveData<>();
        RideCancelData rideCancelData = new RideCancelData(user_id, booking_id, descriptions,chatMessages);
        api.cancelsRide(Constants.Auth, rideCancelData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {

                if (!response.isSuccessful()) {
                    Log.v("onResponse", "Code: " + response.code());
                  /*  if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();
                        //updateProfile(user_id,attribute,value);
                        // BaseActivity.getInstance().stopLoader();
                        //BaseActivity.getInstance().showErrorToast("Try Again");
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    BaseActivity.getInstance().showErrorToast("Try Again");
                    saveError("","passenger App error"," Api name :passengerCancelsRide Api \n"+ "Error Body:"+  response.errorBody()  +"\n"+ "Code :"+  response.code(), response.code());
                    return;
                }
                jsonData.setValue(response.body());
                Log.v("onResponse", "Code Success: " + response.code());
                Log.v("onResponse", " message : " + response.message());
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {

                Log.v("onResponse", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> getRideHistory(String user_id) {
        jsonData = new MutableLiveData<>();
        PostData postData = new PostData(user_id);
        api.getRideHistory(Constants.Auth, postData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {

                if (!response.isSuccessful()) {
                    Log.v("onResponse", "Code: " + response.code());
                   /* if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();
                        // refreshToken(user_id);
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    BaseActivity.getInstance().showErrorToast("Try Again");
                    saveError("","passenger App error"," Api name :getTransactionHistory Api \n"+ "Error Body:"+  response.errorBody()  +"\n"+ "Code :"+  response.code(), response.code());
                    return;
                }
                jsonData.setValue(response.body());
                Log.v("onResponse", "Code Success: " + response.code());
                Log.v("onResponse", " message : " + response.message());
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {

                Log.v("onResponse", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> getTransactionHistory(String user_id) {
        jsonData = new MutableLiveData<>();
        PostData postData = new PostData(user_id);
        api.getTransactionHistory(Constants.Auth, postData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {

                if (!response.isSuccessful()) {
                    Log.v("onResponse", "Code: " + response.code());
                   /* if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();
                        // refreshToken(user_id);
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    BaseActivity.getInstance().showErrorToast("Try Again");
                    saveError("","passenger App error"," Api name :passengerTransactionsHistory Api \n"+ "Error Body:"+  response.errorBody()  +"\n"+ "Code :"+  response.code(), response.code());
                    return;
                }
                jsonData.setValue(response.body());
                Log.v("onResponse", "Code Success: " + response.code());
                Log.v("onResponse", " message : " + response.message());
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {

                Log.v("onResponse", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> passengerChangeDestination(String booking_id, String current_latitude, String current_longitude,
                                                                       String dropoff_latitude, String dropoff_longitude, String trip_one_distance,
                                                                       String trip_two_distance, String trip_total_distance, String trip_one_price,
                                                                       String trip_two_price, String total_price, String trip_total_time) {
        jsonData = new MutableLiveData<>();
        ChangeDestinationData changeDestinationData = new ChangeDestinationData(booking_id, current_latitude, current_longitude, dropoff_latitude, dropoff_longitude,
                trip_one_distance, trip_two_distance, trip_total_distance, trip_one_price, trip_two_price, total_price, trip_total_time);
        api.passengerChangeDestination(Constants.Auth, changeDestinationData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {

                if (!response.isSuccessful()) {
                    Log.v("getRideType", "Code: " + response.code());
                   /* if (response.code() == 429) {
                        //searchCaptain(vehicle_type_id,user_id,  pickup_latitude,  pickup_longitude,  dropoff_latitude,  dropoff_longitude,  distance_kilomiters,  estimate_minutes,  amount,  vehicle_type,  vehicle_amount, oyla_pay);
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    BaseActivity.getInstance().showErrorToast("Try Again");
                    saveError("","passenger App error"," Api name :passengerChangeDestination Api \n"+ "Error Body:"+  response.errorBody()  +"\n"+ "Code :"+  response.code(), response.code());
                    return;
                }
                jsonData.setValue(response.body());
                Log.v("getRideType", "Code Success: " + response.code());
                Log.v("getRideType", " message : " + response.message());
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {

                Log.v("getRideType", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }


    public MutableLiveData<DataModelObject> checkBookingStatus(String user_id) {
        jsonData = new MutableLiveData<>();
        //BookingStatusPostData bookingStatusPostData = new BookingStatusPostData(user_id, "", "");
        BookingStatusPostData bookingStatusPostData = new BookingStatusPostData(user_id, "", "");
        Log.v("checkBookingStatus", "Constants.Auth: " + Constants.Auth);
        // api.checkBookingStatus(Constants.Auth, bookingStatusPostData).enqueue(new Callback<DataModelObject>() {
        api.checkBookingStatus(Constants.Auth, bookingStatusPostData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {
                if (!response.isSuccessful()) {
                    Log.v("checkBookingStatus", "Code: " + response.code());
                  /*  if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();
                        //BaseActivity.getInstance().showErrorToast("Try Again");
                        //getDriverCoordinates(user_id);
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    //  BaseActivity.getInstance().showErrorToast("Try Again");
                    saveError("passenger App error","checkBookingStatus Api",response.message(),response.code());
                    return;
                }
                jsonData.setValue(response.body());
                /*Log.v("GetDriverCoordinates","Lat  "+dataModelObject.getData().getCoordinates().getLat());
                Log.v("GetDriverCoordinates","Log  "+dataModelObject.getData().getCoordinates().getLng());*/

                // Log.v("GetDriverCoordinates", "getBearing " + response.body().getData().getCoordinates().getBearing());
                Log.v("checkBookingStatus", "Code Success: " + response.code());
                Log.v("checkBookingStatus", " message : " + response.message());


            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
                Log.v("LocationService", "onFailure: " + t.getMessage());
               // BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> giveDriverRating(String user_id, String driver_id, String rating, String experience, String booking_id) {
        jsonData = new MutableLiveData<>();
        RatingPostModel ratingPostModel = new RatingPostModel(user_id, driver_id, rating, experience, booking_id, "1");
        Log.v("checkBookingStatus", "Constants.Auth: " + Constants.Auth);
        api.giveDriverRating(Constants.Auth, ratingPostModel).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {
                if (!response.isSuccessful()) {
                    Log.v("checkBookingStatus", "Code: " + response.code());
                    /*if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();
                        //BaseActivity.getInstance().showErrorToast("Try Again");
                        //getDriverCoordinates(user_id);
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    BaseActivity.getInstance().showErrorToast("Try Again");
                    return;
                }
                jsonData.setValue(response.body());
                /*Log.v("GetDriverCoordinates","Lat  "+dataModelObject.getData().getCoordinates().getLat());
                Log.v("GetDriverCoordinates","Log  "+dataModelObject.getData().getCoordinates().getLng());*/
                // Log.v("GetDriverCoordinates", "getBearing " + response.body().getData().getCoordinates().getBearing());
                Log.v("checkBookingStatus", "Code Success: " + response.code());
                Log.v("checkBookingStatus", " message : " + response.message());
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
                Log.v("LocationService", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> passengerLedgers(String user_id) {
        jsonData = new MutableLiveData<>();
        PostData postData = new PostData(user_id);
        api.passengerLedgers(Constants.Auth, postData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {
                if (!response.isSuccessful()) {
                    Log.v("onResponse", "Code: " + response.code());
                   /* if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    // BaseActivity.getInstance().showErrorToast("Try Again");
                    return;
                }
                jsonData.setValue(response.body());
                Log.v("onResponse", "Code Success: " + response.code());
                Log.v("onResponse", " message : " + response.message());
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
                Log.v("onResponse", "onFailure: " + t.getMessage());
             //   BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> passengerPoints(String user_id) {
        jsonData = new MutableLiveData<>();
        PostData postData = new PostData(user_id);
        api.getRewardPoints (Constants.Auth, postData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {
                if (!response.isSuccessful()) {
                    Log.v("onResponse", "Code: " + response.code());
                   /* if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    // BaseActivity.getInstance().showErrorToast("Try Again");
                    return;
                }
                jsonData.setValue(response.body());
                Log.v("onResponse", "Code Success: " + response.code());
                Log.v("onResponse", " message : " + response.message());
            }
            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
                Log.v("onResponse", "onFailure: " + t.getMessage());
             //   BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> passengerDashboard() {
        jsonData = new MutableLiveData<>();
        PostData postData = new PostData();
        api.passengerDashboardData (Constants.Auth, postData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {
                if (!response.isSuccessful()) {
                    Log.v("onResponse", "Code: " + response.code());
                    /*if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    // BaseActivity.getInstance().showErrorToast("Try Again");
                    return;
                }
                jsonData.setValue(response.body());
                Log.v("onResponse", "Code Success: " + response.code());
                Log.v("onResponse", " message : " + response.message());
            }
            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
                Log.v("onResponse", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> getRedeemPointsList(String user_id) {
        jsonData = new MutableLiveData<>();
        PostData postData = new PostData(user_id);
        api.getRedeemPointsList (Constants.Auth, postData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {
                if (!response.isSuccessful()) {
                    Log.v("onResponse", "Code: " + response.code());
                   /* if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    // BaseActivity.getInstance().showErrorToast("Try Again");
                    return;
                }
                jsonData.setValue(response.body());
                Log.v("onResponse", "Code Success: " + response.code());
                Log.v("onResponse", " message : " + response.message());
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
                Log.v("onResponse", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> getRedeemPoints(String user_id,String award_id) {
        jsonData = new MutableLiveData<>();
        RedeemPostData redeemPostData = new RedeemPostData(user_id,award_id);
        api.getRedeemPoints (Constants.Auth, redeemPostData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {
                if (!response.isSuccessful()) {
                    Log.v("onResponse", "Code: " + response.code());
                   /* if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    // BaseActivity.getInstance().showErrorToast("Try Again");
                    return;
                }
                jsonData.setValue(response.body());
                Log.v("onResponse", "Code Success: " + response.code());
                Log.v("onResponse", " message : " + response.message());
            }
            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
                Log.v("onResponse", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> jazzCashPay(JazzCashData jazzCashData) {
        jsonData = new MutableLiveData<>();
        //JazzCashData jazzCashData = new JazzCashData(jazz_number, nic_number, amount);
        api.jazzCashPay(Constants.Auth, jazzCashData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {
                if (!response.isSuccessful()) {
                    Log.v("onResponse", "Code: " + response.code());
                  /*  if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    // BaseActivity.getInstance().showErrorToast("Try Again");
                    return;
                }
                jsonData.setValue(response.body());
                Log.v("onResponse", "Code Success: " + response.code());
                Log.v("onResponse", " message : " + response.message());
            }
            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
                Log.v("onResponse", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> promocodeDiscount(String promoCode) {
        jsonData = new MutableLiveData<>();
        PromoData promoData = new PromoData(promoCode,"Karachi");
        api.promocodeDiscount(Constants.Auth, promoData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {
                if (!response.isSuccessful()) {
                    Log.v("promocodeDiscount", "Code: " + response.code());
                   /* if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    // BaseActivity.getInstance().showErrorToast("Try Again");
                    return;
                }
                jsonData.setValue(response.body() );
                Log.v("promocodeDiscount", "Code Success: " + response.code());
                Log.v("promocodeDiscount", " message : " + response.message());
            }
            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
                Log.v("onResponse", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> getCaptainIfo(String user_id) {
        jsonData = new MutableLiveData<>();
        //PostData postData = new PostData(user_id);
        api.getCaptainIfo(Constants.Auth, user_id).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {
                if (!response.isSuccessful()) {
                    Log.v("onResponse", "Code: " + response.code());
                   /* if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    // BaseActivity.getInstance().showErrorToast("Try Again");
                    return;
                }
                jsonData.setValue(response.body());
                Log.v("onResponse", "Code Success: " + response.code());
                Log.v("onResponse", " message : " + response.message());
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
                Log.v("onResponse", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> getComplaintTypes(String user_id) {
        jsonData = new MutableLiveData<>();
        //PostData postData = new PostData(user_id);
        api.getComplaintTypes(Constants.Auth, user_id).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {
                if (!response.isSuccessful()) {
                    Log.v("onResponse", "Code: " + response.code());
                   /* if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    // BaseActivity.getInstance().showErrorToast("Try Again");
                    return;
                }
                jsonData.setValue(response.body());
                Log.v("onResponse", "Code Success: " + response.code());
                Log.v("onResponse", " message : " + response.message());
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
                Log.v("onResponse", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DirectionResult> getDirection(String origin, String destination, String sensor, String mode, String key) {
        DirectionData = new MutableLiveData<>();
        Log.d("getDirection", "getDirection ");
        //BookingStatusPostData bookingStatusPostData = new BookingStatusPostData(user_id, "", "");
        // DirectionPostData directionPostData = new DirectionPostData( origin , destination, sensor, mode, key);
        //Log.v("checkBookingStatus", "Constants.Auth: " + Constants.Auth);
        // api.checkBookingStatus(Constants.Auth, bookingStatusPostData).enqueue(new Callback<DataModelObject>() {

        api.getDirection(origin, destination, sensor, mode, key).enqueue(new Callback<DirectionResult>() {
            @Override
            public void onResponse(@NotNull Call<DirectionResult> call, @NotNull Response<DirectionResult> response) {

                if (!response.isSuccessful()) {
                    Log.v("calculateEstTimeURL", "Code: " + response.code());
                   /* if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();
                        //BaseActivity.getInstance().showErrorToast("Try Again");
                        //getDriverCoordinates(user_id);
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    //  BaseActivity.getInstance().showErrorToast("Try Again");
                    return;
                }
                //response.body().getRoutes()
                DirectionData.setValue(response.body());
                /*Log.v("GetDriverCoordinates","Lat  "+dataModelObject.getData().getCoordinates().getLat());
                Log.v("GetDriverCoordinates","Log  "+dataModelObject.getData().getCoordinates().getLng());*/
                // Log.v("GetDriverCoordinates", "getBearing " + response.body().getData().getCoordinates().getBearing());
              //  Log.v("getDirection", "Code Success: " + response.code());
               // Log.v("getDirection", " message : " + response.message());
               // Log.v("getDirection", "body " + response.body().toString());
               // Log.v("getDirection", "getData " + response.body().getRoutes());
                //Log.v("getDirection", "getDirectionResult " + response.body().getData().getDirectionResult().toString());
            }

            @Override
            public void onFailure(@NotNull Call<DirectionResult> call, @NotNull Throwable t) {

                Log.v("calculateEstTimeURL", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return DirectionData;
    }

    public MutableLiveData<DirectionResult> getDirectionPickUP(String origin, String destination, String sensor, String mode, String key) {
        DirectionData = new MutableLiveData<>();
       // Log.d("calculateEstTimeURL", "getDirectionPickUP ");
        //BookingStatusPostData bookingStatusPostData = new BookingStatusPostData(user_id, "", "");
        // DirectionPostData directionPostData = new DirectionPostData( origin , destination, sensor, mode, key);
        //Log.v("checkBookingStatus", "Constants.Auth: " + Constants.Auth);
        // api.checkBookingStatus(Constants.Auth, bookingStatusPostData).enqueue(new Callback<DataModelObject>() {
      //  Log.d("calculateEstTimeURL", "origin " + origin);
        //Log.d("calculateEstTimeURL", "destination " + destination);
       // Log.d("calculateEstTimeURL", "sensor " + sensor);
       // Log.d("calculateEstTimeURL", "mode " + mode);
       // Log.d("calculateEstTimeURL", "key " + key);
        api.getDirectionPickup(origin, destination, sensor, mode, key).enqueue(new Callback<DirectionResult>() {
            @Override
            public void onResponse(@NotNull Call<DirectionResult> call, @NotNull Response<DirectionResult> response) {

                if (!response.isSuccessful()) {
                    Log.v("calculateEstTimeURL", "Code: " + response.code());
                  /*  if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();
                        //BaseActivity.getInstance().showErrorToast("Try Again");
                        //getDriverCoordinates(user_id);
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    //  BaseActivity.getInstance().showErrorToast("Try Again");
                    return;
                }
                //response.body().getRoutes()
                DirectionData.setValue(response.body());
                /*Log.v("GetDriverCoordinates","Lat  "+dataModelObject.getData().getCoordinates().getLat());
                Log.v("GetDriverCoordinates","Log  "+dataModelObject.getData().getCoordinates().getLng());*/
                // Log.v("GetDriverCoordinates", "getBearing " + response.body().getData().getCoordinates().getBearing());
                Log.v("calculateEstTimeURL", "Code Success: " + response.code());
              /*  Log.v("calculateEstTimeURL", " message : " + response.message());
                Log.v("calculateEstTimeURL", "body " + response.body().toString());
                Log.v("calculateEstTimeURL", "getData " + response.body().getRoutes());*/
                //Log.v("getDirection", "getDirectionResult " + response.body().getData().getDirectionResult().toString());
            }

            @Override
            public void onFailure(@NotNull Call<DirectionResult> call, @NotNull Throwable t) {
                Log.v("calculateEstTimeURL", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return DirectionData;
    }

    public MutableLiveData<DataModelObject> getDirection2(String origin, String destination, String sensor, String mode, String key) {
        jsonData = new MutableLiveData<>();
        //BookingStatusPostData bookingStatusPostData = new BookingStatusPostData(user_id, "", "");
        // DirectionPostData directionPostData = new DirectionPostData( origin , destination, sensor, mode, key);
        Log.v("checkBookingStatus", "Constants.Auth: " + Constants.Auth);
        // api.checkBookingStatus(Constants.Auth, bookingStatusPostData).enqueue(new Callback<DataModelObject>() {
        api.getDirection2(origin, destination, sensor, mode, key).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {
                if (!response.isSuccessful()) {
                    Log.v("getDirection", "Code: " + response.code());
                    /*if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();
                        //BaseActivity.getInstance().showErrorToast("Try Again");
                        //getDriverCoordinates(user_id);
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    //  BaseActivity.getInstance().showErrorToast("Try Again");
                    return;
                }
                jsonData.setValue(response.body());
                /*Log.v("GetDriverCoordinates","Lat  "+dataModelObject.getData().getCoordinates().getLat());
                Log.v("GetDriverCoordinates","Log  "+dataModelObject.getData().getCoordinates().getLng());*/
                // Log.v("GetDriverCoordinates", "getBearing " + response.body().getData().getCoordinates().getBearing());
               // Log.v("getDirection", "Code Success: " + response.code());
               // Log.v("getDirection", " message : " + response.message());
               // Log.v("getDirection", "body " + response.body().toString());
               // Log.v("getDirection", "getData " + response.body().getData().toString());
               // Log.v("getDirection", "getDirectionResult " + response.body().getData().getDirectionResult().toString());
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
                Log.v("LocationService", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public MutableLiveData<DataModelObject> webPage(String page, String type) {
        jsonData = new MutableLiveData<>();
        //BookingStatusPostData bookingStatusPostData = new BookingStatusPostData(user_id, "", "");
        WebPagePostData webPagePostData = new WebPagePostData(page, type);
        Log.v("checkBookingStatus", "Constants.Auth: " + Constants.Auth);
        // api.checkBookingStatus(Constants.Auth, bookingStatusPostData).enqueue(new Callback<DataModelObject>() {
        api.webPageContent(Constants.Auth, webPagePostData).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {

                if (!response.isSuccessful()) {
                    /*if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();
                        //BaseActivity.getInstance().showErrorToast("Try Again");
                        //getDriverCoordinates(user_id);
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    //  BaseActivity.getInstance().showErrorToast("Try Again");
                    return;
                }
                jsonData.setValue(response.body());
                /*Log.v("GetDriverCoordinates","Lat  "+dataModelObject.getData().getCoordinates().getLat());
                Log.v("GetDriverCoordinates","Log  "+dataModelObject.getData().getCoordinates().getLng());*/
                // Log.v("GetDriverCoordinates", "getBearing " + response.body().getData().getCoordinates().getBearing());
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
                Log.v("LocationService", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }


    public MutableLiveData<DataModelObject> sendNotification(String key, JSONObject notification) {
        jsonData = new MutableLiveData<>();
        //BookingStatusPostData bookingStatusPostData = new BookingStatusPostData(user_id, "", "");
       // WebPagePostData webPagePostData = new WebPagePostData(page, type);
       // Log.v("checkBookingStatus", "Constants.Auth: " + Constants.Auth);
        // api.checkBookingStatus(Constants.Auth, bookingStatusPostData).enqueue(new Callback<DataModelObject>() {
      /*  api.sendNotification(key, notification.toString()).enqueue(new Callback<DataModelObject>() {*/
        JsonParser jsonParser = new JsonParser();
        JsonObject jsonObject = (JsonObject)jsonParser.parse(notification.toString());
        api.sendNotification(key, jsonObject).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {

                if (!response.isSuccessful()) {
                    /*if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();
                        //BaseActivity.getInstance().showErrorToast("Try Again");
                        //getDriverCoordinates(user_id);
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    //  BaseActivity.getInstance().showErrorToast("Try Again");
                    return;
                }
                jsonData.setValue(response.body());
                /*Log.v("GetDriverCoordinates","Lat  "+dataModelObject.getData().getCoordinates().getLat());
                Log.v("GetDriverCoordinates","Log  "+dataModelObject.getData().getCoordinates().getLng());*/
                // Log.v("GetDriverCoordinates", "getBearing " + response.body().getData().getCoordinates().getBearing());
            }

            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
                Log.v("LocationService", "onFailure: " + t.getMessage());
                BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public void saveError(String message, String general_message, String detailed_message, int code) {
        Log.v("saveError", "message: " +general_message);
        ExceptionErrorClass exceptionErrorClass =new ExceptionErrorClass(message,general_message,detailed_message,code);
        api.SaveError(Constants.Auth,exceptionErrorClass).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {
            }
            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
                Log.v("LocationService", "onFailure: " + t.getMessage());
              //  BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });

    }

    public MutableLiveData<DataModelObject> getPackages() {
        jsonData = new MutableLiveData<>();
        api.getPackages(Constants.Auth).enqueue(new Callback<DataModelObject>() {
            @Override
            public void onResponse(@NotNull Call<DataModelObject> call, @NotNull Response<DataModelObject> response) {
                if (!response.isSuccessful()) {
                    /*if (response.code() == 429) {
                        //BaseActivity.getInstance().stopLoader();
                        //BaseActivity.getInstance().showErrorToast("Try Again");
                        //getDriverCoordinates(user_id);
                    }*/
                    BaseActivity.getInstance().stopLoader();
                    //  BaseActivity.getInstance().showErrorToast("Try Again");
                    return;
                }
                jsonData.setValue(response.body());
            }
            @Override
            public void onFailure(@NotNull Call<DataModelObject> call, @NotNull Throwable t) {
                Log.v("LocationService", "onFailure: " + t.getMessage());
                //  BaseActivity.getInstance().retrofitOnFailure(t);
            }
        });
        return jsonData;
    }

    public static RequestBody toRequestBody(String value) {
        RequestBody body = RequestBody.create(value, MediaType.parse("text/plain"));
        return body;
    }

    MultipartBody.Part makePart(String path, String partName) {
        MultipartBody.Part body = null;
        if (path != null) {
            File file = new File(path);
            file = saveBitmapToFile(file);
            Log.v("file.getName", "file.getName() " + file.getName());
            RequestBody reqFile = RequestBody.create(file, MediaType.parse("image/*"));
            body = MultipartBody.Part.createFormData(partName, file.getName(), reqFile);
        }
        return body;
    }

    public File saveBitmapToFile(File file) {
        try {
            // BitmapFactory options to downsize the image
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            o.inSampleSize = 6;
            // factor of downsizing the image

            FileInputStream inputStream = new FileInputStream(file);
            //Bitmap selectedBitmap = null;
            BitmapFactory.decodeStream(inputStream, null, o);
            inputStream.close();

            // The new size we want to scale to
            final int REQUIRED_SIZE = 75;

            // Find the correct scale value. It should be the power of 2.
            int scale = 1;
            while (o.outWidth / scale / 2 >= REQUIRED_SIZE &&
                    o.outHeight / scale / 2 >= REQUIRED_SIZE) {
                scale *= 2;
            }

            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = scale;
            inputStream = new FileInputStream(file);

            Bitmap selectedBitmap = BitmapFactory.decodeStream(inputStream, null, o2);
            inputStream.close();

            // here i override the original image file
            file.createNewFile();
            FileOutputStream outputStream = new FileOutputStream(file);

            selectedBitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
            outputStream.close();

            return file;
        } catch (Exception e) {
            return null;
        }
    }
}