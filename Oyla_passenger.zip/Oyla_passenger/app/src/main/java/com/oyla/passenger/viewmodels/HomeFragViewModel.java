package com.oyla.passenger.viewmodels;

import android.app.Application;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;

import com.oyla.passenger.Repository.JsonRepository;
import com.oyla.passenger.datamodels.jsonreponsedatamodel.DataModelObject;

public class HomeFragViewModel extends SharedViewModel{

    private MutableLiveData<DataModelObject> mutableLiveData;
    private JsonRepository repository;

    public HomeFragViewModel(@NonNull Application application) {
        super(application);
    }
    public void bookingStatusRequest(String user_id) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.checkBookingStatus(user_id);
    }

    public MutableLiveData<DataModelObject>bookingStatusRepose() {
        return mutableLiveData;
    }

    public void passengerLedgersRequest(String user_id) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.passengerLedgers(user_id);
    }

    public MutableLiveData<DataModelObject>passengerLedgersRepose() {
        return mutableLiveData;
    }


    public void passengerPointsRequest(String user_id) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.passengerPoints(user_id);
    }

    public MutableLiveData<DataModelObject>passengerPointsRepose() {
        return mutableLiveData;
    }

    public void passengerDashboardRequest() {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.passengerDashboard();
    }

    public MutableLiveData<DataModelObject>passengerDashboardRepose() {
        return mutableLiveData;
    }

    public void sendRefreshTokenRequest(String user_id) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.refreshToken(user_id);
    }

    public MutableLiveData<DataModelObject> receiveRefreshTokenRepose() {
        return mutableLiveData;
    }
}
