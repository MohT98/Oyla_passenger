package com.oyla.passenger.datamodels.tracking;

public class FirebaseTracking {
    private double lat;
    private double lng;
    private String bearing;

    public FirebaseTracking() {

    }

    public FirebaseTracking(double lat, double lng, String bearing) {
        this.lat = lat;
        this.lng = lng;
        this.bearing = bearing;
    }

    public double getLat() {
        return lat;
    }

    public double getLng() {
        return lng;
    }

    public String getBearing() {
        return bearing;
    }
}
