
package com.oyla.passenger.ui.activity.dahsboard;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkInfo;
import androidx.work.WorkManager;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.messaging.FirebaseMessaging;
import com.judemanutd.autostarter.AutoStartPermissionHelper;
import com.oyla.passenger.BroadcastReceiver.GpsChangeReceiver;
import com.oyla.passenger.MainApp;
import com.oyla.passenger.R;
import com.oyla.passenger.databinding.ActivityDashBoardBinding;
import com.oyla.passenger.datamodels.DashboardContentData;
import com.oyla.passenger.datamodels.chat.BookingFCM;
import com.oyla.passenger.datamodels.usermodel.UserData;
import com.oyla.passenger.interfaces.OylaWallet;
import com.oyla.passenger.services.LatestFirebaseMessagingService;
import com.oyla.passenger.services.location.GetDriverCoordinates;
import com.oyla.passenger.services.location.LocationService;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.ui.activity.ChatActivity;
import com.oyla.passenger.ui.activity.SplashActivity;
import com.oyla.passenger.ui.activity.cabbooking.TrackingActivity;
import com.oyla.passenger.ui.activity.dahsboard.fragment.HomeFragment;
import com.oyla.passenger.ui.activity.dahsboard.fragment.PayFragment;
import com.oyla.passenger.ui.activity.dahsboard.fragment.ProfileFragment;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.SharedPrefManager;
import com.oyla.passenger.viewmodels.HomeFragViewModel;
import com.oyla.passenger.workmanager.NotificationWorker;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import static com.oyla.passenger.utilities.Constants.ERROR_DIALOG_REQUEST;
import static com.oyla.passenger.utilities.Constants.PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION;
import static com.oyla.passenger.utilities.Constants.PERMISSIONS_REQUEST_ENABLE_GPS;

import static com.oyla.passenger.utilities.Constants.mLocationPermissionGranted;
import static com.oyla.passenger.utilities.Constants.referral_code;

public class DashBoardActivity extends BaseActivity implements OylaWallet {
    private static final String TAG = "DashBoardActivity";
    private ActivityDashBoardBinding binding;
    private View iconView1, iconView2, iconView3;
    private View textView1, textView2, textView3;

    GpsChangeReceiver m_gpsChangeReceiver;
    private HomeFragment homeFragment;
    private PayFragment payFragment;
    private ProfileFragment profileFragment;
    private HomeFragViewModel viewModel;
    private Animation animBlink, animEnter, animZoom;
    private boolean PERMENTALY_DENIED;
    private boolean AUTO_START;
    private static final String ENABLED_NOTIFICATION_LISTENERS = "enabled_notification_listeners";
    private AlertDialog enableNotificationListenerAlertDialog;
    public List<DashboardContentData> dashboardContentData;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_dash_board);
        binding = setContentView(this, R.layout.activity_dash_board);
        viewModel = new ViewModelProvider(DashBoardActivity.this).get(HomeFragViewModel.class);
        hideAppBar(this);
        MainApp.getInstance().setOylaWallet(this);
        if (!SharedPrefManager.getInstance(DashBoardActivity.this).getFirstLogin()) {
            SharedPrefManager.getInstance(DashBoardActivity.this).setFirstLogin(true);
        }
        animEnter = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.animation_enter);
        animBlink = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.blink);
        referral_code = "-";
        initIconView();
        initTextView();
        changeIconColor(iconView1, iconView2, iconView3);
        changeTextColor(textView1, textView2, textView3);

        homeFragment = new HomeFragment();
        loadFragment(homeFragment);
        firebaseLogin();
       // jsonCal();
        /* */


        // Log.v("newToken", "new Token method dash board "+((MainApp) this.getApplication()).getFireBaseToken());
        //  Log.v("newToken", "dash board token ==>" + MainApp.getInstance().getFireBaseToken());
        // Log.v("newToken", "new method token  ==>" +  FirebaseMessaging.getInstance().getToken().getResult());


        if (Constants.SING_IN_FIRST) {
            Constants.SING_IN_FIRST = false;
            showSignInDialog();
        }
     /*   mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                // Code to be executed when an ad finishes loading.
                Log.d("Interstitial", "The interstitial was loaded .");
                //Log.d("Interstitial", "LOGIN_SUCCESS "+LOGIN_SUCCESS);
                //  if(LOGIN_SUCCESS){
                if(homeFragment.isVisible()){
                    Log.d("Interstitial", "homeFragment visible");
                    mInterstitialAd.show();
                }else {
                    Log.d("Interstitial", "homeFragment not visible");
                }


                //LOGIN_SUCCESS=false;
                //}
                //mInterstitialAd.show();
            }

            @Override
            public void onAdFailedToLoad(LoadAdError adError) {
                // Code to be executed when an ad request fails.
                Log.d("Interstitial", "The interstitial fail to loaded ");
                mInterstitialAd.loadAd(new AdRequest.Builder().build());
            }

            @Override
            public void onAdOpened() {
                // Code to be executed when the ad is displayed.
            }

            @Override
            public void onAdClicked() {
                // Code to be executed when the user clicks on an ad.
            }


            @Override
            public void onAdClosed() {
                // Code to be executed when the interstitial ad is closed.
                Log.d("Interstitial", "The interstitial close.");
                // mInterstitialAd.loadAd(new AdRequest.Builder().build());
            }
        });*/
      /*  PackageInfo info;
        try {
            info = getPackageManager().getPackageInfo("com.oyla.passenge", PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md;
                md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                String something = new String(Base64.encode(md.digest(), 0));
                //String something = new String(Base64.encodeBytes(md.digest()));
                Log.e("hashkey", something);
            }
        } catch (PackageManager.NameNotFoundException e1) {
            Log.e("name not found", e1.toString());
        } catch (NoSuchAlgorithmException e) {
            Log.e("no such an algorithm", e.toString());
        } catch (Exception e) {
            Log.e("exception", e.toString());
        }*/
    }


    private void showSignInDialog() {
        final Dialog dialog = new Dialog(DashBoardActivity.this);
        dialog.setContentView(R.layout.sigin_confirm_dialog);
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        // if button is clicked, close the custom dialog
        dialog.findViewById(R.id.next).setOnClickListener(v -> {
            dialog.dismiss();
        });

        if (!(DashBoardActivity.this).isFinishing()) {
            //show dialog
            dialog.show();
        }
        Window window = dialog.getWindow();
        assert window != null;
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }


    @SuppressLint("NonConstantResourceId")
    public void clicker(View view) {
        //Fragment fragment;
        switch (view.getId()) {
            case R.id.home_container:
                //animZoom = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.anim_zoom_in_out);
                // binding.bottomLayout.homeContainer.startAnimation(animZoom);
                // binding.bottomLayout.homeContainer.startAnimation(animBlink);
                changeIconColor(iconView1, iconView2, iconView3);
                changeTextColor(textView1, textView2, textView3);
                dashBoardLeger();
                if (homeFragment == null) {
                    homeFragment = new HomeFragment();
                }
                loadFragment(homeFragment);
                //createNotification("String text ");
              /*  finish();
                nextActivity(DashBoardActivity.this, DashBoardActivity.class);*/
                break;

            case R.id.pay_container_icon_card:
                // animZoom = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.anim_zoom_in_out);
                // binding.bottomLayout.payContainerIconCard.startAnimation(animBlink);
                // binding.bottomLayout.payContainerText.startAnimation(animBlink);
                // binding.bottomLayout.payContainerIconCard.startAnimation(animZoom);
                // binding.bottomLayout.payContainerText.startAnimation(animZoom);
                dashBoardLeger();
                changeIconColor(iconView2, iconView3, iconView1);
                changeTextColor(textView2, textView3, textView1);
                payFragment = new PayFragment();
                loadFragment(payFragment);
                break;
            case R.id.profile_container:
                // animZoom = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.anim_zoom_in_out);
                //binding.bottomLayout.profileContainer.startAnimation(animZoom);
                changeIconColor(iconView3, iconView2, iconView1);
                changeTextColor(textView3, textView2, textView1);
                profileFragment = new ProfileFragment();
                loadFragment(profileFragment);
                break;
            default:
                break;
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.v("PermissionGranted", "mLocationPermissionGranted " + mLocationPermissionGranted);
        Log.d("TAG1", "onStart: Count a");
       /* if (isAutoStartAllowed()) {
            openAutoStartSettings();
        }
        if (checkMapServices()) {
            Log.d("TAG1", "mLocationPermissionGranted "+mLocationPermissionGranted);
            if (!mLocationPermissionGranted) {
                Log.v(TAG, "onResume: LocationPermissions");
                Log.d("TAG1", "onStart: Count b");
                getLocationPermission();
            }else {
                startLocationService();
                Log.d("TAG1", "onStart: Count c");
            }
        }*/
        checkLocationPermission();

    }


    private void loadFragment(Fragment fragment) {
        // load fragment
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        transaction.replace(R.id.frame_container, fragment);
        //manager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        //transaction.addToBackStack(null);
        transaction.commit();
    }

    private void changeIconColor(@NonNull View view1, @NonNull View view2, @NonNull View view3) {
        view1.setBackgroundTintList(AppCompatResources.getColorStateList(DashBoardActivity.this, R.color.colorPrimary));
        view2.setBackgroundTintList(AppCompatResources.getColorStateList(DashBoardActivity.this, R.color.colorBlack));
        view3.setBackgroundTintList(AppCompatResources.getColorStateList(DashBoardActivity.this, R.color.colorBlack));
    }

    private void changeTextColor(View view1, View view2, View view3) {
        ((TextView) view1).setTextColor(getResources().getColor(R.color.colorPrimary));
        ((TextView) view2).setTextColor(getResources().getColor(R.color.colorBlack));
        ((TextView) view3).setTextColor(getResources().getColor(R.color.colorBlack));
    }

    private boolean isAutoStartAllowed() {
        return AutoStartPermissionHelper.getInstance().isAutoStartPermissionAvailable(this);
    }

    private void openAutoStartSettings() {
        AutoStartPermissionHelper.getInstance().getAutoStartPermission(this);
        SharedPrefManager.getInstance(DashBoardActivity.this).setAutoStart(true);
        //AUTO_START=true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        //showPermissionDialog();
        Log.d("TAG1", "onResume: Count a");
        /*Log.v("PermissionGranted", "mLocationPermissionGranted " + mLocationPermissionGranted);
        Log.v("PermissionGranted", "checkMapServices " + checkMapServices());
        Log.v("PermissionGranted", "before PERMENTALY_DENIED " + PERMENTALY_DENIED);*/
     /*   if (isAutoStartAllowed()) {
            if(!SharedPrefManager.getInstance(DashBoardActivity.this).getAutoStart()){
                openAutoStartSettings();
            }
        }*/


        Log.v(TAG, "onResume: Dashboard");
        // showPermissionDialog();
        //  receiver = new GpsStatusReceiver();
        // registerReceiver(receiver, new IntentFilter(LocationManager.PROVIDERS_CHANGED_ACTION));
        /*m_gpsChangeReceiver = new GpsChangeReceiver();
        this.registerReceiver(m_gpsChangeReceiver, new IntentFilter(LocationManager.PROVIDERS_CHANGED_ACTION));*/
        dashBoardLeger();
        // dashBoardViewData();
     /*  String language= SharedPrefManager.getInstance(DashBoardActivity.this).getLanguage();
       if(language==null){
           language="en";
       }
        else if(language.equalsIgnoreCase("English")) {
            language="en";
        }
        else if( language.equalsIgnoreCase("اردو")) {
            language="ur";
        }
        else {
            language="EN";
        }
        Log.v("setAppLanguage","setAppLanguage "+language);
        Locale locale = new Locale(language);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale = locale;*/
    }

    private void dashBoardViewData() {
        viewModel.passengerDashboardRequest();
        viewModel.passengerDashboardRepose().observe(Objects.requireNonNull(this), dataModelObject -> {

            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                // Log.v("getModule_name", "getModule_name frag " + dataModelObject.getData().getDashboardContent().get(0).getModule_name());
                       /* Constants.TOTAL_POINTS = dataModelObject.getData().getTotalPoints();
                        binding.pointsText.setText(Constants.TOTAL_POINTS+" "+"pts");*/
                dashboardContentData = dataModelObject.getData().getDashboardContent();
                Collections.sort(
                        dashboardContentData, (Comparator<DashboardContentData>) (o1, o2) ->
                                ((DashboardContentData) o1).getSerial_no().compareToIgnoreCase(((DashboardContentData) o2).getSerial_no())
                );
                       /* for(int i=0;i<dashboardContentData.size();i++){
                            Log.v("getModule_name", "getModule_name frag--- " + dashboardContentData.get(i).getModule_name());
                        }*/
               /* mAdapter = new DashboardAdapter(getActivity(), dashboardContentData);
                binding.dashBoardRecycle.setAdapter(mAdapter);*/

            } else {
                if (dataModelObject.getError().getMessage() != null) {
                    //showToast(MapActivity.this, dataModelObject.getError().getMessage());
                    Log.v("TotalPoints", "getErrorMessage " + dataModelObject.getError().getMessage());
                } else if (dataModelObject.getError().getMessages() != null) {
                    //showToast(MapActivity.this, dataModelObject.getError().getMessages().toString());
                    Log.v("TotalPoints", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                }
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        //unregisterReceiver(m_gpsChangeReceiver);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // unregisterReceiver(m_gpsChangeReceiver);
      /*  Intent broadcastIntent = new Intent();
        broadcastIntent.setAction("restartservice");
        broadcastIntent.setClass(this, Restarter.class);
        this.sendBroadcast(broadcastIntent);*/
    }

    //region initIconView
    private void initIconView() {
        iconView1 = binding.bottomLayout.homeContainerIcon;
        iconView2 = binding.bottomLayout.payContainerIcon;
        iconView3 = binding.bottomLayout.profileContainerIcon;
    }
    //endregion initIconView

    //region initTextView
    private void initTextView() {
        textView1 = binding.bottomLayout.homeContainerText;
        textView2 = binding.bottomLayout.payContainerText;
        textView3 = binding.bottomLayout.profileContainerText;
    }
    //endregion initTextView

    //region permission and backgroud map service  start
    private boolean checkMapServices() {
        if (isServicesOK()) {
            return isMapsEnabled();
        }
        return false;
    }

    public boolean isServicesOK() {
        Log.d(TAG, "isServicesOK: checking google services version");

        int available = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(DashBoardActivity.this);

        if (available == ConnectionResult.SUCCESS) {
            //everything is fine and the user can make map requests
            Log.d(TAG, "isServicesOK: google Play Services is working");
            return true;
        } else if (GoogleApiAvailability.getInstance().isUserResolvableError(available)) {
            //an error occured but we can resolve it
            Log.d(TAG, "isServicesOK: an error occured but we can fix it");
            Dialog dialog = GoogleApiAvailability.getInstance().getErrorDialog(DashBoardActivity.this, available, ERROR_DIALOG_REQUEST);
            Objects.requireNonNull(dialog).show();
        } else {
            Toast.makeText(this, "You can't make map requests", Toast.LENGTH_SHORT).show();
        }
        return false;
    }

    public boolean isMapsEnabled() {
        final LocationManager manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        Log.v("PermissionGranted", "isMapsEnabled " + mLocationPermissionGranted);
        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            buildAlertMessageNoGps();
            return false;
        }
        return true;
    }

  /*  private void buildAlertMessageNoGps() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("This application requires GPS to work properly, do you want to enable it?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(@SuppressWarnings("unused") final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        Intent enableGpsIntent = new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        startActivityForResult(enableGpsIntent, PERMISSIONS_REQUEST_ENABLE_GPS);
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }*/

    private void getLocationPermission() {
        Log.v("PermissionGranted", "getLocationPermission " + mLocationPermissionGranted);
        Log.v("PermissionGranted", "getLocationPermission  PERMENTALY_DENIED " + PERMENTALY_DENIED);
        /*
         * Request location permission, so that we can get the location of the
         * device. The result of the permission request is handled by a callback,
         * onRequestPermissionsResult.
         */
        if (ContextCompat.checkSelfPermission(this.getApplicationContext(),
                android.Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            mLocationPermissionGranted = true;
            //getChatrooms();
            //getUserDetails();
            //startLocationService();
            Log.v("PermissionGranted", "if getLocationPermission " + mLocationPermissionGranted);
            startLocationService();

        } else {
            // mLocationPermissionGranted = false;
        /*    if (ActivityCompat.shouldShowRequestPermissionRationale(DashBoardActivity.this,
                    android.Manifest.permission.ACCESS_FINE_LOCATION)) {
                // now, user has denied permission (but not permanently!)
                Log.v("PermissionGranted","now, user has denied permission (but not permanently!) ");

            }else {*/
            /* if (!PERMENTALY_DENIED) {*/
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                    PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION);
            /*   }*/

            // }

        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        mLocationPermissionGranted = false;
        if (requestCode == PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION) {// If request is cancelled, the result arrays are empty.
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                mLocationPermissionGranted = true;
                startLocationService();
            } else {
                //  finish();
                if (ActivityCompat.shouldShowRequestPermissionRationale(DashBoardActivity.this,
                        Manifest.permission.ACCESS_FINE_LOCATION)) {
                    //  mLocationPermissionGranted = false;
                    Log.d("TAG1", "onResume: Count b");
                    // now, user has denied permission (but not permanently!)
                    Log.v("PermissionGranted", "now, user has denied permission (but not permanently!) ");

                } else {
                    Log.d("TAG1", "onResume: Count c");
                    Log.v("PermissionGranted", "now, user has denied permission permanently");
                   /* ActivityCompat.requestPermissions(this,
                            new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                            PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION);*/
                 /*   if (!PERMENTALY_DENIED) {
                        PERMENTALY_DENIED = true;*/
                    mustShowLocationPermission();
                    // }
                }

            }

        }

    }

   /* @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("onActivityResult", "onActivityResult: called.");
        Log.d(TAG, "onActivityResult: called.");
        if (requestCode == PERMISSIONS_REQUEST_ENABLE_GPS) {
            if (mLocationPermissionGranted) {
                //getChatrooms();
                // getUserDetails();
                startLocationService();
                PERMENTALY_DENIED = true;
            } else {
                getLocationPermission();
            }
        }

    }*/

    //endregion permission and backgroud map service  start

  /*  private void startLocationService() {
        if (!isLocationServiceRunning()) {
            Intent serviceIntent = new Intent(this, LocationService.class);
            serviceIntent.setAction(Constants.ACTION_START_FOREGROUND_SERVICE);
            //startService(serviceIntent);
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                DashBoardActivity.this.startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }
        }
    }

    private boolean isLocationServiceRunning() {
        ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if ("com.oyla.passenger.services.location".equals(service.service.getClassName())) {
                Log.d(TAG, "isLocationServiceRunning: location service is already running.");
                return true;
            }
        }
        Log.d(TAG, "isLocationServiceRunning: location service is not running.");
        return false;
    }*/

    @SuppressLint("SetTextI18n")
    @Override
    public void passengerLedgers(String data) {
        Log.v("passengerLedgers", "passengerLedgers Dashboard " + data);
        Log.v("TotalBalance", "TotalBalance dashBoardLeger----- " + data);
        Constants.WALLET_AMOUNT = data;
        int d = Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(data))));
        if (d < 1) {
            binding.bottomLayout.payContainerText.setText(DashBoardActivity.this.getResources().getString(R.string.currency) + " 0");
        } else {
            binding.bottomLayout.payContainerText.setText(DashBoardActivity.this.getResources().getString(R.string.currency) + " " + d);
        }

    }

    public void dashBoardLeger() {
        new Handler(Looper.getMainLooper()).post(() -> {
            Log.v("passengerLedgers", "dashBoardLe ");
            UserData userData = SharedPrefManager.getInstance(DashBoardActivity.this).getUserInfo();
            viewModel.passengerLedgersRequest(userData.getUserId());
            viewModel.passengerLedgersRepose().observe(Objects.requireNonNull(DashBoardActivity.this), dataModelObject -> {

                if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                    Log.v("TotalBalance", "TotalBalance dashBoardLeger " + dataModelObject.getData().getTotalBalance());
                    MainApp.getInstance().getOylaWallet().passengerLedgers(dataModelObject.getData().getTotalBalance());
                    Constants.WALLET_AMOUNT = dataModelObject.getData().getTotalBalance();
                    int d = Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(dataModelObject.getData().getTotalBalance()))));
                    if (d < 1) {
                        binding.bottomLayout.payContainerText.setText(DashBoardActivity.this.getResources().getString(R.string.currency) + " 0");
                    } else {
                        binding.bottomLayout.payContainerText.setText(DashBoardActivity.this.getResources().getString(R.string.currency) + " " + d);
                    }

                } else {
                    if (dataModelObject.getError().getMessage() != null) {
                        //showToast(MapActivity.this, dataModelObject.getError().getMessage());
                        Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                    } else if (dataModelObject.getError().getMessages() != null) {
                        //showToast(MapActivity.this, dataModelObject.getError().getMessages().toString());
                        Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                    }
                }
            });
        });

    }


    /*public class GpsChangeReceiver extends BroadcastReceiver {
        Context mContext;
        String TAG="GpsChangeReceiver";
        @Override
        public void onReceive(Context context, Intent intent ) {
            mContext=context;
            Log.d(TAG, "onReceive");
            final LocationManager manager = (LocationManager) context.getSystemService( Context.LOCATION_SERVICE );
            if (manager.isProviderEnabled( LocationManager.GPS_PROVIDER ) ) {
                //do something
                Toast.makeText(context, "GPS enabled - ", Toast.LENGTH_SHORT).show();
                Log.d(TAG, "GPS enabled");
            }
            else {
                Toast.makeText(context, "GPS disable - ", Toast.LENGTH_SHORT).show();
                Log.d(TAG, "GPS disable");
                buildAlertMessageNoGps();
            }
        }

    }*/
    public void showPermissionDialog() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivity(intent);
     /*   getApplicationContext().startActivity(new Intent(
                "android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));*/
       /* if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            if (!NotificationManagerCompat.getEnabledListenerPackages(this).contains(getPackageName())) {        //ask for permission
                Intent intent = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
                startActivity(intent);
            }
        }*/
    }

    public void mustShowLocationPermission() {
        AlertDialog alertDialog = new AlertDialog.Builder(this)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle("Location Permission")
                .setCancelable(false)
                .setMessage("Allow Gps Permission from Setting to continue ")
                .setPositiveButton("Yes", (dialogInterface, i) -> {
                    //set what would happen when positive button is clicked
                    Intent intent = new Intent();
                    intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    Uri uri = Uri.fromParts("package", getPackageName(), null);
                    intent.setData(uri);
                    startActivity(intent);
                    mLocationPermissionGranted = true;
                })
                .setNegativeButton("No", (dialogInterface, i) -> {
                   // Toast.makeText(getApplicationContext(),"Allow Permission to continue",Toast.LENGTH_LONG).show();
                    finish();
                })
                .show();
    }

    private void firebaseLogin() {
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        //  Log.v("FirebaseAuth","currentUser "+ currentUser);
        if (currentUser == null) {
            FirebaseAuth.getInstance().signInAnonymously()
                    .addOnCompleteListener(this, task -> {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d("FirebaseAuth", "signInAnonymously:success");

                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w("FirebaseAuth", "signInAnonymously:failure", task.getException());
                            // Toast.makeText(ChatActivity.this, "Authentication failed.", Toast.LENGTH_SHORT).show();
                            //updateUI(null);
                        }
                    });
        } else {
            Log.d("FirebaseAuth", "Already Login");
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        //  Log.d("TAG1", "onStop: Count d");
        if (!Constants.FIRE_BASE_NOTIFY) {
            Intent myService = new Intent(DashBoardActivity.this, LocationService.class);
            myService.setAction(Constants.ACTION_STOP_FOREGROUND_SERVICE);
            stopService(myService);
        }
    }

    private void jsonCal() {
        String JSON_STRING = "";
        String driver_status, lat, lng, latb, lngb;
        double dist1 = 0;
        double dist2 = 0;
        try {
            //JSONObject obj = new JSONObject(JSON_STRING);
            JSONArray jsonArray = new JSONArray(JSON_STRING);
            Log.v("jsonCal", "jsonArray.length() " + jsonArray.length());
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject c = jsonArray.getJSONObject(i);
                driver_status = c.getString("driver_status");
                lat = c.getString("lat");
                lng = c.getString("lng");
                if (Objects.equals(driver_status, "0")) {
                    if (jsonArray.length() - i > 1) {
                        JSONObject cc = jsonArray.getJSONObject(i + 1);
                         latb = cc.getString("lat");
                         lngb = cc.getString("lng");
                        dist1 =dist1 + radiusCalculation(Double.parseDouble(lat), Double.parseDouble(lng),
                                Double.parseDouble(latb),Double.parseDouble(lngb));
                    }
                }
                if (Objects.equals(driver_status, "2")) {
                    if (jsonArray.length() - i > 1) {
                        JSONObject cc = jsonArray.getJSONObject(i + 1);
                        latb = cc.getString("lat");
                        lngb = cc.getString("lng");
                        dist2 =dist2 + radiusCalculation(Double.parseDouble(lat), Double.parseDouble(lng),
                                Double.parseDouble(latb),Double.parseDouble(lngb));

                    }
                }
            }
            Log.v("jsonCal","initial distance "+dist1);
            Log.v("jsonCal","Pickup to DropOff distance "+dist2);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private double radiusCalculation(double latA, double lngA, double latB, double lngB) {
        Location startPoint = new Location("locationA");
        startPoint.setLatitude(latA);
        startPoint.setLongitude(lngA);
        Log.v("radius", "latA " + latA);
        Log.v("radius", "lngA " + lngA);
        Location endPoint = new Location("locationB");
        endPoint.setLatitude(latB);
        endPoint.setLongitude(lngB);
        Log.v("radius", "latB " + latB);
        Log.v("radius", "lngB " + lngB);
       // double distance = startPoint.distanceTo(endPoint);// in meters
        double distance = startPoint.distanceTo(endPoint) / 1000;// in Km
        Log.v("radius", "radius " + distance);
        return distance;
    }


}