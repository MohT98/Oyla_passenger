package com.oyla.passenger.interfaces;

public interface BookingStatusInterface {
    void getBookingStatus();
}
