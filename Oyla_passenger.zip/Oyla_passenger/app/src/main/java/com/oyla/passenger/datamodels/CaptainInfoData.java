package com.oyla.passenger.datamodels;

public class CaptainInfoData {

    private String booking_id;
    private String driver_status;
    private String driver_id;
    private String vehicle_model_year;
    private String vehicle_name;
    private String vehicle_number;
    private String contact_no;
    private String driver_name;
    private String profile_picture;
    private String driver_lat;
    private String driver_long;
    private String driver_ratings;
    private String final_time;
    private String final_distance;
    private String final_amount;

    public CaptainInfoData(String booking_id, String driver_status, String driver_id, String vehicle_model_year, String vehicle_name, String vehicle_number, String contact_no, String driver_name, String profile_picture, String driver_lat, String driver_long, String driver_ratings, String final_time, String final_distance, String final_amount) {
        this.booking_id = booking_id;
        this.driver_status = driver_status;
        this.driver_id = driver_id;
        this.vehicle_model_year = vehicle_model_year;
        this.vehicle_name = vehicle_name;
        this.vehicle_number = vehicle_number;
        this.contact_no = contact_no;
        this.driver_name = driver_name;
        this.profile_picture = profile_picture;
        this.driver_lat = driver_lat;
        this.driver_long = driver_long;
        this.driver_ratings = driver_ratings;
        this.final_time = final_time;
        this.final_distance = final_distance;
        this.final_amount = final_amount;
    }

    public String getBooking_id() {
        return booking_id;
    }

    public void setBooking_id(String booking_id) {
        this.booking_id = booking_id;
    }

    public String getDriver_status() {
        return driver_status;
    }

    public void setDriver_status(String driver_status) {
        this.driver_status = driver_status;
    }

    public String getDriver_id() {
        return driver_id;
    }

    public void setDriver_id(String driver_id) {
        this.driver_id = driver_id;
    }

    public String getVehicle_model_year() {
        return vehicle_model_year;
    }

    public void setVehicle_model_year(String vehicle_model_year) {
        this.vehicle_model_year = vehicle_model_year;
    }

    public String getVehicle_name() {
        return vehicle_name;
    }

    public void setVehicle_name(String vehicle_name) {
        this.vehicle_name = vehicle_name;
    }

    public String getVehicle_number() {
        return vehicle_number;
    }

    public void setVehicle_number(String vehicle_number) {
        this.vehicle_number = vehicle_number;
    }

    public String getContact_no() {
        return contact_no;
    }

    public void setContact_no(String contact_no) {
        this.contact_no = contact_no;
    }

    public String getDriver_name() {
        return driver_name;
    }

    public void setDriver_name(String driver_name) {
        this.driver_name = driver_name;
    }

    public String getProfile_picture() {
        return profile_picture;
    }

    public void setProfile_picture(String profile_picture) {
        this.profile_picture = profile_picture;
    }

    public String getDriver_lat() {
        return driver_lat;
    }

    public void setDriver_lat(String driver_lat) {
        this.driver_lat = driver_lat;
    }

    public String getDriver_long() {
        return driver_long;
    }

    public void setDriver_long(String driver_long) {
        this.driver_long = driver_long;
    }

    public String getDriver_ratings() {
        return driver_ratings;
    }

    public void setDriver_ratings(String driver_ratings) {
        this.driver_ratings = driver_ratings;
    }

    public String getFinal_time() {
        return final_time;
    }

    public void setFinal_time(String final_time) {
        this.final_time = final_time;
    }

    public String getFinal_distance() {
        return final_distance;
    }

    public void setFinal_distance(String final_distance) {
        this.final_distance = final_distance;
    }

    public String getFinal_amount() {
        return final_amount;
    }

    public void setFinal_amount(String final_amount) {
        this.final_amount = final_amount;
    }
}
