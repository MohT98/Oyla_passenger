package com.oyla.passenger.BroadcastReceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.auth.api.phone.SmsRetriever;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.api.Status;
import com.oyla.passenger.interfaces.OtpReceivedInterface;

public class SmsBroadcastReceiver extends BroadcastReceiver {
    private static final String TAG = "SmsBroadcastReceiver";
    OtpReceivedInterface otpReceiveInterface = null;
    public void setOnOtpListeners(OtpReceivedInterface otpReceiveInterface) {
        this.otpReceiveInterface = otpReceiveInterface;
    }
    @Override public void onReceive(Context context, Intent intent) {
       // Toast.makeText(context,"onReceive",Toast.LENGTH_SHORT).show();
        Log.d(TAG, "onReceive: ");
        if (SmsRetriever.SMS_RETRIEVED_ACTION.equals(intent.getAction())) {
            Bundle extras = intent.getExtras();
            Log.d(TAG, "onReceive: extras "+extras);
            Status mStatus = (Status) extras.get(SmsRetriever.EXTRA_STATUS);
            Log.d(TAG, "onReceive: mStatus "+mStatus);
            switch (mStatus.getStatusCode()) {
                case CommonStatusCodes.SUCCESS:
                    // Get SMS message contents'
                    String message = (String) extras.get(SmsRetriever.EXTRA_SMS_MESSAGE);
                    Log.d(TAG, "onReceive: message "+message);
                   // Toast.makeText(context,"onReceive message",Toast.LENGTH_SHORT).show();
                    if (otpReceiveInterface != null) {
                        String otp = message.replace("<#> Your otp code is : ", "");
                        otpReceiveInterface.onOtpReceived(otp);
                    }
                    break;
                case CommonStatusCodes.TIMEOUT:
                    // Waiting for SMS timed out (5 minutes)
                   // Toast.makeText(context,"onReceive",Toast.LENGTH_SHORT).show();
                    Log.d(TAG, "onReceive: failure");
                    if (otpReceiveInterface != null) {
                        otpReceiveInterface.onOtpTimeout();
                    }
                    break;
            }
        }
    }
}
