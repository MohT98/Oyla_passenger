package com.oyla.passenger.ui.activity;


import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.inputmethod.EditorInfo;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.oyla.passenger.R;
import com.oyla.passenger.adapter.ChatAdapter;
import com.oyla.passenger.databinding.ActivityChatBinding;
import com.oyla.passenger.datamodels.CheckBookingStatusData;
import com.oyla.passenger.datamodels.chat.BookingFCM;
import com.oyla.passenger.datamodels.chat.ChatDataModel;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.viewmodels.SendNotificationViewModel;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ChatActivity extends BaseActivity {
    private final int SIGN_IN_REQUEST_CODE = 1234;
    private List<ChatDataModel> chatDataModelsList;
    private ActivityChatBinding binding;
    private ChatAdapter mAdapter;
    private FirebaseAuth mAuth;
    private DatabaseReference rootRef;
    private DatabaseReference messageRef, fcmRef;
    private SendNotificationViewModel viewModel;
    private ChatDataModel chatDataModel;
    String bookingId, driverFCM;
    private CheckBookingStatusData bookingStatusData;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_chat);
        //bookingId="oyla_123";
        hideAppBar(this);
        binding = setContentView(this, R.layout.activity_chat);
        viewModel = new ViewModelProvider(this).get(SendNotificationViewModel.class);
        binding.onBack.setOnClickListener(v -> onBackPressed());
        binding.recyclerViewChat.setHasFixedSize(true);
        binding.recyclerViewChat.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerViewChat.setItemAnimator(new DefaultItemAnimator());
        bookingStatusData = getIntent().getParcelableExtra("bookingStatusData");
        bookingId = bookingStatusData.getBooking_id();

        mAuth = FirebaseAuth.getInstance();
        rootRef = FirebaseDatabase.getInstance().getReference();
        messageRef = rootRef.child(bookingId).child("messages");
        fcmRef = rootRef.child(bookingId).child("fcm");
        chatDataModelsList = new ArrayList<>();

        mAdapter = new ChatAdapter(this, chatDataModelsList);
        binding.recyclerViewChat.setAdapter(mAdapter);
        binding.sendMessage.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                //do here your stuff f
               /* if( v.getText().toString().isEmpty()){
                    return false ;
                }*/
                //sendMessage(v.getText().toString());
                checkSpace(v.getText().toString());
                return true;
            }
            return false;
        });

        binding.sendButton.setOnClickListener(v -> {
           /* if(binding.sendMessage.getText().toString().isEmpty()){
                return ;
            }*/
            //sendMessage(binding.sendMessage.getText().toString());
            checkSpace(binding.sendMessage.getText().toString());
        });

        ValueEventListener fcmEventListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NotNull DataSnapshot dataSnapshot) {
                // Get Post object and use the values to update the UI
                BookingFCM bookingFCM = dataSnapshot.getValue(BookingFCM.class);
                assert bookingFCM != null;
                if(bookingFCM.getFcm2() != null){
                    driverFCM = bookingFCM.getFcm2();
                }else {
                    driverFCM = "123";
                }

                Log.v("bookingIdFCM", "driverFCM " + driverFCM);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Getting Post failed, log a message
                Log.w("FirebaseAuth", "loadPost:onCancelled", databaseError.toException());
            }
        };
        fcmRef.addValueEventListener(fcmEventListener);

        binding.sendMessage.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Log.v("onTextChanged", "onTextChanged count " + count);
                if (count == 1) {
                    if (s.toString().matches(" ")) {
                        binding.sendMessage.setText("");
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }


    private void sendMessage(String message) {
        Constants.badgeCounter++;
        /*InputMethodManager inputManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);*/
        if (message == null || TextUtils.isEmpty(message.trim())) {
            return;
        }
        //message.trim();
       // Log.v("onTextChanged", "onTextChanged count " + count);
        binding.recyclerViewChat.scrollToPosition(chatDataModelsList.size() - 1);
        binding.sendMessage.setText("");
        ChatDataModel chatDataModel = new ChatDataModel(bookingId,  message, new Date().getTime(), "1");
        rootRef.child(bookingId).child("messages").push().setValue(chatDataModel);
        sendNotification(message);
    }

    private void displayChatMessages() {
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NotNull DataSnapshot dataSnapshot) {
                // Get Post object and use the values to update the UI
                if (chatDataModelsList.size() > 0) {
                    chatDataModelsList.clear();
                }
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    /*ChatDataModel chatDataModel = ds.getValue(ChatDataModel.class);*/
                    chatDataModel = ds.getValue(ChatDataModel.class);
                    chatDataModelsList.add(chatDataModel);
                }
                binding.recyclerViewChat.scrollToPosition(chatDataModelsList.size() - 1);
                mAdapter.notifyDataSetChanged();
               // Log.v("bookingIdFCM", "messageData chat Activity" + chatDataModelsList.toString());

             /*   JSONObject notificationchat = new JSONObject();
                try {
                    notificationchat.put("data", chatDataModelsList);
                    JsonParser jsonParser = new JsonParser();
                    JsonObject jsonObject = (JsonObject)jsonParser.parse(notificationchat.toString());
                    Log.w("FirebaseAuth", "messageData jsonObject" +jsonObject);
                } catch (JSONException e) {
                    e.printStackTrace();
                }*/
          //      JSONArray jsArray = new JSONArray(chatDataModelsList);
              /*  Gson gson = new GsonBuilder().create();
                JsonArray myCustomArray = gson.toJsonTree(chatDataModelsList).getAsJsonArray();*/

                String json = new Gson().toJson(chatDataModelsList);

                Log.w("bookingIdFCM", "messageData myCustomArray json" +json);



            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Getting Post failed, log a message
                Log.w("FirebaseAuth", "loadPost:onCancelled", databaseError.toException());
            }
        };
        messageRef.addValueEventListener(eventListener);
    }

    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        //  Log.v("FirebaseAuth","currentUser "+ currentUser);
        if (currentUser == null) {
            mAuth.signInAnonymously()
                    .addOnCompleteListener(this, task -> {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d("FirebaseAuth", "signInAnonymously:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            displayChatMessages();
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w("FirebaseAuth", "signInAnonymously:failure", task.getException());
                            Toast.makeText(ChatActivity.this, "Authentication failed.", Toast.LENGTH_SHORT).show();
                            //updateUI(null);
                        }
                    });
        } else {
            displayChatMessages();
        }
    }

    private void sendNotification(String message) {
        String key = "key=" + "AAAA2bJgPWE:APA91bGRMquwv5CWZmut6Lg9ipDxzAZz-4shrgXlhELl9ZK9kPcENdYcNG7k4WFeXBeBuMLQcjavqMegyHCJYLiAlg3IUDX9baCxoKLQYSZwAlP4Rm2yUbbnQHncusHH_wqv_QtJXNkw";
        JSONObject notification = new JSONObject();
        JSONObject notifcationBody = new JSONObject();
        try {
            notifcationBody.put("title", "New Message");
            notifcationBody.put("body", message);
            notifcationBody.put("badge", Constants.badgeCounter);
            notifcationBody.put("sound", "default");
            notifcationBody.put("message", message);
            notifcationBody.put("notification_type", "20");
            /*notification.put("to",  LatestFirebaseMessagingService.getToken(this));*/
            /*notification.put("to", "fXEB9wfEU0y8tMr4av7zrA:APA91bGFrZxeaNuiPk3BXjzCqmrZ9jGiQQU5MbuU0CSUjv8UErp-jZyNjKFNP5vA35VJIH_wJSj51ub3ADs-wRZhmo_aypcc-QBjORf2gidI0b8X71DUsy5dRjq1-w2cKO_jCqJjBE9x");*/
            notification.put("to", driverFCM);
            notification.put("notification", notifcationBody);
            notification.put("data", notifcationBody);
            viewModel.sendNotificationRequest(key, notification);
        } catch (JSONException e) {
            Log.e("FirebaseAuth", "onCreate: " + e.getMessage());
        }
    }
    private void checkSpace(String message){
        String newMessage;
       /* Log.e("FirebaseAuth", "message=" + message);
        Log.e("FirebaseAuth", "==>" + message.charAt(0));
        if ( message.charAt(0) == ' ') {
            newMessage= message.replace(String.valueOf(message.charAt(0)), "");
            Log.e("FirebaseAuth", "newMessage=" + newMessage);
            Log.e("FirebaseAuth", "==}" + message.charAt(0));
           // message=newMessage;
            checkSpace( message);
        }else{*/
            //newMessage
            sendMessage(message);
       // }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        getSharedPreferences("newChatMessageCounter", MODE_PRIVATE).edit().putString("messageCounter", "0").apply();
        finish();
    }
}