package com.oyla.passenger.datamodels.usermodel;

public class BookingInfoData {
    private String driver_id;
    private String temp_id;
    private String user_id;
    private String pickup_latitude;
    private String pickup_longitude;
    private String dropoff_latitude;
    private String dropoff_longitude;
    private String distance_kilomiters;
    private String estimate_minutes;
    private String amount;
    private String vehicle_type;
    private String vehicle_amount;
    private String oyla_pay;


    public BookingInfoData(String driver_id, String temp_id, String user_id, String pickup_latitude, String pickup_longitude, String dropoff_latitude, String dropoff_longitude, String distance_kilomiters, String estimate_minutes, String amount, String vehicle_type, String vehicle_amount, String oyla_pay) {
        this.driver_id = driver_id;
        this.temp_id = temp_id;
        this.user_id = user_id;
        this.pickup_latitude = pickup_latitude;
        this.pickup_longitude = pickup_longitude;
        this.dropoff_latitude = dropoff_latitude;
        this.dropoff_longitude = dropoff_longitude;
        this.distance_kilomiters = distance_kilomiters;
        this.estimate_minutes = estimate_minutes;
        this.amount = amount;
        this.vehicle_type = vehicle_type;
        this.vehicle_amount = vehicle_amount;
        this.oyla_pay = oyla_pay;
    }

    public String getDriver_id() {
        return driver_id;
    }

    public void setDriver_id(String driver_id) {
        this.driver_id = driver_id;
    }

    public String getTemp_id() {
        return temp_id;
    }

    public void setTemp_id(String temp_id) {
        this.temp_id = temp_id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getPickup_latitude() {
        return pickup_latitude;
    }

    public void setPickup_latitude(String pickup_latitude) {
        this.pickup_latitude = pickup_latitude;
    }

    public String getPickup_longitude() {
        return pickup_longitude;
    }

    public void setPickup_longitude(String pickup_longitude) {
        this.pickup_longitude = pickup_longitude;
    }

    public String getDropoff_latitude() {
        return dropoff_latitude;
    }

    public void setDropoff_latitude(String dropoff_latitude) {
        this.dropoff_latitude = dropoff_latitude;
    }

    public String getDropoff_longitude() {
        return dropoff_longitude;
    }

    public void setDropoff_longitude(String dropoff_longitude) {
        this.dropoff_longitude = dropoff_longitude;
    }

    public String getDistance_kilomiters() {
        return distance_kilomiters;
    }

    public void setDistance_kilomiters(String distance_kilomiters) {
        this.distance_kilomiters = distance_kilomiters;
    }

    public String getEstimate_minutes() {
        return estimate_minutes;
    }

    public void setEstimate_minutes(String estimate_minutes) {
        this.estimate_minutes = estimate_minutes;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getVehicle_type() {
        return vehicle_type;
    }

    public void setVehicle_type(String vehicle_type) {
        this.vehicle_type = vehicle_type;
    }

    public String getVehicle_amount() {
        return vehicle_amount;
    }

    public void setVehicle_amount(String vehicle_amount) {
        this.vehicle_amount = vehicle_amount;
    }

    public String getOyla_pay() {
        return oyla_pay;
    }

    public void setOyla_pay(String oyla_pay) {
        this.oyla_pay = oyla_pay;
    }
}
