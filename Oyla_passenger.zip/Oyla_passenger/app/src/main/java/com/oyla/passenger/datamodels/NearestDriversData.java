package com.oyla.passenger.datamodels;

import android.os.Parcel;
import android.os.Parcelable;

public class NearestDriversData implements Parcelable {
    private String id;
    private String driver_id;
    private String lat;
    private String lng;
    private String area_name;
    private String bearing;
    private String vehicle_cat_id;
    private int status;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDriver_id() {
        return driver_id;
    }

    public void setDriver_id(String driver_id) {
        this.driver_id = driver_id;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getArea_name() {
        return area_name;
    }

    public void setArea_name(String area_name) {
        this.area_name = area_name;
    }

    public String getBearing() {
        return bearing;
    }

    public void setBearing(String bearing) {
        this.bearing = bearing;
    }

    public String getVehicle_cat_id() {
        return vehicle_cat_id;
    }

    public void setVehicle_cat_id(String vehicle_cat_id) {
        this.vehicle_cat_id = vehicle_cat_id;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public static Creator<NearestDriversData> getCREATOR() {
        return CREATOR;
    }

    protected NearestDriversData(Parcel in) {
        id = in.readString();
        driver_id = in.readString();
        lat = in.readString();
        lng = in.readString();
        area_name = in.readString();
        bearing = in.readString();
        vehicle_cat_id = in.readString();
        status = in.readInt();
    }

    public static final Creator<NearestDriversData> CREATOR = new Creator<NearestDriversData>() {
        @Override
        public NearestDriversData createFromParcel(Parcel in) {
            return new NearestDriversData(in);
        }

        @Override
        public NearestDriversData[] newArray(int size) {
            return new NearestDriversData[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(driver_id);
        dest.writeString(lat);
        dest.writeString(lng);
        dest.writeString(area_name);
        dest.writeString(bearing);
        dest.writeString(vehicle_cat_id);
        dest.writeInt(status);
    }
}
