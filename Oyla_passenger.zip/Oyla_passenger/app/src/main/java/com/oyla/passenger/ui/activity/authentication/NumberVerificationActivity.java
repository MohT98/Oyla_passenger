package com.oyla.passenger.ui.activity.authentication;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.gms.auth.api.phone.SmsRetriever;
import com.google.android.gms.auth.api.phone.SmsRetrieverClient;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.oyla.passenger.BroadcastReceiver.SmsBroadcastReceiver;
import com.oyla.passenger.MainApp;
import com.oyla.passenger.utilities.DialogBoxSingleton;
import com.oyla.passenger.R;
import com.oyla.passenger.databinding.ActivityNumberVerificationBinding;
import com.oyla.passenger.interfaces.OtpReceivedInterface;
import com.oyla.passenger.services.retrofit.Api;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.ui.activity.dahsboard.DashBoardActivity;
import com.oyla.passenger.ui.activity.LoginOptionActivity;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.SharedPrefManager;
import com.oyla.passenger.viewmodels.SignInViewModel;

import java.util.Locale;
import java.util.Objects;

import static com.oyla.passenger.utilities.Constants.Token;

//import com.stfalcon.smsverifycatcher.SmsVerifyCatcher;

public class NumberVerificationActivity extends BaseActivity implements OtpReceivedInterface, View.OnKeyListener {

    private ActivityNumberVerificationBinding binding;
    private SignInViewModel viewModel;
    private final long START_TIME_IN_MILLIS = 60000;
   // private final long START_TIME_IN_MILLIS = 30000;
    // private final long START_TIME_IN_MILLIS = 10000;
    private CountDownTimer mCountDownTimer;
    private boolean mTimerRunning;
    private long mTimeLeftInMillis = START_TIME_IN_MILLIS;
    private String value = "";
    private String userId, otpCode, accessToken, countryCode;
    private Api api;
    // private SmsVerifyCatcher smsVerifyCatcher;
    private SmsBroadcastReceiver mSmsBroadcastReceiver;
    private boolean c1 = true;
    private boolean c2 = true;
    private boolean c3 = true;
    private boolean c4 = true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //  smsListener();

        viewModel = new ViewModelProvider(this).get(SignInViewModel.class);

        binding = setContentView(this, R.layout.activity_number_verification);
        binding.setViewModel(viewModel);
        hideAppBar(this);
        binding.continueButtons.customButtonText.setText(getResources().getString(R.string.continue_text));
        binding.resendButtons.customButtonText.setText(getResources().getString(R.string.resend_text));
        binding.userMobNumberText.setText(getIntent().getStringExtra("value"));

        binding.backButton.setOnClickListener(view -> onBackPressed());
        binding.editNumberText.setOnClickListener(view -> onBackPressed());

        mSmsBroadcastReceiver = new SmsBroadcastReceiver();
        mSmsBroadcastReceiver.setOnOtpListeners(this);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(SmsRetriever.SMS_RETRIEVED_ACTION);
        getApplicationContext().registerReceiver(mSmsBroadcastReceiver, intentFilter);
        //startSMSListener();
        //binding.continueButtons.button.setVisibility(View.INVISIBLE);
        binding.codeOne.setOnKeyListener(this);
        binding.codeTwo.setOnKeyListener(this);
        binding.codeThree.setOnKeyListener(this);
        binding.codeFour.setOnKeyListener(this);
        startTimer();
        value = getIntent().getStringExtra("value");
        userId = getIntent().getStringExtra("userId");
        accessToken = getIntent().getStringExtra("AccessToken");
        countryCode = getIntent().getStringExtra("countryCode");
        Log.v("newToken", "NumberVerificationActivity FB token: " + MainApp.getInstance().getFireBaseToken());

        binding.continueButtons.button.setOnClickListener(view -> {
            if (!isFinishing()) {
                startLoader();
            }
           /* final Handler handler = new Handler(Looper.getMainLooper());
            handler.postDelayed(this::verifyOTP, 3000);*/
            verifyOTP();
        });


        binding.codeOne.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() == 1) {
                    binding.codeTwo.requestFocus();
                }
            }
        });

        binding.codeTwo.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() == 1) {
                    binding.codeThree.requestFocus();
                }
                if (s.length() == 0) {
                    // binding.codeOne.requestFocus();
                    //moveBack();
                }
            }
        });

        binding.codeThree.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() == 1) {
                    binding.codeFour.requestFocus();
                }
                if (s.length() == 0) {
                    // binding.codeTwo.requestFocus();
                    //moveBack();
                }
            }
        });

        binding.codeFour.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                Log.v("codeFour", "codeFour " + s.length());
                if (s.length() == 0) {
                    // binding.codeThree.requestFocus();
                    // moveBack();
                }
            }
        });

        Log.v("mobile_no", "mobile_no " + value);
       /* if(MainApp.getInstance().getFireBaseToken().equalsIgnoreCase("empty") || MainApp.getInstance().getFireBaseToken() ==null){
            showToast(this, "Please try Again");
        }else{
            MainApp.getInstance().getFireBaseToken();
            startLoader();
            viewModel.sendMob(mobile_no);

            showToast(this, "Number sent for verification");
            mobileApiResponse();
        }*/

        binding.resendButtons.customButtonText.setOnClickListener(v -> {
            binding.codeOne.setText("");
            binding.codeTwo.setText("");
            binding.codeThree.setText("");
            binding.codeFour.setText("");
            binding.codeOne.requestFocus();
            startSMSListener();
            startLoader();
            //Constants.Auth = Constants.Bearer + " " +  SharedPrefManager.getInstance(getApplicationContext()).getUserInfo().getAccessToken();
            Constants.Auth = Constants.Bearer + " " + accessToken;
            viewModel.resendOTP(userId, value,Constants.NETWORK);
            showToast(this, "Number sent for verification");
            resetTimer();
            startTimer();
            binding.resendButtonsLayout.setVisibility(View.GONE);
            binding.continueButtonsLayout.setVisibility(View.VISIBLE);
            viewModel.resendOTPRepose().observe(this, dataModelObject -> {
                stopLoader();

            });
        });
    }


    private void verifyOTP() {
        //startLoader();
            //stopLoader();
            //nextActivity(NumberVerificationActivity.this, SignUpActivity.class);
            otpCode = Objects.requireNonNull(binding.codeOne.getText()).toString() + Objects.requireNonNull(binding.codeTwo.getText()).toString() + Objects.requireNonNull(binding.codeThree.getText()).toString() + binding.codeFour.getText().toString();
            // Constants.Auth = Constants.Bearer + " " + Constants.Token;
            // Log.v("onChanged","Mob number "+dataModelObject.getData().getUser().getUserPhoneNumber());
            Log.v("otpCode.length()", "otpCode.length() " + otpCode.length());
            if (otpCode.isEmpty() || otpCode.length() < 4) {
                showToast(NumberVerificationActivity.this, "Please Enter OTP Code");
                stopLoader();
            } else {
              /*  if (!isFinishing()) {
                    startLoader();
                }*/
                Log.v("mobileApiResponse", "accessToken " + accessToken);
                // Constants.Auth = Constants.Bearer + " " +  SharedPrefManager.getInstance(getApplicationContext()).getUserInfo().getAccessToken();
                Constants.Auth = Constants.Bearer + " " + accessToken;
                viewModel.sendOtp(userId, otpCode);
                // showToast(NumberVerificationActivity.this,"Wait for user verification");
                    otpRepose();
            }

    }

    /*private void verifyOTP() {
        //startLoader();
        final Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(() -> {
            //stopLoader();
            //nextActivity(NumberVerificationActivity.this, SignUpActivity.class);
            otpCode = Objects.requireNonNull(binding.codeOne.getText()).toString() + Objects.requireNonNull(binding.codeTwo.getText()).toString() + Objects.requireNonNull(binding.codeThree.getText()).toString() + binding.codeFour.getText().toString();
            // Constants.Auth = Constants.Bearer + " " + Constants.Token;
            // Log.v("onChanged","Mob number "+dataModelObject.getData().getUser().getUserPhoneNumber());
            Log.v("otpCode.length()", "otpCode.length() " + otpCode.length());
            if (otpCode.isEmpty() || otpCode.length() < 4) {
                showToast(NumberVerificationActivity.this, "Please Enter OTP Code");
            } else {
                if (!isFinishing()) {
                    startLoader();
                }
                Log.v("mobileApiResponse", "accessToken " + accessToken);
                // Constants.Auth = Constants.Bearer + " " +  SharedPrefManager.getInstance(getApplicationContext()).getUserInfo().getAccessToken();
                Constants.Auth = Constants.Bearer + " " + accessToken;
                viewModel.sendOtp(userId, otpCode);
                // showToast(NumberVerificationActivity.this,"Wait for user verification");
                otpRepose();
            }
        }, 3000);
    }*/

    private void mobileApiResponse() {
        Log.v("onChanged", "mobApiResponse");

        viewModel.mobApiResponse().observe(this, dataModelObject -> {
            stopLoader();
            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {

                //showToast(NumberVerificationActivity.this, dataModelObject.getMsg());
                /*String content = "";
                content += "Msg: " +dataModelObject.getMsg() + "\n";
                content += "Status : "+dataModelObject.getStatus() + "\n";
                content += "AccessToken(): " +dataModelObject.getAccessToken() + "\n";
                content += "Token_type: " +dataModelObject.getToken_type() + "\n\n";
                Log.v("onChanged","content "+content);*/
                Token = dataModelObject.getAccessToken();
                userId = dataModelObject.getData().getUser().getUserId();
                SharedPrefManager.getInstance(NumberVerificationActivity.this).
                        userInfo(
                                dataModelObject.getData().getUser().getUserId(), dataModelObject.getAccessToken()
                        );
                Log.v("mobileApiResponse", "getAccessToken " + dataModelObject.getAccessToken());
                Log.v("mobileApiResponse", "Mob number " + dataModelObject.getData().getUser().getUserMobNumber());
                Log.v("mobileApiResponse", "User Id " + dataModelObject.getData().getUser().getUserId());
            } else {
                // showToast(NumberVerificationActivity.this, dataModelObject.getMsg());
                if (dataModelObject.getError().getMessage() != null) {
                    showToast(NumberVerificationActivity.this, dataModelObject.getError().getMessage());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                } else if (dataModelObject.getError().getMessages() != null) {
                    showToast(NumberVerificationActivity.this, dataModelObject.getError().getMessages().toString());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                }
            }

        });
    }

    private void otpRepose() {

        viewModel.receiveOtpRepose().observe(this, dataModelObject -> {
            Log.v("otpRepose", "otpRepose " + dataModelObject.getStatus());
            stopLoader();
            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {

                /*String content = "";
                content += "Msg: " +dataModelObject.getMsg() + "\n";
                content += "Status : "+dataModelObject.getStatus() + "\n";
                content += "getUserPhoneNumber: " +dataModelObject.getData().getUser().getUserPhoneNumber() + "\n\n";
                content += "getUserId: " +dataModelObject.getData().getUser().getUserId() + "\n\n";
                content += "isVERIFIED: " +dataModelObject.getData().getUser().getIsVERIFIED() + "\n\n";
                Log.v("content","content "+content);*/
                SharedPrefManager.getInstance(NumberVerificationActivity.this).setSocialFlag(false);
                Log.v("otpRepose", "otpRepose " + dataModelObject.getData().getUser().getIsVERIFIED());
                if (dataModelObject.getData().getUser().getIsVERIFIED() == 1) {
                  /*  SharedPrefManager.getInstance(NumberVerificationActivity.this).
                            userInfo(userId,accessToken);*/
                    Intent i = new Intent(NumberVerificationActivity.this, SignUpActivity.class);
                    i.putExtra("userId", userId);
                    i.putExtra("accessToken", accessToken);
                    i.putExtra("countryCode", countryCode);

                    startActivity(i);
                } else {
                   // showToast(NumberVerificationActivity.this, Messages.SignInSuccess);
                    MainApp.getInstance().setUserData(dataModelObject.getData().getUser());
                    SharedPrefManager.getInstance(NumberVerificationActivity.this).
                            userInfo(userId, accessToken);

                    Constants.SOCIAL=false;
                    /*SharedPrefManager.getInstance(NumberVerificationActivity.this).
                            userInfo(
                                    dataModelObject.getData().getUser().getUserId(),dataModelObject.getAccessToken()
                            );*/
                  /*  SharedPrefManager.getInstance(NumberVerificationActivity.this).
                            userProfile(
                                    dataModelObject.getData().getUser().getUserId(),
                                    dataModelObject.getData().getUser().getUserFirstName(),
                                    dataModelObject.getData().getUser().getUserLastName(),
                                    dataModelObject.getData().getUser().getUserEmail(),
                                    dataModelObject.getData().getUser().getUserMobNumber(),
                                    dataModelObject.getData().getUser().getProfilePic(),
                                    dataModelObject.getData().getUser().getIsVERIFIED(),
                                    "-", "-", "-",Token
                            );*/
                    Constants.LOGIN_SUCCESS = true;
                    Constants.SING_IN_FIRST=true;
                    nextActivity(NumberVerificationActivity.this, DashBoardActivity.class);
                }
                finish();

            } else {
                //showToast(NumberVerificationActivity.this, dataModelObject.getError().getMessage());
                //  showToast(NumberVerificationActivity.this, "Invalid OTP code.");
                DialogBoxSingleton.getInstance().showErrorPopup(NumberVerificationActivity.this,dataModelObject.getError());
                if (dataModelObject.getError().getMessage() != null) {
                   // showToast(NumberVerificationActivity.this, dataModelObject.getError().getMessage());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                } else if (dataModelObject.getError().getMessages() != null) {
                   // showToast(NumberVerificationActivity.this, dataModelObject.getError().getMessages().toString());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                }

            }
        });
    }


    private void startTimer() {
        mCountDownTimer = new CountDownTimer(mTimeLeftInMillis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                mTimeLeftInMillis = millisUntilFinished;
                updateCountDownText();
            }

            @Override
            public void onFinish() {
                mTimerRunning = false;
                binding.resendButtonsLayout.setVisibility(View.VISIBLE);
                binding.continueButtonsLayout.setVisibility(View.GONE);
                //nextActivity(NumberVerificationActivity.this, SignUpActivity.class);
               /* mButtonStartPause.setText("Start");
                mButtonStartPause.setVisibility(View.INVISIBLE);
                mButtonReset.setVisibility(View.VISIBLE);*/
            }
        }.start();
        mTimerRunning = true;
      /*  mButtonStartPause.setText("pause");
        mButtonReset.setVisibility(View.INVISIBLE);*/
    }

    private void pauseTimer() {
        mCountDownTimer.cancel();
        mTimerRunning = false;
    }

    private void resetTimer() {
        mTimeLeftInMillis = START_TIME_IN_MILLIS;
        updateCountDownText();
       /* mButtonReset.setVisibility(View.INVISIBLE);
        mButtonStartPause.setVisibility(View.VISIBLE);*/
    }

    private void updateCountDownText() {
        int minutes = (int) (mTimeLeftInMillis / 1000) / 60;
        int seconds = (int) (mTimeLeftInMillis / 1000) % 60;
        String timeLeftFormatted = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
        binding.timerTextOne.setText(timeLeftFormatted);
        binding.timerTextTwo.setText(timeLeftFormatted);
    }

    @Override
    protected void onStart() {
        super.onStart();
        // smsVerifyCatcher.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
        //   smsVerifyCatcher.onStop();
    }

    /**
     * need for Android 6 real time permissions
     */
/*    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        smsVerifyCatcher.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }*/
    @Override
    public void onBackPressed() {
        Intent i;
        if( Constants.SOCIAL){
            i = new Intent(this, LoginOptionActivity.class);
            Constants.SOCIAL=false;
        }else {
            i = new Intent(this, SignInActivity.class);
        }

        i.putExtra("countryCode", countryCode);
        startActivity(i);
        finish();
        super.onBackPressed();
    }

    @Override
    public void onOtpReceived(String otp) {
        // Toast.makeText(this, "Otp Received " + otp, Toast.LENGTH_LONG).show();
        String[] separated = otp.split(":");
        String code = separated[1] = separated[1].trim();
        char[] minArray = code.toCharArray();
        Log.v("messageText", "messageText " + otp);
        Log.v("messageText", "minArray " + minArray.length);
        binding.codeOne.setText(String.valueOf(minArray[0]));
        binding.codeTwo.setText(String.valueOf(minArray[1]));
        binding.codeThree.setText(String.valueOf(minArray[2]));
        binding.codeFour.setText(String.valueOf(minArray[3]));
        if (!isFinishing()) {
            startLoader();
        }
        final Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(this::verifyOTP, 3000);

    }

    @Override
    public void onOtpTimeout() {
    }


    private void smsListener() {
        SmsRetrieverClient client = SmsRetriever.getClient(this);
        client.startSmsRetriever();
    }

/*    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        // if (event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_DEL) {

            moveBack();
           // Log.v("dispatchKeyEvent", "dispatchKeyEvent if");

        } else {
            // Log.v("dispatchKeyEvent","dispatchKeyEvent else");
        }
     *//*   Log.v("dispatchKeyEvent","event.getAction() "+event.getKeyCode());
        Log.v("dispatchKeyEvent","KeyEvent.KEYCODE_DEL "+KeyEvent.KEYCODE_DEL);*//*
        // }

        return super.dispatchKeyEvent(event);
    }*/


    public void startSMSListener() {
        SmsRetrieverClient mClient = SmsRetriever.getClient(this);
        Task<Void> mTask = mClient.startSmsRetriever();
        mTask.addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                // layoutInput.setVisibility(View.GONE);
                //  layoutVerify.setVisibility(View.VISIBLE);
                //Toast.makeText(SignInActivity.this, "SMS Retriever starts", Toast.LENGTH_LONG).show();
            }
        });
        mTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                //Toast.makeText(SignInActivity.this, "Error", Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public boolean onKey(View v, int keyCode, KeyEvent event) {
        Log.v("moveBack2", "keyCode = "+keyCode);
        if (event.getAction() == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DEL) {
            Log.v("moveBack2", "ACTION_DOWN ");
            Log.v("moveBack2", "KEYCODE_1 ");
            moveBack(v);

        }
        return false;
    }
    private void moveBack(View view) {

        if (view == binding.codeFour) {
            Log.v("moveBack2", " moveBack3 codeFour ");
            Log.v("moveBack2", "moveBack3 codeFour length " + binding.codeFour.length());
            if (binding.codeFour.length() == 0) {
                binding.codeThree.requestFocus();
            }

        } else if (view == binding.codeThree) {
            Log.v("moveBack2", "moveBack3 codeThree ");
            Log.v("moveBack2", "moveBack3 codeFour length " + binding.codeThree.length());
            if (binding.codeThree.length() == 0) {
                binding.codeTwo.requestFocus();
            }
        } else if (view == binding.codeTwo) {
            Log.v("moveBack2", "moveBack3 codeTwo  ");
            Log.v("moveBack2", "moveBack3 codeFour length " + binding.codeTwo.length());
            if (binding.codeTwo.length() == 0) {
                binding.codeOne.requestFocus();
            }
            //  binding.codeOne.requestFocus();
        }

    }
    private void moveBack2() {
       /* Log.v("dispatchKeyEvent","binding.codeFour.isFocused() "+binding.codeFour.isFocused());
        Log.v("dispatchKeyEvent","binding.codeThree.isFocused() "+binding.codeThree.isFocused());
        Log.v("dispatchKeyEvent","binding.codeTwo.isFocused() "+binding.codeTwo.isFocused());*/

        // if (binding.codeFour.hasFocus()) {
        if (Objects.requireNonNull(this.getCurrentFocus()).getId() == binding.codeFour.getId()) {
            Log.v("dispatchKeyEvent", "codeFour isFocused() " + binding.codeFour.isFocused());
            Log.v("dispatchKeyEvent", "codeFour length " + binding.codeFour.length());
            if (binding.codeFour.length() == 0) {
                binding.codeThree.requestFocus();
            } else if (binding.codeFour.length() == 1) {
                binding.codeFour.requestFocus();
            }


        } //else if (binding.codeThree.isFocused()) {
        else if (Objects.requireNonNull(this.getCurrentFocus()).getId() == binding.codeThree.getId()) {
            //else if (binding.codeThree.hasFocus()) {
            Log.v("dispatchKeyEvent", "codeThree isFocused() " + binding.codeThree.isFocused());
            Log.v("dispatchKeyEvent", "codeFour length " + binding.codeThree.length());
            if (binding.codeThree.length() == 0) {
                binding.codeTwo.requestFocus();
            } else if (binding.codeThree.length() == 1) {
                binding.codeThree.requestFocus();
            }
        } else if (Objects.requireNonNull(this.getCurrentFocus()).getId() == binding.codeTwo.getId()) {
            // else if (binding.codeTwo.hasFocus()) {
            /*else if (binding.codeTwo.isFocused()) {*/
            Log.v("dispatchKeyEvent", "codeTwo isFocused() " + binding.codeTwo.isFocused());
            Log.v("dispatchKeyEvent", "codeFour length " + binding.codeTwo.length());
            if (binding.codeTwo.length() == 0) {
                binding.codeOne.requestFocus();
            } else if (binding.codeTwo.length() == 1) {
                binding.codeTwo.requestFocus();
            }
            //  binding.codeOne.requestFocus();
        }
    }

    private void moveBack3(View view) {
        // if (binding.codeFour.hasFocus()) {
        if (view == binding.codeFour) {
            Log.v("moveBack2", "codeFour ");

            if (Objects.requireNonNull(binding.codeFour.getText()).toString().isEmpty()) {
                Log.v("moveBack2", "codeFour length " + binding.codeFour.length());
                binding.codeThree.requestFocus();

            }

        } //else if (binding.codeThree.isFocused()) {
        else if (view == binding.codeThree) {
            //else if (binding.codeThree.hasFocus()) {
            Log.v("moveBack2", "codeThree ");

            if (binding.codeThree.getText().toString().isEmpty()) {
                binding.codeTwo.requestFocus();
                Log.v("moveBack2", "codeFour length " + binding.codeThree.length());

            }
        } else if (view == binding.codeTwo) {
            // else if (binding.codeTwo.hasFocus()) {
            /*else if (binding.codeTwo.isFocused()) {*/
            Log.v("moveBack2", "codeTwo  ");

            if (binding.codeTwo.getText().toString().isEmpty()) {
                binding.codeOne.requestFocus();
                Log.v("moveBack2", "codeFour length " + binding.codeTwo.length());

            }
            //  binding.codeOne.requestFocus();
        }

    }


}