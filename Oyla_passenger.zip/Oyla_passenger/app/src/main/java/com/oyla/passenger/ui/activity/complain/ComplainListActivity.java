package com.oyla.passenger.ui.activity.complain;

import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import com.oyla.passenger.R;
import com.oyla.passenger.adapter.ComplainListAdapter;
import com.oyla.passenger.databinding.ActivityComplainListBinding;
import com.oyla.passenger.datamodels.ComplainData;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.DialogBoxSingleton;
import com.oyla.passenger.viewmodels.ComplainListViewModel;
import java.util.List;

public class ComplainListActivity extends BaseActivity {

    private ActivityComplainListBinding binding;
    private List<ComplainData> complainItems;
    private ComplainListAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        hideAppBar(this);
        binding = setContentView(this, R.layout.activity_complain_list);
        ComplainListViewModel viewModel = new ViewModelProvider(this).get(ComplainListViewModel.class);
        binding.onBack.setOnClickListener(v -> onBackPressed());
        binding.recyclerView.setHasFixedSize(true);
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerView.setItemAnimator(new DefaultItemAnimator());

        Log.v("bookingId","bookingId= "+ getIntent().getStringExtra("bookingId"));
        Log.v("bookingId","passengerId= "+ getIntent().getStringExtra("passengerId"));


        viewModel.sendComplaintTypesRequest("1");
        viewModel.receiveComplaintTypesRepose().observe(this, dataModelObject -> {
            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                complainItems=dataModelObject.getData().getComplaintTypes();
                mAdapter = new ComplainListAdapter(this, complainItems);

                binding.recyclerView.setAdapter(mAdapter);
                mAdapter.setOnItemClickListener(position -> {
                    Intent intent = new Intent(ComplainListActivity.this, SendComplainActivity.class);
                    intent.putExtra("id", complainItems.get(position).getId());
                    intent.putExtra("subjectName", complainItems.get(position).getName());
                    intent.putExtra("bookingId", getIntent().getStringExtra("bookingId"));
                    startActivity(intent);
                });
            }else {
                if(dataModelObject.getError().getMessage()!=null){
                    DialogBoxSingleton.getInstance().showErrorPopup(ComplainListActivity.this,dataModelObject.getError());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                }else if(dataModelObject.getError().getMessages()!=null){
                   // showToast(RideHistoryListActivity.this, dataModelObject.getError().getMessages().toString());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                }
            }

        });
    }
}