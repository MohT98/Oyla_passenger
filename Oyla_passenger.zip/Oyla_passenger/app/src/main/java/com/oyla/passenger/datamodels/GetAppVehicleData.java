package com.oyla.passenger.datamodels;

public class GetAppVehicleData {
    String user_id;
    String lat;
    String lng;
    String city_name;
    String dropoff_lat;
    String dropoff_lng;

    public GetAppVehicleData(String user_id, String lat, String lng, String city_name, String dropoff_lat, String dropoff_lng) {
        this.user_id = user_id;
        this.lat = lat;
        this.lng = lng;
        this.city_name = city_name;
        this.dropoff_lat = dropoff_lat;
        this.dropoff_lng = dropoff_lng;
    }
}
