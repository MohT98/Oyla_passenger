package com.oyla.passenger.interfaces;

public interface SearchLocation {
    void onLocationSelect(String place);
}
