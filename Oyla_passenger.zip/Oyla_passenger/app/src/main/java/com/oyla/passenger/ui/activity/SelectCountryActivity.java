package com.oyla.passenger.ui.activity;

import android.animation.LayoutTransition;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Html;
import android.util.Base64;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.oyla.passenger.R;
import com.oyla.passenger.databinding.ActivitySelectCountryActivityBinding;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.utilities.Constants;

import java.util.Locale;

public class SelectCountryActivity extends BaseActivity  {

    ActivitySelectCountryActivityBinding binding;
    String countryCode="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=setContentView(this,R.layout.activity_select_country_activity);
        hideAppBar(this);
        countryCode=binding.ccp.getSelectedCountryCode();
        /*binding.countries.setOnClickListener(v->{
            binding.ccp.showCountryCodePickerDialog();
        });*/
        Constants.COUNTRY_NAME=binding.ccp.getSelectedCountryName();
        Constants.PHONE_CODE=binding.ccp.getSelectedCountryCode();
        countryCode=binding.ccp.getSelectedCountryNameCode();

        binding.ccp.setOnCountryChangeListener(selectedCountry -> {
            countryCode= selectedCountry.getIso();
            Constants.COUNTRY_NAME=selectedCountry.getName();
            Constants.PHONE_CODE=selectedCountry.getPhoneCode();
        });

      /*  Intent ii = new Intent(SelectCountryActivity.this, ChatActivity.class);
        startActivity(ii);*/

        binding.next.setOnClickListener(v->{
            Intent i = new Intent(SelectCountryActivity.this, LoginOptionActivity.class);
            i.putExtra("countryCode", countryCode);
            startActivity(i);
                finish();
        });
      /*  String aa = "<p><img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQsAAAAgCAYAAAAFSV0TAAAIH0lEQVR4Ae1c27HtJgx1L8mfm8hfKnA/VHALoR73Q0aAQBJvb7wfDpnJbBuDJJakhcA+dzPrv4XAQmAh0IHA1tFndfkEAqcy+7aZ7VBGKf0JC5bOhQBDYJEFg+MLbpAkdmVOfZht2406v8CuZcL/HoHnkMWpzG8vwKdR+2Y2IAlKGP/7EF0AfAsCDyALbQ4o1yHJvgXVC3boYzdK+63HqiYuILiG3I3A75IFrr4PSSx9bGbbNnOs44m7Y37Jv4jAD5KFL9e3w/Tm1an2r05CsG9fBxMXQ3gNexcCw2RhV0BR8ufa7prAqY7mgR+u0rBS2/+/ernWRtWIAisoOodc212AL7kMAa1+e7vLJjN4M0QWkIQ0ZkFXrm3QhoHu2hzSADbanV9gF1ixN1+B2Gt8wMbMvxkKKH3UqwokBlpJ5drmT2NJFAh8e4UqzJ1+O0AW/iCRnRHk2oBBVHP1vzQTSJJiwoMtha1JSK6U7C7ZUR3UIjQxuEUW0B1eocp559qE6HV7BYHTnJmTclutSh9cEX91jNbd2+6rKlrjBsjCVRHyvb8r+fm3APooJG3LmtbzSmI5O/y2w24/uE3mVOaolfst3d3PB8miapc/n2FBmmvrNu7GjucjPh5Lt7l+QWQ+uBHGguhyTrl4eMm8sLjXfThEFoV5iObTqOOmfV2RLLDCIWSxK/NH9x6Biim8dBtt6XNg48ziJVveOLjkm1DVCfJ+o2n9qiDxyELnbe/zY7+W8Z7lqpkukqOH5KdSBuqVA88gSz70Bt9AFtocf/1j/vaHi6MTqALZmAyOhdXh+BcPNw/3HUZpi4KDpvy6YFNwVtKIMHeeQsiNbe+mGPNWIRC0qa8xEH01ZGOCJONbLexRRsjCEsW3EFyJLCiuvbbSMRB/cVzehxG3Bll4wY3Aj+LgygeI/VR5s2cMmS0gH8LuTqN1YYQ+kgNWNtSq9weG+Km0gk+m4aOtw5TEJjKuNthyrqdSwK2Kq0IsvD1zu2rX7eNcnKRkIRVj1fWthAHzgDhRZsfVVk7hI/d5sghVxZCt3gdJTrd9eB9ZVEDVYnvg7j0xEaaTItL9pOyBSSjbO+9PfR+hUDLAT9PJIeWp9ctfoLrgOcwBX4MW+LYTicFu7UAzxvVJYrSoCYIa53Fta1t/K0XloxGgB/Dr3EbfFS+40AUfYoVG7NxzlRw+r/2WsGz7sEEWNaWlZ3JivF8ovzFqwp628qYC+zQY1B4C2b5u5WqTC7WtBCLt03stZXk2D69xYa8IznHJAJi0V+Wa7piISBjvPa3JBBpWlpa14lxrs4jPnLzwnYzf0tKSOfaVV4h1PpkCgXj7+J8JZPRinEo14L9eUknG8oZgk28OFUPQTXOqhaU2Yi3myuzLyhwZurnX4nA+WVRLOOIMSHyS2MmMQgM6H1eZ8EBcQPn/x59PlM8CZFVjhVg7WvKFutqtfMOBgQkrZfj7j2hjzUE1NfDMke9E21sKC88hwENs+yoiJvu4fbioADZ4HeWnRmAfSyjwmjGsyqQv+NkLCQnJzrIw1qJv8DsdIgVAN3uoetiT8Rtikx1sZXv9YXEEu3ABhG+HqH0U957PFsokx32YTmU+WcCZBXMAUUqBsBNuBxEEQU8yxSoCWdgREw8weZ7gySs4hdj6wiXYTPXGwIxOps+vqXKB3YNNXX79dVl5LB/HAo35ueVjLqesTz6JvrRE0eFD6Rf7/QqLVcA02mvlsufz4yWxiWIXgqSUUxjrERtZpcQneFXeqjMfYnfy2yALD04wmowsXrogxiHu9Yzo3PlWY+TbCPYe2gOONgTt4X0ytMDcYmCEPi9flBxbZvRxlSUd45LsgTRJkLYE519Y3SK+gCU/tESCbJNZGvAjNrhVluvOj89hJhNH2kKf3xEvOZu89SxHHOYRb+iTs6cjxujZGQMq9SF7bIy5jSxCqZRjfJa00iS8rwCJXcIvn6gLVKhI6M6dA+lWjbjSB3tFiZdvL5EM2AH/uhXVi0ZeXUFxfPzFROT77fh87MoFYn6eZXw4CdCkitpjtWf3S2ZnqzT2k/pl4ntMS37JxReKJr8WM+EXZp/t63Th3Oiqf0e85GxCk9nil2zrnF/QThwT3kTGBnFVy6m8D6mABlnQrr3X3LncP7VkivIxGVIwYh9+BSCUEtj1BGdHeTJAy0lRTCIZpKF8TO1wgZa28zn03k2wnSUt91dxviRZuU8zdiMWoSO1WZIBfdbnhyA2ozptQvkUf9+WEYSx53BAW1FGn31ZDFm8oDxqE1qet43bVfr3W2BsTibI7ss9tCL3ewNZ+L9lgOAKzogBGZoSa2IfCzYDN+ksGtzYSAbiMRwwSnkY0CQJsk5mz3OOoHbT57SdluzCtku3GGyZ4C0DXNbUgUVbLJ9vgrc95KX4EHOm6Cfy7CW3x9mPbQU7YByxhc2ZtLfjBP0i9aB+95zJx2RmRE7mRPXLWA7dfFzI52GstCcM7Lq4hyy6VM/thMzLHZD/e5a5mpe0hcC3IMDJSJJacTHtNP8xZEFXBA7Sa2zaiePnu3WdA33ezGXBzQiE1/RY3fhfuYpeMOM5ZAGTD+WWB0iWYxcA+o0h7cOp4Xn4oJsQY8Oq14DXEOCHsfMWy2eRxWsY/+xoCI65SU3PRPCQ72fhWYZPQmCRxSQgPykGzmsONfnf66gdSH5yskv3xxBYZPEx6OcpxrJzbnUxz74l6RkILLJ4hh/XLBYCtyOwyOJ2iJeChcAzEFhk8Qw/rlksBG5HYJHF7RAvBQuBZyDwH5Hy23hXVFzoAAAAAElFTkSuQmCC\" alt=\"\"></p>";
        String nr =  aa.replace("data:image/png;base64,", "");
        Log.v("base64","nr "+nr);
        try {
            binding.message.setText(Html.fromHtml(nr, source -> {
                byte[] data = Base64.decode(source, Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
                Drawable drawable = new BitmapDrawable(getResources(), bitmap);
                drawable.setBounds(0, 0, drawable.getIntrinsicWidth()+300, drawable.getIntrinsicHeight()+0);
               // drawable.setBounds(0, 0,500, 80);
                return drawable;
            }, null));

        }catch (Exception ex)
        {
            binding.message.setText(Html.fromHtml(aa));
        }*/
    }
}