package com.oyla.passenger.services.location;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;

import android.os.Build;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.work.Constraints;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkInfo;
import androidx.work.WorkManager;


//import com.google.android.gms.location.LocationRequest;
import android.location.LocationListener;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.oyla.passenger.BroadcastReceiver.Restarter;
import com.oyla.passenger.MainApp;
import com.oyla.passenger.R;
import com.oyla.passenger.Repository.JsonRepository;
import com.oyla.passenger.datamodels.jsonreponsedatamodel.DataModelObject;
import com.oyla.passenger.datamodels.usermodel.UserData;
import com.oyla.passenger.datamodels.usermodel.UserLocation;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.ui.activity.SplashActivity;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.SharedPrefManager;
import com.oyla.passenger.viewmodels.LocationViewModel;
import com.oyla.passenger.workmanager.NotificationWorker;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class LocationService extends Service implements LocationListener {

    private static final String TAG = "LocationService";
    LocationViewModel viewModel;
    private MutableLiveData<DataModelObject> mutableLiveData;
    private JsonRepository repository;
    private FusedLocationProviderClient mFusedLocationClient;
    private final static long UPDATE_INTERVAL = 60 * 1000;  /* 60 secs */
    private final static long FASTEST_INTERVAL = 60 * 1000; /* 50 sec */
  // private final static long UPDATE_INTERVAL = 5 * 1000;  /* 60 secs */
   // private final static long FASTEST_INTERVAL = 5 * 1000; /* 50 sec */
    public static boolean LOCATION_DATA_SAVED = true;
    UserData userData;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        String CHANNEL_ID = "my_channel_01";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "My Channel",
                    NotificationManager.IMPORTANCE_DEFAULT);

            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }

            Intent notificationIntent = new Intent(this, SplashActivity.class);
            notificationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);



        /*    Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setContentTitle("aaaa")
                    .setContentText("")
                    .build();*/

            NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentTitle("Oyla Application is running");
            mBuilder.setContentIntent(pendingIntent);
            Notification notification = mBuilder.build();
            startForeground(1, notification);
      /*      AudioManager audioManager =
                    (AudioManager)getSystemService(Context.AUDIO_SERVICE);

            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC,0,0);*/

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if(intent!=null){
            Log.d(TAG, "onStartCommand: called.");
            if (intent.getAction().equals(Constants.ACTION_START_FOREGROUND_SERVICE)) {
                Log.i("LocationService", "Received Start Foreground Intent ");
                // your start service code
                getLocation();
            } else if (intent.getAction().equals(Constants.ACTION_STOP_FOREGROUND_SERVICE)) {
                Log.i("LocationService", "Received Stop Foreground Intent");
                //your end servce code
                stopForeground(true);
                stopSelfResult(startId);
            }
        }
        return START_STICKY;
    }

    private void getLocation() {
        // ---------------------------------- LocationRequest ------------------------------------
        // Create the location request to start receiving updates
        // LocationRequest is used to constantly retrieve location
        //LocationRequest mLocationRequestHighAccuracy = new LocationRequest();
        LocationRequest mLocationRequestHighAccuracy = LocationRequest.create();
        mLocationRequestHighAccuracy.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequestHighAccuracy.setInterval(UPDATE_INTERVAL);
        mLocationRequestHighAccuracy.setFastestInterval(FASTEST_INTERVAL);


        // new Google API SDK v11 uses getFusedLocationProviderClient(this)
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Log.d(TAG, "getLocation: stopping the location service.");
            stopSelf();
            return;
        }
        Log.d(TAG, "getLocation: getting location information.");
        mFusedLocationClient.requestLocationUpdates(mLocationRequestHighAccuracy, new LocationCallback() {
                    @Override
                    public void onLocationResult(LocationResult locationResult) {

                        Log.d(TAG, "onLocationResult: got location result.");
                        Location location = locationResult.getLastLocation();
                        if (location != null) {
                          //  Log.d(TAG, "location.getTime() " + location.getTime());
                          //  Log.d(TAG, "location.hasAccuracy() " + location.hasAccuracy());
                           // Log.d(TAG, "getAccuracy " + location.getAccuracy());
                            userData = SharedPrefManager.getInstance(getApplicationContext()).getUserInfo();
                            Log.d(TAG, "userData " + userData.getUserId());
                            Log.d(TAG, "location.getLatitude() " + location.getLatitude());
                            Log.d(TAG, "location.getLongitude() " + location.getLongitude());
                            Log.d(TAG, "location.getBearing() " + location.getBearing());

                          /*  Toast.makeText(LocationService.this,"Lat "+location.getLatitude()+
                                            location.getLatitude()
                                    ,Toast.LENGTH_SHORT).show();*/
                           // Log.d(TAG, "location.getSpeed() " + location.getSpeed());
                            Log.d(TAG, "-------------------------------------- ");
                            //User user = ((UserClient)(getApplicationContext())).getUser();
                            // GeoPoint geoPoint = new GeoPoint(location.getLatitude(), location.getLongitude());
                            MainApp.getInstance().setUserLocation(new UserLocation(userData, location));
                            //UserLocation userLocation = new UserLocation(userData, location);
                            Log.v(TAG, "LOCATION_DATA_SAVED " + LOCATION_DATA_SAVED);
                            if (LOCATION_DATA_SAVED) {
                                // saveUserLocation(userLocation);
                                saveUserLocation(MainApp.getInstance().getUserLocation());
                            }
                        }
                    }
                },
                Looper.myLooper()); // Looper.myLooper tells this to repeat forever until thread is destroyed
    }

    private void saveUserLocation(final UserLocation userLocation) {
        String city, area;
        //userLocation.getLocation().getLatitude();
      //  userLocation.getLocation().getLongitude();
        if(userLocation== null || userLocation.getLocation()== null ){
            return;
        }
        if(getStringAddress2(userLocation.getLocation().getLatitude(),
                userLocation.getLocation().getLongitude())!=null){
            List<Address> addresses = getStringAddress2(userLocation.getLocation().getLatitude(),
                    userLocation.getLocation().getLongitude());
            if (addresses != null) {
                Log.v(TAG, "getSubLocality " + addresses.get(0).getSubLocality());
                Log.v(TAG, "getLocality " + addresses.get(0).getLocality());
                if (addresses.get(0).getSubLocality() == null) {
                    area = "no info";
                } else {
                    area = addresses.get(0).getSubLocality();
                }
                if (addresses.get(0).getLocality() == null) {
                    city = "no info";
                } else {
                    city = addresses.get(0).getLocality();
                }
                if (mutableLiveData == null) {
                    mutableLiveData = new MutableLiveData<>();
                }
                LOCATION_DATA_SAVED = false;
                repository = new JsonRepository();
        /*    Toast.makeText(this,"Lat "+userLocation.getLocation().getLatitude()+
                    userLocation.getLocation().getLatitude()+city+area
                    ,Toast.LENGTH_SHORT).show();*/
                Log.v("getAccessToken", "getAccessToken " + userData.getFcm_token());
                Constants.Auth = Constants.Bearer + " " + SharedPrefManager.getInstance(getApplicationContext()).getUserInfo().getAccessToken();
                mutableLiveData = repository.setPassengerCoordinates(
                        userLocation.getUserData().getUserId(),
                        String.valueOf(userLocation.getLocation().getLatitude()),
                        String.valueOf(userLocation.getLocation().getLongitude()),
                        city, area, String.valueOf(userLocation.getLocation().getBearing())
                );
            }
        }

    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onDestroy() {
        Log.i("LocationService", "onCreate() , service stopped...");
        mFusedLocationClient.flushLocations();
      //  workManagerExp();
       /* Intent broadcastIntent = new Intent();
        broadcastIntent.setAction("restartservice");
        broadcastIntent.setClass(this, Restarter.class);
        this.sendBroadcast(broadcastIntent);*/
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        Log.i("LocationService", "onTaskRemoved called ");
        super.onTaskRemoved(rootIntent);
        //do something you want
        //stop service
        this.stopSelf();
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {
            userData = SharedPrefManager.getInstance(getApplicationContext()).getUserInfo();
            Log.d("onLocationChanged", "userData " + userData.getUserId());
            Log.d("onLocationChanged", "location.getLatitude() " + location.getLatitude());
            Log.d("onLocationChanged", "location.getLongitude() " + location.getLongitude());
            Log.d("onLocationChanged", "location.getBearing() " + location.getBearing());
            // Log.d(TAG, "location.getSpeed() " + location.getSpeed());
            Log.d("onLocationChanged", "-------------------------------------- ");
            //User user = ((UserClient)(getApplicationContext())).getUser();
            // GeoPoint geoPoint = new GeoPoint(location.getLatitude(), location.getLongitude());
            MainApp.getInstance().setUserLocation(new UserLocation(userData, location));
            //UserLocation userLocation = new UserLocation(userData, location);
            Log.v("onLocationChanged", "LOCATION_DATA_SAVED " + LOCATION_DATA_SAVED);
            if (LOCATION_DATA_SAVED) {
                // saveUserLocation(userLocation);
                saveUserLocation(MainApp.getInstance().getUserLocation());
            }
    }
    public List<Address> getStringAddress2(double latitude, double longitude) {
        android.location.Geocoder geocoder;
        List<Address> addresses;
        geocoder = new Geocoder(this, Locale.getDefault());
        Log.v("LatLog", "latitude " + latitude);
        Log.v("LatLog", "longitude " + longitude);
        if (latitude != 0.0 && longitude != 0.0) {
            try {
                if (geocoder.getFromLocation(latitude, longitude, 1) != null) {
                    addresses = geocoder.getFromLocation(latitude, longitude, 1);
                    Log.v("getStringAddress", "getSubLocality " + addresses.get(0).getSubLocality());
                    Log.v("getStringAddress", "getLocality " + addresses.get(0).getLocality());
                } else {
                    addresses = null;
                }

              /*  String address = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
                String city = addresses.get(0).getLocality();
                String state = addresses.get(0).getAdminArea();
                String country = addresses.get(0).getCountryName();
                String postalCode = addresses.get(0).getPostalCode();
                String knownName = addresses.get(0).getFeatureName();*/
                //  Log.v("getStringAddress","postalCode "+postalCode);

                return addresses;
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        } else {
            return null;
        }
    }
    @RequiresApi(api = Build.VERSION_CODES.M)
    private void workManagerExp() {
        Log.v("workManagerExp", "workManagerExp ");

        Constraints constraints = new Constraints.Builder()
                .setRequiresDeviceIdle(false)
                .setRequiresCharging(false)
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .setRequiresBatteryNotLow(true)
                .setRequiresStorageNotLow(false)
                .build();


       /* final OneTimeWorkRequest mRequest = new OneTimeWorkRequest.Builder(NotificationWorker.class)
                .setConstraints(constraints)
                .build();*/
        final PeriodicWorkRequest mRequest = new PeriodicWorkRequest.Builder(NotificationWorker.class, 5, TimeUnit.SECONDS)
                // setting a backoff on case the work needs to retry
                .setConstraints(constraints)
                .build();
        /*mWorkManager.enqueueUniquePeriodicWork("SYNC_DATA_WORK_NAME", ExistingPeriodicWorkPolicy.KEEP, //Existing Periodic Work policy
                refreshCpnWork   //work request
        );*/
        /* mWorkManager.enqueue(mRequest);*/
        WorkManager.getInstance().enqueue(mRequest);

    }
}