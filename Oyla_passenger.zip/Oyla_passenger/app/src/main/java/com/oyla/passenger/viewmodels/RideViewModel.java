package com.oyla.passenger.viewmodels;

import android.app.Application;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;

import com.oyla.passenger.Repository.JsonRepository;
import com.oyla.passenger.datamodels.GetAppVehicleData;
import com.oyla.passenger.datamodels.SearchCaptainData;
import com.oyla.passenger.datamodels.mapmodel.direction.DirectionResult;
import com.oyla.passenger.datamodels.jsonreponsedatamodel.DataModelObject;

public class RideViewModel extends SharedViewModel{

    private MutableLiveData<DataModelObject> mutableLiveData;
    private MutableLiveData<DirectionResult> mutableLiveDirectionData;
    private JsonRepository repository;

    public RideViewModel(@NonNull Application application) {
        super(application);
    }
    public void sendRideTypeRequest( GetAppVehicleData getAppVehicleData ) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
         mutableLiveData = repository.getRideType(getAppVehicleData);
    }
    public MutableLiveData<DataModelObject> receiveRideTypeRepose() {
        return mutableLiveData;
    }


    public void findNearestDriverRequest(String lat, String lng) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.getNearestDrivers( lat,  lng);
    }
    public MutableLiveData<DataModelObject> findNearestDriverRepose() {
        return mutableLiveData;
    }



    public void findCaptainRequest(String vehicle_type_id,String user_id, String pickup_latitude, String pickup_longitude, String dropoff_latitude, String dropoff_longitude, String distance_kilomiters, String estimate_minutes,
                                   String amount, String vehicle_type, String vehicle_amount, String oyla_pay,String payment_type,
                                   String peak_factor_rate,String driver_initial_distance,String min_ride_fares,String pickup_address, String dropoff_address,int is_skip_dropoff) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.searchCaptain(vehicle_type_id,user_id,  pickup_latitude,  pickup_longitude,  dropoff_latitude,
                dropoff_longitude,  distance_kilomiters,  estimate_minutes,  amount,  vehicle_type,
                vehicle_amount, oyla_pay,payment_type,  peak_factor_rate,driver_initial_distance,min_ride_fares,pickup_address,dropoff_address,is_skip_dropoff);
    }
    public void findCaptainRequest2( SearchCaptainData searchCaptainData) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.searchCaptain2(searchCaptainData);
    }
    public MutableLiveData<DataModelObject> findCaptainRepose() {
        return mutableLiveData;
    }



    public void sendCancelRideRequest(String user_id,String booking_id,String descriptions,String chatMessages) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.cancelRide(user_id,booking_id,descriptions,chatMessages);
    }

    public MutableLiveData<DataModelObject> receiveCancelRideRepose() {
        return mutableLiveData;
    }



    public void passengerChangeDestinationRequest(String booking_id,String current_latitude, String current_longitude,
                                                  String dropoff_latitude, String dropoff_longitude, String trip_one_distance,
                                                  String trip_two_distance, String trip_total_distance, String trip_one_price,
                                                  String trip_two_price, String total_price, String trip_total_time) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.passengerChangeDestination(booking_id,current_latitude,current_longitude,dropoff_latitude,dropoff_longitude,
                trip_one_distance,trip_two_distance,trip_total_distance,trip_one_price,trip_two_price,total_price,trip_total_time);
    }
    public MutableLiveData<DataModelObject> passengerChangeDestinationRepose() {
        return mutableLiveData;
    }

    public void bookingStatusRequest(String user_id) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.checkBookingStatus(user_id);
    }

    public MutableLiveData<DataModelObject>bookingStatusRepose() {
        return mutableLiveData;
    }

    public void directionResultRequest(String origin, String destination, String sensor, String mode, String key) {
        Log.v("jsonData", "init");

        if (mutableLiveDirectionData == null) {
            mutableLiveDirectionData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveDirectionData = repository.getDirection(origin , destination, sensor, mode, key);
    }

    public MutableLiveData<DirectionResult>directionResultRepose() {
        return mutableLiveDirectionData;
    }


    public void directionResultPickUPRequest(String origin, String destination, String sensor, String mode, String key) {
        Log.v("jsonData", "init");
        Log.d("calculateEstTimeURL", "directionResultRequest ");
        if (mutableLiveDirectionData == null) {
            mutableLiveDirectionData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveDirectionData = repository.getDirectionPickUP(origin , destination, sensor, mode, key);
    }

    public MutableLiveData<DirectionResult>directionResultPickUPRepose() {
        return mutableLiveDirectionData;
    }



    public void promoRequest(String promo) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.promocodeDiscount(promo);
    }

    public MutableLiveData<DataModelObject>promoRepose() {
        return mutableLiveData;
    }


    public void sendRefreshTokenRequest(String user_id) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.refreshToken(user_id);
    }

    public MutableLiveData<DataModelObject> receiveRefreshTokenRepose() {
        return mutableLiveData;
    }


    public void driverInfoRequest(String id) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.getCaptainIfo(id);
    }

    public MutableLiveData<DataModelObject>driverInfoRepose() {
        return mutableLiveData;
    }


    public void directionResultRequest2(String origin, String destination, String sensor, String mode, String key) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.getDirection2(origin , destination, sensor, mode, key);
    }

    public MutableLiveData<DataModelObject>directionResultRepose2() {
        return mutableLiveData;
    }
}