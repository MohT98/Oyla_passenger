package com.oyla.passenger.viewmodels;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;

public class SharedViewModel extends AndroidViewModel {



    public SharedViewModel(@NonNull Application application) {
        super(application);
    }


}