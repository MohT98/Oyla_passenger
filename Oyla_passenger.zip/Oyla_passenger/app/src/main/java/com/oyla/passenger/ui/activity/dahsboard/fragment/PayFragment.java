package com.oyla.passenger.ui.activity.dahsboard.fragment;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.textfield.TextInputLayout;
import com.oyla.passenger.MainApp;
import com.oyla.passenger.R;
import com.oyla.passenger.databinding.FragmentPayBinding;
import com.oyla.passenger.datamodels.usermodel.UserData;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.ui.activity.history.RideHistoryListActivity;
import com.oyla.passenger.ui.activity.history.TransactionHistoryListActivity;
import com.oyla.passenger.ui.activity.packages.PackagesListActivity;
import com.oyla.passenger.ui.activity.pay.JazzCashActivity;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.DialogBoxSingleton;
import com.oyla.passenger.utilities.Messages;
import com.oyla.passenger.utilities.SharedPrefManager;
import com.oyla.passenger.viewmodels.PayFragViewModel;

import org.jetbrains.annotations.NotNull;

import java.util.Objects;

import static com.facebook.FacebookSdk.getApplicationContext;

public class PayFragment extends Fragment  {

    private FragmentPayBinding binding;
    private PayFragViewModel viewModel;
    private Animation animBlink;
    private Animation animEnter,animExit,animFade;
    private  UserData userData;
    public PayFragment() {
        // Required empty public constructor
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_pay, container, false);
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_pay, container, false);
        View view = binding.getRoot();
        //MainApp.getInstance().setOylaWallet(this);
        binding.addFundCard.setBackgroundResource(R.drawable.jazzcash_bg);
        binding.transactionHistoryCard.setBackgroundResource(R.drawable.credit_bg);

        animBlink= AnimationUtils.loadAnimation(getApplicationContext(), R.anim.blink);
        binding.rideHistoryCard.setOnClickListener(v -> BaseActivity.getInstance().nextActivity(getActivity(), RideHistoryListActivity.class));
        binding.transactionHistoryCard.setOnClickListener(v -> BaseActivity.getInstance().nextActivity(getActivity(), TransactionHistoryListActivity.class));


        binding.addCardLayout.setOnClickListener(v -> {
            //BaseActivity.getInstance().nextActivity(getActivity(), AddCardActivity.class);
            binding.addCardLayout.startAnimation(animBlink);
            DialogBoxSingleton.getInstance().showPopup(getActivity(), "Coming Soon....",true);
        });
        binding.addCreditLayout.setOnClickListener(v -> {
           // BaseActivity.getInstance().nextActivity(getActivity(), AddCreditActivity.class);
            binding.addCreditLayout.startAnimation(animBlink);
           //DialogBoxSingleton.getInstance().showPopup(getActivity(), "Coming Soon....",true);
            discountDialog();
        });
        binding.emergencyIcon.setOnClickListener(v -> {
            // BaseActivity.getInstance().nextActivity(getActivity(), AddCreditActivity.class);
            binding.emergencyIcon.startAnimation(animBlink);
            //Constants.phoneCall(getActivity());
           // BaseActivity.getInstance().helpLineDialog();
            DialogBoxSingleton.getInstance().helpLineDialog(getActivity(), getActivity());
        });
        binding.addFundCard.setOnClickListener(v -> {
           // BaseActivity.getInstance().nextActivity(getActivity(), JazzCashActivity.class);
        });
        binding.addFundButton.setOnClickListener(v -> {
            DialogBoxSingleton.getInstance().showPopup(getActivity(), "Coming Soon....", true);
            //BaseActivity.getInstance().nextActivity(getActivity(), JazzCashActivity.class);
        });
        binding.packagesCard.setOnClickListener(v -> {
            DialogBoxSingleton.getInstance().showPopup(getActivity(), "Coming Soon....", true);
            //BaseActivity.getInstance().nextActivity(getActivity(), PackagesListActivity.class);
        });
        viewModel = new ViewModelProvider(requireActivity()).get(PayFragViewModel.class);
        animEnter = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.animation_enter);
        animExit = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slide_in_right);
        animFade= AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fade_in);
        binding.parentLayout.post(() -> {
            binding.addFundCard.startAnimation(animEnter);
            binding.addCardLayout.startAnimation(animExit);
            binding.transactionHistoryCard.startAnimation(animEnter);
            binding.rideHistoryCard.startAnimation(animEnter);
            binding.topBarLayout.startAnimation(animFade);
        });

         userData = SharedPrefManager.getInstance(getActivity()).getUserInfo();

        return view;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onResume() {
        super.onResume();
        Log.v("onResumePay","onResumePay");
        Log.v("onResumePay","Constants.WALLET_AMOUNT "+Constants.WALLET_AMOUNT);
        //binding.availableCreditText.setText(getResources().getString(R.string.currency)+" " + Constants.WALLET_AMOUNT+"--");
     /*   int d=Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(Constants.WALLET_AMOUNT))));
       // int d=Integer.parseInt(Constants.WALLET_AMOUNT);
        if(d<1){
            binding.availableCreditText.setText(" 0");
        }else {
            binding.availableCreditText.setText(" "+d);
        }*/
        viewModel.passengerLedgersRequest(userData.getUserId());
        viewModel.passengerLedgersRepose().observe(requireActivity(), dataModelObject -> {

            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                Log.v("onResumePay ", "TotalBalance frag " + dataModelObject.getData().getTotalBalance());
                MainApp.getInstance().getOylaWallet().passengerLedgers(dataModelObject.getData().getTotalBalance());
                int d=Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(dataModelObject.getData().getTotalBalance()))));
                // int d=Integer.parseInt(Constants.WALLET_AMOUNT);
                if(d<1){
                    binding.availableCreditText.setText(" 0");
                }else {
                    binding.availableCreditText.setText(" "+d);
                }
            } else {
                if (dataModelObject.getError().getMessage() != null) {
                    //showToast(MapActivity.this, dataModelObject.getError().getMessage());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                } else if (dataModelObject.getError().getMessages() != null) {
                    //showToast(MapActivity.this, dataModelObject.getError().getMessages().toString());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                }
            }
        });
    }

/*    @Override
    public void passengerLedgers(String data) {
        Log.v("passengerLedgers","passengerLedgers Frag "+data);
        Constants.WALLET_AMOUNT=data;
       // binding.availableCreditText.setText(Constants.WALLET_AMOUNT+"--");
       // binding.availableCreditText.setText(data+"----");
    }*/


    private void discountDialog() {
        final int[] error_count = {0};
        final Dialog dialog = new Dialog(getActivity(), R.style.full_screen_dialog);
        //final Dialog dialog = new Dialog(AddCreditActivity.this);
        //dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.add_promo_dialog);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);

        EditText enterVoucherEdiText = dialog.findViewById(R.id.enterPromoEdiText);
        TextInputLayout enterVoucherTextInput = dialog.findViewById(R.id.enterPromoTextInput);
        dialog.findViewById(R.id.cancelButton).setOnClickListener(v -> dialog.dismiss());

        dialog.findViewById(R.id.activateCode).setOnClickListener(V -> {
            error_count[0] = 1;
            if (enterVoucherEdiText.getText().toString().isEmpty()) {
                showError(Messages.EmptyMessage, enterVoucherTextInput, enterVoucherEdiText);
                // userData.setUserPassword(null);
                return;
            }else {
                viewModel.promoRequest(enterVoucherEdiText.getText().toString().trim());
                ((BaseActivity) requireActivity()).startLoader();
                viewModel.promoRepose().observe(getActivity(), dataModelObject -> {
                    ((BaseActivity) getActivity()).stopLoader();
                            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                                Toast.makeText(getActivity(),"Promo Activate Success fully",Toast.LENGTH_SHORT).show();
                            }else {
                                if (dataModelObject.getError().getMessage() != null) {
                                    Toast.makeText(getActivity(), dataModelObject.getError().getMessage(),Toast.LENGTH_SHORT).show();
                                  //  showToast(MapActivity.this, dataModelObject.getError().getMessage());
                                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                                } else if (dataModelObject.getError().getMessages() != null) {
                                    //showToast(MapActivity.this, dataModelObject.getError().getMessages().toString());
                                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                                }
                            }
                    dialog.dismiss();
                });
            }
        });
        enterVoucherEdiText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s != null) {
                    removeError(enterVoucherTextInput);
                }
                Log.v("countcount", "count " + count);
            }
            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        if (!(requireActivity()).isFinishing()) {
            //show dialog
            dialog.show();
        }

        Window window = dialog.getWindow();
        assert window != null;
        //window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        //window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setGravity(Gravity.BOTTOM);
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    public void showError(String str, TextInputLayout inputLayout, EditText editText) {
        inputLayout.setError(str);
        editText.requestFocus();
    }


    public void removeError(TextInputLayout inputLayout) {
        inputLayout.setError(null);
        inputLayout.setErrorEnabled(false);
    }
}
