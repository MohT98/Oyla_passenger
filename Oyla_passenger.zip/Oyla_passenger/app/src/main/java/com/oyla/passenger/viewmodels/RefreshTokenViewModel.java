package com.oyla.passenger.viewmodels;

import android.app.Application;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;

import com.oyla.passenger.Repository.JsonRepository;
import com.oyla.passenger.datamodels.jsonreponsedatamodel.DataModelObject;

public class RefreshTokenViewModel extends SharedViewModel{

    private MutableLiveData<DataModelObject> mutableLiveData;
    private JsonRepository repository;

    public RefreshTokenViewModel(@NonNull Application application) {
        super(application);
    }
    public void sendRefreshTokenRequest(String user_id) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.refreshToken(user_id);
    }

    public MutableLiveData<DataModelObject> receiveRefreshTokenRepose() {
        return mutableLiveData;
    }

    public void bookingStatusRequest(String user_id) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.checkBookingStatus(user_id);
    }

    public MutableLiveData<DataModelObject>bookingStatusRepose() {
        return mutableLiveData;
    }

}