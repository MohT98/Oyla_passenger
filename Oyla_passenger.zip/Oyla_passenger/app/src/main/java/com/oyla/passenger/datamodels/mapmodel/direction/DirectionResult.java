package com.oyla.passenger.datamodels.mapmodel.direction;

import com.google.gson.annotations.SerializedName;
import com.oyla.passenger.datamodels.mapmodel.direction.location.Route;

import java.util.List;

public class DirectionResult {
    @SerializedName("routes")
    private List<Route> routes;

    public List<Route> getRoutes() {
        return routes;
    }
}
