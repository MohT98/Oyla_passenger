package com.oyla.passenger.datamodels;

public class UpdateMobPostData {
    String user_id;
    String mobile_no;
    String network;
    String otp_code;

    public UpdateMobPostData(String user_id, String mobile_no, String network, String otp_code) {
        this.user_id = user_id;
        this.mobile_no = mobile_no;
        this.network = network;
        this.otp_code = otp_code;
    }
}
