package com.oyla.passenger.datamodels.chat;

import android.os.Parcel;
import android.os.Parcelable;

public class ChatDataModel implements Parcelable {

    private String booking_id;
    private String receiver_id;
    private String sender_id;
    private String message;
    private long messageTime;
    private String type;

    public ChatDataModel(){

    }
    public ChatDataModel(String booking_id, String receiver_id, String sender_id, String message, long messageTime, String type) {
        this.booking_id = booking_id;
        this.receiver_id = receiver_id;
        this.sender_id = sender_id;
        this.message = message;
        this.messageTime = messageTime;
        this.type = type;
    }

    public ChatDataModel(String booking_id,  String message, long messageTime, String type) {
        this.booking_id = booking_id;
        this.message = message;
        this.messageTime = messageTime;
        this.type = type;
    }

    public String getBooking_id() {
        return booking_id;
    }

    public void setBooking_id(String booking_id) {
        this.booking_id = booking_id;
    }

    public String getReceiver_id() {
        return receiver_id;
    }

    public void setReceiver_id(String receiver_id) {
        this.receiver_id = receiver_id;
    }

    public String getSender_id() {
        return sender_id;
    }

    public void setSender_id(String sender_id) {
        this.sender_id = sender_id;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public long getMessageTime() {
        return messageTime;
    }

    public void setMessageTime(long messageTime) {
        this.messageTime = messageTime;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public static Creator<ChatDataModel> getCREATOR() {
        return CREATOR;
    }

    protected ChatDataModel(Parcel in) {
        booking_id = in.readString();
        receiver_id = in.readString();
        sender_id = in.readString();
        message = in.readString();
        messageTime = in.readLong();
        type = in.readString();
    }

    public static final Creator<ChatDataModel> CREATOR = new Creator<ChatDataModel>() {
        @Override
        public ChatDataModel createFromParcel(Parcel in) {
            return new ChatDataModel(in);
        }

        @Override
        public ChatDataModel[] newArray(int size) {
            return new ChatDataModel[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(booking_id);
        dest.writeString(receiver_id);
        dest.writeString(sender_id);
        dest.writeString(message);
        dest.writeLong(messageTime);
        dest.writeString(type);
    }

    @Override
    public String toString() {
        return "ChatDataModel{" +
                "booking_id='" + booking_id + '\'' +
                ", receiver_id='" + receiver_id + '\'' +
                ", sender_id='" + sender_id + '\'' +
                ", message='" + message + '\'' +
                ", messageTime=" + messageTime +
                ", type='" + type + '\'' +
                '}';
    }
}
