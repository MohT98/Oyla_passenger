package com.oyla.passenger.datamodels;

import android.os.Parcel;
import android.os.Parcelable;

public class DashboardContentData implements Parcelable {
    private String id;
    private String module_name;
    private String image_url;
    private String serial_no;
    private String status;

    public String getId() {
        return id;
    }

    public String getModule_name() {
        return module_name;
    }

    public String getImage_url() {
        return image_url;
    }

    public String getSerial_no() {
        return serial_no;
    }

    public String getStatus() {
        return status;
    }

    protected DashboardContentData(Parcel in) {
        id = in.readString();
        module_name = in.readString();
        image_url = in.readString();
        serial_no = in.readString();
        status = in.readString();
    }

    public static final Creator<DashboardContentData> CREATOR = new Creator<DashboardContentData>() {
        @Override
        public DashboardContentData createFromParcel(Parcel in) {
            return new DashboardContentData(in);
        }

        @Override
        public DashboardContentData[] newArray(int size) {
            return new DashboardContentData[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(module_name);
        dest.writeString(image_url);
        dest.writeString(serial_no);
        dest.writeString(status);
    }
}
