package com.oyla.passenger.viewmodels;

import android.app.Application;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;

import com.oyla.passenger.Repository.JsonRepository;
import com.oyla.passenger.datamodels.jsonreponsedatamodel.DataModelObject;

public class WebPageViewModel extends SharedViewModel {

    private MutableLiveData<DataModelObject> mutableLiveData;
    private JsonRepository repository;

    public WebPageViewModel(@NonNull Application application) {
        super(application);
    }

    public void webPageRequest(String page ,String type) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.webPage(page,type);
    }

    public MutableLiveData<DataModelObject> webPageRepose() {
        return mutableLiveData;
    }
}
