package com.oyla.passenger.datamodels.historydata;

import android.os.Parcel;
import android.os.Parcelable;

public class TransactionHistoryData implements Parcelable {
    String id ;
    String passenger_id;
    String booking_id;
    String type;
    String amount;
    String payment_type;
    String extra_amount;
    String description;
    String currency;
    String created_at;
    String updated_at;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPassenger_id() {
        return passenger_id;
    }

    public void setPassenger_id(String passenger_id) {
        this.passenger_id = passenger_id;
    }

    public String getBooking_id() {
        return booking_id;
    }

    public void setBooking_id(String booking_id) {
        this.booking_id = booking_id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getPayment_type() {
        return payment_type;
    }

    public void setPayment_type(String payment_type) {
        this.payment_type = payment_type;
    }

    public String getExtra_amount() {
        return extra_amount;
    }

    public void setExtra_amount(String extra_amount) {
        this.extra_amount = extra_amount;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(String updated_at) {
        this.updated_at = updated_at;
    }

    public static Creator<TransactionHistoryData> getCREATOR() {
        return CREATOR;
    }

    protected TransactionHistoryData(Parcel in) {
        id = in.readString();
        passenger_id = in.readString();
        booking_id = in.readString();
        type = in.readString();
        amount = in.readString();
        payment_type = in.readString();
        extra_amount = in.readString();
        description = in.readString();
        currency = in.readString();
        created_at = in.readString();
        updated_at = in.readString();
    }

    public static final Creator<TransactionHistoryData> CREATOR = new Creator<TransactionHistoryData>() {
        @Override
        public TransactionHistoryData createFromParcel(Parcel in) {
            return new TransactionHistoryData(in);
        }

        @Override
        public TransactionHistoryData[] newArray(int size) {
            return new TransactionHistoryData[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(passenger_id);
        dest.writeString(booking_id);
        dest.writeString(type);
        dest.writeString(amount);
        dest.writeString(payment_type);
        dest.writeString(extra_amount);
        dest.writeString(description);
        dest.writeString(currency);
        dest.writeString(created_at);
        dest.writeString(updated_at);
    }
}
