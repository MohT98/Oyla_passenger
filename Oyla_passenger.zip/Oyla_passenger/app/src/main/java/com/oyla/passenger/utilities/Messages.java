package com.oyla.passenger.utilities;

public class Messages {

    //region Validation Messages
    public static final String EmptyMessage = "This field is required.";
    public static final String passwordShortMessage = "Password should be at least 8 characters long";
    public static final String userNameShortMessage = "Name should be at least 3 characters long";
    public static final String emailValidMessage = "Enter valid email address";
    public static final String phoneNumberValidMessage = "Number should be at least 10 characters long";
    public static final String phoneNumberValidMessage2 = "Number should be at least 11 characters long";
    public static final String cnicMessage = "Enter last 6 digit of CNIC";

    //endregion

    //region Error Messages
/*    public static final String seriesErrorMessage = "Please select a series.";
    public static final String classErrorMessage = "Please select a class.";
    public static final String subjectErrorMessage = "Please select a subject.";
    public static final String termErrorMessage = "Please select a term.";
    public static final String unitErrorMessage = "Please select a unit.";
    public static final String dateErrorMessage = "Please select a date.";
    public static final String NoPaperHtmlFound = "Please wait while loading paper.If it is taking too long contact to your adminstrator.";
    public static final String QueestionChangeError = "Error while changing question.";
    public static final String Error = "Error";
    public static final String FileNotSavedSuccess = "Error occured while downloading file.";
    public static final String OLDNEWSAME = "You have entered new password same as old password.";
    public static final String NetworkError = "Cannot connect to Internet...Please check your connection!";*/
    public static final String ServerError = "Network failure. Please try again after some time!";
   /* public static final String SignOutError = "Sign out Un-Success.";
    public static final String SignInError = "Sign In Un-Success.";*/

    //endregion

    //region Success Messages
   /* public static final String PaperSaveSuccess = "Paper generated successfully.";
    public static final String FileSavedSuccess = "File has been saved to ";
    public static final String GuestSettingsSaveSuccess = "Your settings have been saved successfully.";
    public static final String GuestSettingsSaveError = "Your settings not saved.";
    public static final String SignOutSuccess = "Sign out successfully.";*/
    public static final String SignInSuccess = "Sign In successfully.";
   /* public static final String GuestSignUPMessageError = "Error while creating account.";
    public static final String OrderSaveError = "Error while placing request.";
    public static final String OrderSaveSuccess = "Request has been placed successfully";*/
    //endregion

    public static final String partnerReached="Partner Reached at your location: ";
    public static final String partnerSelected="Partner On the way: ";
    public static final String partnerBusy="Partner arrive soon after finish ride: ";
    public static final String rideStarted="Moving toward destination: ";
    public static final String rideCompleted="Ride has completed: ";

    public static final String WALLET_MESSAGE = "Your wallet amount is not sufficient to use in this ride";

}
