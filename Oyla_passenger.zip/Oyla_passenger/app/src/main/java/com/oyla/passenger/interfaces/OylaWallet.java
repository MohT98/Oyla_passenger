package com.oyla.passenger.interfaces;

public interface OylaWallet {
    void passengerLedgers(String data);
}
