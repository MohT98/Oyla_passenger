package com.oyla.passenger.datamodels;

public class DummyDistanceTracker {
    private double lat;
    private double lng;

    public DummyDistanceTracker(double lat, double lng) {
        this.lat = lat;
        this.lng = lng;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLng() {
        return lng;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }
}
