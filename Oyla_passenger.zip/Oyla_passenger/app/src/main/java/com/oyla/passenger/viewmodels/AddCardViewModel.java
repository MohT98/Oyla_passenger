package com.oyla.passenger.viewmodels;

import android.app.Application;
import android.text.Editable;
import android.text.TextWatcher;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;

public class AddCardViewModel extends SharedViewModel {
    private MutableLiveData<String> CardDate = new MutableLiveData<>();

    public AddCardViewModel(@NonNull Application application) {
        super(application);
    }

    public MutableLiveData<String> getCardDate() {
        if (CardDate == null) {
            CardDate = new MutableLiveData<>();
        }
        return CardDate;
    }


    public TextWatcher onDateChanged = new TextWatcher() {

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {


        }

        @Override
        public void afterTextChanged(Editable s) {
            CardDate.setValue(s.toString());

        }
    };
}
