package com.oyla.passenger.ui.activity.reward;

import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.oyla.passenger.R;
import com.oyla.passenger.adapter.RewardListAdapter;
import com.oyla.passenger.databinding.ActivityRewardListBinding;
import com.oyla.passenger.datamodels.redeemdata.RedeemListData;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.viewmodels.RewardViewModel;

import java.util.List;

public class RewardListActivity extends BaseActivity {

    private RewardViewModel viewModel;
    ActivityRewardListBinding binding;
    List<RedeemListData> rewardItems;
    private RewardListAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // setContentView(R.layout.activity_reward_list);
        binding = setContentView(this, R.layout.activity_reward_list);
        viewModel = new ViewModelProvider(RewardListActivity.this).get(RewardViewModel.class);
        hideAppBar(this);
        binding.onBack.setOnClickListener(v -> onBackPressed());

        // ArrayList<TransactionHistoryData> transactionItems = new ArrayList<TransactionHistoryData>();
        binding.recyclerView.setHasFixedSize(true);
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerView.setItemAnimator(new DefaultItemAnimator());


    }

    @Override
    protected void onResume() {
        super.onResume();

        viewModel.rewardListRequest();
        startLoader();
        viewModel.rewardListRepose().observe(RewardListActivity.this, dataModelObject -> {
            stopLoader();
            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                Log.v("TotalPoints", "TotalPoints frag " + dataModelObject.getData().getRedeemAward().get(0).getDescription());
                rewardItems=dataModelObject.getData().getRedeemAward();
                mAdapter = new RewardListAdapter(this, rewardItems);
                binding.recyclerView.setAdapter(mAdapter);
                mAdapter.setOnItemClickListener(position -> {
                    Intent intent = new Intent(RewardListActivity.this, RewardDetailActivity.class);
                    intent.putExtra("Item", rewardItems.get(position));
                    startActivity(intent);
                });
            } else {
                if (dataModelObject.getError().getMessage() != null) {
                    //showToast(MapActivity.this, dataModelObject.getError().getMessage());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                } else if (dataModelObject.getError().getMessages() != null) {
                    //showToast(MapActivity.this, dataModelObject.getError().getMessages().toString());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                }
            }
        });
    }
}