package com.oyla.passenger.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.oyla.passenger.MainApp;
import com.oyla.passenger.ui.activity.dahsboard.DashBoardActivity;
import com.oyla.passenger.utilities.DialogBoxSingleton;
import com.oyla.passenger.R;
import com.oyla.passenger.databinding.ActivityLoginOptionBinding;
import com.oyla.passenger.services.LatestFirebaseMessagingService;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.ui.activity.authentication.SignInActivity;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.SharedPrefManager;
import com.oyla.passenger.viewmodels.LoginOptionViewModel;

import org.json.JSONException;

import java.util.Arrays;

import static com.oyla.passenger.utilities.Constants.F_SIGN_IN;
import static com.oyla.passenger.utilities.Constants.G_SIGN_IN;
import static com.oyla.passenger.utilities.Constants.RC_SIGN_IN;
import static com.oyla.passenger.utilities.Constants.Token;
import static com.oyla.passenger.utilities.Constants.firebaseAuth;
import static com.oyla.passenger.utilities.Constants.googleSignInClient;


public class LoginOptionActivity extends BaseActivity {
    private ActivityLoginOptionBinding binding;
    String countryCode = "";
    CallbackManager callbackManager;
    LoginButton loginButton;
    private LoginOptionViewModel viewModel;
    private String value = "0";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_continue_option);
        binding = setContentView(this, R.layout.activity_login_option);
        hideAppBar(this);
        hideStatusBar(this);
        viewModel = new ViewModelProvider(this).get(LoginOptionViewModel.class);
        countryCode = getIntent().getStringExtra("countryCode");
        if (countryCode.equalsIgnoreCase("pk")) {
            binding.continueMobile.customButtonText.setText(getResources().getString(R.string.continue_mobile));
            binding.fbLoginButton.setVisibility(View.GONE);
            binding.googleLoginButton.setVisibility(View.GONE);
            LinearLayout.LayoutParams param = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    1.0f
            );
            binding.continueLayout.setLayoutParams(param);

        } else {
            binding.continueMobile.customButtonText.setText(getResources().getString(R.string.continue_email));
        }

        binding.continueMobile.customButtonText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);

        binding.continueMobile.button.setOnClickListener(view -> {
            if (agreementCheck()) {
                Intent i = new Intent(LoginOptionActivity.this, SignInActivity.class);
                // Intent i = new Intent(LoginOptionActivity.this, DashBoardActivity.class);
                Constants.G_SIGN_IN = false;
                i.putExtra("countryCode", countryCode);
                startActivity(i);
                finish();
            }

        });
        binding.fbLoginButton.setOnClickListener(view -> {
            if (agreementCheck()) {
                fbRegister();
            }

        });
        binding.googleLoginButton.setOnClickListener(view -> {

            // Configure sign-in to request the user's ID, email address, and basic
            // profile. ID and basic profile are included in DEFAULT_SIGN_IN.
            //startLoader();
            if (agreementCheck()) {
                googleSignIn();
            }

        });
        configureGoogleClient();
        callbackManager = CallbackManager.Factory.create();

        binding.privacyPolicy.setOnClickListener(v -> {
            Intent i = new Intent(LoginOptionActivity.this, WebPageActivity.class);
            i.putExtra("pageName", "privacy_poilicy");
            startActivity(i);
        });

    }

    private boolean agreementCheck() {
        if (!binding.checkBox.isChecked()) {
            showToastMessage(getString(R.string.term_condition_continue));
            //Toast toast = Toast.makeText(LoginOptionActivity.this,getString(R.string.term_condition_continue),Toast.LENGTH_LONG);
            //toast.setGravity(Gravity.BOTTOM,0,50);
            // toast.show();
            binding.checkBox.requestFocus();
            return false;
        } else return true;
    }

    private void fbRegister() {
        LoginManager.getInstance().logInWithReadPermissions(this, Arrays.asList("email", "public_profile"));
        // LoginManager.getInstance().logInWithPublishPermissions(this, Arrays.asList("publish_actions"));
        LoginManager.getInstance().registerCallback(callbackManager,
                new FacebookCallback<LoginResult>() {
                    @Override
                    public void onSuccess(LoginResult loginResult) {
                        // App code
                        Log.w("fbRegister", "onSuccess");
                        getUserProfile(loginResult.getAccessToken());
                    }
                    @Override
                    public void onCancel() {
                        // App code
                        Log.w("fbRegister", "onCancel");
                    }
                    @Override
                    public void onError(FacebookException exception) {
                        Log.w("fbRegister", "exception " + exception);
                        // App code
                    }
                });
    }

    private void getUserProfile(AccessToken currentAccessToken) {
        GraphRequest request = GraphRequest.newMeRequest(
                currentAccessToken, (object, response) -> {
                    Log.d("fbRegister", "JSONObject " + object.toString());
                    try {
                        Constants.facebookObject = object;
                        String first_name = object.getString("first_name");
                        String last_name = object.getString("last_name");
                        String email = object.getString("email");
                        String id = object.getString("id");
                        Log.v("fbRegister", "first_name " + first_name);
                        Log.v("fbRegister", "email " + email);
                        String image_url = "https://graph.facebook.com/" + id + "/picture?type=normal";
                        Constants.G_SIGN_IN = true;
                        Constants.F_SIGN_IN = true;
                        LoginManager.getInstance().logOut();
                      /*  Intent i = new Intent(LoginOptionActivity.this, SignInActivity.class);
                        i.putExtra("countryCode",countryCode);
                        startActivity(i);
                        finish();*/
                        registerSocialInfo(first_name, email, "facebook");
                        // txtUsername.setText("First Name: " + first_name + "\nLast Name: " + last_name);
                        //  txtEmail.setText(email);
                        // Picasso.with(MainActivity.this).load(image_url).into(imageView);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                });
        Bundle parameters = new Bundle();
        parameters.putString("fields", "first_name,last_name,email,id");
        request.setParameters(parameters);
        request.executeAsync();
    }

    private void googleSignIn() {
        Intent signInIntent = googleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                Constants.G_SIGN_IN = true;
                // Google Sign In was successful, authenticate with Firebase
                GoogleSignInAccount account = task.getResult(ApiException.class);
                // showToastMessage("Google Sign in Succeeded");
                Log.w("GoogleSign", "Google Sign in Succeeded");
                firebaseAuthWithGoogle(account);
            } catch (ApiException e) {
                // Google Sign In failed, update UI appropriately
                Log.w("GoogleSign", "Google sign in failed", e);
                /*showToastMessage("Google Sign in Failed " + e);*/
                //showToastMessage("Google Sign in Failed ");
            }
        } else {
            callbackManager.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void firebaseAuthWithGoogle(GoogleSignInAccount account) {
        Log.d("GoogleSign", "firebaseAuthWithGoogle:" + account.getId());
        AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(), null);
        firebaseAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            FirebaseUser user = firebaseAuth.getCurrentUser();
                            Log.d("GoogleSign", "signInWithCredential:success: currentUser: " + user.getEmail());
                            // showToastMessage("Firebase Authentication Succeeded ");
                            //stopLoader();
                            launchMainActivity(user);
                        } else {
                            //stopLoader();
                            // If sign in fails, display a message to the user.
                            Log.w("GoogleSign", "signInWithCredential:failure", task.getException());
                            //  showToastMessage("Firebase Authentication failed:" + task.getException());
                            showToastMessage(" Authentication failed:");
                        }
                    }
                });
    }

    private void showToastMessage(String message) {
        Toast.makeText(LoginOptionActivity.this, message, Toast.LENGTH_LONG).show();
    }

    private void launchMainActivity(FirebaseUser user) {
        if (user != null) {
         /*   Intent i = new Intent(LoginOptionActivity.this, SignInActivity.class);
            i.putExtra("countryCode",countryCode);
            startActivity(i);
            finish();*/
            registerSocialInfo(user.getDisplayName(), user.getEmail(), "google");
        }
    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent(LoginOptionActivity.this, SelectCountryActivity.class);
        startActivity(i);
        finish();
        super.onBackPressed();
    }

  /*  public static String printKeyHash(Activity context) {
        PackageInfo packageInfo;
        String key = null;
        try {
            //getting application package name, as defined in manifest
            String packageName = context.getApplicationContext().getPackageName();

            //Retriving package info
            packageInfo = context.getPackageManager().getPackageInfo(packageName,
                    PackageManager.GET_SIGNATURES);

            Log.e("Package Name=", context.getApplicationContext().getPackageName());

            for (Signature signature : packageInfo.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                key = new String(Base64.encode(md.digest(), 0));

                // String key = new String(Base64.encodeBytes(md.digest()));
                Log.e("KeyHash=", key);
            }
        } catch (PackageManager.NameNotFoundException e1) {
            Log.e("Name not found", e1.toString());
        }
        catch (NoSuchAlgorithmException e) {
            Log.e("No such an algorithm", e.toString());
        } catch (Exception e) {
            Log.e("Exception", e.toString());
        }

        return key;
    }*/

    private void registerSocialInfo(String name, String email, String provider) {
        startLoader();
        viewModel.registerSocial(
                Constants.type, value,
                email,
                name, "_", provider,
                LatestFirebaseMessagingService.getToken(this), Constants.referral_code);
        // showToast(SignInActivity.this,"Wait for user verification");
        registerSocialApiRepose();
    }

    private void registerSocialApiRepose() {
        Log.v("registerSocialApiRepose", "mobApiResponse");
        viewModel.registerSocialRepose().observe(this, dataModelObject -> {
            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                //stopLoader();
                Token = dataModelObject.getAccessToken();
                //userId = dataModelObject.getData().getUser().getUserId();
                Log.v("registerSocialApiRepose", "dataModelObject " + dataModelObject.getData().getUser());
                //Log.v("onChanged", "Mob number " + dataModelObject.getData().getUser().getUserMobNumber());
                //Log.v("onChanged", "User Id " + dataModelObject.getData().getUser().getUserId());
                if (dataModelObject.getData().getUser() != null) {

                /*    showToast(SignInActivity.this, Messages.SignInSuccess);
                    MainApp.getInstance().setUserData(dataModelObject.getData().getUser());
                    SharedPrefManager.getInstance(SignInActivity.this).
                            userInfo(
                                    dataModelObject.getData().getUser().getUserId(), dataModelObject.getAccessToken()
                            );*/
                  /*  SharedPrefManager.getInstance(SignInActivity.this).
                            userProfile(
                                    dataModelObject.getData().getUser().getUserId(),
                                    dataModelObject.getData().getUser().getUserFirstName(),
                                    dataModelObject.getData().getUser().getUserLastName(),
                                    dataModelObject.getData().getUser().getUserEmail(),
                                    dataModelObject.getData().getUser().getUserMobNumber(),
                                    dataModelObject.getData().getUser().getProfilePic(),
                                    dataModelObject.getData().getUser().getIsVERIFIED(),
                                    "-", "-", "-",
                                    dataModelObject.getAccessToken()
                            );*/
                    SharedPrefManager.getInstance(LoginOptionActivity.this).setSocialFlag(true);

                    googleSignOut();
                    stopLoader();
                    G_SIGN_IN = false;
                    F_SIGN_IN = false;
                    Constants.SOCIAL = true;
                    Constants.LOGIN_SUCCESS = true;
                    Constants.SING_IN_FIRST = true;
                    //Intent i = new Intent(SignInActivity.this, DashBoardActivity.class);

                    MainApp.getInstance().setUserData(dataModelObject.getData().getUser());
                    SharedPrefManager.getInstance(LoginOptionActivity.this).
                            userInfo(dataModelObject.getData().getUser().getUserId(), dataModelObject.getAccessToken());
                    Intent i = new Intent(LoginOptionActivity.this, DashBoardActivity.class);
                    startActivity(i);
                    finish();

                } else {
                    stopLoader();
                    googleSignOut();
                    // showToast(SignInActivity.this, "Unable to SignIn");
                   /* if(dataModelObject.getError().getMessage()!=null){
                        showToast(SignInActivity.this, dataModelObject.getError().getMessage());
                    }else {
                        showToast(SignInActivity.this, dataModelObject.getError().getMessages().toString());
                    }*/

                }


            } else {
                stopLoader();
                googleSignOut();
                /*  showToast(SignInActivity.this, dataModelObject.getError().getMessage().toString());*/
                // showToast(SignInActivity.this, "Unable to SignIn");
                DialogBoxSingleton.getInstance().showErrorPopup(LoginOptionActivity.this, dataModelObject.getError());
                if (dataModelObject.getError().getMessage() != null) {
                    // showToast(SignInActivity.this, dataModelObject.getError().getMessage());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                } else if (dataModelObject.getError().getMessages() != null) {
                    //showToast(SignInActivity.this, dataModelObject.getError().getMessages().toString());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                }
            }

        });
    }

    private void googleSignOut() {
        // Firebase sign out
        Constants.firebaseAuth.signOut();
        G_SIGN_IN = false;
        // Google sign out

        Constants.googleSignInClient.signOut().addOnCompleteListener(this,
                task -> {
                    // Google Sign In failed, update UI appropriately
                    Log.w("GoogleSign", "Signed out of google");
                });
    }

}