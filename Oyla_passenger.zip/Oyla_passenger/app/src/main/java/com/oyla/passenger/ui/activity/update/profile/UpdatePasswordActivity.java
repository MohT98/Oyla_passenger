package com.oyla.passenger.ui.activity.update.profile;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;

import androidx.lifecycle.ViewModelProvider;

import com.oyla.passenger.R;
import com.oyla.passenger.databinding.ActivityUpdatePasswordBinding;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.utilities.Messages;
import com.oyla.passenger.viewmodels.UpdateProfileViewModel;

public class UpdatePasswordActivity extends BaseActivity {
    private ActivityUpdatePasswordBinding binding;
    private Activity activity;
    private UpdateProfileViewModel viewModel;
    int errorCount=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        activity=UpdatePasswordActivity.this;
       // setContentView(R.layout.activity_update_password);
        binding = setContentView(this, R.layout.activity_update_password);
        viewModel = new ViewModelProvider(this).get(UpdateProfileViewModel.class);
        binding.setViewModel(viewModel);

        hideAppBar(this);
        binding.updateButtons.customButtonText.setText(getResources().getString(R.string.update_text));

        viewModel.getCurrentPassword().observe(this, s -> {
            if (s != null) {
                removeError(binding.currentPasswordTextInput);
                if (TextUtils.isEmpty(s)) {
                    showError(Messages.EmptyMessage, binding.currentPasswordTextInput, binding.currentPasswordEditText);
                   // userData.setUserPassword(null);
                } else if (viewModel.validatePassword(s)) {
                    if (errorCount > 0) {
                        showError(Messages.passwordShortMessage, binding.currentPasswordTextInput, binding.currentPasswordEditText);
                    }
                   // userData.setUserPassword(s);
                } else {
                    //userData.setUserPassword(s);

                }
            } else {
                showError(Messages.EmptyMessage, binding.currentPasswordTextInput, binding.currentPasswordEditText);
               // userData.setUserPassword(null);
            }
        });

        viewModel.getConfirmPassword().observe(this, s -> {
            if (s != null) {
                removeError(binding.rePasswordTextInput);
                if (TextUtils.isEmpty(s)) {
                    showError(Messages.EmptyMessage, binding.rePasswordTextInput, binding.rePasswordEditText);
                    // userData.setUserPassword(null);
                } else if (viewModel.validatePassword(s)) {
                    if (errorCount > 0) {
                        showError(Messages.passwordShortMessage, binding.rePasswordTextInput, binding.rePasswordEditText);
                    }
                    // userData.setUserPassword(s);
                } else {
                    //userData.setUserPassword(s);

                }
            } else {
                showError(Messages.EmptyMessage, binding.rePasswordTextInput, binding.rePasswordEditText);
                // userData.setUserPassword(null);
            }
        });

        viewModel.getNewPassword().observe(this, s -> {
            if (s != null) {
                removeError(binding.newPasswordTextInput);
                if (TextUtils.isEmpty(s)) {
                    showError(Messages.EmptyMessage, binding.newPasswordTextInput, binding.newPasswordEditText);
                    // userData.setUserPassword(null);
                } else if (viewModel.validatePassword(s)) {
                    if (errorCount > 0) {
                        showError(Messages.passwordShortMessage, binding.newPasswordTextInput, binding.newPasswordEditText);
                    }
                    // userData.setUserPassword(s);
                } else {
                    //userData.setUserPassword(s);

                }
            } else {
                showError(Messages.EmptyMessage, binding.newPasswordTextInput, binding.newPasswordEditText);
                // userData.setUserPassword(null);
            }
        });


        binding.onBack.setOnClickListener(v -> onBackPressed());
        binding.updateButtons.button.setOnClickListener(v -> {
            errorCount = 1;
           /* if (TextUtils.isEmpty(Objects.requireNonNull(binding.currentPasswordEditText.getText()).toString())) {
                showError(Messages.EmptyMessage, binding.currentPasswordTextInput, binding.currentPasswordEditText);
                return;
            } else if (TextUtils.isEmpty(Objects.requireNonNull(binding.currentPasswordEditText.getText()).toString())) {
                showError(Messages.passwordShortMessage, binding.currentPasswordTextInput, binding.currentPasswordEditText);
                return;
            }*/
        });
    }


}