package com.oyla.passenger.ui.activity.cabbooking;

import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;

import android.Manifest;
import android.animation.LayoutTransition;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.maps.GeoApiContext;
import com.google.maps.internal.PolylineEncoding;
import com.oyla.passenger.BroadcastReceiver.Restarter;
import com.oyla.passenger.MainApp;
import com.oyla.passenger.R;
import com.oyla.passenger.databinding.ActivityTrackingBinding;
import com.oyla.passenger.datamodels.CheckBookingStatusData;
import com.oyla.passenger.datamodels.chat.BookingFCM;
import com.oyla.passenger.datamodels.chat.ChatDataModel;
import com.oyla.passenger.datamodels.jsonreponsedatamodel.DataList;
import com.oyla.passenger.datamodels.FireBaseDataModelObject;
import com.oyla.passenger.datamodels.mapmodel.direction.DirectionResult;
import com.oyla.passenger.datamodels.tracking.FirebaseTracking;
import com.oyla.passenger.datamodels.usermodel.DriverCoordinate;
import com.oyla.passenger.datamodels.usermodel.UserData;
import com.oyla.passenger.interfaces.BookingStatusInterface;
import com.oyla.passenger.interfaces.ChatMessageCallBacks;
import com.oyla.passenger.interfaces.OnCaptainFind;
import com.oyla.passenger.interfaces.SearchLocation;
import com.oyla.passenger.interfaces.ServiceCallbacks;
import com.oyla.passenger.services.LatestFirebaseMessagingService;
import com.oyla.passenger.services.RideBookingStatus;
import com.oyla.passenger.services.location.GetDriverCoordinates;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.ui.activity.CaptainReviewActivity;
import com.oyla.passenger.ui.activity.ChatActivity;
import com.oyla.passenger.ui.activity.SearchLocationActivity;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.DialogBoxSingleton;
import com.oyla.passenger.utilities.Messages;
import com.oyla.passenger.utilities.SharedPrefManager;
import com.oyla.passenger.viewmodels.RideViewModel;

import org.jetbrains.annotations.NotNull;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.oyla.passenger.utilities.Constants.DEFAULT_ZOOM;
import static com.oyla.passenger.utilities.Constants.MAP_VIEW_BUNDLE_KEY;
import static com.oyla.passenger.utilities.Constants.defaultLocation;
import static com.oyla.passenger.utilities.Constants.mLocationPermissionGranted;
import static java.lang.Math.cos;
import static java.lang.Math.sin;

public class TrackingActivity extends BaseActivity implements OnMapReadyCallback, View.OnClickListener
        , OnCaptainFind, ServiceCallbacks, SearchLocation, BookingStatusInterface, LocationListener, ChatMessageCallBacks {
    private boolean SHOW_POLYLINE = true;
    private boolean SHOW_FINISH_DIALOG = false;
    private boolean FINISH_DIALOG_VIEW = false;
    private ActivityTrackingBinding binding;
    private String MAP_KEY;
    private GoogleMap mGoogleMap;
    private LatLng startLatLng, centerLatLng, newLatLng;
    private FusedLocationProviderClient mFusedLocationClient;
    private final String TAG = "mapsActivity";
    private Location lastKnownLocation;
    private CheckBookingStatusData bookingStatusData;
    private final ArrayList<LatLng> markerPoints = new ArrayList<>();
    private DataList dataList;
    private boolean RideReceived;
    private RideViewModel viewModel;
    private boolean FINDING_CAPTAIN;
    private boolean ZOOM_ROUTE;
    private String rideCurrentStatusText = "Ride Info:";
    // private String city = "";
    private int SKIP_DROP_OFF = 0;
    private String vehicleType, typeID;
    boolean RIDE_VIEw_FULL = false;
    boolean SELECTED_RIDE = false;
    boolean CONFIRM_RIDE = false;
    boolean RIDE_STARTED = false;//move toward destination
    boolean RIDE_ACCEPTED = false;
    private boolean Driver_Start_Ride;
    private boolean FIND_CAPTAIN_CANCEL = false;
    private boolean AFTER_RIDE_CANCEL = false;
    private boolean Driver_Selected_Ride;
    public static boolean PICK_UP_TRACKING = false;
    private Marker trackerMarker;
    private Marker rideStartMarker;
    private Handler animateMarkerHandler;
    private boolean isAlreadyDoingAnimateMarker;
    private boolean Resume_Ride_Tracking = false;
    private String currentTripDuration = " ";
    private String currentTripTime = " ";
    private LatLng diverLatLng;
    private boolean routeConfirm;
    private Boolean CHANGE_ADDRESS = false;
    private Boolean dropOffAddressBol = false;
    private String currentLat, currentLng;
    private boolean BOOKING_RESPONSE = false;
    private final ArrayList<LatLng> newMarkerPoints = new ArrayList<>();
    private final ArrayList<LatLng> oldMarkerPoints = new ArrayList<>();
    private String trip_one_distance, trip_two_distance, trip_total_distance;
    private String trip_one_price, trip_two_price, total_price;
    private String trip_one_duration, trip_two_duration, trip_total_time;
    private Polyline polyLine = null;
    private List<LatLng> newDecodedPath;
    private boolean isRotating;
    private final Handler mHandlerUI = new Handler(Looper.getMainLooper());
    private double tempLat = 0;
    private double tempLng = 0;
    private String bookingId;
    private DatabaseReference rootDatabaseReference, trackingRef;
    private List<ChatDataModel> chatDataModelsList;
    private int newChatMessageCounter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_tracking);
        MainApp.getInstance().setOnCaptainFind(this);
        MainApp.getInstance().setServiceCallbacks(this);
        MainApp.getInstance().setSearchLocation(this);
        MainApp.getInstance().setBookingStatusInterface(this);
        MainApp.getInstance().setChatMessageCallBacks(this);
        viewModel = new ViewModelProvider(this).get(RideViewModel.class);
        binding = setContentView(this, R.layout.activity_tracking);
        hideAppBar(this);
        MAP_KEY = getString(R.string.maps_api_key);
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        initGoogleMap(savedInstanceState);
        // captainInfoScreen();
        //captainInfoSlider();
        rootDatabaseReference = FirebaseDatabase.getInstance().getReference();
        binding.emergencyIcon.setOnClickListener(v -> {
            // BaseActivity.getInstance().nextActivity(getActivity(), AddCreditActivity.class);
           // binding.emergencyIcon.startAnimation(animBlink);
            DialogBoxSingleton.getInstance().helpLineDialog(TrackingActivity.this, TrackingActivity.this);
            //helpLineDialog();
            // Constants.phoneCall(MapActivity.this);
        });

    }

    private void initGoogleMap(Bundle savedInstanceState) {
        Bundle mapViewBundle = null;
        if (savedInstanceState != null) {
            mapViewBundle = savedInstanceState.getBundle(MAP_VIEW_BUNDLE_KEY);
        }
        binding.mapView.onCreate(mapViewBundle);
        binding.mapView.getMapAsync(this);
        //   if (mGeoApiContext == null) {
        // .apiKey(getString(R.string.maps_api_key))
   /*     GeoApiContext mGeoApiContext = new GeoApiContext.Builder()
                // .apiKey(getString(R.string.maps_api_key))
                .apiKey(MAP_KEY)
                .build();*/
        new GeoApiContext.Builder()
                .apiKey(MAP_KEY)
                .build();
        // }
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        Bundle mapViewBundle = outState.getBundle(MAP_VIEW_BUNDLE_KEY);
        if (mapViewBundle == null) {
            mapViewBundle = new Bundle();
            outState.putBundle(MAP_VIEW_BUNDLE_KEY, mapViewBundle);
        }
        binding.mapView.onSaveInstanceState(mapViewBundle);
    }

    @Override
    public void onMapReady(final GoogleMap map) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        mGoogleMap = map;
        mGoogleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        mGoogleMap.getUiSettings().setZoomControlsEnabled(true);
        mGoogleMap.getUiSettings().setZoomGesturesEnabled(true);
        mGoogleMap.getUiSettings().setCompassEnabled(true);
        // mGoogleMap.setOnPolylineClickListener(this);

        getDeviceLocation();
        updateLocationUI();

        map.setOnCameraIdleListener(() -> {
            centerLatLng = mGoogleMap.getCameraPosition().target;
          //  Log.v("dropOffAddressBol", "address " + getStringAddress(centerLatLng.latitude, centerLatLng.longitude));
            if (dropOffAddressBol) {
                //     binding.dropOffAddressText.setText(getStringAddress(centerLatLng.latitude, centerLatLng.longitude));
                binding.captainInfoLayout.changeAddressText.setText(getStringAddress(centerLatLng.latitude, centerLatLng.longitude));
            }
        });


        Log.v("cameraZoom", "setOnCameraMoveListener: ");
        map.setOnCameraMoveListener(() -> {
            CameraPosition cameraPosition = map.getCameraPosition();
            Log.v("cameraZoom", "Zoom: " + cameraPosition.zoom);
            Constants.TRACK_ZOOM = (int) cameraPosition.zoom;
        });
        if (markerPoints.size() > 0) {
            markerPoints.clear();
        }

        if (bookingStatusData != null && !bookingStatusData.getDriver_status().equalsIgnoreCase("3")) {


            Log.d("bookingStatusData", "bookingStatusData");
            Log.d("bookingStatusData", "bookingStatusData status" + bookingStatusData.getStatus());
            if (bookingStatusData.getStatus().equalsIgnoreCase("1") || bookingStatusData.getStatus().equalsIgnoreCase("0")) {
                RideReceived = true;
                markerPoints.add(new LatLng(
                        Double.parseDouble(bookingStatusData.getPickup_latitude()),
                        Double.parseDouble(bookingStatusData.getPickup_longitude())));

                markerPoints.add(new LatLng(
                        Double.parseDouble(bookingStatusData.getDropoff_latitude()),
                        Double.parseDouble(bookingStatusData.getDropoff_longitude())));
             /*   markerPoints.add(new LatLng(
                        SharedPrefManager.getInstance(TrackingActivity.this).getPickLat(),
                        SharedPrefManager.getInstance(TrackingActivity.this).getPickLng()));
                markerPoints.add(new LatLng(
                        SharedPrefManager.getInstance(TrackingActivity.this).getDropLat(),
                        SharedPrefManager.getInstance(TrackingActivity.this).getDropLng()));*/
                MainApp.getInstance().setPerKM(Double.parseDouble(bookingStatusData.getRate_per_kilometer()));
                MainApp.getInstance().setPerMint(Double.parseDouble(bookingStatusData.getRate_per_minute()));
                MainApp.getInstance().setVehicleRate(Double.parseDouble(bookingStatusData.getVehicle_amount()));
                MainApp.getInstance().setTax_percentage(bookingStatusData.getTax_percentage());
                MainApp.getInstance().setPeak_factor_rate(bookingStatusData.getPeak_factor_rate());
                Log.v("refreshRide", "resumeRideTracking--");

                SHOW_POLYLINE = true;
                BOOKING_RESPONSE = true;
                Constants.FIRE_BASE_NOTIFY = true;
                bookingId = bookingStatusData.getBooking_id();
                Log.v("bookingIdFCM", "bookingId--" + bookingId);

                //chat module
                BookingFCM bookingFCM = new BookingFCM(LatestFirebaseMessagingService.getToken(this));
                rootDatabaseReference.child(bookingId).child("fcm").child("fcm1").setValue(bookingFCM.getFcm1());
                //getChatMessage();
                // resumeRideTracking();
                onResume();
            }
        } else {
            SHOW_FINISH_DIALOG = false;
            RideReceived = false;
            SharedPreferences sharedPreferences2 = TrackingActivity.this.getSharedPreferences("Driver_Info", 0);
            sharedPreferences2.edit().remove("Driver_Info_Object").apply();
            SharedPrefManager.getInstance(TrackingActivity.this).removeBookingInfo();
            Intent i = new Intent(TrackingActivity.this, MapActivity.class);
            startActivity(i);
            finish();
        }
    }

    private void getDeviceLocation() {
        try {
            if (mLocationPermissionGranted) {
                Log.d("getDeviceLocation", "mLocationPermissionGranted");
                if (MainApp.getInstance().getUserLocation() != null) {
                    startLatLng = new LatLng(MainApp.getInstance().getUserLocation().getLocation().getLatitude(), MainApp.getInstance().getUserLocation().getLocation().getLongitude());
                    //mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(startLatLng, DEFAULT_ZOOM));
                    mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(startLatLng, DEFAULT_ZOOM));
                    Log.d("getDeviceLocation", "if");
                } else {
                    Log.d("getDeviceLocation", "else");
                    Task<Location> locationResult = mFusedLocationClient.getLastLocation();
                    locationResult.addOnCompleteListener(this, task -> {
                        if (task.isSuccessful()) {
                            // Set the map's camera position to the current location of the device.
                            lastKnownLocation = task.getResult();
                            if (lastKnownLocation != null) {
                                startLatLng = new LatLng(lastKnownLocation.getLatitude(), lastKnownLocation.getLongitude());
                                /*mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(startLatLng, DEFAULT_ZOOM));*/
                                mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(startLatLng, DEFAULT_ZOOM));
                            }
                            else {
                                Log.d("getDeviceLocation", "lastKnownLocation null");
                                //getLocation();
                                mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
                                checkLocationPermission();
                                //getDeviceLocation();
                            }
                        } else {
                            Log.d("getDeviceLocation", "Current location is null. Using defaults.");
                            Log.e(TAG, "Exception: %s", task.getException());
                            mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultLocation, DEFAULT_ZOOM));
                            mGoogleMap.getUiSettings().setMyLocationButtonEnabled(false);
                        }
                    });
                }
            }
        } catch (SecurityException e) {
            Log.e("getDeviceLocation", "Exception: %s " + e.getMessage(), e);
        }
    }

    private void updateLocationUI() {
        if (mGoogleMap == null) {
            return;
        }
        try {
            if (mLocationPermissionGranted) {
                mGoogleMap.setMyLocationEnabled(false);
                mGoogleMap.getUiSettings().setCompassEnabled(false);
                mGoogleMap.getUiSettings().setMyLocationButtonEnabled(false);
            } else {
                mGoogleMap.setMyLocationEnabled(false);
                mGoogleMap.getUiSettings().setMyLocationButtonEnabled(false);
                mGoogleMap.getUiSettings().setCompassEnabled(false);
                lastKnownLocation = null;
                //getLocationPermission();
            }
        } catch (SecurityException e) {
            Log.e("Exception: %s", Objects.requireNonNull(e.getMessage()));
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        binding.mapView.onStart();
    }

    @Override
    public void onStop() {
        super.onStop();
        binding.mapView.onStop();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        binding.mapView.onLowMemory();
    }

    @Override
    public void onResume() {
        super.onResume();
        // outstandingBalance();
        binding.mapView.onResume();
        bookingStatusData = getIntent().getParcelableExtra("bookingStatusData");
        vehicleType = getIntent().getStringExtra("vehicleType");
        //resetRideFlowTag(false, false, false);
        typeID = getIntent().getStringExtra("typeID");
        Log.v("typeID", "typeID " + typeID);
        Log.v("refreshRide", "FINDING_CAPTAIN " + FINDING_CAPTAIN);
        Log.v("refreshRide", "RideReceived " + RideReceived);
        newChatMessageCounter = Integer.parseInt(getSharedPreferences("newChatMessageCounter", MODE_PRIVATE).getString("messageCounter", "0"));
        Log.v("newChatMessageCounter", "onResume " + newChatMessageCounter);
        if (newChatMessageCounter > 0) {
            binding.captainInfoLayout.chatMessageBadge.setVisibility(View.VISIBLE);
            binding.captainInfoLayout.chatMessageBadge.setText(String.valueOf(newChatMessageCounter));
        } else {
            resetChatbadgeCounter();
        }

       /* driverStatus = getIntent().getStringExtra("driverStatus");
        rideStatus = getIntent().getStringExtra("rideStatus");*/
     /*   m_gpsChangeReceiver = new GpsChangeReceiver();
        this.registerReceiver(m_gpsChangeReceiver, new IntentFilter(LocationManager.PROVIDERS_CHANGED_ACTION));*/
        if (MainApp.getInstance().getUserData() == null || MainApp.getInstance().getUserData().getUserId() == null) {
            Constants.Auth = Constants.Bearer + " " + SharedPrefManager.getInstance(getApplicationContext()).getUserInfo().getAccessToken();
            Log.v("refreshRide", "user model null ");
            UserData userData = SharedPrefManager.getInstance(getApplicationContext()).getUserInfo();
            viewModel.sendRefreshTokenRequest(userData.getUserId());
            startLoader();
            viewModel.receiveRefreshTokenRepose().observe(this, dataModelObject -> {
                stopLoader();
                if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                    MainApp.getInstance().setUserData(dataModelObject.getData().getUser());
                } else {
                    if (dataModelObject.getError().getMessage() != null) {
                        // showToast(SettingActivity.this, dataModelObject.getError().getMessage());
                        Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                    } else if (dataModelObject.getError().getMessages() != null) {
                        // showToast(SettingActivity.this, dataModelObject.getError().getMessages().toString());
                        Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                    }
                }
                onResume();
            });
        } else {
            refreshTracking();
        }
    }

    @Override
    public void onClick(View v) {

    }

    @Override
    public void getBookingStatus() {
        refreshTracking();
    }

    @Override
    public void onRideRecieved(String json) {
        runOnUiThread(() -> {
            stopLoader();
            FINDING_CAPTAIN = false;
            rideInfoFromSharedPreferences(json);
        });
    }

    private void rideInfoFromSharedPreferences(String json) {
        if (json != null) {
            SharedPreferences sharedPreferences = TrackingActivity.this.getSharedPreferences("Driver_Info", 0);
            String json2, Status, notificationType;
            json2 = sharedPreferences.getString("Driver_Info_Object", "");
            Gson gson = new Gson();
            FireBaseDataModelObject fireBaseDataModelObject = gson.fromJson(json2, FireBaseDataModelObject.class);
            notificationType = fireBaseDataModelObject.getNotification_type();
            viewModel.bookingStatusRequest(MainApp.getInstance().getUserData().getUserId());
            viewModel.bookingStatusRepose().observe(this, dataModelObject -> {
                if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                    bookingStatusData = dataModelObject.getData().getBookingInfo();
                    SKIP_DROP_OFF = bookingStatusData.getIs_skip_dropoff();
                    typeID = dataModelObject.getData().getBookingInfo().getVehicle_type_id();
                } else {
                    if (dataModelObject.getError().getMessage() != null) {
                        Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                    } else if (dataModelObject.getError().getMessages() != null) {
                        Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                    }
                }
            });
            if (notificationType != null) {
                stopRideBookingStatusService();
                if (notificationType.equalsIgnoreCase("1")) {
                    rideCurrentStatusText = fireBaseDataModelObject.getMsg();
                    dataList = gson.fromJson(fireBaseDataModelObject.getData(), DataList.class);
                    Status = dataList.getCaptain_info_data().getDriver_status();
                    //Log.v("newToken", "notificationType " + notificationType);
                    //  Log.v("newToken", "Status " + Status);
                    //  Log.v("newToken", "Status " + dataList);
                    RideReceived = true;
                    if (Status.equalsIgnoreCase("1")) {
                        stopLoader();
                        //showToast(TrackingActivity.this, Messages.partnerReached);
                        showCustomSuccessToast(TrackingActivity.this, Messages.partnerReached);
                        ZOOM_ROUTE = false;
                        RIDE_ACCEPTED = true;
                    } else if (Status.equalsIgnoreCase("2")) {
                        stopLoader();
                        Driver_Start_Ride = true;
                        ZOOM_ROUTE = false;
                        SHOW_POLYLINE = true;
                        mGoogleMap.clear();

                        // if (Resume_Ride_Tracking) {
                        if (!(TrackingActivity.this).isFinishing()) {
                            startLoader();
                        }

                        rideStart();
                    } else if (Status.equalsIgnoreCase("3")) {
                        stopLoader();
                        /*SHOW_FINISH_DIALOG = true;*/
                        ZOOM_ROUTE = true;
                        Constants.TRACK_ZOOM = DEFAULT_ZOOM;
                        if (MainApp.getInstance() != null) {
                            MainApp.getInstance().setDriverCoordinate(null);
                        }
                        resetChatbadgeCounter();
                        rideComplete();
                    } else if (Status.equalsIgnoreCase("0")) {
                        stopLoader();
                        FIND_CAPTAIN_CANCEL = false;
                        AFTER_RIDE_CANCEL = true;
                        Driver_Selected_Ride = true;
                        ZOOM_ROUTE = false;
                        Constants.TRACK_ZOOM = DEFAULT_ZOOM;
                        mGoogleMap.clear();
                        RIDE_ACCEPTED = true;
                        startLoader();
                        SHOW_POLYLINE = true;
                        driverSelectedRide();
                    }
                } else if (notificationType.equalsIgnoreCase("0")) {
                    stopLoader();
                    resetChatbadgeCounter();
                    if (fireBaseDataModelObject.getMsg() != null) {
                        //showToast(TrackingActivity.this, fireBaseDataModelObject.getMsg());
                        Constants.FIRE_BASE_NOTIFY = false;
                        showCustomWarningToast(TrackingActivity.this, fireBaseDataModelObject.getMsg());
                    }
                    rideCancelByPartner();
                }
            }
        } else {
            stopRideBookingStatusService();
        }
    }

    private void driverSelectedRide() {
        Log.v("driverSelectedRide", "driverSelectedRide");
        showCustomSuccessToast(TrackingActivity.this, rideCurrentStatusText);
        if (trackerMarker != null) {
            trackerMarker = null;
        }
        if (animateMarkerHandler != null) {
            animateMarkerHandler.removeCallbacksAndMessages(null);
        }
        if (rideStartMarker != null) {
            rideStartMarker.remove();
            rideStartMarker = null;
        }
        PICK_UP_TRACKING = true;
        startGetDriverCoordinatesService();
        captainInfoScreen();
        captainInfoSlider();
        //  startLoader();
    }

    @SuppressLint("SetTextI18n")
    private void captainInfoScreen() {
        int minusWalletAmount = 0;
        int plusWalletAmount;
        double routeAmount;
        Log.v("refreshRide", "captainInfoScreen SKIP_DROP_OFF" + SKIP_DROP_OFF);
        if (dataList == null || MainApp.getInstance().getDataList() == null) {
            //   if ( MainApp.getInstance().getDataList() != null) {
            dataList = MainApp.getInstance().getDataList();
        }
        if (dataList != null) {
            // binding.captainInfoLayout.confirmDropOff.setVisibility(View.GONE);
            //  binding.captainInfoLayout.cancelDropOff.setVisibility(View.GONE);
            binding.captainInfoLayout.captainInfo1.setVisibility(View.VISIBLE);
            if (bookingStatusData == null) {
                checkBookingStatus();
            } else {
                if (Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(Constants.WALLET_AMOUNT)))) > 0 && SharedPrefManager.getInstance(TrackingActivity.this).getOylaPay()) {
                    plusWalletAmount = -(Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(Constants.WALLET_AMOUNT)))));
                    routeAmount = Double.parseDouble(bookingStatusData.getFinal_amount());
                    routeAmount = routeAmount + plusWalletAmount;
                    if (routeAmount < 1) {
                        routeAmount = 0;
                    }
                    Log.v("fareAmount", " if routeAmount " + routeAmount);
                } else if (Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(Constants.WALLET_AMOUNT)))) < 0) {
                    minusWalletAmount = -(Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(Constants.WALLET_AMOUNT)))));
                    routeAmount = Double.parseDouble(bookingStatusData.getFinal_amount());
                    routeAmount = routeAmount + minusWalletAmount;
                    plusWalletAmount = 0;
                    Log.v("fareAmount", " else if routeAmount " + routeAmount);
                } else {
                    routeAmount = Double.parseDouble(bookingStatusData.getFinal_amount());
                    Log.v("fareAmount", " else routeAmount " + routeAmount);
                }
                binding.captainInfoLayout.totalFairText.setText(getResources().getString(R.string.currency) + " " + Math.round(routeAmount));
                Log.v("minusWalletAmount", "minusWalletAmount " + minusWalletAmount);
                Log.v("fareAmount", "routeAmount " + routeAmount);
                Log.v("newToken", "currentTripTime " + currentTripTime);
                Log.v("newToken", "currentTripDuration " + currentTripDuration);
                binding.captainInfoLayout.rideCurrentStatusText.setText(rideCurrentStatusText);
                binding.captainInfoLayout.totalDistanceText.setText(currentTripDuration);
                binding.captainInfoLayout.expectedTimeText.setText(currentTripTime);
                Log.v("captainInfoScreen", "dataList " + dataList);
                if (dataList.getCaptain_info_data() == null) {
                    return;
                }
                Log.v("captainInfoScreen", "getBooking_id " + dataList.getCaptain_info_data().getBooking_id());
                Log.v("captainInfoScreen", "getContact_no " + dataList.getCaptain_info_data().getContact_no());
                binding.captainInfoLayout.captainName.setText(dataList.getCaptain_info_data().getDriver_name());
                binding.captainInfoLayout.contactNumber.setText(dataList.getCaptain_info_data().getContact_no());
                binding.captainInfoLayout.carNumber.setText(dataList.getCaptain_info_data().getVehicle_number());
                //binding.captainInfoLayout.carType.setText(bookingInfoData.getVehicle_type() + "( " + dataList.getCaptain_info_data().getVehicle_name() + " )");
                binding.captainInfoLayout.carType.setText(bookingStatusData.getVehicle_type() + "(" + dataList.getCaptain_info_data().getVehicle_name() + ")");
                binding.captainInfoLayout.ratingtext.setText(getResources().getString(R.string.rating_text) + ": " + Math.round(Double.parseDouble(dataList.getCaptain_info_data().getDriver_ratings())));
                Log.v("newToken", "bookingStatusData.getBooking_changes " + bookingStatusData.getBooking_changes());
                binding.captainInfoLayout.contactLayout.setOnClickListener(v -> {
                    ClipboardManager clipboard = (ClipboardManager) TrackingActivity.this.getSystemService(CLIPBOARD_SERVICE);
                    ClipData clip = ClipData.newPlainText("label", dataList.getCaptain_info_data().getContact_no());
                    clipboard.setPrimaryClip(clip);
                    BaseActivity.getInstance().showToast(TrackingActivity.this, "Phone Number Copy");

                });
                binding.captainInfoLayout.sendMessage.setVisibility(View.VISIBLE);
                binding.captainInfoLayout.sendMessage.setOnClickListener((v -> {
                    binding.captainInfoLayout.chatMessageBadge.setVisibility(View.GONE);
                    resetChatbadgeCounter();
                    Intent chatIntent = new Intent(TrackingActivity.this, ChatActivity.class);
                    chatIntent.putExtra("bookingStatusData", bookingStatusData);
                    startActivity(chatIntent);
                }));
                binding.captainInfoLayout.phoneCall.setOnClickListener((v -> {
                    //stopLoader();
                    try {
                        if (dataList.getCaptain_info_data().getContact_no() != null || dataList.getCaptain_info_data().getContact_no().isEmpty())
                            call("+" + dataList.getCaptain_info_data().getContact_no());
                    } catch (Exception ex) {
                        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, 1);
                    }
                }));
                /*setGlideImage(
                        TrackingActivity.this,
                        appVehicles.get(selectedRidePosition).getImage_url(),
                        binding.captainInfoLayout.carTypeIcon,
                        Constants.ASSETS_BASE_URL);*/
                if (bookingStatusData != null && bookingStatusData.getVehicle_type_id() != null) {
                    if (bookingStatusData.getVehicle_type_id().equalsIgnoreCase("1")) {
                        binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.gomini);
                    } else if (bookingStatusData.getVehicle_type_id().equalsIgnoreCase("2")) {
                        binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.go);
                    } else if (bookingStatusData.getVehicle_type_id().equalsIgnoreCase("3")) {
                        binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.go_plus);
                    } else if (bookingStatusData.getVehicle_type_id().equalsIgnoreCase("4")) {
                        binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.business);
                    } else if (bookingStatusData.getVehicle_type_id().equalsIgnoreCase("5")) {
                        binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.royal);
                    } else if (bookingStatusData.getVehicle_type_id().equalsIgnoreCase("6")) {
                        binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.dabba);
                    } else if (bookingStatusData.getVehicle_type_id().equalsIgnoreCase("7")) {
                        binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.pickup);
                    } else if (bookingStatusData.getVehicle_type_id().equalsIgnoreCase("8")) {
                        binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.agro);
                    } else if (bookingStatusData.getVehicle_type_id().equalsIgnoreCase("9")) {
                        binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.riksha);
                    } else if (bookingStatusData.getVehicle_type_id().equalsIgnoreCase("10")) {
                        binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.bike);
                    } else {
                        binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.go_plus);
                    }
                } else {
                    binding.captainInfoLayout.carTypeIcon.setImageResource(R.drawable.go_plus);
                }

                if (dataList.getCaptain_info_data().getProfile_picture() != null) {
                    setGlideImage(getApplicationContext(), dataList.getCaptain_info_data().getProfile_picture(),
                            binding.captainInfoLayout.captainProfile, Constants.PROFILE_BASE_URL);
                }

                binding.captainInfoLayout.shareInfo.setOnClickListener(v -> {
                    Intent intent = new Intent(android.content.Intent.ACTION_SEND);
                    String shareBody = "Oyla Driver info  Share by :" + MainApp.getInstance().getUserData().getUserFirstName();
                    shareBody = shareBody + "\n" + "Driver name: " + dataList.getCaptain_info_data().getDriver_name();
                    shareBody = shareBody + "\n" + "Vehicle name: " + dataList.getCaptain_info_data().getVehicle_name();
                    shareBody = shareBody + "\n" + "Vehicle number: " + dataList.getCaptain_info_data().getVehicle_number();
                    if (diverLatLng != null) {
                        String uri = "https://www.google.com/maps/?q=" + diverLatLng.latitude + "," + diverLatLng.longitude;
                        /*   String uri = "https://www.google.com/maps/?q=" + MainApp.getInstance().getUserLocation().getLocation().getLatitude() + "," + MainApp.getInstance().getUserLocation().getLocation().getLongitude();*/
                        shareBody = shareBody + "\n" + "Current Location: " + uri;
                    }
                    intent.setType("text/plain");
                    intent.putExtra(android.content.Intent.EXTRA_SUBJECT, getString(R.string.oyla_captain_info));
                    intent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
                    startActivity(Intent.createChooser(intent, getString(R.string.share_using)));
                });

                Log.v("Captain_info_data", "bookingStatusData " + bookingStatusData.getBooking_id());
                Log.v("Captain_info_data", "getBooking_id() " + dataList.getCaptain_info_data().getBooking_id());

                binding.captainInfoLayout.cancelRideButton.setOnClickListener(v -> cancelReasonDialog(MainApp.getInstance().getUserData().getUserId(), dataList.getCaptain_info_data().getBooking_id()));

                if (!RIDE_STARTED) {
                    binding.captainInfoLayout.cancelRideButton.setVisibility(View.VISIBLE);
                    binding.captainInfoLayout.changeDropOffButton.setVisibility(View.GONE);
                    binding.captainInfoLayout.confirmDropOff.setVisibility(View.GONE);
                    binding.captainInfoLayout.cancelDropOff.setVisibility(View.GONE);
                } else {
                    binding.captainInfoLayout.cancelRideButton.setVisibility(View.GONE);
                    if (bookingStatusData.getBooking_changes() == null) {
                        if (SKIP_DROP_OFF == 0) {
                            binding.captainInfoLayout.changeDropOffButton.setVisibility(View.VISIBLE);
                        } else {
                            binding.captainInfoLayout.changeDropOffButton.setVisibility(View.GONE);
                        }
                    } else {
                        binding.captainInfoLayout.changeDropOffButton.setVisibility(View.GONE);
                    }
                    //binding.captainInfoLayout.confirmDropOff.setVisibility(View.VISIBLE);
                }
                binding.captainInfoLayout.changeDropOffButton.setOnClickListener(v -> {
                    RIDE_STARTED = true;
                    CHANGE_ADDRESS = true;
                    mGoogleMap.clear();
                    binding.captainInfoLayout.changeAddressCardView.setVisibility(View.VISIBLE);
                    binding.captainInfoLayout.captainInfo2.setVisibility(View.GONE);
                    binding.captainInfoLayout.confirmDropOff.setVisibility(View.VISIBLE);
                    binding.captainInfoLayout.cancelDropOff.setVisibility(View.VISIBLE);
                    contractView2();
                    currentLat = MainApp.getInstance().getDriverCoordinate().getLat();
                    currentLng = MainApp.getInstance().getDriverCoordinate().getLng();
                    Log.d("TimeAndDistance", "currentLng " + currentLng);
                    Log.d("TimeAndDistance", "currentLat " + currentLat);
                    // if(isGetDriverCoordinatesServiceRunning()){
                    Intent myService = new Intent(TrackingActivity.this, GetDriverCoordinates.class);
                    myService.setAction(Constants.ACTION_STOP_FOREGROUND_SERVICE);
                    stopService(myService);
                    // }
                  /*  final Handler handler = new Handler(Looper.getMainLooper());
                    handler.postDelayed(() -> {*/
                    //Do something after 100ms
                    binding.dropOffMarker.setVisibility(View.VISIBLE);
                    routeConfirm = false;
                    dropOffAddressBol = true;
                    //binding.dropOffAddressTextLayout.setVisibility(View.VISIBLE);
                    /*mGoogleMap.clear();*/
                    binding.captainInfoLayout.confirmDropOff.setVisibility(View.VISIBLE);
                    binding.captainInfoLayout.cancelDropOff.setVisibility(View.VISIBLE);
                    CHANGE_ADDRESS = true;
                    /* }, 200);*/
                });
                binding.captainInfoLayout.changeAddressCardView.setOnClickListener(v -> {
                    //SHOW_POLYLINE=true;
                    if (rideStartMarker != null) {
                        rideStartMarker = null;
                    }
                    CHANGE_ADDRESS = true;
                    //List<Address> addresses = getStringAddress2(centerLatLng.latitude, centerLatLng.longitude);
                    Intent i = new Intent(TrackingActivity.this, SearchLocationActivity.class);
                    i.putExtra("message", getResources().getString(R.string.drop_off_message));
                    /*i.putExtra("city", addresses.get(0).getLocality());*/
                    i.putExtra("city", " ");
                    //i.putExtra("country", addresses.get(0).getCountryName());
                    i.putExtra("country", "Pakistan");
                    /*PICK_UP_ADDRESS = false;
                    DROP_OFF_ADDRESS = false;*/
                    startActivity(i);
                });
                binding.captainInfoLayout.confirmDropOff.setOnClickListener(v -> {
                    binding.captainInfoLayout.changeAddressCardView.setVisibility(View.GONE);
                    binding.captainInfoLayout.captainInfo2.setVisibility(View.VISIBLE);
                    binding.captainInfoLayout.cancelDropOff.setVisibility(View.GONE);
                    binding.captainInfoLayout.confirmDropOff.setVisibility(View.GONE);
                    binding.captainInfoLayout.changeDropOffButton.setVisibility(View.GONE);
                    contractView2();
                    binding.dropOffMarker.setVisibility(View.GONE);
                    routeConfirm = true;
                    dropOffAddressBol = false;
                    // binding.dropOffAddressTextLayout.setVisibility(View.GONE);
                    newLatLng = new LatLng(Double.parseDouble(currentLat), Double.parseDouble(currentLng));
                    oldMarkerPoints.add(new LatLng(markerPoints.get(0).latitude, markerPoints.get(0).longitude));
                    oldMarkerPoints.add(newLatLng);
                    Log.d("changeDropOff", "TimeAndDistance: calculating directions.");
                    SHOW_POLYLINE = true;
                    trip_one_duration = "";
                    trip_two_duration = "";
                    trip_one_distance = "";
                    trip_two_distance = "";
                    trip_one_price = "";
                    trip_two_price = "";
                    CHANGE_ADDRESS = false;
                    //calculateTimeAndDistance(oldMarkerPoints, true);
                    calculateTimeAndDistanceURL(oldMarkerPoints, true);
                });

                binding.captainInfoLayout.cancelDropOff.setOnClickListener(v -> {
                    binding.captainInfoLayout.changeAddressCardView.setVisibility(View.GONE);
                    binding.captainInfoLayout.captainInfo2.setVisibility(View.VISIBLE);
                    binding.captainInfoLayout.cancelDropOff.setVisibility(View.GONE);
                    binding.captainInfoLayout.confirmDropOff.setVisibility(View.GONE);
                    binding.dropOffMarker.setVisibility(View.GONE);
                    CHANGE_ADDRESS = false;
                    if (trackerMarker != null) {
                        trackerMarker = null;
                    }
                    routeConfirm = true;
                    dropOffAddressBol = false;
                    // binding.dropOffAddressTextLayout.setVisibility(View.GONE);
                    SHOW_POLYLINE = false;
                    if (rideStartMarker != null) {
                        rideStartMarker = null;
                    }
                    startGetDriverCoordinatesService();
                });
            }
        }
    }

    private void calculateTimeAndDistanceURL(List<LatLng> latLngList, boolean trip) {
        String origin = latLngList.get(0).latitude + "," + latLngList.get(0).longitude;
        String dest = latLngList.get(1).latitude + "," + latLngList.get(1).longitude;
        viewModel.directionResultRequest(origin, dest, "false", "driving", MAP_KEY);
        viewModel.directionResultRepose().observe(this, directionResult -> {
            //   stopLoader();
            //Log.d("calculateDirectionsURL", "directionResultRepose");
            // Log.d("calculateDirectionsURL", "dataModelObject "+dataModelObject .toString());

            if (directionResult.getRoutes() != null) {
                //currentTripDuration = String.valueOf(result.routes[0].legs[0].duration);
                // currentTripTime = String.valueOf(result.routes[0].legs[0].distance);
                Log.d("ChangedropOff", "if");
               /* currentTripDuration = String.valueOf(directionResult.getRoutes().get(0).getLegs().get(0).getDistance().getText());
                currentTripTime = String.valueOf(directionResult.getRoutes().get(0).getLegs().get(0).getDuration().getText());*/
                if (trip) {
                    trip_one_distance = String.valueOf(directionResult.getRoutes().get(0).getLegs().get(0).getDistance().getText());
                    trip_one_duration = String.valueOf(directionResult.getRoutes().get(0).getLegs().get(0).getDuration().getText());
                    Log.d("changeDropOff", "calculateTimeAndDistance: duration: trip_one_distance " + trip_one_distance);
                    Log.d("changeDropOff", "calculateTimeAndDistance: distance: trip_one_duration " + trip_one_duration);
                    markerPoints.remove(markerPoints.get(markerPoints.size() - 1));
                    markerPoints.add(centerLatLng);
                    //SharedPrefManager.getInstance(MapActivity.this).setDropLat(centerLatLng.latitude);
                    // SharedPrefManager.getInstance(MapActivity.this).setDropLng(centerLatLng.longitude);
                   // Log.v("changeDropOff", "address drop off " + getStringAddress(centerLatLng.latitude, centerLatLng.longitude));
                    //Log.v("changeDropOff", "address drop off marker point " + getStringAddress(markerPoints.get(1).latitude, markerPoints.get(1).latitude));

                    newMarkerPoints.add(newLatLng);
                    newMarkerPoints.add(centerLatLng);
                    calculateTimeAndDistanceURL(newMarkerPoints, false);
                    //  directionsApiRequest.cancel();
                } else {
                    trip_two_distance = String.valueOf(directionResult.getRoutes().get(0).getLegs().get(0).getDistance().getText());
                    trip_two_duration = String.valueOf(directionResult.getRoutes().get(0).getLegs().get(0).getDuration().getText());
                    //trip_two_distance = String.valueOf(result.routes[0].legs[0].distance).trim();
                    // trip_two_duration = String.valueOf(result.routes[0].legs[0].duration).trim();
                    Log.d("changeDropOff", "calculateTimeAndDistance: duration: trip_two_distance " + trip_two_distance);
                    Log.d("changeDropOff", "calculateTimeAndDistance: distance: trip_two_duration " + trip_two_duration);
                    // directionsApiRequest.cancel();
                    ChangeDestination();
                }
                //drawPolyLineOnMap(directionResult.getRoutes().get(0).getLegs());
            } else {
                Log.d("calculateDirectionsURL", "else");
            }
        });
    }

    @SuppressLint("SetTextI18n")
    private void ChangeDestination() {
        if (trackerMarker != null) {
            trackerMarker = null;
        }
        startGetDriverCoordinatesService();
        Log.d("changeDropOff", "ChangeDestination ");
        double trip_one_dist = getTripDestination(trip_one_distance);
        double trip_two_dist = getTripDestination(trip_two_distance);
        trip_total_distance = String.valueOf(trip_one_dist + trip_two_dist);
        trip_total_distance = String.valueOf(Math.round(Double.parseDouble(trip_total_distance)));
        Log.d("changeDropOff", "ChangeDestination 2 ");
        int trip_one_durat = getTripTime(trip_one_duration);
        int trip_two_durat = getTripTime(trip_two_duration);
        trip_total_time = String.valueOf(trip_one_durat + trip_two_durat);
        Log.d("changeDropOff", "ChangeDestination 3 ");
        Log.d("changeDropOff", "trip_one_dist " + trip_one_dist);
        Log.d("changeDropOff", "trip_one_durat " + trip_one_durat);
        Log.d("changeDropOff", "---- ");
        trip_one_price = tripFareCalculation(trip_one_durat, trip_one_dist);
        Log.d("changeDropOff", "ChangeDestination 4 ");
        trip_two_price = tripFareCalculation(trip_two_durat, trip_two_dist);
        Log.d("changeDropOff", "ChangeDestination 5");
        total_price = String.valueOf(Integer.parseInt(trip_one_price) + Integer.parseInt(trip_two_price));
        runOnUiThread(() -> {
            binding.captainInfoLayout.totalFairText.setText(getResources().getString(R.string.currency) + " " + total_price);
            binding.captainInfoLayout.totalDistanceText.setText(trip_two_distance);
            binding.captainInfoLayout.expectedTimeText.setText(trip_two_duration);
            currentTripDuration = trip_two_distance;
            currentTripTime = trip_two_duration;
            if (!(TrackingActivity.this).isFinishing()) {
                startLoader();
            }
            viewModel.passengerChangeDestinationRequest(
                    dataList.getCaptain_info_data().getBooking_id(), currentLat, currentLng
                    , String.valueOf(markerPoints.get(1).latitude), String.valueOf(markerPoints.get(1).longitude)
                    , String.valueOf(trip_one_dist), String.valueOf(trip_two_dist)
                    , trip_total_distance, trip_one_price, trip_two_price, total_price, trip_total_time);

            viewModel.passengerChangeDestinationRepose().observe(this, dataModelObject -> {
                stopLoader();
                if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                    if (trackerMarker != null) {
                        trackerMarker = null;
                    }
                    if (rideStartMarker != null) {
                        rideStartMarker.remove();
                        rideStartMarker = null;
                    }
                    checkBookingStatus();
                    binding.captainInfoLayout.confirmDropOff.setVisibility(View.GONE);
                } else {
                    if (dataModelObject.getError().getMessage() != null) {
                        showToast(TrackingActivity.this, dataModelObject.getError().getMessage());
                        Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                    } else if (dataModelObject.getError().getMessages() != null) {
                        showToast(TrackingActivity.this, dataModelObject.getError().getMessages().toString());
                        Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                    }
                    //showToast(MapActivity.this, dataModelObject.getError().getMessage());
                }
            });
        });
    }

    private double getTripDestination(String distance) {
        double finalDistance = 0;
        if (distance.contains("km")) {
            distance = distance.replace("km", "");
            distance = distance.replace(" ", "");
            if (distance.contains(",")) {
                distance = distance.replace(",", "");
            }
            finalDistance = Double.parseDouble(distance);
        } else if (distance.contains("m")) {
            Log.v("fareCalculation", "Distance in meter");
            distance = distance.replace("m", "");
            distance = distance.replace(" ", "");
            if (distance.contains(",")) {
                distance = distance.replace(",", "");
            }
            finalDistance = Double.parseDouble(distance);
            finalDistance = finalDistance / 1000;
        }

        return finalDistance;
    }

    private int getTripTime(String duration) {
        String addHours = "0";
        String addMinutes = "0";
        boolean HOUR = false;
        if (duration.contains("hours")) {
            duration = duration.replace("hours", ":");
            HOUR = true;

        } else if (duration.contains("hour")) {
            duration = duration.replace("hour", ":");
            HOUR = true;
        }

        if (duration.contains("mins")) {
            duration = duration.replace("mins", "");
            addMinutes = duration;
        }
        if (HOUR) {
            String[] splitTime = duration.split(":");
            addHours = splitTime[0].trim();
            addMinutes = splitTime[1].trim();
        }
        //  Log.v("selectRideType", "finalDistance  " + finalDistance);
        addHours = addHours.replace(" ", "");
        addMinutes = addMinutes.replace(" ", "");
        // int finalTotalMint =Integer.valueOf(durationMint);
        int finalTotalHour = Integer.parseInt(addHours);
        finalTotalHour = finalTotalHour * 60;
        int tripTime = Integer.parseInt(addMinutes) + finalTotalHour;
        Log.v("selectRideType", "tripTime  " + tripTime);
        // double tripTimeDistance1 = finalDistance;
        return tripTime;
    }

    private String tripFareCalculation(int totalMint, double totalDistance) {
        double perKM = MainApp.getInstance().getPerKM();
        Log.d("changeDropOff", "perKM " + perKM);
        double perMint = MainApp.getInstance().getPerMint();
        Log.d("changeDropOff", "perKM " + perKM);
        double vehicleRate = MainApp.getInstance().getVehicleRate();
        Log.d("changeDropOff", "vehicleRate " + vehicleRate);
        Log.d("changeDropOff", "tax_percentage " + MainApp.getInstance().getTax_percentage().trim());
        double tax_percentage = Double.parseDouble(MainApp.getInstance().getTax_percentage().trim());
        Log.d("changeDropOff", "tax_percentage2 " + tax_percentage);
       /* Log.v("selectRideType", "vehicleRate  " + vehicleRate);
        Log.v("calculateTime", "totalDistance  " + totalDistance);*/
        double d = (perKM * totalDistance) + (perMint * totalMint) + vehicleRate;
        //int fair = (int) d;
        double fair = (int) d;
        double taxPrice = (tax_percentage / 100) * fair;
        double totalPrice = fair + taxPrice;
        // dataSet.get(i).setFair(String.valueOf(fair));
        return String.valueOf(Math.round(totalPrice));
        // return String.valueOf(totalPrice);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void captainInfoSlider() {
        binding.captainInfoLayout.topLayout.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    Log.i("scrollLayout", "ACTION_DOWN");
                    break;
                case MotionEvent.ACTION_MOVE:
                    Log.i("scrollLayout", "ACTION_MOVE");
                    break;
                case MotionEvent.ACTION_UP:
                    Log.i("scrollLayout", "ACTION_UP");
                    Log.i("scrollLayout", "RIDE_VIEw_FULL " + RIDE_VIEw_FULL);
                    if (RIDE_VIEw_FULL) {
                        contractView2();
                        RIDE_VIEw_FULL = false;
                    } else {
                        RIDE_VIEw_FULL = true;
                        expandView2();
                    }
                    break;
                default:
                    return false;
            }
            return true;
        });
    }

    private void expandView2() {
        RelativeLayout.LayoutParams layout_description = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        layout_description.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        binding.captainInfoLayout.infoArrow.setRotation(270);
        binding.captainInfoLayout.secondLayout.setVisibility(View.VISIBLE);
        binding.captainInfoLayout.captainInfo2.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
        binding.captainInfoLayout.secondLayout.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
        binding.captainInfoLayout.captainInfo2.setLayoutParams(layout_description);
    }

    private void contractView2() {
        RelativeLayout.LayoutParams layout_description = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        layout_description.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        binding.captainInfoLayout.infoArrow.setRotation(90);
        binding.captainInfoLayout.secondLayout.setVisibility(View.GONE);
        binding.captainInfoLayout.secondLayout.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
        binding.captainInfoLayout.captainInfo2.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
        binding.captainInfoLayout.captainInfo2.setLayoutParams(layout_description);
    }

    private void rideCancelByPartner() {
        stopRideBookingStatusService();
        //resetRideFlowTag(false, false, false);
        // resetRideStatusTag(false, false, false);
        AFTER_RIDE_CANCEL = false;
        FIND_CAPTAIN_CANCEL = false;
        SHOW_POLYLINE = false;
        FINDING_CAPTAIN = false;
        if (trackerMarker != null) {
            trackerMarker = null;
        }
        if (animateMarkerHandler != null) {
            animateMarkerHandler.removeCallbacksAndMessages(null);
        }
        RIDE_ACCEPTED = false;
        RIDE_STARTED = false;
        routeConfirm = false;
        Driver_Selected_Ride = false;
        Driver_Start_Ride = false;
        RideReceived = false;
        Resume_Ride_Tracking = false;
        PICK_UP_TRACKING = false;
        MainApp.getInstance().Booking_REQUEST = false;
        CONFIRM_RIDE = false;
        SELECTED_RIDE = false;
        if (markerPoints != null) {
            markerPoints.clear();
        }
        binding.captainInfoLayout.captainInfo1.setVisibility(View.GONE);
        if (MainApp.getInstance() != null) {
            MainApp.getInstance().setDriverCoordinate(null);
        }
        Intent myService = new Intent(TrackingActivity.this, GetDriverCoordinates.class);
        myService.setAction(Constants.ACTION_STOP_FOREGROUND_SERVICE);
        stopService(myService);
        SharedPreferences sharedPreferences2 = TrackingActivity.this.getSharedPreferences("Driver_Info", 0);
        sharedPreferences2.edit().remove("Driver_Info_Object").apply();
        SharedPrefManager.getInstance(TrackingActivity.this).removeBookingInfo();
        binding.captainInfoLayout.totalFairText.setText("");
        dataList = null;
        //startgetNearestDriverService();
        onBackPressed();
    }

    private void refreshTracking() {
        if (FINDING_CAPTAIN || RideReceived) {
            Log.v("refreshRide", " if FINDING_CAPTAIN " + FINDING_CAPTAIN);
            Log.v("refreshRide", " if RideReceived " + RideReceived);
            Log.v("refreshRide", " CHANGE_ADDRESS " + CHANGE_ADDRESS);
            Log.v("refreshRide", " SHOW_FINISH_DIALOG " + SHOW_FINISH_DIALOG);

            viewModel.bookingStatusRequest(MainApp.getInstance().getUserData().getUserId());
            viewModel.bookingStatusRepose().observe(this, dataModelObject -> {
                if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                    if (!CHANGE_ADDRESS) {
                        //Log.v("refreshRide", "if CHANGE_ADDRESS " + CHANGE_ADDRESS);
                        bookingStatusData = dataModelObject.getData().getBookingInfo();
                        SKIP_DROP_OFF = bookingStatusData.getIs_skip_dropoff();

                       /* String fdis = String.valueOf(Math.round(Double.parseDouble(bookingStatusData.getFinal_amount())));
                        Log.v("refreshRide", "if SKIP_DROP_OFF " + SKIP_DROP_OFF);
                        Log.v("refreshRide", "if fdis " + fdis);
                        Log.v("refreshRide", "if getTemp_id " + bookingStatusData.getTemp_id());*/
                        typeID = dataModelObject.getData().getBookingInfo().getVehicle_type_id();
                        MainApp.getInstance().setDataList(dataModelObject.getData());
                        dataList = MainApp.getInstance().getDataList();
                        startGetDriverCoordinatesService();
                        mGoogleMap.clear();
                        if (FINDING_CAPTAIN) {
                            if (bookingStatusData.getTemp_id() != null && bookingStatusData.getTemp_id().equalsIgnoreCase(MainApp.getInstance().getBookingInfoData().getTemp_id())) {
                                Log.v("refreshRide", " inner FINDING_CAPTAIN " + FINDING_CAPTAIN);
                                resumeRideTracking();
                            }
                        } else if (RideReceived) {
                            SHOW_FINISH_DIALOG = true;
                            Log.v("refreshRide", "inner SHOW_FINISH_DIALOG " + RideReceived);
                            resumeRideTracking();
                        }
                    }
                } else {
                    if (dataModelObject.getError().getMessage() != null) {
                        //  showToast(MapActivity.this, dataModelObject.getError().getMessage());
                        Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                    } else if (dataModelObject.getError().getMessages() != null) {
                        //  showToast(MapActivity.this, dataModelObject.getError().getMessages().toString());
                        Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                    }
                }
            });
        }
    }

    private void resumeRideTracking() {

        Log.v("newToken", "resumeRideTracking ");
        Log.v("refreshRide", " resumeRideTracking ");
        routeConfirm = true;
        Resume_Ride_Tracking = true;
        FINDING_CAPTAIN = false;
        BOOKING_RESPONSE = false;
        Log.v("driverInfoRepose", "driverInfoRepose ");
        if (MainApp.getInstance().getDataList() != null && MainApp.getInstance().getDataList().getCaptain_info_data() != null) {
            Log.v("refreshRide", " if driverInfoRepose  ");
            RideReceived = true;
            resumeRideScenario();
        }
    }

    private void resumeRideScenario() {
        Log.v("RideBookingService", " resumeRideSenarios ");
        Log.v("refreshRide", " resumeRideSenarios  ");
        // Log.v("refreshRide", " resumeRideSenarios  SHOW_FINISH_DIALOG " + SHOW_FINISH_DIALOG);
        stopRideBookingStatusService();
       // getFirebaseTracking();
        stopLoader();
        if (!(TrackingActivity.this).isFinishing()) {
            startLoader();
        }
        AFTER_RIDE_CANCEL = true;
        FIND_CAPTAIN_CANCEL = false;
        // Log.v("refreshRide", " getStatus  " + bookingStatusData.getStatus());
        // Log.v("refreshRide", " getDriver_status  " + bookingStatusData.getDriver_status());
        typeID = bookingStatusData.getVehicle_type_id();
        if (bookingStatusData.getStatus().equalsIgnoreCase("0") && bookingStatusData.getDriver_status().equalsIgnoreCase("0")) {
            Log.v("stopRideBooking ", "refreshRide --1");
            RIDE_ACCEPTED = true;
            ZOOM_ROUTE = false;
            /*rideCurrentStatusText = Messages.partnerSelected;*/
            rideCurrentStatusText = getResources().getString(R.string.partnerSelected);
            driverSelectedRide();
        } else if (bookingStatusData.getStatus().equalsIgnoreCase("0") && bookingStatusData.getDriver_status().equalsIgnoreCase("1")) {
            Log.v("refreshRide", " --2");
           // rideCurrentStatusText = Messages.partnerReached;
            rideCurrentStatusText =  getResources().getString(R.string.partnerReached);
            //createNotification(rideCurrentStatusText);
            ZOOM_ROUTE = false;
            RIDE_ACCEPTED = true;
            driverSelectedRide();

        } else if (bookingStatusData.getStatus().equalsIgnoreCase("1") && bookingStatusData.getDriver_status().equalsIgnoreCase("2")) {
            RIDE_ACCEPTED = false;
            Log.v("refreshRide", " --3");
            ZOOM_ROUTE = false;
            //rideCurrentStatusText = Messages.rideStarted;
            rideCurrentStatusText =  getResources().getString(R.string.rideStarted);
            rideStart();
        }
        /*else if (json.equalsIgnoreCase("Ride Completed")) {*/
        else if (bookingStatusData.getStatus().equalsIgnoreCase("4") || bookingStatusData.getDriver_status().equalsIgnoreCase("3")) {
            RIDE_ACCEPTED = false;
            ZOOM_ROUTE = true;
            SHOW_POLYLINE = false;
            stopLoader();
            Log.v("refreshRide", " rideComplete  bookingStatusData");
            dataList = null;
            rideComplete();
            // rideCompleteResume();
            SharedPreferences sharedPreferences2 = TrackingActivity.this.getSharedPreferences("Driver_Info", 0);
            sharedPreferences2.edit().remove("Driver_Info_Object").apply();
            SharedPrefManager.getInstance(TrackingActivity.this).removeBookingInfo();

        } else {
            RideReceived = false;
            SHOW_FINISH_DIALOG = false;
            FINDING_CAPTAIN = false;
            Constants.FIRE_BASE_NOTIFY = false;
            stopLoader();
            // stopRideBookingStatusService();
            showToast(TrackingActivity.this, "Ride has been cancel");
            rideCancelByPartner();
        }
    }

    @Override
    public void onLocationSelect(String place) {
        //binding.dropOffAddressText.setText(place);
        binding.captainInfoLayout.changeAddressText.setText(place);
        List<Address> addressList;
        try {
            Geocoder geocoder = new Geocoder(getApplicationContext());
            addressList = geocoder.getFromLocationName(place, 5);
            Address location = addressList.get(0);
            Log.v("onLocationSelect", "location.getLatitude() " + location.getLatitude());
            Log.v("onLocationSelect", "location.getLongitude() " + location.getLongitude());
            LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
            mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, DEFAULT_ZOOM));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void doTracking() {
        /*  new Handler(Looper.getMainLooper()).post(() -> {*/
        //  mGoogleMap.clear();
        Log.v("SHOW_POLYLINE", "doTracking SHOW_POLYLINE " + SHOW_POLYLINE);
        Log.v("SHOW_POLYLINE", "SKIP_DROP_OFF " + SKIP_DROP_OFF);
        Log.v("SHOW_POLYLINE", "RIDE_STARTED " + RIDE_STARTED);

        if (dataList == null || bookingStatusData == null) {
            checkBookingStatus();
            return;
        }

        if (SKIP_DROP_OFF == 1 && RIDE_STARTED) {
            SHOW_POLYLINE = false;
            binding.captainInfoLayout.totalDistanceText.setText("");
            binding.captainInfoLayout.expectedTimeText.setText("");
            stopLoader();
        }
        if (SHOW_POLYLINE) {
            //newTrackingRoute();
            Log.v("SHOW_POLYLINE", "trackingPolylineRoute ");
            trackingPolylineRoute();
            //  SHOW_POLYLINE=false;
        } else {
            if (polyLine != null) {
                Log.v("SHOW_POLYLINE", "trackingNonPolylineRoute ");
                Log.v("SHOW_POLYLINE", "polyLine ");
                polyLine.remove();
                polyLine = null;
                if (rideStartMarker != null) {
                    Log.v("SHOW_POLYLINE", "rideStartMarker ");
                    rideStartMarker.remove();
                    rideStartMarker = null;
                }
            }
            trackingNonPolylineRoute();
        }
        //});
    }

    private void trackingPolylineRoute() {
        Log.v("SHOW_POLYLINE", "trackingRoute ");
        // LatLng diverLatLng;
        ArrayList<LatLng> trackingMarkerPoints = new ArrayList<>();
        Log.v("newToken", "BOOKING_RESPONSE " + BOOKING_RESPONSE);
        Log.v("doTracking", "doTracking ");
        Log.v("doTracking", "BOOKING_RESPONSE " + BOOKING_RESPONSE);
        if (BOOKING_RESPONSE) {
            BOOKING_RESPONSE = false;
            if (dataList.getCaptain_info_data() != null && dataList.getCaptain_info_data().getDriver_lat() != null && dataList.getCaptain_info_data().getDriver_long() != null) {
                diverLatLng = new LatLng(Double.parseDouble(dataList.getCaptain_info_data().getDriver_lat()), Double.parseDouble(dataList.getCaptain_info_data().getDriver_long()));
                Log.d("captainInfoData", "captainInfoData getBooking_id " + dataList.getCaptain_info_data().getBooking_id());
                trackingMarkerPoints.add(diverLatLng);
                trackingMarkerPoints.add(new LatLng(markerPoints.get(0).latitude, markerPoints.get(0).longitude));
                //calculateDirections(trackingMarkerPoints);
                calculateDirectionsURL(trackingMarkerPoints);
            }
           /* if (Driver_Start_Ride) {
                Driver_Start_Ride = false;
                stopLoader();
            }
            if (Driver_Selected_Ride) {
                Driver_Selected_Ride = false;
                stopLoader();
            }*/
            //  }
        } else {
            if (MainApp.getInstance().getDriverCoordinate() != null) {
                //stopLoader();
              /*  if (Driver_Start_Ride) {
                    Driver_Start_Ride = false;
                    stopLoader();
                }
                if (Driver_Selected_Ride) {
                    Driver_Selected_Ride = false;
                    stopLoader();
                }*/
                // Log.d("GetDriverCoordinates", "MainApp.getInstance().getDriverCoordinate().getLat() " + MainApp.getInstance().getDriverCoordinate().getLat());
                //  Log.d("GetDriverCoordinates", "MainApp.getInstance().getDriverCoordinate().getLng() " + MainApp.getInstance().getDriverCoordinate().getLng());
                //MainApp.getInstance().getDriverCoordinate().getLng();
                diverLatLng = new LatLng(Double.parseDouble(MainApp.getInstance().getDriverCoordinate().getLat()), Double.parseDouble(MainApp.getInstance().getDriverCoordinate().getLng()));
                trackingMarkerPoints.add(diverLatLng);
                //  Log.d("GetDriverCoordinates", "PICK_UP_TRACKING " + PICK_UP_TRACKING);
                // showToast(MapActivity.this, getStringAddress(diverLatLng.latitude, diverLatLng.longitude));
                if (markerPoints == null) {
                    return;
                }
                if (RIDE_STARTED) {
                    if (markerPoints.size() < 2) {
                        return;
                    }
                    trackingMarkerPoints.add(new LatLng(markerPoints.get(1).latitude, markerPoints.get(1).longitude));

                    // trackingMarkerPoints.add(new LatLng(31.50967734630642,74.31757159320492));
                } else {
                    if (markerPoints.size() < 1) {
                        return;
                    }
                    PICK_UP_TRACKING = true;
                    trackingMarkerPoints.add(new LatLng(markerPoints.get(0).latitude, markerPoints.get(0).longitude));

                    // trackingMarkerPoints.add(new LatLng(31.50967734630642,74.31757159320492));
                }
                /* SHOW_POLYLINE = false;*/
                if (trackingMarkerPoints.size() > 1) {
                    calculateDirectionsURL(trackingMarkerPoints);
                }

                //calculateDirections(trackingMarkerPoints);

            }
        }
        trackingMarkerPoints = null;
    }

    private void calculateDirectionsURL(List<LatLng> latLngList) {
        SHOW_POLYLINE = false;
        Log.d("calculateDirectionsURL", "calculateDirectionsURL");
        String origin = latLngList.get(0).latitude + "," + latLngList.get(0).longitude;
        String dest = latLngList.get(1).latitude + "," + latLngList.get(1).longitude;
        //Log.d("calculateDirectionsURL", "origin " + origin);
        //Log.d("calculateDirectionsURL", "dest " + dest);
        // Log.d("pointRoute", "origin " + origin);
        // Log.d("pointRoute", "dest " + dest);
        viewModel.directionResultRequest(origin, dest, "false", "driving", MAP_KEY);
        viewModel.directionResultRepose().observe(this, directionResult -> {
            //   stopLoader();
            //Log.d("calculateDirectionsURL", "directionResultRepose");
            // Log.d("calculateDirectionsURL", "dataModelObject "+dataModelObject .toString());
            stopLoader();
            if (directionResult.getRoutes() != null && directionResult.getRoutes().size() > 0) {
                currentTripDuration = String.valueOf(directionResult.getRoutes().get(0).getLegs().get(0).getDistance().getText());
                currentTripTime = String.valueOf(directionResult.getRoutes().get(0).getLegs().get(0).getDuration().getText());
                //currentTripDuration = String.valueOf(result.routes[0].legs[0].duration);
                // currentTripTime = String.valueOf(result.routes[0].legs[0].distance);
                Log.d("calculateDirectionsURL", "if");
                //Log.d("calculateDirectionsURL", "currentTripTime " + currentTripTime);
                // Log.d("calculateDirectionsURL", "currentTripDuration " + currentTripDuration);
                addPolyLinesToMap(directionResult, currentTripTime, currentTripDuration);
                //drawPolyLineOnMap(directionResult.getRoutes().get(0).getLegs());
            } else {
                onBackPressed();
                //showToast(TrackingActivity.this, "Currently NO Partner Available ");
                Log.d("calculateDirectionsURL", "else");
            }
        });
    }

    private void addPolyLinesToMap(DirectionResult result, String time, String dist) {
        Log.d("calculateDirectionsURL", "addPolyLinesToMap2");
        if (result != null) {
            if (result.getRoutes() != null) {
                if (!result.getRoutes().isEmpty()) {
                    if (result.getRoutes().get(0).getLegs() != null) {
                        if (!result.getRoutes().get(0).getLegs().isEmpty()) {
                            if (result.getRoutes().get(0).getLegs().get(0).getSteps() != null) {
                                if (!result.getRoutes().get(0).getLegs().get(0).getSteps().isEmpty()) {
                                    new Handler(Looper.getMainLooper()).post(() -> {
                                        if (newDecodedPath != null) {
                                            newDecodedPath.clear();
                                        }
                                        for (int s = 0; s < result.getRoutes().get(0).getLegs().get(0).getSteps().size(); s++) {
                                            //List<com.google.maps.model.LatLng> decodedPath = PolylineEncoding.decode(result.getRoutes().get(0).getLegs().get(0).getSteps().get(s).getPolyline().getPoints());
                                            List<com.google.maps.model.LatLng> decodedPath = PolylineEncoding.decode(result.getRoutes().get(0).getOverviewPolyLine().getPoints());
                                            Log.d("calculateDirectionsURL", "getOverviewPolyLine " + result.getRoutes().get(0).getOverviewPolyLine().getPoints());
                                            newDecodedPath = new ArrayList<>();
                                            for (com.google.maps.model.LatLng latLng : decodedPath) {
                                                newDecodedPath.add(new LatLng(latLng.lat, latLng.lng));
                                            }
                                            if (polyLine != null) {
                                                polyLine.remove();
                                            }
                                            polyLine = mGoogleMap.addPolyline(new PolylineOptions().addAll(newDecodedPath));
                                            polyLine.setColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                                            //polyLine.setClickable(false);
                                            //  mPolylineData.add(new PolylineData(polyLine, route.legs[0]));
                                        }
                                        polylineMarker(polyLine, time, dist);
                                        // onPolylineClick(polyLine)
                                        if (ZOOM_ROUTE) {
                                            zoomRoute(polyLine.getPoints());
                                        }
                                        Log.d("calculateDirectionsURL", "newDecodedPath " + newDecodedPath);
                                    });
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public void zoomRoute(List<LatLng> lstLatLngRoute) {
        if (mGoogleMap == null || lstLatLngRoute == null || lstLatLngRoute.isEmpty()) return;
        LatLngBounds.Builder boundsBuilder = new LatLngBounds.Builder();
        for (LatLng latLngPoint : lstLatLngRoute) boundsBuilder.include(latLngPoint);
        /* int routePadding = 120;*/
        // int routePadding = 220;
        int routePadding = 180;
        LatLngBounds latLngBounds = boundsBuilder.build();
        // mGoogleMap.setLatLngBoundsForCameraTarget(latLngBounds);
        mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngBounds(latLngBounds, routePadding), 1500, null
        );
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    public void polylineMarker(Polyline polyline, String time, String dist) {
        // mGoogleMap.clear();
        //Log.d("calculateDirectionsURL", "onPolylineClick ");
        //Log.d("calculateDirectionsURL", "onPolylineClick time " + time);
        //Log.d("calculateDirectionsURL", "onPolylineClick dist " + dist);
        // formatDate = new SimpleDateFormat("hh:mm:ss a");
        // for (PolylineData polylineData : mPolylineData) {
        LatLng startLocation = new LatLng(polyline.getPoints().get(0).latitude, polyline.getPoints().get(0).longitude);
        // Log.d("calculateDirectionsURL", "startLocation " + startLocation.latitude + "," + startLocation.longitude);
        //  Log.v("onPolylineClick", "startLocation.latitude" + startLocation.latitude);
        //  Log.v("onPolylineClick", "startLocation.longitude " + startLocation.longitude);
        LatLng endLocation = new LatLng(polyline.getPoints().get(polyline.getPoints().size() - 1).latitude, polyline.getPoints().get(polyline.getPoints().size() - 1).longitude);
        //Log.d("calculateDirectionsURL", "endLocation " + endLocation.latitude + "," + endLocation.longitude);
        //float bearing = (float) bearingBetweenLocations(startLocation, endLocation);
        //float bearing = bearingBetweenLatLngs(startLocation, endLocation);
        float bearing = 0;
        Log.v("calculateDirectionsURL", "RIDE_STARTED " + RIDE_STARTED);
        Log.v("calculateDirectionsURL", "RIDE_ACCEPTED " + RIDE_ACCEPTED);
        //rideStartMarker
        if (RIDE_ACCEPTED) {
            if (rideStartMarker == null) {
                rideStartMarker = mGoogleMap.addMarker(new MarkerOptions()
                                .position(endLocation)
                                .icon(BitmapDescriptorFactory.fromBitmap(createLayoutCustomMarker(TrackingActivity.this, R.drawable.pickup_icon, " ", true)))
                        //.snippet("Trip Duration: " + polylineData.getLeg().duration)
                );
            } else {
                rideStartMarker.setPosition(new LatLng(endLocation.latitude, endLocation.longitude));
            }
        } else if (RIDE_STARTED) {
            if (rideStartMarker == null) {
                rideStartMarker = mGoogleMap.addMarker(new MarkerOptions()
                                .position(endLocation)
                                .icon(BitmapDescriptorFactory.fromBitmap(createLayoutCustomMarker(TrackingActivity.this, R.drawable.drop_off_icon, " ", true)))
                        //.snippet("Trip Duration: " + polylineData.getLeg().duration)
                );
            } else {
                rideStartMarker.setPosition(new LatLng(endLocation.latitude, endLocation.longitude));
            }
        } else {
            Marker markerStart = mGoogleMap.addMarker(new MarkerOptions()
                            .position(startLocation)
                            .icon(BitmapDescriptorFactory.fromBitmap(createLayoutCustomMarker(TrackingActivity.this, R.drawable.pickup_icon, " ", true)))
                    //.snippet("Trip Duration: " + polylineData.getLeg().duration)
            );
            markerStart.showInfoWindow();
        }

        if (PICK_UP_TRACKING) {
                   /* if (trackerMarker != null) {
                        trackerMarker.remove();
                    }*/
                   /* if(MainApp.getInstance().getDriverCoordinate().getBearing()!=null){
                        bearing=Float.parseFloat(MainApp.getInstance().getDriverCoordinate().getBearing());
                    }*/
            //bearing= Float.parseFloat(MainApp.getInstance().getDriverCoordinate().getBearing());
            Log.v("GetDriverCoordinates", " tracking : " + MainApp.getInstance().getBearing());
            bearing = MainApp.getInstance().getBearing();
            // trackerMarker = mGoogleMap.addMarker(new MarkerOptions());
            Log.v("trackerMarker", " startLatLng.latitude : " + startLocation.latitude);
            Log.v("trackerMarker", " startLatLng.longitude : " + startLocation.longitude);
            Log.v("trackerMarker", "-------------- ");
            if (trackerMarker == null) {
                trackerMarker = mGoogleMap.addMarker(new MarkerOptions()
                                .position(startLocation)
                                .anchor(0.5f, 0.5f)
                                .flat(true)
                                .rotation(bearing)
                        //.icon(bitmapDescriptorFromVector(getResources().getDrawable(R.drawable.page_10_car_vertical, null)))
                );
                if (typeID.equalsIgnoreCase("9")) {
                    trackerMarker.setIcon(bitmapDescriptorFromVector(getResources().getDrawable(R.drawable.richshaw, null)));
                } else if (typeID.equalsIgnoreCase("10")) {
                    trackerMarker.setIcon(bitmapDescriptorFromVector(getResources().getDrawable(R.drawable.bike_map, null)));
                } else {
                    trackerMarker.setIcon(bitmapDescriptorFromVector(getResources().getDrawable(R.drawable.aerial_car, null)));
                }
                mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(startLocation, Constants.TRACK_ZOOM));
            } else {
                // bearing=MainApp.getInstance().getUserLocation().getLocation().getBearing();
                // Log.v("LocationService", " trackerMarker bearing : " + bearing);
                //rotateMarker(trackerMarker, bearing);
                animateMarkerTo(trackerMarker, startLocation.latitude, startLocation.longitude, bearing);
                //updateCamera(bearing,endLocation.latitude, endLocation.longitude);
            }

        }
        if (Resume_Ride_Tracking) {
            Resume_Ride_Tracking = false;
            stopLoader();
        }
        if (RideReceived) {
            captainInfoScreen();
            captainInfoSlider();
        }
    }

    private void trackingNonPolylineRoute() {
        Log.v("SHOW_POLYLINE", "trackingRoute2 ");
        ArrayList<LatLng> trackingMarkerPoints = new ArrayList<>();
        Log.v("newToken", "BOOKING_RESPONSE " + BOOKING_RESPONSE);
        Log.v("doTracking", "doTracking ");
        Log.v("doTracking", "BOOKING_RESPONSE " + BOOKING_RESPONSE);
        if (BOOKING_RESPONSE) {
            BOOKING_RESPONSE = false;
            diverLatLng = new LatLng(Double.parseDouble(dataList.getCaptain_info_data().getDriver_lat()), Double.parseDouble(dataList.getCaptain_info_data().getDriver_long()));
            Log.d("captainInfoData", "captainInfoData getBooking_id " + dataList.getCaptain_info_data().getBooking_id());
            trackingMarkerPoints.add(diverLatLng);
            trackingMarkerPoints.add(new LatLng(markerPoints.get(0).latitude, markerPoints.get(0).longitude));
            //calculateDirections(trackingMarkerPoints);
            trackMarkerOnRoute(trackingMarkerPoints);
          /*  if (Driver_Start_Ride) {
                Driver_Start_Ride = false;
                stopLoader();
            }
            if (Driver_Selected_Ride) {
                Driver_Selected_Ride = false;
                stopLoader();
            }*/
            //  }
        } else {
            if (MainApp.getInstance().getDriverCoordinate() != null) {
                //stopLoader();
                /*if (Driver_Start_Ride) {
                    Driver_Start_Ride = false;
                    stopLoader();
                }
                if (Driver_Selected_Ride) {
                    Driver_Selected_Ride = false;
                    stopLoader();
                }*/
                // Log.d("GetDriverCoordinates", "MainApp.getInstance().getDriverCoordinate().getLat() " + MainApp.getInstance().getDriverCoordinate().getLat());
                // Log.d("GetDriverCoordinates", "MainApp.getInstance().getDriverCoordinate().getLng() " + MainApp.getInstance().getDriverCoordinate().getLng());
                //MainApp.getInstance().getDriverCoordinate().getLng();
                diverLatLng = new LatLng(Double.parseDouble(MainApp.getInstance().getDriverCoordinate().getLat()), Double.parseDouble(MainApp.getInstance().getDriverCoordinate().getLng()));
                trackingMarkerPoints.add(diverLatLng);
                Log.d("GetDriverCoordinates", "PICK_UP_TRACKING " + PICK_UP_TRACKING);
             /*    showToastLong(TrackingActivity.this, diverLatLng.latitude+","+ diverLatLng.longitude+
                         "\n"+ getStringAddress(diverLatLng.latitude, diverLatLng.longitude));*/
                if (markerPoints == null) {
                    return;
                }
                if (RIDE_STARTED) {
                    if (markerPoints.size() < 2) {
                        return;
                    }
                    trackingMarkerPoints.add(new LatLng(markerPoints.get(1).latitude, markerPoints.get(1).longitude));
                    // trackingMarkerPoints.add(new LatLng(31.50967734630642,74.31757159320492));
                } else {
                    if (markerPoints.size() < 1) {
                        return;
                    }
                    PICK_UP_TRACKING = true;
                    trackingMarkerPoints.add(new LatLng(markerPoints.get(0).latitude, markerPoints.get(0).longitude));
                    // trackingMarkerPoints.add(new LatLng(31.50967734630642,74.31757159320492));
                }
                //calculateDirections(trackingMarkerPoints);
                if (trackingMarkerPoints.size() > 1) {
                    trackMarkerOnRoute(trackingMarkerPoints);
                }
            }
        }
        trackingMarkerPoints = null;
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    private void trackMarkerOnRoute(List<LatLng> latLngList) {
        Log.v("newTrackingRoute", "trackingRoute ELSE");
        Log.v("newTrackingRoute", "PICK_UP_TRACKING " + PICK_UP_TRACKING);
        Log.v("newTrackingRoute", "RideReceived " + RideReceived);
        /*new Handler(Looper.getMainLooper()).post(() -> {*/
        mHandlerUI.post(() -> {
            LatLng startLocation = new LatLng(latLngList.get(0).latitude, latLngList.get(0).longitude);
            if (tempLat == 0) {
                tempLat = latLngList.get(0).latitude;
            }
            if (tempLat == 0) {
                tempLng = latLngList.get(0).longitude;
            }
            if (PICK_UP_TRACKING) {
                float bearing = MainApp.getInstance().getBearing();
                // trackerMarker = mGoogleMap.addMarker(new MarkerOptions());
                Log.v("trackMarkerOnRoute", " startLatLng.latitude : " + startLocation.latitude);
                Log.v("trackMarkerOnRoute", " startLatLng.longitude : " + startLocation.longitude);
                Log.v("trackMarkerOnRoute", "-------------- ");

                if (trackerMarker == null) {
                    trackerMarker = mGoogleMap.addMarker(new MarkerOptions()
                                    .position(startLocation)
                                    .flat(true)
                                    .rotation(bearing)
                            //.icon(bitmapDescriptorFromVector(getResources().getDrawable(R.drawable.page_10_car_vertical, null)))
                    );
                    if (typeID.equalsIgnoreCase("9")) {
                        //trackerMarker.setIcon(bitmapDescriptorFromVector(ResourcesCompat.getDrawable(null, R.drawable.aerial_car, null)));
                        trackerMarker.setIcon(bitmapDescriptorFromVector(getResources().getDrawable(R.drawable.richshaw, null)));
                    } else if (typeID.equalsIgnoreCase("10")) {
                        trackerMarker.setIcon(bitmapDescriptorFromVector(getResources().getDrawable(R.drawable.bike_map, null)));
                        //trackerMarker.setIcon(bitmapDescriptorFromVector(ResourcesCompat.getDrawable(null, R.drawable.bike_map, null)));
                    } else {
                        trackerMarker.setIcon(bitmapDescriptorFromVector(getResources().getDrawable(R.drawable.aerial_car, null)));
                        // trackerMarker.setIcon(bitmapDescriptorFromVector(ResourcesCompat.getDrawable(null, R.drawable.aerial_car, null)));
                    }
                    mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(startLocation, Constants.TRACK_ZOOM));
                } else {
                 /*   showToast(MapActivity.this, startLocation.latitude+","+ startLocation.longitude+
                            "\n"+ getStringAddress(startLocation.latitude, startLocation.longitude));*/
                    //` Log.v("newToken", " trackerMarker bearing : " + bearing);
                    Log.d("rotateMarker", "bearing: " + bearing);
                    //bearing=MainApp.getInstance().getUserLocation().getLocation().getBearing();
                    // Log.v("LocationService", " trackerMarker bearing : " + bearing);
                    //rotateMarker(trackerMarker, bearing);
                    animateMarkerTo(trackerMarker, startLocation.latitude, startLocation.longitude,bearing);
                   /* CameraPosition cameraPosition = new CameraPosition.Builder()
                            .target(startLocation)
                            .zoom(Constants.TRACK_ZOOM)
                            .bearing(bearing)
                            .build();*/
                   /* mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(startLocation, Constants.TRACK_ZOOM));*/
                   // mGoogleMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition), 1000, null);
                    //updateCamera(bearing,endLocation.latitude, endLocation.longitude);
                }
              /*  if (!isAlreadyDoingAnimateMarker) {
                    mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(startLocation, Constants.TRACK_ZOOM));
                }*/

                //mGoogleMap.animateCamera(CameraUpdateFactory.newCameraPosition(newCamPos));
            }
            LatLng endLocation = new LatLng(latLngList.get(1).latitude, latLngList.get(1).longitude);
            Log.d("newTrackingRoute", "lat long " + endLocation.latitude + "," + endLocation.longitude);
            //Log.d("newTrackingRoute", getStringAddress(endLocation.latitude, endLocation.longitude));
            Log.d("newTrackingRoute", "---------------");
            if (RIDE_ACCEPTED) {
                if (rideStartMarker == null) {
                    rideStartMarker = mGoogleMap.addMarker(new MarkerOptions()
                                    .position(endLocation)
                                    .icon(BitmapDescriptorFactory.fromBitmap(createLayoutCustomMarker(TrackingActivity.this, R.drawable.pickup_icon, " ", true)))
                            //.snippet("Trip Duration: " + polylineData.getLeg().duration)
                    );
                } else {
                    rideStartMarker.setPosition(new LatLng(endLocation.latitude, endLocation.longitude));
                    //animateMarkerTo(rideStartMarker, endLocation.latitude, endLocation.longitude);
                }
            } else if (RIDE_STARTED) {
                if (SKIP_DROP_OFF == 1) {
                    if (rideStartMarker != null) {
                        rideStartMarker.remove();
                    }
                    return;
                }
                if (rideStartMarker == null) {
                    rideStartMarker = mGoogleMap.addMarker(new MarkerOptions()
                            .position(endLocation)
                            .icon(BitmapDescriptorFactory.fromBitmap(createLayoutCustomMarker(TrackingActivity.this, R.drawable.drop_off_icon, " ", true)))
                    );
                } else {
                    rideStartMarker.setPosition(new LatLng(endLocation.latitude, endLocation.longitude));
                    // animateMarkerTo(rideStartMarker, endLocation.latitude, endLocation.longitude);
                }
            }
            if (Resume_Ride_Tracking) {
                Resume_Ride_Tracking = false;
                stopLoader();
            }
            if (RideReceived) {
                Log.v("newTrackingRoute", "RideReceived captainInfoScreen" + RideReceived);
                captainInfoScreen();
                captainInfoSlider();
            }
            startLocation = null;
        });
    }

    public static Bitmap createLayoutCustomMarker(Context context, @DrawableRes int resource, String time, Boolean bol) {
        @SuppressLint("InflateParams") View marker = ((LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.custom_marker_layout, null);
        ImageView markerImage;
        if (bol) {
            markerImage = marker.findViewById(R.id.pickUp);
            markerImage.setImageResource(resource);
            TextView waitTime = marker.findViewById(R.id.waitTime);
            waitTime.setText(time);
            marker.findViewById(R.id.dropOffDurationLayout).setVisibility(View.GONE);
        } else {
            markerImage = marker.findViewById(R.id.arrivalImage);
            markerImage.setImageResource(resource);
            TextView arrivalTime = marker.findViewById(R.id.arrivalTime);
            arrivalTime.setText(time);
        }
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((Activity) context).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        marker.setLayoutParams(new ViewGroup.LayoutParams(52, ViewGroup.LayoutParams.WRAP_CONTENT));
        marker.measure(displayMetrics.widthPixels, displayMetrics.heightPixels);
        marker.layout(0, 0, displayMetrics.widthPixels, displayMetrics.heightPixels);
        marker.buildDrawingCache();
        Bitmap bitmap = Bitmap.createBitmap(marker.getMeasuredWidth(), marker.getMeasuredHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        marker.draw(canvas);
        return bitmap;
    }

    public BitmapDescriptor bitmapDescriptorFromVector(Drawable drawable) {
        Canvas canvas = new Canvas();
        Log.v("bitmapDescriptor", "getIntrinsicWidth " + drawable.getIntrinsicWidth());
        Log.v("bitmapDescriptor", "getIntrinsicHeight " + drawable.getIntrinsicHeight());
        //  Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Bitmap bitmap = Bitmap.createBitmap(120, 120, Bitmap.Config.ARGB_8888);
        canvas.setBitmap(bitmap);
        //  drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
        drawable.setBounds(0, 0, 120, 120);
        drawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

    public void rotateMarker(final Marker marker, final float toRotation) {
        Log.d("rotateMarker", "rotateMarker: " + toRotation);
        if (!isRotating) {
            isRotating = true;
            //final Handler handler = new Handler();
            final Handler handler = new Handler(Looper.getMainLooper());
            final long start = SystemClock.uptimeMillis();
            final float startRotation = marker.getRotation();
            final long duration = 1000;
            float deltaRotation = Math.abs(toRotation - startRotation) % 360;
            final float rotation = (deltaRotation > 180 ? 360 - deltaRotation : deltaRotation) *
                    ((toRotation - startRotation >= 0 && toRotation - startRotation <= 180) ||
                            (toRotation - startRotation <= -180 && toRotation - startRotation >= -360) ? 1 : -1);
            final LinearInterpolator interpolator = new LinearInterpolator();
            handler.post(new Runnable() {
                @Override
                public void run() {
                    long elapsed = SystemClock.uptimeMillis() - start;
                    float t = interpolator.getInterpolation((float) elapsed / duration);
                    marker.setRotation((startRotation + t * rotation) % 360);
                    if (t < 1.0) {
                        // Post again 16ms later.
                        handler.postDelayed(this, 16);
                    } else {
                        isRotating = false;
                    }
                }
            });
        }
    }

    private void animateMarkerTo(final Marker marker, final double lat, final double lng,float bearing) {
       // Log.v("isAlreadyDoing", "isAlreadyDoingAnimateMarker " + isAlreadyDoingAnimateMarker);
       // if (!isAlreadyDoingAnimateMarker) {
           // mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(lat, lng), Constants.TRACK_ZOOM));
        CameraPosition cameraPosition = new CameraPosition.Builder()
                .target(new LatLng(lat,lng))
                .zoom(Constants.TRACK_ZOOM)
                .bearing(bearing)
                .build();
        mGoogleMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition), 1000, null);
        rotateMarker(trackerMarker, bearing);

            isAlreadyDoingAnimateMarker = true;
            Log.v("isAlreadyDoing", "isAlreadyDoingAnimateMarker " + isAlreadyDoingAnimateMarker);
            if (animateMarkerHandler == null) {
                animateMarkerHandler = new Handler(Looper.getMainLooper());
            }
       // showToast(TrackingActivity.this, lat+","+ lng+ "\n"+ getStringAddress(lat, lng));
            //animateMarkerHandler = new Handler();
            final long start = SystemClock.uptimeMillis();
            /*final long DURATION_MS = 5000;*/
            final long DURATION_MS = 4000;
            final Interpolator interpolator = new AccelerateDecelerateInterpolator();
            final LatLng startPosition = marker.getPosition();
            //BEARING_FLAG = true;
            /*animateMarkerHandler.post(new Runnable() {*/
            animateMarkerHandler.post(new Runnable() {

                @Override
                public void run() {
                    float elapsed = SystemClock.uptimeMillis() - start;
                    float t = elapsed / DURATION_MS;
                    //  Log.v("isAlreadyDoing", "elapsed " + elapsed);
                    float v = interpolator.getInterpolation(t);
                   // LatLng startingLocation=new LatLng(startPosition.latitude,startPosition.latitude);
                    double currentLat = (lat - startPosition.latitude) * v + startPosition.latitude;
                    double currentLng = (lng - startPosition.longitude) * v + startPosition.longitude;
                   // LatLng endingLocation=new LatLng(currentLat,currentLng);
                    //double targetBearing=getBearing(startingLocation,endingLocation);

                    marker.setPosition(new LatLng(currentLat, currentLng));
                    marker.setFlat(true);
                    //marker.setRotation((float) targetBearing);
                   // rotateMarker(trackerMarker, (float) targetBearing);
                    marker.setAnchor(0.5f, 0.5f);
                    // if animation is not finished yet, repeat
                    if (t < 1) {
                        animateMarkerHandler.postDelayed(this, 16);
                    }
                    // isAlreadyDoing = false;
                }
            });
           /* Log.v("isAlreadyDoing", "---------------------------------- ");
            animateMarkerHandler.postDelayed(() -> {
                Log.v("isAlreadyDoing", "((((((((((((((((((((((((((((((((((((((((((((((( ");
                isAlreadyDoingAnimateMarker = false;
            }, DURATION_MS);*/
      //  }
    }

    private void checkBookingStatus() {
        //startLoader();
        Log.v("checkBookingStatus", " checkBookingStatus  ");
        viewModel.bookingStatusRequest(MainApp.getInstance().getUserData().getUserId());
        viewModel.bookingStatusRepose().observe(this, dataModelObject -> {
            //  stopLoader();
            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                bookingStatusData = dataModelObject.getData().getBookingInfo();
                SKIP_DROP_OFF = bookingStatusData.getIs_skip_dropoff();
                typeID = dataModelObject.getData().getBookingInfo().getVehicle_type_id();
                dataList = MainApp.getInstance().getDataList();
                captainInfoScreen();
                /* resumeRideScenario();*/
            } else {
                // ((BaseActivity) getActivity()).showToast(getActivity(), dataModelObject.getError().getMessage());
                //Log.v("bookingStatusRepose", "error " + dataModelObject.getError().getMessage());
                if (dataModelObject.getError().getMessage() != null) {
                    //showToast(TrackingActivity.this, dataModelObject.getError().getMessage());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                } else if (dataModelObject.getError().getMessages() != null) {
                    //showToast(TrackingActivity.this, dataModelObject.getError().getMessages().toString());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                }
            }
        });
    }

    private void stopRideBookingStatusService() {
        Log.v("stopRideBooking", " stopRideBookingStatusService  ");
        Intent myService = new Intent(TrackingActivity.this, RideBookingStatus.class);
        myService.setAction(Constants.ACTION_STOP_FOREGROUND_SERVICE);
        stopService(myService);
    }

    private void startGetDriverCoordinatesService() {
        if (!isGetDriverCoordinatesServiceRunning()) {
            Intent serviceIntent = new Intent(this, GetDriverCoordinates.class);
            serviceIntent.setAction(Constants.ACTION_START_FOREGROUND_SERVICE);
           /* if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                TrackingActivity.this.startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }*/
            startService(serviceIntent);
        }
    }

    private boolean isGetDriverCoordinatesServiceRunning() {
        ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if ("com.oyla.passenger.services.location.GetDriverCoordinates".equals(service.service.getClassName())) {
                Log.d("GetDriverCoordinates", "GetDriverCoordinates service is already running.");
                return true;
            }
        }
        Log.d("GetDriverCoordinates", "GetDriverCoordinates: location service is not running.");
        return false;
    }

    private void call(String number) {
        Log.v("callUser", "number " + number);
        Intent intent = new Intent(Intent.ACTION_CALL);
        intent.setData(Uri.parse("tel:" + number));
        startActivity(intent);
        final Handler handler = new Handler(Looper.getMainLooper());
        //Do something after 100ms
        handler.postDelayed(this::stopLoader, 100);
    }

    private void cancelReasonDialog(String userId, String bookingId) {
        getChatMessage();

        Log.v("cancelReasonDialog", "cancelReasonDialog");
        // Log.v("cancelReasonDialog","bookingId "+bookingId);
        if (bookingStatusData != null && bookingStatusData.getBooking_id() != null) {
            bookingId = bookingStatusData.getBooking_id();
            Log.v("cancelReasonDialog", "bookingId bookingStatusData " + bookingId);
        }

        final Dialog dialog = new Dialog(TrackingActivity.this);
        dialog.setContentView(R.layout.cancel_reason_dialog);
        RadioGroup rGroup = dialog.findViewById(R.id.radioGroup);
        String finalBookingId = bookingId;
        rGroup.setOnCheckedChangeListener((group, checkedId) -> {
            RadioButton checkedRadioButton = group.findViewById(checkedId);
            RideReceived = false;
           /* if (FIND_CAPTAIN_CANCEL) {
                // findCaptainCancelFlagReset();
            } else {*/
            /* afterRideAcceptCancelFlag();*/
            // }
            String chatMessages = "";
            if (chatDataModelsList != null && chatDataModelsList.size() > 0) {
                chatMessages = new Gson().toJson(chatDataModelsList);
            } else {
                chatMessages = "";
            }
            stopLoader();
            viewModel.sendCancelRideRequest(userId, finalBookingId, checkedRadioButton.getText().toString(), chatMessages);
            startLoader();
            dialog.dismiss();
            cancelRideApiResponse();
        });
        dialog.show();
        dialog.setCancelable(true);
        Window window = dialog.getWindow();
        assert window != null;
        window.setGravity(Gravity.BOTTOM);
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private void afterRideAcceptCancelFlag() {
        if (!(TrackingActivity.this).isFinishing()) {
            startLoader();
        }
        if (trackerMarker != null) {
            trackerMarker = null;
        }
        if (rideStartMarker != null) {
            rideStartMarker = null;
        }
        if (animateMarkerHandler != null) {
            animateMarkerHandler.removeCallbacksAndMessages(null);
        }
        FINDING_CAPTAIN = false;
        RideReceived = false;
        PICK_UP_TRACKING = false;
        MainApp.getInstance().Booking_REQUEST = false;
        CONFIRM_RIDE = false;
        SELECTED_RIDE = false;
        // markerPoints.remove(markerPoints.get(markerPoints.size() - 1));
        markerPoints.clear();
        routeConfirm = false;
        Driver_Selected_Ride = false;
        Driver_Start_Ride = false;
        RIDE_ACCEPTED = false;
        RIDE_STARTED = false;
        Resume_Ride_Tracking = false;
        binding.captainInfoLayout.captainInfo1.setVisibility(View.GONE);
        mGoogleMap.clear();
        contractView2();
    }

    private void cancelRideApiResponse() {
        ZOOM_ROUTE = true;
        Constants.TRACK_ZOOM = DEFAULT_ZOOM;
        Log.v("cancelRideApiResponse", "cancelRideApiResponse ");
        viewModel.receiveCancelRideRepose().observe(this, dataModelObject -> {
            stopLoader();
            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                SHOW_POLYLINE = false;
                afterRideAcceptCancelFlag();
                Intent myService = new Intent(TrackingActivity.this, GetDriverCoordinates.class);
                myService.setAction(Constants.ACTION_STOP_FOREGROUND_SERVICE);
                stopService(myService);
                Log.v("cancelRideApiResponse", "cancelRideApiResponse 1 ");
                SharedPreferences sharedPreferences2 = TrackingActivity.this.getSharedPreferences("Driver_Info", 0);
                sharedPreferences2.edit().remove("Driver_Info_Object").apply();
                SharedPrefManager.getInstance(TrackingActivity.this).removeBookingInfo();
                Log.v("cancelRideApiResponse", "cancelRideApiResponse 2");
                if (MainApp.getInstance() != null) {
                    MainApp.getInstance().setDriverCoordinate(null);
                }
                showToastLong(TrackingActivity.this, "Ride has been Cancel");
                AFTER_RIDE_CANCEL = false;
                FIND_CAPTAIN_CANCEL = false;
                RideReceived = false;
                FINDING_CAPTAIN = false;
                SHOW_FINISH_DIALOG = false;
                dataList = null;
                Constants.FIRE_BASE_NOTIFY = false;
                MainApp.getInstance().setDataList(null);
                onBackPressed();
            } else {
                if (dataModelObject.getError().getMessage() != null) {
                    showToast(TrackingActivity.this, dataModelObject.getError().getMessage());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                } else if (dataModelObject.getError().getMessages() != null) {
                    showToast(TrackingActivity.this, dataModelObject.getError().getMessages().toString());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                }
                // showToast(MapActivity.this, dataModelObject.getError().getMessage());
            }
        });
    }

    private void rideStart() {
        isAlreadyDoingAnimateMarker = false;
      /*  if (animateMarkerHandler != null) {
            animateMarkerHandler =null;
        }*/
        SHOW_FINISH_DIALOG = true;
        RIDE_ACCEPTED = false;
        RIDE_STARTED = true;
        mGoogleMap.clear();
        if (trackerMarker != null) {
            trackerMarker = null;
        }
        if (rideStartMarker != null) {
            rideStartMarker.remove();
            rideStartMarker = null;
        }
        if (animateMarkerHandler != null) {
            animateMarkerHandler.removeCallbacksAndMessages(null);
        }
        //showToast(MapActivity.this, Messages.rideStarted);
        //rideCurrentStatusText = "Moving toward destination";
        rideCurrentStatusText =  getResources().getString(R.string.rideStarted);

        driverSelectedRide();
    }

    private void rideComplete() {
        Log.v("refreshRide", " rideComplete --");
        if (trackerMarker != null) {
            trackerMarker = null;
        }
        if (animateMarkerHandler != null) {
            animateMarkerHandler.removeCallbacksAndMessages(null);
        }
        if (rideStartMarker != null) {
            rideStartMarker.remove();
            rideStartMarker = null;
        }
        //nearestRiderMarker
        mGoogleMap.clear();
        binding.captainInfoLayout.totalFairText.setText("");
        PICK_UP_TRACKING = false;
        MainApp.getInstance().Booking_REQUEST = false;
        CONFIRM_RIDE = false;
        SELECTED_RIDE = false;
        if (markerPoints != null) {
            if (markerPoints.size() > 1) {
                markerPoints.remove(markerPoints.get(markerPoints.size() - 1));
            } else {
                markerPoints.clear();
            }
        }
        routeConfirm = false;
        Driver_Selected_Ride = false;
        Driver_Start_Ride = false;
        RIDE_ACCEPTED = false;
        RIDE_STARTED = false;
        Resume_Ride_Tracking = false;

        binding.captainInfoLayout.captainInfo1.setVisibility(View.GONE);
        // showToast(MapActivity.this, "Ride has completed");
        MainApp.getInstance().Booking_REQUEST = false;
        // createNotification(Messages.rideCompleted);
        //rideCurrentStatusText = Messages.rideCompleted;
        rideCurrentStatusText =  getResources().getString(R.string.rideCompleted);
        Intent myService = new Intent(TrackingActivity.this, GetDriverCoordinates.class);
        myService.setAction(Constants.ACTION_STOP_FOREGROUND_SERVICE);
        stopService(myService);
        contractView2();
        Log.v("refreshRide", " finishRideDialog");
        Log.v("refreshRide", " finishRideDialog RideReceived " + RideReceived);
        Log.v("refreshRide", " finishRideDialog SHOW_FINISH_DIALOG " + SHOW_FINISH_DIALOG);
        binding.captainInfoLayout.totalFairText.setText("");
        binding.captainInfoLayout.totalDistanceText.setText("");
        binding.captainInfoLayout.expectedTimeText.setText("");
        if (SHOW_FINISH_DIALOG) {
            SHOW_FINISH_DIALOG = false;
            Log.v("finishRideDialog", "FINISH_DIALOG_VIEW -- " + FINISH_DIALOG_VIEW);
            if (!FINISH_DIALOG_VIEW) {
                finishRideDialog();
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private void finishRideDialog() {
        FINISH_DIALOG_VIEW = true;
        Log.v("refreshRide", "finishRideDialog");
        Log.v("finishRideDialog", "FINISH_DIALOG_VIEW " + FINISH_DIALOG_VIEW);
        //final Dialog dialog = new Dialog(MapActivity.this, R.style.full_screen_dialog);
        final Dialog dialog = new Dialog(TrackingActivity.this);
        //dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.finsh_and_review_ride_dialog);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        // EditText enterVoucherEdiText = dialog.findViewById(R.id.enterPromoEdiText);
        // TextInputLayout enterVoucherTextInput = dialog.findViewById(R.id.enterPromoTextInput);
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        dialog.findViewById(R.id.complete).setOnClickListener(v -> {
            dialog.dismiss();
            ((TextView) dialog.findViewById(R.id.totalFareText)).setText("");
            ((TextView) dialog.findViewById(R.id.totalDistanceText)).setText("");
            ((TextView) dialog.findViewById(R.id.expectedTimeText)).setText("");
            Log.v("captainInfoScreen", "dataList " + dataList);
            Intent i = new Intent(TrackingActivity.this, CaptainReviewActivity.class);
            i.putExtra("bookingId", bookingStatusData.getBooking_id());
            i.putExtra("passengerId", bookingStatusData.getPassenger_id());
            i.putExtra("driverId", bookingStatusData.getDriver_id());
            startActivity(i);
            finish();
        });
        dialog.findViewById(R.id.nextReview).setOnClickListener(v -> {
            dialog.dismiss();
            Intent i = new Intent(TrackingActivity.this, CaptainReviewActivity.class);
            i.putExtra("bookingId", bookingStatusData.getBooking_id());
            i.putExtra("passengerId", bookingStatusData.getPassenger_id());
            i.putExtra("driverId", bookingStatusData.getDriver_id());
            startActivity(i);
            finish();
        });
        String final_amount;
        String final_distance;
        String final_time;
        if (dataList != null) {
            if (dataList.getCaptain_info_data() != null && dataList.getCaptain_info_data().getFinal_amount() != null
                    && dataList.getCaptain_info_data().getFinal_time() != null) {
                Log.v("refreshRide", "finishRideDialog if");
                final_distance = dataList.getCaptain_info_data().getFinal_distance();
                final_amount = String.valueOf(Math.round(Double.parseDouble(dataList.getCaptain_info_data().getFinal_amount())));
                final_time = dataList.getCaptain_info_data().getFinal_time();
            } else {
                Log.v("refreshRide", "finishRideDialog else");
                final_distance = bookingStatusData.getDistance_kilomiters();
                final_amount = String.valueOf(Math.round(Double.parseDouble(bookingStatusData.getFinal_amount())));
                final_time = bookingStatusData.getRide_complete_time();
            }
        } else {
            Log.v("refreshRide", "finishRideDialog 2nd else");
            final_distance = bookingStatusData.getDistance_kilomiters();
            final_amount = String.valueOf(Math.round(Double.parseDouble(bookingStatusData.getFinal_amount())));
            final_time = bookingStatusData.getRide_complete_time();
        }
        double value = Double.parseDouble(final_distance);
        final_distance = String.valueOf(Double.parseDouble(new DecimalFormat("##.##").format(value)));
        ((TextView) dialog.findViewById(R.id.totalFareText)).setText(getResources().getString(R.string.currency) + " " + final_amount);
        ((TextView) dialog.findViewById(R.id.totalDistanceText)).setText(final_distance + " " + getResources().getString(R.string.km));
        ((TextView) dialog.findViewById(R.id.expectedTimeText)).setText(final_time + " " + getResources().getString(R.string.min));
        SharedPreferences sharedPreferences = TrackingActivity.this.getSharedPreferences("Driver_Info", 0);
        sharedPreferences.edit().remove("Driver_Info_Object").apply();
        SharedPrefManager.getInstance(TrackingActivity.this).removeBookingInfo();
        if (!(TrackingActivity.this).isFinishing()) {
            //show dialog
            dialog.show();
        }
        Window window = dialog.getWindow();
        assert window != null;
        window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        window.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.colorTransparent2)));
        window.setGravity(Gravity.CENTER);
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {

    }

    @Override
    protected void onDestroy() {
        stopLoader();
        stopRideBookingStatusService();
        Intent broadcastIntent = new Intent();
        broadcastIntent.setAction("restartservice");
        broadcastIntent.setClass(this, Restarter.class);
        this.sendBroadcast(broadcastIntent);
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        finish();
        //super.onBackPressed();
    }

    private void getChatMessage() {
        DatabaseReference messageRef;
        chatDataModelsList = new ArrayList<>();
        //messageRef= FirebaseDatabase.getInstance().getReference();
        messageRef = rootDatabaseReference.child(bookingId).child("messages");
        // messageRef.child(bookingId).child("messages");
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NotNull DataSnapshot dataSnapshot) {
                // Get Post object and use the values to update the UI
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    /*ChatDataModel chatDataModel = ds.getValue(ChatDataModel.class);*/
                    ChatDataModel chatDataModel = ds.getValue(ChatDataModel.class);
                    chatDataModelsList.add(chatDataModel);
                    assert chatDataModel != null;
                    //  Log.v("bookingIdFCM", "chatDataModel--"+chatDataModel.getMessage());
                }
                    /*if(chatDataModelsList.size()>0){
                        Gson gson = new GsonBuilder().create();
                        chatMessagesArray= gson.toJsonTree(chatDataModelsList).getAsJsonArray();
                        Log.w("FirebaseAuth", "chat_messages  myCustomArray" +chatMessagesArray);

                    }*/
                String json = new Gson().toJson(chatDataModelsList);
                Log.v("bookingIdFCM", "messageData myCustomArray getChatMessage" + json);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Getting Post failed, log a message
                Log.w("FirebaseAuth", "loadPost:onCancelled", databaseError.toException());
            }
        };
        messageRef.addValueEventListener(eventListener);
    }

    @Override
    public void newChatMessage(String message) {
        runOnUiThread(() -> {
            //stopLoader();
            Log.v("newChatMessage", "newChatMessage  " + message);
            Log.v("newChatMessage", "newChatMessage  " + message);
            newChatMessageCounter++;
            getSharedPreferences("newChatMessageCounter", MODE_PRIVATE).edit().putString("messageCounter", String.valueOf(newChatMessageCounter)).apply();
            binding.captainInfoLayout.chatMessageBadge.setVisibility(View.VISIBLE);
            binding.captainInfoLayout.chatMessageBadge.setText(String.valueOf(newChatMessageCounter));
            Constants.badgeCounter = 0;
            // showToast(TrackingActivity.this,message);
        });
    }

    private void resetChatbadgeCounter() {
        Log.v("newChatMessageCounter", "resetChatbadgeCounter before " + newChatMessageCounter);
        binding.captainInfoLayout.chatMessageBadge.setVisibility(View.GONE);
        newChatMessageCounter = 0;
        getSharedPreferences("newChatMessageCounter", MODE_PRIVATE).edit().putString("messageCounter", String.valueOf(newChatMessageCounter)).apply();
        Log.v("newChatMessageCounter", "resetChatbadgeCounter after " + newChatMessageCounter);
    }

    private void getFirebaseTracking() {
       /* DatabaseReference trackingRef;
        trackingRef = rootDatabaseReference.child(bookingId).child("tracking");*/
        Log.v("getFirebaseTracking", "  getFirebaseTracking ");
        stopLoader();
        trackingRef = rootDatabaseReference.child(bookingId).child("tracking");
        ValueEventListener trackingEventListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NotNull DataSnapshot dataSnapshot) {
                // Get Post object and use the values to update the UI
                FirebaseTracking firebaseTracking = dataSnapshot.getValue(FirebaseTracking.class);
                if (firebaseTracking != null) {
                    Log.v("getFirebaseTracking", "  Lat "+  firebaseTracking.getLat());
                    Log.v("getFirebaseTracking", "  Lng "+ firebaseTracking.getLng());
                    Log.v("getFirebaseTracking", "  bearing "+ firebaseTracking.getBearing());
                    Log.v("getFirebaseTracking", "  ---------------------------- ");
                    /*public DriverCoordinate(String lat, String lng, String city, String area_name, String bearing, String decode_path, String current_arrival_time, String current_distance) {*/
                    DriverCoordinate  driverCoordinate=new DriverCoordinate(String.valueOf(Objects.requireNonNull(firebaseTracking).getLat()),String.valueOf(Objects.requireNonNull(firebaseTracking).getLng()));
                    MainApp.getInstance().setDriverCoordinate(driverCoordinate);
                    MainApp.getInstance().setBearing(Float.parseFloat(Objects.requireNonNull(firebaseTracking).getBearing()));
                    showFirebaseTacking();
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Getting Post failed, log a message
                Log.w("getFirebaseTracking", "loadPost:onCancelled", databaseError.toException());
            }
        };
        trackingRef.addValueEventListener(trackingEventListener);
    }
    private void showFirebaseTacking(){
        Log.v("SHOW_POLYLINE", "doTracking SHOW_POLYLINE " + SHOW_POLYLINE);
        Log.v("SHOW_POLYLINE", "SKIP_DROP_OFF " + SKIP_DROP_OFF);
        Log.v("SHOW_POLYLINE", "RIDE_STARTED " + RIDE_STARTED);

        if (dataList == null || bookingStatusData == null) {
            checkBookingStatus();
            return;
        }

        if (SKIP_DROP_OFF == 1 && RIDE_STARTED) {
            SHOW_POLYLINE = false;
            binding.captainInfoLayout.totalDistanceText.setText("");
            binding.captainInfoLayout.expectedTimeText.setText("");
            stopLoader();
        }
        if (SHOW_POLYLINE) {
            //newTrackingRoute();
            Log.v("SHOW_POLYLINE", "trackingPolylineRoute ");
            trackingPolylineRoute();
            //  SHOW_POLYLINE=false;
        } else {
            if (polyLine != null) {
                Log.v("SHOW_POLYLINE", "trackingNonPolylineRoute ");
                Log.v("SHOW_POLYLINE", "polyLine ");
                polyLine.remove();
                polyLine = null;
                if (rideStartMarker != null) {
                    Log.v("SHOW_POLYLINE", "rideStartMarker ");
                    rideStartMarker.remove();
                    rideStartMarker = null;
                }
            }
            trackingNonPolylineRoute();
        }
    }
    public static double getBearing(LatLng source,LatLng destination) {

/*//Source
        JSONObject source = step.getJSONObject("start_location");
        double lat1 = Double.parseDouble(source.getString("lat"));
        double lng1 = Double.parseDouble(source.getString("lng"));

// destination
        JSONObject destination = step.getJSONObject("end_location");
        double lat2 = Double.parseDouble(destination.getString("lat"));
        double lng2 = Double.parseDouble(destination.getString("lng"));*/


        double lat1 = source.latitude;
        double lng1 = source.longitude;


        double lat2 = destination.latitude;
        double lng2 = destination.longitude;

        double fLat = degreeToRadians(lat1);
        double fLong = degreeToRadians(lng1);
        double tLat = degreeToRadians(lat2);
        double tLong = degreeToRadians(lng2);

        double dLon = (tLong - fLong);

        double degree = radiansToDegree(Math.atan2(sin(dLon) * cos(tLat),
                cos(fLat) * sin(tLat) - sin(fLat) * cos(tLat) * cos(dLon)));

        if (degree >= 0) {
            return degree;
        } else {
            return 360 + degree;
        }
    }

    private static double degreeToRadians(double latLong) {
        return (Math.PI * latLong / 180.0);
    }

    private static double radiansToDegree(double latLong) {
        return (latLong * 180.0 / Math.PI);
    }
}