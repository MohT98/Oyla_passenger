package com.oyla.passenger.datamodels.jsonreponsedatamodel;

import com.oyla.passenger.datamodels.usermodel.ErrorList;

public class DataModelObject {

    private String status;
    private String msg;
    private String token_type;
    private String accessToken;
    private DataList data;
    private ErrorList error;
    private String notification_type;

    public ErrorList getError() {
        return error;
    }

    public DataList getData() {
        return data;
    }

    public String getStatus() {
        return status;
    }

    public String getMsg() {
        return msg;
    }

    public String getToken_type() {
        return token_type;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public String getNotification_type() {
        return notification_type;
    }
}
