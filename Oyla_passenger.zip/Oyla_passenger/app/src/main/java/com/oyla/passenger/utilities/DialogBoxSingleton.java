package com.oyla.passenger.utilities;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.app.ActivityCompat;

import com.google.android.material.textfield.TextInputLayout;
import com.oyla.passenger.R;
import com.oyla.passenger.datamodels.usermodel.ErrorList;
import com.oyla.passenger.ui.BaseActivity;

public class DialogBoxSingleton {

   /* private static MySingleton instance = null;
    private static Context context;

    private static MySingleton ourInstance = new MySingleton();*/

   /* private static final MySingleton ourInstance = new MySingleton();
    public static MySingleton getInstance() {
        return ourInstance;
    }*/

    private static DialogBoxSingleton instance;

    public static DialogBoxSingleton getInstance() {
        if (instance == null) {
            synchronized (DialogBoxSingleton.class) {
                if (instance == null)
                    instance = new DialogBoxSingleton();
            }
        }
        // Return the instance
        return instance;
    }


    private DialogBoxSingleton() {
    }

    public void showErrorPopup(Context context, ErrorList errorModel) {
        String error = null;
        if (errorModel.getMessage() != null) {
            error = errorModel.getMessage();
            //  Log.v("playstore","if playstore "+error);
        } else {
            for (String message : errorModel.getMessages()) {
                error = message;
                // Log.v("playstore","else playstore "+error);
            }
        }
        // Log.v("playstore","playstore "+error);

        final Dialog dialog = new Dialog(context);
        dialog.setContentView(R.layout.error_popup);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        TextView errorBody = dialog.findViewById(R.id.errorBody);
        errorBody.setText(error != null ? error : context.getString(R.string.error));
        Button okay = dialog.findViewById(R.id.next);

        String finalError = error;
        okay.setOnClickListener(v -> {
            if (finalError.equalsIgnoreCase("Please update to latest oyla app version from playstore.")) {
                final String appPackageName = context.getPackageName(); // getPackageName() from Context or Activity object
                try {
                    context.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
                } catch (android.content.ActivityNotFoundException anfe) {
                    context.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
                }
            }
            dialog.dismiss();
        });
        dialog.show();
        Window window = dialog.getWindow();
        assert window != null;
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    public void showPopup(Context context, String message, Boolean bol) {
        final Dialog dialog = new Dialog(context);
        dialog.setContentView(R.layout.error_popup);
        //dialog.setCancelable(false);
        dialog.setCancelable(bol);
        //dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        TextView errorBody = dialog.findViewById(R.id.errorBody);
        errorBody.setText(message != null ? message : context.getString(R.string.error));
        Button okay = dialog.findViewById(R.id.next);
        okay.setOnClickListener(v -> dialog.dismiss());
        /*okay.setOnClickListener(v -> dialog.dismiss());*/
        dialog.show();
        Window window = dialog.getWindow();
        assert window != null;
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    public void showInternetPopup(Context context, String message, Boolean bol) {
        final Dialog dialog = new Dialog(context);
        dialog.setContentView(R.layout.error_popup);
        //dialog.setCancelable(false);
        dialog.setCancelable(bol);
        //dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        TextView errorBody = dialog.findViewById(R.id.errorBody);
        errorBody.setText(message != null ? message : context.getString(R.string.error));
        Button okay = dialog.findViewById(R.id.next);
        okay.setOnClickListener(v -> {
            if(!haveNetworkConnection(context)){
                context.startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
            }
            dialog.dismiss();
        });
        /*okay.setOnClickListener(v -> dialog.dismiss());*/

            dialog.show();


        Window window = dialog.getWindow();
        assert window != null;
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }


    /*    public static synchronized MySingleton getInstance() {
            if (context == null) {
                throw new IllegalArgumentException("Impossible to get the instance. This class must be initialized before");
            }

            if (instance == null) {
                instance = new MySingleton();
            }

            return instance;
        }*/
    public void helpLineDialog(Context context, Activity activity) {
        Log.v("emergencyIcon", "helpLineDialog");
        final int[] error_count = {0};
        final Dialog dialog = new Dialog(context, R.style.full_screen_dialog);
        //final Dialog dialog = new Dialog(AddCreditActivity.this);
        //dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.help_line_dialog);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        EditText enterVoucherEdiText = dialog.findViewById(R.id.enterPromoEdiText);
        TextInputLayout enterVoucherTextInput = dialog.findViewById(R.id.enterPromoTextInput);
        dialog.findViewById(R.id.cancelButton).setOnClickListener(v -> dialog.dismiss());
   /*     dialog.findViewById(R.id.activateCall).setOnClickListener(V -> {
            try {
                Intent intent = new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse("tel:" + context.getResources().getString(R.string.help_line)));
                context.startActivity(intent);
            } catch (Exception ex) {
                ActivityCompat.requestPermissions(
                        activity,
                        new String[]{Manifest.permission.CALL_PHONE},
                        1
                );
            }
            //Constants.phoneCall(context);
        });*/

        dialog.findViewById(R.id.activateCall).setOnClickListener(V -> {
            initiateCall(context,activity,context.getResources().getString(R.string.help_line));
        });

        //if (!(BaseActivity.this).isFinishing()) {
        //show dialog
        dialog.show();
        //}
        Window window = dialog.getWindow();
        assert window != null;
        //window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        //window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setGravity(Gravity.BOTTOM);
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private void initiateCall(Context context, Activity activity,String number){
        try {
            Intent intent = new Intent(Intent.ACTION_CALL);
            intent.setData(Uri.parse("tel:" + number));
            context.startActivity(intent);
        } catch (Exception ex) {
            ActivityCompat.requestPermissions(
                    activity,
                    new String[]{Manifest.permission.CALL_PHONE},
                    1
            );
        }
    }

    public void cityToCityDialog(Context context, Activity activity) {
        Log.v("emergencyIcon", "helpLineDialog");
        final int[] error_count = {0};
        final Dialog dialog = new Dialog(context, R.style.full_screen_dialog);
        //final Dialog dialog = new Dialog(AddCreditActivity.this);
        //dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.city_to_city_dialog);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        EditText enterVoucherEdiText = dialog.findViewById(R.id.enterPromoEdiText);
        TextInputLayout enterVoucherTextInput = dialog.findViewById(R.id.enterPromoTextInput);
        dialog.findViewById(R.id.cancelButton).setOnClickListener(v -> dialog.dismiss());

        dialog.findViewById(R.id.button1).setOnClickListener(V -> {
            initiateCall(context,activity,"+923065265261");
        });
        dialog.findViewById(R.id.button2).setOnClickListener(V -> {
            initiateCall(context,activity,"+923006952701");
        });
        dialog.findViewById(R.id.button3).setOnClickListener(V -> {
            initiateCall(context,activity,"+923006952909");
        });
        dialog.findViewById(R.id.button4).setOnClickListener(V -> {
            initiateCall(context,activity,"+923025265262");
        });

        //if (!(BaseActivity.this).isFinishing()) {
        //show dialog
        dialog.show();
        //}
        Window window = dialog.getWindow();
        assert window != null;
        //window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        //window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setGravity(Gravity.BOTTOM);
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    public void workShopDialog(Context context, Activity activity) {
        Log.v("emergencyIcon", "helpLineDialog");
        final int[] error_count = {0};
        final Dialog dialog = new Dialog(context, R.style.full_screen_dialog);
        //final Dialog dialog = new Dialog(AddCreditActivity.this);
        //dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.work_shop_dialog);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        EditText enterVoucherEdiText = dialog.findViewById(R.id.enterPromoEdiText);
        TextInputLayout enterVoucherTextInput = dialog.findViewById(R.id.enterPromoTextInput);
        dialog.findViewById(R.id.cancelButton).setOnClickListener(v -> dialog.dismiss());

        dialog.findViewById(R.id.button1).setOnClickListener(V -> {
            initiateCall(context,activity,"+923006952516");
        });
        dialog.findViewById(R.id.button2).setOnClickListener(V -> {
            initiateCall(context,activity,"+923006952162");
        });



        //if (!(BaseActivity.this).isFinishing()) {
        //show dialog
        dialog.show();
        //}
        Window window = dialog.getWindow();
        assert window != null;
        //window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        //window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setGravity(Gravity.BOTTOM);
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    public void showPromoPopup(Context context, String message,Boolean bol) {
        final Dialog dialog = new Dialog(context);
        dialog.setContentView(R.layout.promotion_popup);
        dialog.setCancelable(true);
        // dialog.setCancelable(bol);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        dialog.findViewById(R.id.cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        /*okay.setOnClickListener(v -> dialog.dismiss());*/
        dialog.show();
        Window window = dialog.getWindow();
        assert window != null;
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }
    private boolean haveNetworkConnection(Context context) {
        boolean haveConnectedWifi = false;
        boolean haveConnectedMobile = false;

        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo[] netInfo = cm.getAllNetworkInfo();
        for (NetworkInfo ni : netInfo) {
            if (ni.getTypeName().equalsIgnoreCase("WIFI"))
                if (ni.isConnected())
                    haveConnectedWifi = true;
            if (ni.getTypeName().equalsIgnoreCase("MOBILE"))
                if (ni.isConnected())
                    haveConnectedMobile = true;
        }
        return haveConnectedWifi || haveConnectedMobile;
    }
}