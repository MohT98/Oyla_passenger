package com.oyla.passenger.datamodels;

public class ChangeDestinationData {

    private String booking_id;
    private String current_latitude;
    private String current_longitude;
    private String dropoff_latitude;
    private String dropoff_longitude;
    private String trip_one_distance;
    private String trip_two_distance;
    private String trip_total_distance;
    private String trip_one_price;
    private String trip_two_price;
    private String total_price;
    private String trip_total_time;

    public ChangeDestinationData(String booking_id, String current_latitude, String current_longitude, String dropoff_latitude, String dropoff_longitude, String trip_one_distance, String trip_two_distance, String trip_total_distance, String trip_one_price, String trip_two_price, String total_price, String trip_total_time) {
        this.booking_id = booking_id;
        this.current_latitude = current_latitude;
        this.current_longitude = current_longitude;
        this.dropoff_latitude = dropoff_latitude;
        this.dropoff_longitude = dropoff_longitude;
        this.trip_one_distance = trip_one_distance;
        this.trip_two_distance = trip_two_distance;
        this.trip_total_distance = trip_total_distance;
        this.trip_one_price = trip_one_price;
        this.trip_two_price = trip_two_price;
        this.total_price = total_price;
        this.trip_total_time = trip_total_time;
    }
}
