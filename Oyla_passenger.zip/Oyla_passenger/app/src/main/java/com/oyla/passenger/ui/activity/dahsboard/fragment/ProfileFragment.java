package com.oyla.passenger.ui.activity.dahsboard.fragment;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.oyla.passenger.MainApp;
import com.oyla.passenger.R;
import com.oyla.passenger.databinding.FragmentProfileBinding;
import com.oyla.passenger.datamodels.usermodel.UserData;
import com.oyla.passenger.services.location.LocationService;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.ui.activity.SettingActivity;
import com.oyla.passenger.ui.activity.SplashActivity;
import com.oyla.passenger.ui.activity.WebPageActivity;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.DialogBoxSingleton;
import com.oyla.passenger.utilities.SharedPrefManager;
import com.oyla.passenger.viewmodels.LogOutViewModel;

import java.util.Locale;
import java.util.Objects;

import static android.content.Context.CLIPBOARD_SERVICE;
import static com.facebook.FacebookSdk.getApplicationContext;

public class ProfileFragment extends Fragment implements View.OnClickListener {

    private View view;
    private Intent i;
    private FragmentProfileBinding binding;
    private String language;
    UserData userData ;
    LogOutViewModel viewModel;
    private Animation animFade;

    public ProfileFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @SuppressLint("SetTextI18n")
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        // return inflater.inflate(R.layout.fragment_profile, container, false);
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_profile, container, false);
        viewModel = new ViewModelProvider(requireActivity()).get(LogOutViewModel.class);
        userData = SharedPrefManager.getInstance(getActivity()).getUserInfo();
        animFade= AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fade_in);
      //  binding.parentLayout.startAnimation(animFade);
        view = binding.getRoot();
        binding.profileEditLayout.setOnClickListener(this);
        binding.languageLayout.setOnClickListener(this);
        binding.signOutLayout.setOnClickListener(this);
        binding.shareAppLayout.setOnClickListener(this);
        binding.rateAppLayout.setOnClickListener(this);
        binding.referralLayout.setOnClickListener(this);
        binding.privacyPolicy.setOnClickListener(this);
        binding.complainLayout.setOnClickListener(this);

        binding.helpLayout.setOnClickListener(this);
        binding.emergencyIcon.setOnClickListener(v -> {
            //Constants.phoneCall(getActivity());
            //BaseActivity.getInstance().helpLineDialog();
            DialogBoxSingleton.getInstance().helpLineDialog(getActivity(), getActivity());
        });


        if(MainApp.getInstance().getUserData()!=null && MainApp.getInstance().getUserData().getReferral_id()!=null
         && !MainApp.getInstance().getUserData().getReferral_id().isEmpty()){
            binding.referralIdText.setText(MainApp.getInstance().getUserData().getReferral_id());
        }
        else {
            binding.referralLayout.setVisibility(View.GONE);
        }

        binding.referralLayout.setOnLongClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) getActivity().getSystemService(CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("label", binding.referralIdText.getText().toString().trim());
            clipboard.setPrimaryClip(clip);
            BaseActivity.getInstance().showToast(getActivity(),"Referral Id Copied");
            return false;
        });

        // BaseActivity.getInstance().configureGoogleClient();
        try {
            PackageInfo pInfo = requireActivity().getPackageManager().getPackageInfo(getActivity().getPackageName(), 0);
            binding.appVersion.setText("App version " + pInfo.versionName);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return view;
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.profileEditLayout:
                i = new Intent(getActivity(), SettingActivity.class);
                startActivity(i);
                break;
            case R.id.languageLayout:
               showLanguageDialog();
                /**/
                break;
            case R.id.complainLayout:
                complainReasonDialog("","");
                break;
            case R.id.referralLayout:
                Intent intent = new Intent(android.content.Intent.ACTION_SEND);
                /*This will be the actual content you wish you share.*/
                String  shareBody=MainApp.getInstance().getUserData().getReferral_id();;
                /*The type of the content is text, obviously.*/
                intent.setType("text/plain");
                /*Applying information Subject and Body.*/
                intent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
                /*Fire!*/
                startActivity(Intent.createChooser(intent, getString(R.string.share_using)));
                break;
            case R.id.signOutLayout:
                Constants.Auth = Constants.Bearer + " " +  SharedPrefManager.getInstance(getActivity()).getUserInfo().getAccessToken();
               // Constants.Auth = Constants.Bearer + " " + MainApp.getInstance().getUserData().getAccessToken();
                viewModel.sendLogoutRequest(userData.getUserId());
                ((BaseActivity) requireActivity()).startLoader();
                viewModel.receiveLogoutRepose().observe(this,dataModelObject -> {
                    ((BaseActivity) getActivity()).stopLoader();
                    if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                        if (Constants.G_SIGN_IN) {
                            googleSignOut();
                        }
                        Intent myService = new Intent(getActivity(), LocationService.class);
                        myService.setAction(Constants.ACTION_STOP_FOREGROUND_SERVICE);
                        getActivity().stopService(myService);
                        requireActivity().finish();
                        SharedPrefManager.getInstance(getActivity()).logout();
                    }
                });
                break;
            case R.id.shareAppLayout:
                //createReferralURL();
                shareLink();
                break;
            case R.id.helpLayout:
                i = new Intent(getActivity(), WebPageActivity.class);
                i.putExtra("pageName","getHelp");
                startActivity(i);
                break;
            case R.id.rateAppLayout:
                Uri uri = Uri.parse("market://details?id=" + requireActivity().getPackageName());
                Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);
                try {
                    startActivity(myAppLinkToMarket);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getActivity(), " unable to find market app", Toast.LENGTH_LONG).show();
                }
                break;
            case R.id.privacyPolicy:
                i = new Intent(getActivity(), WebPageActivity.class);
                i.putExtra("pageName","privacy_poilicy");
                startActivity(i);
                break;
            default:
                break;
        }
    }

    private void showLanguageDialog() {
        final Dialog dialog = new Dialog(requireActivity());
        dialog.setContentView(R.layout.language_dialog);
        RadioGroup rGroup = dialog.findViewById(R.id.radioGroupLanguage);
        if (language.equalsIgnoreCase("english")){
          //  BaseActivity.getInstance().setAppLanguage("EN");
            rGroup.check(R.id.radio_one);
        }

        else if (language.equalsIgnoreCase("اردو")){
           // BaseActivity.getInstance().setAppLanguage("UR");
            rGroup.check(R.id.radio_two);
        }

        else if (language.equalsIgnoreCase("العربية"))
            rGroup.check(R.id.radio_three);
        else
            rGroup.check(R.id.radio_one);

        dialog.findViewById(R.id.cancel).setOnClickListener(v -> dialog.dismiss());

        rGroup.setOnCheckedChangeListener((group, checkedId) -> {
            RadioButton checkedRadioButton = group.findViewById(checkedId);
          /*  Log.v("setAppLanguage","rGroup.getCheckedRadioButtonId() "+rGroup.getCheckedRadioButtonId());*/
            language = (String) checkedRadioButton.getText();
           /* BaseActivity.getInstance().setAppLanguage(language);*/
            setAppLanguage(language);
            binding.languageName.setText(language);
            SharedPrefManager.getInstance(getActivity()).setLanguage(language);
            dialog.dismiss();
            //Toast.makeText(SettingActivity.this, "Selected Radio Button: " + checkedRadioButton.getText(), Toast.LENGTH_SHORT).show();
        });
        dialog.show();
        Window window = dialog.getWindow();
        assert window != null;
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

   /* private void setAppLanguage(String language){
        Log.v("setAppLanguage","setAppLanguage "+language);
        Locale locale = new Locale(language);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale = locale;
        Objects.requireNonNull(getActivity()).getBaseContext().getResources().updateConfiguration(config,
                getActivity().getBaseContext().getResources().getDisplayMetrics());
    }*/
    private void googleSignOut() {
        // Firebase sign out
        Constants.firebaseAuth.signOut();
        Constants.G_SIGN_IN = false;
        // Google sign out

        Constants.googleSignInClient.signOut().addOnCompleteListener(requireActivity(),
                task -> {
                    // Google Sign In failed, update UI appropriately
                    Log.w("GoogleSign", "Signed out of google");
                });
    }

    @Override
    public void onResume() {
        language = SharedPrefManager.getInstance(getActivity()).getLanguage();
        if(language== null){
            language = getResources().getString(R.string.english);
        }else {
            binding.languageName.setText(language);
        }
        if( MainApp.getInstance().getUserData()!=null){
           // if(MainApp.getInstance().getUserData().getProvider().equalsIgnoreCase("mobile_no")){
                if(MainApp.getInstance().getUserData().getUserMobNumber().equalsIgnoreCase("0") ||
                        (MainApp.getInstance().getUserData().getUserMobNumber().length()==15)){
                    binding.userMobileNumber.setText( getResources().getString(R.string.not_added));
                }
                else {
                    binding.userMobileNumber.setText( MainApp.getInstance().getUserData().getUserMobNumber());
                }
         //   }
            //binding.userEmail.setText( MainApp.getInstance().getUserData().getUserEmail());
            binding.userNameText.setText( MainApp.getInstance().getUserData().getUserFirstName());
            if(MainApp.getInstance().getUserData().getUserEmail()==null || MainApp.getInstance().getUserData().getUserEmail().isEmpty()){
                // binding.profileUploadIcon
                binding.userEmail.setText( getResources().getString(R.string.not_added));
            }else {
                binding.userEmail.setText( MainApp.getInstance().getUserData().getUserEmail());
            }
           /* if(!MainApp.getInstance().getUserData().getUserEmail().contains("@oyla.com")){
                binding.userEmail.setText( MainApp.getInstance().getUserData().getUserEmail());
            }*/
        }

        super.onResume();
    }

    private void shareLink(){
        Intent intent = new Intent(android.content.Intent.ACTION_SEND);
        StringBuilder sb = new StringBuilder();
        /*This will be the actual content you wish you share.*/
        //String shareBody = "https://play.google.com/store/apps/details?id=com.oyla.passenger&referrer=9BE46300";
        //String shareBody = "https://play.google.com/store/apps/details?id=com.oyla.passenger&referrer=OylaPassenger-00";
        String shareBody = "https://play.google.com/store/apps/details?id=com.oyla.passenger&referrer=";

        shareBody=shareBody+MainApp.getInstance().getUserData().getReferral_id();;
        /*The type of the content is text, obviously.*/
        intent.setType("text/plain");
        /*Applying information Subject and Body.*/
        intent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
        /*Fire!*/
        startActivity(Intent.createChooser(intent, getString(R.string.share_using)));
    }

    private void complainReasonDialog(String userId, String bookingId) {

        final Dialog dialog = new Dialog(getActivity());
        dialog.setContentView(R.layout.complain_dialog_box);
        RadioGroup rGroup = dialog.findViewById(R.id.radioGroup);
        LinearLayout editComplainLayout = dialog.findViewById(R.id.editComplainLayout);
        EditText complainEditText = dialog.findViewById(R.id.complainEditText);
        Button saveComplainButton = dialog.findViewById(R.id.saveComplainButton);


        rGroup.setOnCheckedChangeListener((group, checkedId) -> {
            RadioButton checkedRadioButton = group.findViewById(checkedId);
           /* if (FIND_CAPTAIN_CANCEL) {
                findCaptainCancelFlagReset();
            } else {
                afterRideAcceptCancelFlag();
            }
            viewModel.sendCancelRideRequest(userId, bookingId, checkedRadioButton.getText().toString());*/
            if(checkedRadioButton.getId()==R.id.radio_four){
                editComplainLayout.setVisibility(View.VISIBLE);
                complainEditText.requestFocus();

            }else {
                editComplainLayout.setVisibility(View.GONE);
                /*viewModel.sendCancelRideRequest(userId, bookingId, checkedRadioButton.getText().toString());*/
                dialog.dismiss();
            }

            //cancelRideApiResponse();
        });
        saveComplainButton.setOnClickListener(v->{
            if(complainEditText.getText().toString().trim().isEmpty()){
                //Toast.makeText(getActivity(),"Should not be Empty",Toast.LENGTH_SHORT).show();
                complainEditText.setError("Should not be Empty");
            }else {
                dialog.dismiss();
                /*viewModel.sendCancelRideRequest(userId, bookingId, checkedRadioButton.getText().toString());*/
            }

        });
        dialog.show();
        dialog.setCancelable(true);
        Window window = dialog.getWindow();
        assert window != null;
        window.setGravity(Gravity.BOTTOM);
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }
    public void setAppLanguage(String language){
        Log.v("setAppLanguage","setAppLanguage "+language);
        if(language.equalsIgnoreCase("English")) {
            language="en";
        }
        else if( language.equalsIgnoreCase("اردو")) {
            language="ur";
        }
        Log.v("setAppLanguage","setAppLanguage "+language);
        Locale locale = new Locale(language);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        Resources resources = getResources();
        config.locale = locale;
        //resources.updateConfiguration(config, resources.getDisplayMetrics());
        requireActivity().getBaseContext().getResources().updateConfiguration(config, requireActivity().getBaseContext().getResources().getDisplayMetrics());
        Intent intent = requireActivity().getIntent();
        //Intent intent = new Intent(getBaseContext(), DashBoardActivity.class);
        requireActivity().finish();
        startActivity(intent);
    }
}
