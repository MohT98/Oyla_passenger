package com.oyla.passenger.services.location;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.lifecycle.MutableLiveData;

import com.oyla.passenger.MainApp;
import com.oyla.passenger.Repository.JsonRepository;
import com.oyla.passenger.datamodels.jsonreponsedatamodel.DataModelObject;
import com.oyla.passenger.interfaces.ServiceCallbacks;
import com.oyla.passenger.services.retrofit.Api;
import com.oyla.passenger.services.retrofit.ApiClient;
import com.oyla.passenger.ui.activity.cabbooking.MapActivity;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.SharedPrefManager;

import io.reactivex.disposables.Disposable;

import static com.oyla.passenger.ui.activity.cabbooking.MapActivity.PICK_UP_TRACKING;

public class NearestDriverCoordinates extends Service {
    private static final String TAG = "NearestDriverCoordinate";
  //  private static  int LOCATION_UPDATE_INTERVAL = 5 * 1000;   /*5 secs*/
    private static  int LOCATION_UPDATE_INTERVAL = 1000;  /* 1 secs */
    private ServiceCallbacks serviceCallbacks;

    //private Handler mHandler = new Handler();
    private Handler mHandler =new Handler(Looper.getMainLooper());

    //private Handler mHandler =  new Handler(Looper.getMainLooper());

    private Runnable mRunnable;
    private MutableLiveData<DataModelObject> mutableLiveData;
    public static boolean NEAREST_LOCATION_GET = true;
    private double lat=0.0;
    private double lng=0.0;

    Disposable disposable;
    Api api;

    public NearestDriverCoordinates() {
        api = ApiClient.createService(Api.class);
        Log.d("newToken", " NearestDriverCoordinates Constucter");
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
   /*     if (Build.VERSION.SDK_INT >= 26) {
            String CHANNEL_ID = "my_channel_01";
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "My Channel",
                    NotificationManager.IMPORTANCE_DEFAULT);

            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(channel);

            Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setContentTitle("")
                    .setContentText("").build();

            startForeground(1, notification);
        }*/
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, " NearestDriverCoordinates onStartCommand: called.");

        if (intent.getAction().equals(Constants.ACTION_START_FOREGROUND_SERVICE)) {
            Log.i(TAG, "NearestDriverCoordinates Received Start Foreground Intent ");
            // your start service code
            NEAREST_LOCATION_GET = true;
            getDriverLocation();
        } else if (intent.getAction().equals(Constants.ACTION_STOP_FOREGROUND_SERVICE)) {
            Log.i(TAG, "NearestDriverCoordinates Received Stop Foreground Intent");
            //your end servce code
            stopForeground(true);
            stopSelfResult(startId);
            PICK_UP_TRACKING = false;
        }
        return START_NOT_STICKY;
    }

    private void getDriverLocation() {

        mHandler.postDelayed(mRunnable = () -> {
            if (NEAREST_LOCATION_GET) {
                retrieveCaptainLocations();
            }

            mHandler.postDelayed(mRunnable, LOCATION_UPDATE_INTERVAL);
        }, LOCATION_UPDATE_INTERVAL);
        if(LOCATION_UPDATE_INTERVAL== 1000){
            LOCATION_UPDATE_INTERVAL= 2 * 1000;
        }
       /* if(LOCATION_UPDATE_INTERVAL== 3 * 1000){
            LOCATION_UPDATE_INTERVAL= 5 * 1000;
        }*/
        Log.i(TAG, "LOCATION_UPDATE_INTERVAL "+LOCATION_UPDATE_INTERVAL);
    }

    private void retrieveCaptainLocations() {

       // if((MainApp.getInstance().getUserLocation().getLocation())
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        Log.i(TAG, "retrieveCaptainLocations ");
        Log.i(TAG, "NEAREST_LOCATION_GET "+NEAREST_LOCATION_GET);
        JsonRepository repository = new JsonRepository();
        // Log.v("getAccessToken", "getAccessToken " + userData.getFcm_token());
       /* Log.v("GetDriverCoordinates", "getDriver_id " + dataList.getCaptain_info_data().getDriver_id());
        Log.v("GetDriverCoordinates", "getDriver_name " + dataList.getCaptain_info_data().getDriver_name());*/
        Constants.Auth = Constants.Bearer + " " + SharedPrefManager.getInstance(getApplicationContext()).getUserInfo().getAccessToken();
       // mutableLiveData = repository.getDriverCoordinates(dataList.getCaptain_info_data().getDriver_id());
        Log.v("newToken", "mutableLiveData  ");
        if(MainApp.getInstance().getUserLocation()!=null){
            lat= MapActivity.pickupMarkerLat;
            lng= MapActivity.pickupMarkerLng;
            Log.v("pickupMarker", "pickupMarkerLat  "+lat);
            Log.v("pickupMarker", "pickupMarkerLng  "+lng);
            if(lat==0.0 && lng==0.0){
                if(MainApp.getInstance().getUserLocation().getLocation()!=null){
                    lat=MainApp.getInstance().getUserLocation().getLocation().getLatitude();
                    lng=MainApp.getInstance().getUserLocation().getLocation().getLongitude();
                }
            }
            if(MainApp.getInstance().getUserLocation().getLocation()!=null){
                NEAREST_LOCATION_GET = false;
                mutableLiveData = repository.getNearestDrivers(
                        String.valueOf(lat),
                        String.valueOf(lng)
                );
            }

        }

        MainApp.getInstance().getNearestDriver().getNearestDriver();
       /* coordinateInternal(String.valueOf(MainApp.getInstance().getUserLocation().getLocation().getLatitude()),
                String.valueOf(MainApp.getInstance().getUserLocation().getLocation().getLongitude())
        );*/
    }

    @Override
    public void onDestroy() {
        Log.i(TAG, "NearestDriverCoordinates onCreate() , service stopped...");
        mHandler.removeCallbacks(mRunnable);
       // disposable.dispose();
    }


    @Override
    public void onTaskRemoved(Intent rootIntent) {
        Log.i(TAG, "NearestDriverCoordinates onTaskRemoved called ");
        super.onTaskRemoved(rootIntent);
        //do something you want
        //stop service
        this.stopSelf();
    }
}