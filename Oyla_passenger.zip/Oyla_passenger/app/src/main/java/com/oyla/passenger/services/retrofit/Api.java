package com.oyla.passenger.services.retrofit;

import com.google.gson.JsonObject;
import com.oyla.passenger.datamodels.BookingStatusPostData;
import com.oyla.passenger.datamodels.ChangeDestinationData;
import com.oyla.passenger.datamodels.ExceptionErrorClass;
import com.oyla.passenger.datamodels.GetAppVehicleData;
import com.oyla.passenger.datamodels.JazzCashData;
import com.oyla.passenger.datamodels.PostData;
import com.oyla.passenger.datamodels.PromoData;
import com.oyla.passenger.datamodels.RatingPostModel;
import com.oyla.passenger.datamodels.RegisterNewComplaintData;
import com.oyla.passenger.datamodels.redeemdata.RedeemPostData;
import com.oyla.passenger.datamodels.RefreshTokenPostData;
import com.oyla.passenger.datamodels.ResendOTPPostData;
import com.oyla.passenger.datamodels.RideCancelData;
import com.oyla.passenger.datamodels.SearchCaptainData;
import com.oyla.passenger.datamodels.SocialLoginData;
import com.oyla.passenger.datamodels.UpdateMobPostData;
import com.oyla.passenger.datamodels.mapmodel.direction.DirectionResult;
import com.oyla.passenger.datamodels.jsonreponsedatamodel.DataModelObject;
import com.oyla.passenger.datamodels.usermodel.UpdateData;
import com.oyla.passenger.datamodels.usermodel.WebPagePostData;

import org.json.JSONObject;

import java.util.Map;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.PartMap;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface Api {

    @GET("https://maps.googleapis.com/maps/api/directions/json")
    Call<DirectionResult> getDirection(@Query("origin") String origin, @Query("destination") String destination, @Query("sensor") String sensor, @Query("mode") String mode, @Query("key") String gkey);

    @GET("https://maps.googleapis.com/maps/api/directions/json")
    Call<DirectionResult> getDirectionPickup(@Query("origin") String origin, @Query("destination") String destination, @Query("sensor") String sensor, @Query("mode") String mode, @Query("key") String gkey);

    @GET("https://maps.googleapis.com/maps/api/directions/json")
    Call<DataModelObject> getDirection2(@Query("origin") String origin, @Query("destination") String destination, @Query("sensor") String sensor, @Query("mode") String mode, @Query("key") String gkey);

    @FormUrlEncoded
    @POST("user_authentication")
    Call<DataModelObject> registerMobile(@FieldMap Map<String, String> fields);


    @POST("verifyCode")
    Call<DataModelObject> verifyOTP(@Header("Authorization") String bearer, @Body PostData postData);

    @POST("resendOTP")
    Call<DataModelObject> reSendOTP(@Header("Authorization") String bearer, @Body ResendOTPPostData resendOTPPostData);
    @POST("verifyOtpUpdateMobile ")
    Call<DataModelObject> verifyOtpUpdateMobile (@Header("Authorization") String bearer, @Body UpdateMobPostData updateMobPostData);


    @POST("updateUser")
    Call<DataModelObject> signUp(@Header("Authorization") String bearer, @Body PostData postData);

    @POST("social_login_mobile")
    Call<DataModelObject> socialLogin(@Header("Authorization") String bearer, @Body SocialLoginData socialLoginData);

    @POST("setPassengerCoordinates")
    Call<DataModelObject> setPassengerCoordinates(@Header("Authorization") String bearer, @Body PostData postData);

    @POST("logout")
    Call<DataModelObject> logout(@Header("Authorization") String bearer, @Body PostData postData);

    @POST("userRefreshToken")
    Call<DataModelObject> refreshToken(@Header("Authorization") String bearer, @Body RefreshTokenPostData refreshTokenPostData);

    @POST("passengerLedgers")
    Call<DataModelObject> passengerLedgers(@Header("Authorization") String bearer, @Body PostData postData);

    @POST("getRewardPoints ")
    Call<DataModelObject> getRewardPoints (@Header("Authorization") String bearer, @Body PostData postData);

    @POST("passengerDashboardData")
    Call<DataModelObject> passengerDashboardData (@Header("Authorization") String bearer, @Body PostData postData);

    @POST("getRedeemPointsList ")
    Call<DataModelObject> getRedeemPointsList (@Header("Authorization") String bearer, @Body PostData postData);

    @POST("getRedeemPoints ")
    Call<DataModelObject> getRedeemPoints (@Header("Authorization") String bearer, @Body RedeemPostData redeemPostData );

    @POST("promocodeDiscount")
    Call<DataModelObject> promocodeDiscount(@Header("Authorization") String bearer, @Body PromoData promoData);


    @POST("checkBookingStatusByPassenger")
    Call<DataModelObject> getCaptainIfo(@Header("Authorization") String bearer, @Query("passenger_id") String passenger_id);



    @POST("jazzCashPay")
    Call<DataModelObject> jazzCashPay(@Header("Authorization") String bearer, @Body JazzCashData jazzCashData);

    @POST("getAppVehicle")
    Call<DataModelObject> getVehicleType(@Header("Authorization") String bearer, @Body GetAppVehicleData getAppVehicleData);

    @POST("saveTempRideInfo")
    Call<DataModelObject> searchCaptain(@Header("Authorization") String bearer, @Body SearchCaptainData searchCaptainData);

    @POST("getNearestDrivers")
    Call<DataModelObject> getNearestDrivers(@Header("Authorization") String bearer, @Body PostData postData);


    @POST("getDriverCoordinates")
    Call<DataModelObject> getDriverCoordinates(@Header("Authorization") String bearer, @Body PostData postData);

  

    @POST("setProfile")
    Call<DataModelObject> updateProfile(@Header("Authorization") String bearer, @Body UpdateData updateData);

    @POST("passengerChangeDestination")
    Call<DataModelObject> passengerChangeDestination(@Header("Authorization") String bearer, @Body ChangeDestinationData changeDestinationData);


    @POST("checkBookingStatus")
    Call<DataModelObject> checkBookingStatus(@Header("Authorization") String bearer, @Body BookingStatusPostData bookingStatusPostData);

    @POST("getPageData")
    Call<DataModelObject> webPageContent(@Header("Authorization") String bearer, @Body WebPagePostData webPagePostData);

    @POST("giveDriverRating")
    Call<DataModelObject> giveDriverRating(@Header("Authorization") String bearer, @Body  RatingPostModel ratingPostModel);


    /*    @Multipart
        @POST("setProfile")
        Call<DataModelObject> updateProfileImage(@Header("Authorization") String bearer,
                                                 @Part MultipartBody.Part file,
                                                 @Part("user_id") RequestBody user_id);*/
/*    @Multipart
    @POST("setProfile")
    Call <DataModelObject> updateProfileImage(@Header("Authorization") String bearer,
                                                   @Part("user_id") RequestBody id,
                                                   @Part("profile_picture") RequestBody fullName,
                                                    @Part MultipartBody.Part image
                                                   );*/
/*
    @Multipart
    @POST("setProfile")
    Call <DataModelObject> updateProfileImage(@Header("Authorization") String bearer,
                                              @Part("user_id") RequestBody id,
                                              @Part("profile_picture")MultipartBody.Part file
    );*/

    @Multipart
    @POST("setProfile")
    Call <DataModelObject> updateProfileImage(@Header("Authorization") String bearer,
                                              @PartMap Map<String, RequestBody> params,
                                              @Part MultipartBody.Part file
    );

    @POST("passengerCancelsRide")
    Call<DataModelObject> cancelsRide(@Header("Authorization") String bearer, @Body RideCancelData rideCancelData);

    @POST("getTransactionHistory")
    Call<DataModelObject>getRideHistory(@Header("Authorization") String bearer, @Body PostData postData);

    @POST("passengerTransactionsHistory")
    Call<DataModelObject>getTransactionHistory(@Header("Authorization") String bearer, @Body PostData postData);

    /*@POST("https://fcm.googleapis.com/fcm/send")
    Call<DataModelObject> sendNotification(@Query("key") String key);*/
    /*@Headers("Content-Type: application/json")
    @POST("https://fcm.googleapis.com/fcm/send/{key}")
    Call<DataModelObject> sendNotification(@Path("key") String key,@Body String body);*/
    @Headers({"Content-Type: application/json"})
    @POST("https://fcm.googleapis.com/fcm/send")
    Call<DataModelObject> sendNotification(@Header("Authorization") String key ,@Body JsonObject jsonObject);

    @POST("getComplaintTypes")
    Call<DataModelObject> getComplaintTypes(@Header("Authorization") String bearer, @Query("purpose") String purpose);

    @POST("saveErrorInfo")
    Call<DataModelObject> SaveError(@Header("Authorization") String bearer,@Body ExceptionErrorClass exceptionErrorClass);

   /* @POST("registerNewComplaint")
    Call<DataModelObject> registerNewComplaint(@Header("Authorization") String bearer,  @Body PostData postData);*/

    @Multipart
    @POST("registerNewComplaint")
    Call <DataModelObject> registerNewComplaint(@Header("Authorization") String bearer,
                                              @PartMap Map<String, RequestBody> params,
                                              @Part MultipartBody.Part file
    );

    @GET("getPackages")
    Call<DataModelObject> getPackages(@Header("Authorization") String bearer);

}