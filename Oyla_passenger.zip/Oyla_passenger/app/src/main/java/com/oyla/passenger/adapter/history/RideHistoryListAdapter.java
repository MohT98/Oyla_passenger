  package com.oyla.passenger.adapter.history;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.oyla.passenger.R;
import com.oyla.passenger.datamodels.historydata.RideHistoryData;
import com.oyla.passenger.ui.activity.complain.ComplainListActivity;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class RideHistoryListAdapter extends RecyclerView.Adapter<RideHistoryListAdapter.MyViewHolder> {

    //  private ArrayList<TransactionHistoryData> dataSet;
    private List<RideHistoryData> dataSet;
    private Context mCtx;
    private OnItemClickListener mListener;

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    public RideHistoryListAdapter(Context mCtx, List<RideHistoryData> data) {
        this.dataSet = data;
        this.mCtx = mCtx;
    }


    @NonNull
    @Override
    public RideHistoryListAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.ride_history_list_item, parent, false);
        MyViewHolder myViewHolder = new MyViewHolder(view, mListener);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final RideHistoryListAdapter.MyViewHolder holder, final int listPosition) {

        holder.captainName.setText(dataSet.get(listPosition).getDriver_name());
        String currentString =dataSet.get(listPosition).getCreated_at();
        String[] separated = currentString.split("T");
        holder.dataTime.setText(separated[0]);
        String date=separated[0];
      /* SimpleDateFormat dateFormat= new SimpleDateFormat("dd-MM-yyyy");
        //SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy/MM/dd");

        try {

            Date d=dateFormat.parse(date);
            assert d != null;
            holder.dataTime.setText(d.toString());
        }
        catch(Exception e) {
            //java.text.ParseException: Unparseable date: Geting error
            //System.out.println("Excep"+e);
            Log.v("DateExcep","Excep() "+e);
        }*/

       // String time1=separated[1];
       // holder.dataTime.setText(dataSet.get(listPosition).getUpdated_at());
        holder.amountType.setText(dataSet.get(listPosition).getPayment_type());
       // holder.amount.setText(dataSet.get(listPosition).getFinal_amount());

      /*  String time2 =dataSet.get(listPosition).getUpdated_at();
         separated = time2.split("T");
        time2=separated[1];
        Log.v("dataTime","time1 "+time1);
        Log.v("dataTime","time2 "+time2);*/

        holder.vehicleType.setText(dataSet.get(listPosition).getVehicle_type());
        holder.ratingBar.setRating(Float.parseFloat(dataSet.get(listPosition).getBooking_rating()));
       /* holder.transactionCardView.setOnClickListener(v->{

            Intent intent = new Intent(mCtx, TransactionDetailActivity.class);
            intent.putExtra("Item", dataSet.get(listPosition));
            mCtx.startActivity(intent);
        });*/
      //  Log.v("Fine_user_type","vehicleType "+dataSet.get(listPosition).getVehicle_type());
        //Log.v("Fine_user_type","Fine_user_type "+dataSet.get(listPosition).getFine_user_type());
       // if(dataSet.get(listPosition).getFine_user_type()!=null){

          //  Log.v("Fine_user_type","Cancel_fine_amount() "+dataSet.get(listPosition).getCancel_fine_amount());
        Log.v("getStatus","status() "+dataSet.get(listPosition).getStatus());
            //if(dataSet.get(listPosition).getFine_user_type().equalsIgnoreCase("Passenger")){
        if(dataSet.get(listPosition).getStatus().equalsIgnoreCase("4") /*|| !dataSet.get(listPosition).getStatus().equalsIgnoreCase("1")*/)
        {
            holder.amount.setText( String.valueOf(Math.round(Float.parseFloat(dataSet.get(listPosition).getFinal_amount()))));
            holder.amountType.setVisibility(View.VISIBLE);
            holder.amountTypeText.setVisibility(View.VISIBLE);
            }
       /* if(dataSet.get(listPosition).getStatus().equalsIgnoreCase("4")) {*/
        else {
            //Log.v("Fine_user_type","getFinal_amount() "+dataSet.get(listPosition).getFinal_amount());
            if(dataSet.get(listPosition).getCancel_fine_amount()==null || dataSet.get(listPosition).getCancel_fine_amount().equalsIgnoreCase("0")){
                holder.amount.setText( "0");
            }else {
                holder.amount.setText("- "+ Math.round(Float.parseFloat(dataSet.get(listPosition).getCancel_fine_amount())));
            }
            holder.amountType.setVisibility(View.GONE);
            holder.amountTypeText.setVisibility(View.GONE);
            }
       /* }else {
            holder.amount.setText( String.valueOf(Math.round(Float.parseFloat(dataSet.get(listPosition).getFinal_amount()))));
        }*/



        Glide
                .with(mCtx)
                //.load("http://lead2need.ca/stagingadmin/public/vehicles/gallery/dummy.jpg")
                .load("http://storage.googleapis.com/"+dataSet.get(listPosition).getDriver_profile_picture())
                .centerCrop()
                .placeholder(R.drawable.profile_update_icon)
                .into(holder.profileIcon);
        holder.reportProblem.setOnClickListener(v->{
            Log.v("bookingId","bookingId "+dataSet.get(listPosition).getId());
            Log.v("bookingId","passengerId "+dataSet.get(listPosition).getPassenger_id());
            Intent intent = new Intent(mCtx, ComplainListActivity.class);
            intent.putExtra("bookingId", dataSet.get(listPosition).getId());
            intent.putExtra("passengerId", dataSet.get(listPosition).getPassenger_id());
            mCtx.startActivity(intent);
            //complainReasonDialog(dataSet.get(listPosition).getPassenger_id(),dataSet.get(listPosition).getId());
        });

    }


    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView captainName, dataTime, amount, amountType, vehicleType,amountTypeText,reportProblem;
        RatingBar ratingBar;
        CardView transactionCardView;
        CircleImageView profileIcon;


        public MyViewHolder(@NonNull View itemView, final OnItemClickListener listener) {
            super(itemView);
            amountTypeText= itemView.findViewById(R.id.amountTypeText);
            captainName = itemView.findViewById(R.id.captainName);
            reportProblem = itemView.findViewById(R.id.reportProblem);
            dataTime = itemView.findViewById(R.id.dataTime);
            amount = itemView.findViewById(R.id.amount);
            amountType = itemView.findViewById(R.id.amountType);
            vehicleType = itemView.findViewById(R.id.vehicleType);
            ratingBar = itemView.findViewById(R.id.ratingBar);
            transactionCardView = itemView.findViewById(R.id.transactionCardView);
            profileIcon= itemView.findViewById(R.id.profileIcon);
            itemView.setOnClickListener(v -> {
                if (listener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onItemClick(position);
                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    private void complainReasonDialog(String userId, String bookingId) {

        final Dialog dialog = new Dialog(mCtx);
        dialog.setContentView(R.layout.complain_dialog_box);
        RadioGroup rGroup = dialog.findViewById(R.id.radioGroup);
        LinearLayout editComplainLayout = dialog.findViewById(R.id.editComplainLayout);
        EditText complainEditText = dialog.findViewById(R.id.complainEditText);
        Button saveComplainButton = dialog.findViewById(R.id.saveComplainButton);


        rGroup.setOnCheckedChangeListener((group, checkedId) -> {
            RadioButton checkedRadioButton = group.findViewById(checkedId);
           /* if (FIND_CAPTAIN_CANCEL) {
                findCaptainCancelFlagReset();
            } else {
                afterRideAcceptCancelFlag();
            }
            viewModel.sendCancelRideRequest(userId, bookingId, checkedRadioButton.getText().toString());*/
            if(checkedRadioButton.getId()==R.id.radio_four){
                editComplainLayout.setVisibility(View.VISIBLE);
                complainEditText.requestFocus();

            }else {
                editComplainLayout.setVisibility(View.GONE);
                /*viewModel.sendCancelRideRequest(userId, bookingId, checkedRadioButton.getText().toString());*/
                dialog.dismiss();
            }

            //cancelRideApiResponse();
        });
        saveComplainButton.setOnClickListener(v->{
            if(complainEditText.getText().toString().trim().isEmpty()){
                //Toast.makeText(getActivity(),"Should not be Empty",Toast.LENGTH_SHORT).show();
                complainEditText.setError("Should not be Empty");
            }else {
                dialog.dismiss();
                /*viewModel.sendCancelRideRequest(userId, bookingId, checkedRadioButton.getText().toString());*/
            }

        });
        dialog.show();
        dialog.setCancelable(true);
        Window window = dialog.getWindow();
        assert window != null;
        window.setGravity(Gravity.BOTTOM);
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }
}

