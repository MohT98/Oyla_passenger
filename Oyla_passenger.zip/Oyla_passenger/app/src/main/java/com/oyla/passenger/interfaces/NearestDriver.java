package com.oyla.passenger.interfaces;

public interface NearestDriver {
    void getNearestDriver();
}
