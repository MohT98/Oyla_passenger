package com.oyla.passenger.ui.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.fragment.app.DialogFragment;
import androidx.lifecycle.ViewModelProvider;

import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;
import com.oyla.passenger.MainApp;
import com.oyla.passenger.R;
import com.oyla.passenger.databinding.ActivitySettingBinding;
import com.oyla.passenger.datamodels.FileModel;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.ui.activity.update.profile.UpdateMobNumberActivity;
import com.oyla.passenger.ui.activity.update.profile.UpdatePasswordActivity;
import com.oyla.passenger.utilities.DatePickerFragment;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.Messages;
import com.oyla.passenger.utilities.SharedPrefManager;
import com.oyla.passenger.viewmodels.UpdateProfileViewModel;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.net.URISyntaxException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

public class SettingActivity extends BaseActivity implements View.OnClickListener, DatePickerDialog.OnDateSetListener {
    private ActivitySettingBinding binding;
    private UpdateProfileViewModel viewModel;
    private String gender, language;
    private int nameErrorCount = 0;
    private int mobErrorCount = 0;
    private int emailErrorCount = 0;
    PermissionListener permissionlistener;
    private String stringImage;
    int PICK_IMAGE = 123;
    int CAMERA_REQUEST = 124;
    private String user_id = "";
    private Bitmap profileBitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_setting);

        binding = setContentView(this, R.layout.activity_setting);
        viewModel = new ViewModelProvider(this).get(UpdateProfileViewModel.class);
        binding.setViewModel(viewModel);
        //UserData userData = SharedPrefManager.getInstance(this).getUserInfo();

        if (SharedPrefManager.getInstance(SettingActivity.this).getLanguage() == null) {
            language = getResources().getString(R.string.english);
        } else {
            language = SharedPrefManager.getInstance(SettingActivity.this).getLanguage();
            binding.languageName.setText(language);
        }
      /*  if(SharedPrefManager.getInstance(SettingActivity.this).getGender()== null ){
            gender = getResources().getString(R.string.not_added);
            Log.v("getGender","if "+gender);
            binding.userGender.setText(gender);
        }else {
            gender=SharedPrefManager.getInstance(SettingActivity.this).getGender();
            binding.userGender.setText(gender);
            Log.v("getGender","else");
        }*/

        hideAppBar(this);
        binding.onBack.setOnClickListener(this);
        binding.userGenderLayout.setOnClickListener(this);
        binding.languageLayout.setOnClickListener(this);
        binding.userBirthdayLayout.setOnClickListener(this);
        binding.userNameTextView.setOnClickListener(this);
        //binding.userMobileNumberTextView.setOnClickListener(this);
        binding.userMobileLayout.setOnClickListener(this);
        binding.userEmailTextView.setOnClickListener(this);
        binding.userPasswordLayout.setOnClickListener(this);
        binding.editMobIcon.setOnClickListener(this);
        binding.editUserNameIcon.setOnClickListener(this);
        binding.editEmailIcon.setOnClickListener(this);
        binding.profileUploadIcon.setOnClickListener(this);
        binding.rateAppLayout.setOnClickListener(this);

        try {
            PackageInfo pInfo = this.getPackageManager().getPackageInfo(this.getPackageName(), 0);
            binding.appVersion.setText("App version " + pInfo.versionName);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        viewModel.getUserName().observe(this, s -> {
            if (s != null) {
                removeError(binding.userNameTextInput);
                if (TextUtils.isEmpty(s)) {
                    showError(Messages.EmptyMessage, binding.userNameTextInput, binding.userNameEditText);
                    //userData.setUserName(null);
                } else if (viewModel.validateUserName(s)) {
                    if (nameErrorCount > 0) {
                        showError(Messages.userNameShortMessage, binding.userNameTextInput, binding.userNameEditText);
                    }
                    //userData.setUserName(s);
                } /*else {
                    //userData.setUserName(s);
                }*/
            } /*else {

                // userData.setUserName(null);
            }*/
        });
        viewModel.getUserPhoneNumber().observe(this, s -> {
            if (s != null) {
                Log.v("hintLength", "s number length " + s.length());
                removeError(binding.phoneNumberTextInput);
                if (TextUtils.isEmpty(s)) {
                    showError(Messages.EmptyMessage, binding.phoneNumberTextInput, binding.phoneNumberEditText);
                    //userData.setUserName(null);
                } else if (s.length() < 10) {
                    if (mobErrorCount > 0) {
                        showError(Messages.phoneNumberValidMessage, binding.phoneNumberTextInput, binding.phoneNumberEditText);
                    }
                    //userData.setUserName(s);
                } /*else {
                    //userData.setUserName(s);
                }*/
            } /*else {
                //showError(Messages.EmptyMessage, binding.uNameTextInput, binding.usame);
                //model.setUserName(null);
            }*/
        });
        viewModel.getUserEmail().observe(this, s -> {
            if (s != null) {
                removeError(binding.userEmailTextInput);
                if (TextUtils.isEmpty(s)) {
                    showError(Messages.EmptyMessage, binding.userEmailTextInput, binding.userEmailEditText);
                    //userData.setUserName(null);
                } else if (!viewModel.validateUserEmail(s)) {
                    if (emailErrorCount > 0) {
                        showError(Messages.emailValidMessage, binding.userEmailTextInput, binding.userEmailEditText);
                    }
                    //userData.setUserName(s);
                } /*else {
                    //userData.setUserName(s);
                }*/
            } /*else {

                // userData.setUserName(null);
            }*/
        });

        permissionlistener = new PermissionListener() {
            @Override
            public void onPermissionGranted() {
               // Toast.makeText(SettingActivity.this, "Permission Granted", Toast.LENGTH_SHORT).show();
                showImagePickerDialog();
            }

            @Override
            public void onPermissionDenied(List<String> deniedPermissions) {
                Toast.makeText(SettingActivity.this, "Permission Denied\n" + deniedPermissions.toString(), Toast.LENGTH_SHORT).show();
            }


        };
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.onBack:
                // hideLayout();
                onBackPressed();
                break;
            case R.id.userGenderLayout:
                // hideLayout();
                showGenderDialog();
                break;
            case R.id.languageLayout:
                //hideLayout();
                showLanguageDialog();
                break;
            case R.id.userBirthdayLayout:
                // hideLayout();
                showDatePickerDialog();
                break;
            case R.id.userNameTextView:
                binding.userNameEditText.requestFocus();
                binding.userNameTextView.setVisibility(View.GONE);
                binding.userNameEditLayout.setVisibility(View.VISIBLE);
                // nextActivity(SettingActivity.this, UpdateNameActivity.class);
                break;
            case  R.id.userMobileLayout:
                Intent updateIntent = new Intent(SettingActivity.this, UpdateMobNumberActivity.class);
                updateIntent.putExtra("userMobileNumber",binding.userMobileNumberTextView.getText().toString().trim());
                startActivity(updateIntent);
                break;
            case R.id.userMobileNumberTextView:
               // nextActivity(SettingActivity.this, UpdateMobNumberActivity.class);
              /*  Intent updateIntent = new Intent(SettingActivity.this, UpdateMobNumberActivity.class);
                updateIntent.putExtra("userMobileNumber",binding.userMobileNumberTextView.getText().toString().trim());
                startActivity(updateIntent);*/
                if (MainApp.getInstance().getUserData().getProvider().equalsIgnoreCase("mobile_no")) {
                    //   binding.userMobileNumberTextView.setText( MainApp.getInstance().getUserData().getUserMobNumber());
                    showToast(SettingActivity.this, "Not Allowed to Change your phone number");
                } else {
                    binding.phoneNumberEditText.requestFocus();
                    binding.userMobileNumberTextView.setVisibility(View.GONE);
                    binding.editMobLayout.setVisibility(View.VISIBLE);
                }
             /*   if(SharedPrefManager.getInstance(SettingActivity.this).getSocialFlag()){
                    binding.phoneNumberEditText.requestFocus();
                    binding.userMobileNumberTextView.setVisibility(View.GONE);
                    binding.editMobLayout.setVisibility(View.VISIBLE);

                }else {
                    showToast(SettingActivity.this,"Not Allowed to Change your phone number");
                }*/
                //`nextActivity(SettingActivity.this, UpdateMobNumberActivity.class);
                break;
            case R.id.userEmailTextView:
                // nextActivity(SettingActivity.this, UpdateEmailActivity.class);
                // if(SharedPrefManager.getInstance(SettingActivity.this).getSocialFlag()){
                if (MainApp.getInstance().getUserData().getProvider().equalsIgnoreCase("email") ||
                        MainApp.getInstance().getUserData().getProvider().equalsIgnoreCase("google") ||
                        MainApp.getInstance().getUserData().getProvider().equalsIgnoreCase("gmail") ||
                        MainApp.getInstance().getUserData().getProvider().equalsIgnoreCase("facebook")) {
                    showToast(SettingActivity.this, "Not Allowed to Change your email");
                } else {
                    binding.userEmailEditText.requestFocus();
                    binding.userEmailTextView.setVisibility(View.GONE);
                    binding.userEmailEditTextLayout.setVisibility(View.VISIBLE);
                }

                break;
            case R.id.userPasswordLayout:
                nextActivity(SettingActivity.this, UpdatePasswordActivity.class);
                break;
            case R.id.editMobIcon:
                mobNumberUpdateProcess();
                break;
            case R.id.editUserNameIcon:
                nameUpdateProcess();
                break;
            case R.id.editEmailIcon:
                emailUpdateProcess();
                break;
            case R.id.profileUploadIcon:
                getStoragePermission();
                break;

            case R.id.rateAppLayout:
                Uri uri = Uri.parse("market://details?id=" + getPackageName());
                Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);
                try {
                    startActivity(myAppLinkToMarket);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getApplicationContext(), " unable to find market app", Toast.LENGTH_LONG).show();
                }
                break;

            default:
                break;

        }
    }

    private void showImagePickerDialog() {
        final Dialog dialog = new Dialog(SettingActivity.this);
        dialog.setContentView(R.layout.image_picker_dialog);
        // if button is clicked, close the custom dialog
        dialog.findViewById(R.id.takePhoto).setOnClickListener(v -> {


            Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(cameraIntent, CAMERA_REQUEST);
            dialog.dismiss();


        });
        dialog.findViewById(R.id.choose).setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK);
            intent.setType("image/*");
            startActivityForResult(intent, PICK_IMAGE);

            dialog.dismiss();
        });
        dialog.show();
        Window window = dialog.getWindow();
        assert window != null;
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private void showLanguageDialog() {

        final Dialog dialog = new Dialog(SettingActivity.this);
        dialog.setContentView(R.layout.language_dialog);
        RadioGroup rGroup = dialog.findViewById(R.id.radioGroupLanguage);
        if (language.equalsIgnoreCase("english"))
            rGroup.check(R.id.radio_one);
        else if (language.equalsIgnoreCase("اردو"))
            rGroup.check(R.id.radio_two);
        else if (language.equalsIgnoreCase("العربية"))
            rGroup.check(R.id.radio_three);
        else
            rGroup.check(R.id.radio_one);

        dialog.findViewById(R.id.cancel).setOnClickListener(v -> dialog.dismiss());

        rGroup.setOnCheckedChangeListener((group, checkedId) -> {
            RadioButton checkedRadioButton = group.findViewById(checkedId);
            language = (String) checkedRadioButton.getText();
            binding.languageName.setText(language);
            SharedPrefManager.getInstance(SettingActivity.this).setLanguage(language);
            setAppLanguage(language);
            dialog.dismiss();
            //Toast.makeText(SettingActivity.this, "Selected Radio Button: " + checkedRadioButton.getText(), Toast.LENGTH_SHORT).show();
        });
        dialog.show();
        Window window = dialog.getWindow();
        assert window != null;
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private void showGenderDialog() {
        if (SharedPrefManager.getInstance(SettingActivity.this).getGender() == null) {
            gender = getResources().getString(R.string.not_added);
            Log.v("getGender", "if " + gender);

        } else {
            gender=MainApp.getInstance().getUserData().getUserGender();
        }
        final Dialog dialog = new Dialog(SettingActivity.this);
        dialog.setContentView(R.layout.gender_dialog);
        RadioGroup rGroup = dialog.findViewById(R.id.radioGroup);
        if (gender.equalsIgnoreCase("female"))
            rGroup.check(R.id.radio_one);
        else if (gender.equalsIgnoreCase("Male"))
            rGroup.check(R.id.radio_two);
        else
            rGroup.check(R.id.radio_three);

        dialog.findViewById(R.id.ok).setOnClickListener(v -> {
            binding.userGender.setText(gender);
            startLoader();
            viewModel.updateProfileRequest(user_id,
                    "gender", gender, SettingActivity.this);
            updateProfile();
            dialog.dismiss();

        });
        dialog.findViewById(R.id.cancel).setOnClickListener(v -> dialog.dismiss());

        rGroup.setOnCheckedChangeListener((group, checkedId) -> {
            RadioButton checkedRadioButton = group.findViewById(checkedId);
            gender = (String) checkedRadioButton.getText();
            SharedPrefManager.getInstance(SettingActivity.this).setGender(gender);
            //Toast.makeText(SettingActivity.this, "Selected Radio Button: " + checkedRadioButton.getText(), Toast.LENGTH_SHORT).show();
        });
        dialog.show();
        Window window = dialog.getWindow();
        assert window != null;
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private void showDatePickerDialog() {
        DialogFragment datePicker = new DatePickerFragment();
        datePicker.show(getSupportFragmentManager(), "date picker");
    }

    private void nameUpdateProcess() {
        nameErrorCount = 1;
        removeError(binding.userNameTextInput);
        binding.userNameTextView.setVisibility(View.VISIBLE);
        binding.userNameEditLayout.setVisibility(View.GONE);
        if (Objects.requireNonNull(binding.userNameEditText.getText()).toString().trim().isEmpty()) {
            // showError(Messages.EmptyMessage, binding.userNameTextInput);
            showToast(SettingActivity.this, Messages.EmptyMessage);
            return;
        } else if (viewModel.validateUserName(String.valueOf(binding.userNameEditText.getText()))) {
            /*showError2(Messages.userNameShortMessage, binding.userNameTextInput, binding.userNameEditText);*/
            //   showError(Messages.userNameShortMessage, binding.userNameTextInput);
            showToast(SettingActivity.this, Messages.userNameShortMessage);
            return;
        }
        startLoader();
        binding.userNameTextView.setText(binding.userNameEditText.getText().toString());
        viewModel.updateProfileRequest(user_id,
                "first_name",
                binding.userNameEditText.getText().toString().trim(),
                SettingActivity.this);
        updateProfile();
        showToast(getApplicationContext(), "Proceed");
    }

    private void mobNumberUpdateProcess() {
        mobErrorCount = 1;
        removeError(binding.phoneNumberTextInput);
        binding.userMobileNumberTextView.setVisibility(View.VISIBLE);
        binding.editMobLayout.setVisibility(View.GONE);
        // Toast.makeText(getApplicationContext(), "phoneNumberEditText Lost the focus", Toast.LENGTH_SHORT).show();
        if (Objects.requireNonNull(binding.phoneNumberEditText.getText()).toString().trim().isEmpty()) {
            // showError(Messages.EmptyMessage, binding.phoneNumberTextInput);
            showToast(SettingActivity.this, Messages.EmptyMessage);

            return;
        } else if (String.valueOf(binding.phoneNumberEditText.getText()).length() < 10) {
            showToast(SettingActivity.this, Messages.phoneNumberValidMessage);
            // showError(Messages.phoneNumberValidMessage, binding.phoneNumberTextInput);
            return;
        }
        binding.userMobileNumberTextView.setText(binding.phoneNumberEditText.getText().toString());
        startLoader();
        viewModel.updateProfileRequest(user_id,
                "mobile_no",
                binding.phoneNumberEditText.getText().toString().trim(),
                SettingActivity.this);
        updateProfile();
        showToast(getApplicationContext(), "Proceed");
    }

    private void emailUpdateProcess() {
        emailErrorCount = 1;
        // Toast.makeText(getApplicationContext(), "phoneNumberEditText Lost the focus", Toast.LENGTH_SHORT).show();
        removeError(binding.userEmailTextInput);
        binding.userEmailTextView.setVisibility(View.VISIBLE);
        binding.userEmailEditTextLayout.setVisibility(View.GONE);
        if (Objects.requireNonNull(binding.userEmailEditText.getText()).toString().trim().isEmpty()) {
            //showError(Messages.EmptyMessage, binding.userEmailTextInput);
            showToast(SettingActivity.this, Messages.EmptyMessage);
            return;
        } else if (!viewModel.validateUserEmail(binding.userEmailEditText.getText().toString())) {
            showToast(SettingActivity.this, Messages.emailValidMessage);
            // showError(Messages.emailValidMessage, binding.userEmailTextInput);
            return;
        }
        binding.userEmailTextView.setText(binding.userEmailEditText.getText().toString());
        startLoader();
        viewModel.updateProfileRequest(user_id,
                "email",
                binding.userEmailEditText.getText().toString().trim(),
                SettingActivity.this);
        updateProfile();
        showToast(getApplicationContext(), "Proceed");
    }


    private void updateProfile() {
        viewModel.updateProfileRepose().observe(this, dataModelObject -> {
            stopLoader();
            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                MainApp.getInstance().setUserData(dataModelObject.getData().getUser());
                showToast(SettingActivity.this, "Profile Update SuccessFully");

            } else {
                //showToast(SettingActivity.this, dataModelObject.getError().getMessage());
                if (dataModelObject.getError().getMessage() != null) {
                    showToast(SettingActivity.this, dataModelObject.getError().getMessage());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                } else if (dataModelObject.getError().getMessages() != null) {
                    showToast(SettingActivity.this, dataModelObject.getError().getMessages().toString());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                }
            }


        });
    }


    @Override
    public void onDateSet(DatePicker view, int year, int month, int date) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.YEAR, year);
        c.set(Calendar.MONTH, month);
        c.set(Calendar.DATE, date);
        //String currentDateString = DateFormat.getDateInstance(DateFormat.DEFAULT).format(c.getTime());
        String oldDateString = DateFormat.getDateInstance(DateFormat.DATE_FIELD).format(c.getTime());
        String newDate = parseDateToddMMyyyy(oldDateString);
        binding.userBirthday.setText(newDate);
        Log.v("onDateSet", "onDateSet " + newDate);
        startLoader();
        viewModel.updateProfileRequest(user_id, "date_of_birth", newDate, SettingActivity.this);
        updateProfile();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            FileModel fileModel;
            if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && null != data) {
                Uri imageUri = data.getData();
                fileModel = getFilePath(imageUri);
                Log.v("setGlideImage", "getFileName " + fileModel.getFileName());
                Log.v("setGlideImage", "getFilePath " + fileModel.getFilePath());
                Log.v("setGlideImage", "imageUri " + imageUri);
                stringImage = fileModel.getFilePath();
                updateImage(fileModel.getFileName());
                // binding.profileUploadIcon.setImageURI(imageUri);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    profileBitmap = ImageDecoder.decodeBitmap(ImageDecoder.createSource(this.getContentResolver(), Objects.requireNonNull(imageUri)));
                } else {
                    profileBitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);
                }
                // binding.profileUploadIcon.setImageBitmap(profileBitmap);
                //stringImage = encodeTobase64(bitmap);
            }
            if (requestCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK) {
                profileBitmap = (Bitmap) Objects.requireNonNull(Objects.requireNonNull(data).getExtras()).get("data");
                fileModel = getFilePath(getImageUri(SettingActivity.this, Objects.requireNonNull(profileBitmap)));
                stringImage = fileModel.getFilePath();
                updateImage(fileModel.getFileName());
                //binding.profileUploadIcon.setImageBitmap(profileBitmap);
                // stringImage = encodeTobase64(bitmap);
            }
        } catch (Exception e) {
            stopLoader();
            Log.v("ExceptionException", "Exception " + e);
            Toast.makeText(this, "Something went wrong", Toast.LENGTH_LONG).show();
        }
        super.onActivityResult(requestCode, resultCode, data);

    }

    @Override
    public void onResume() {
        user_id = SharedPrefManager.getInstance(SettingActivity.this).getUserInfo().getUserId();
        if (MainApp.getInstance().getUserData() != null) {
            binding.userNameTextView.setText(MainApp.getInstance().getUserData().getUserFirstName());
            //binding.userMobileNumberTextView.setText( MainApp.getInstance().getUserData().getUserMobNumber());
            if (MainApp.getInstance().getUserData().getUserMobNumber().equalsIgnoreCase("0") ||
                    (MainApp.getInstance().getUserData().getUserMobNumber().length() == 15)) {
                binding.userMobileNumberTextView.setText(getResources().getString(R.string.not_added));
            } else {
                binding.userMobileNumberTextView.setText(MainApp.getInstance().getUserData().getUserMobNumber());
            }
            //if(MainApp.getInstance().getUserData().getUserEmail().contains("@oyla.com")){
            if (MainApp.getInstance().getUserData().getUserEmail() == null || MainApp.getInstance().getUserData().getUserEmail().isEmpty()) {
                // binding.profileUploadIcon
                binding.userEmailTextView.setText(getResources().getString(R.string.not_added));
            } else {
                binding.userEmailTextView.setText(MainApp.getInstance().getUserData().getUserEmail());
            }
            if (MainApp.getInstance().getUserData().getProfilePic() != null &&
                    !MainApp.getInstance().getUserData().getProfilePic().isEmpty()) {
                setGlideImage(getApplicationContext(), MainApp.getInstance().getUserData().getProfilePic()
                        , binding.profileUploadIcon, Constants.PROFILE_BASE_URL);
            }
            if (MainApp.getInstance().getUserData().getUserDOB() == null) {
                binding.userBirthday.setText(getResources().getString(R.string.not_added));
            } else {
                binding.userBirthday.setText(MainApp.getInstance().getUserData().getUserDOB());
            }
            if (SharedPrefManager.getInstance(SettingActivity.this).getGender() == null) {
                gender = getResources().getString(R.string.not_added);
                Log.v("getGender", "if " + gender);
                binding.userGender.setText(gender);
            } else {
                binding.userGender.setText(MainApp.getInstance().getUserData().getUserGender());
            }
        }
        super.onResume();
    }

    private void updateImage(String imageName) {
        startLoader();
        viewModel.updateProfileImageRequest(user_id, stringImage, imageName, SettingActivity.this);

        viewModel.updateProfileImageRepose().observe(this, dataModelObject -> {
            stopLoader();
            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                MainApp.getInstance().setUserData(dataModelObject.getData().getUser());
                showToast(SettingActivity.this, "Profile Update SuccessFully");
                binding.profileUploadIcon.setImageBitmap(profileBitmap);
               /* if(MainApp.getInstance().getUserData().getProfilePic()!=null &&
                        ! MainApp.getInstance().getUserData().getProfilePic().isEmpty()){
                    setGlideImage(SettingActivity.this,MainApp.getInstance().getUserData().getProfilePic(),binding.profileUploadIcon);
                }*/
            } else {
                //showToast(SettingActivity.this, dataModelObject.getError().getMessage());
                if (dataModelObject.getError().getMessage() != null) {
                    showToast(SettingActivity.this, dataModelObject.getError().getMessage());
                    Log.v("setGlideImage", "getErrorMessage " + dataModelObject.getError().getMessage());
                } else if (dataModelObject.getError().getMessages() != null) {
                    showToast(SettingActivity.this, dataModelObject.getError().getMessages().toString());
                    Log.v("setGlideImage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                }
            }
        });
    }

    public FileModel getFilePath(Uri uri) throws URISyntaxException {
        FileModel fileModel = new FileModel();
        String path = null;
        String selection = null;
        String[] selectionArgs = null;


        // Uri is different in versions after KITKAT (Android 4.4), we need to
        if (Build.VERSION.SDK_INT >= 19 && DocumentsContract.isDocumentUri(getApplicationContext(), uri)) {
            if (isExternalStorageDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                path = Environment.getExternalStorageDirectory() + "/" + split[1];
                //path =getExternalFilesDirs();
            } else if (isDownloadsDocument(uri)) {
                final String id = DocumentsContract.getDocumentId(uri);
                uri = ContentUris.withAppendedId(
                        Uri.parse("content://downloads/public_downloads"), Long.parseLong(id));
            } else if (isMediaDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];
                if ("image".equals(type)) {
                    uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(type)) {
                    uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(type)) {
                    uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }
                selection = "_id=?";
                selectionArgs = new String[]{
                        split[1]
                };
            }
        }
        if ("content".equalsIgnoreCase(uri.getScheme())) {


            if (isGooglePhotosUri(uri)) {
                path = uri.getLastPathSegment();
            }

            String[] projection = {
                    MediaStore.Images.Media.DATA
            };
            Cursor cursor = null;
            try {
                cursor = getContentResolver()
                        .query(uri, projection, selection, selectionArgs, null);
                int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                //get path
                if (cursor.moveToFirst()) {
                    path = cursor.getString(column_index);
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if ("file".equalsIgnoreCase(uri.getScheme())) {
            path = uri.getPath();
        }

        //set file path
        fileModel.setFilePath(path);
        //set file name
        fileModel.setFileName(getFileName(uri));

        File file = new File(path);
        long fileSizeInBytes = file.length();
        // Convert the bytes to Kilobytes (1 KB = 1024 Bytes)
        long fileSizeInKB = fileSizeInBytes / 1024;
        //
        fileModel.setFileSize(fileSizeInKB);
        return fileModel;
    }

    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

    public static boolean isGooglePhotosUri(Uri uri) {
        return "com.google.android.apps.photos.content".equals(uri.getAuthority());
    }

    public String getFileName(Uri uri) {
        String result = null;
        if (uri.getScheme().equals("content")) {
            try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    result = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                }
            }
        }
        return result;
    }

    @SuppressLint("SimpleDateFormat")
    public String parseDateToddMMyyyy(String time) {
        String inputPattern = "MM/dd/yy";
        String outputPattern = "dd-MM-yyyy";
        SimpleDateFormat inputFormat = new SimpleDateFormat(inputPattern);
        SimpleDateFormat outputFormat = new SimpleDateFormat(outputPattern);

        Date date = null;
        String str = null;

        try {
            date = inputFormat.parse(time);
            str = outputFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return str;
    }

    private void getStoragePermission() {
        TedPermission.with(this)
                .setPermissionListener(permissionlistener)
                .setDeniedMessage("If you reject permission,you can not use this service\n\nPlease turn on permissions at [Setting]  [Permission]")
                .setPermissions(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA)
                .check();

    }

    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title"+System.currentTimeMillis(), null);
        return Uri.parse(path);
    }

    @Override
    protected void onDestroy() {
        // set an exit transition


        super.onDestroy();

    }
    public void setAppLanguage(String language){
        Log.v("setAppLanguage","setAppLanguage "+language);
        if(language.equalsIgnoreCase("English")) {
            language="en";
        }
        else if( language.equalsIgnoreCase("اردو")) {
            language="ur";
        }
        Log.v("setAppLanguage","setAppLanguage "+language);
        Locale locale = new Locale(language);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        Resources resources = getResources();
        config.locale = locale;
        //resources.updateConfiguration(config, resources.getDisplayMetrics());
        getBaseContext().getResources().updateConfiguration(config,getBaseContext().getResources().getDisplayMetrics());
        Intent intent = getIntent();
        //Intent intent = new Intent(getBaseContext(), DashBoardActivity.class);
        finish();
        startActivity(intent);
    }
}