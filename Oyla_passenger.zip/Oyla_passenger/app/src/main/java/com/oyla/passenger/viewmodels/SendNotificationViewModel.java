package com.oyla.passenger.viewmodels;

import android.app.Application;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;

import com.oyla.passenger.Repository.JsonRepository;
import com.oyla.passenger.datamodels.jsonreponsedatamodel.DataModelObject;

import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

public class SendNotificationViewModel extends SharedViewModel{

    private MutableLiveData<DataModelObject> mutableLiveData;
    private JsonRepository repository;

    public SendNotificationViewModel(@NonNull Application application) {
        super(application);
    }

    public void sendNotificationRequest(String key, JSONObject notification) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.sendNotification( key,  notification);
    }

    public MutableLiveData<DataModelObject>sendNotificationRepose() {
        return mutableLiveData;
    }
}
