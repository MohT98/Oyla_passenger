package com.oyla.passenger.ui.activity;

import android.os.Bundle;
import android.util.Log;

import androidx.lifecycle.ViewModelProvider;

import com.oyla.passenger.R;
import com.oyla.passenger.databinding.ActivityCaptainReviewBinding;
import com.oyla.passenger.datamodels.CheckBookingStatusData;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.viewmodels.CaptainReviewViewModel;

public class CaptainReviewActivity extends BaseActivity {

    private ActivityCaptainReviewBinding binding;
    private CheckBookingStatusData bookingStatusData;
    private String bookingId;
    private String passengerId;
    private String driverId;
    private String driverRating="";
    private CaptainReviewViewModel viewModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        hideAppBar(this);
        binding=setContentView(this,R.layout.activity_captain_review);
        bookingId = getIntent().getStringExtra("bookingId");
        passengerId = getIntent().getStringExtra("passengerId");
        driverId = getIntent().getStringExtra("driverId");
        binding.onBack.setOnClickListener(v->{
            onBackPressed();
        });
        binding.reviewRatingBar.setOnRatingBarChangeListener((ratingBar, rating, fromUser) -> {
            driverRating=String.valueOf(rating);
            ratingBar.setRating(rating);
        });

        viewModel = new ViewModelProvider(this).get(CaptainReviewViewModel.class);
        binding.captainReview.setOnClickListener(v->{
            if(driverRating.isEmpty()){
                showToast(this, "Give Rating First");
                return;
            }
            startLoader();
            viewModel.giveDriverRatingRequest(passengerId,driverId,driverRating,binding.experienceEditText.getText().toString(),bookingId);

            viewModel.giveDriverRatingRepose().observe(this, dataModelObject -> {
                stopLoader();
                if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                        finish();
                } else {
                    //showToast(this, dataModelObject.getError().getMessage());
                    //Log.v("bookingStatusRepose", "error " + dataModelObject.getError().getMessage());
                    if(dataModelObject.getError().getMessage()!=null){
                        showToast(CaptainReviewActivity.this, dataModelObject.getError().getMessage());
                        Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                    }else if(dataModelObject.getError().getMessages()!=null){
                        showToast(CaptainReviewActivity.this, dataModelObject.getError().getMessages().toString());
                        Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                    }
                }

            });

        });


    }
}