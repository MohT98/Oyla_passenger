package com.oyla.passenger.datamodels.packages;

import android.os.Parcel;
import android.os.Parcelable;

public class PackagesList implements Parcelable {
    private String id;
    private String name;
    private String price;
    private String km_limit;
    private String validity;

    public PackagesList(String id, String name, String price, String km_limit, String validity) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.km_limit = km_limit;
        this.validity = validity;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getKm_limit() {
        return km_limit;
    }

    public void setKm_limit(String km_limit) {
        this.km_limit = km_limit;
    }

    public String getValidity() {
        return validity;
    }

    public void setValidity(String validity) {
        this.validity = validity;
    }

    public static Creator<PackagesList> getCREATOR() {
        return CREATOR;
    }

    protected PackagesList(Parcel in) {
        id = in.readString();
        name = in.readString();
        price = in.readString();
        km_limit = in.readString();
        validity = in.readString();
    }

    public static final Creator<PackagesList> CREATOR = new Creator<PackagesList>() {
        @Override
        public PackagesList createFromParcel(Parcel in) {
            return new PackagesList(in);
        }

        @Override
        public PackagesList[] newArray(int size) {
            return new PackagesList[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(name);
        dest.writeString(price);
        dest.writeString(km_limit);
        dest.writeString(validity);
    }
}
