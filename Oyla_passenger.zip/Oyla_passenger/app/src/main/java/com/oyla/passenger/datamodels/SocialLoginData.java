package com.oyla.passenger.datamodels;

import com.oyla.passenger.BuildConfig;
import com.oyla.passenger.MainApp;
import com.oyla.passenger.utilities.Constants;

public class SocialLoginData {
    private String type;
    private String mobile_no;
    private String email;
    private String first_name;
    private String last_name;
    private String provider;
    private String fcm_token;
    private String referral_code;
    private String countryName;
    private String countryCode;
    private String device_id;
    private String network;
    private String version_code;
    private String app_version;
    private String operating_system;

    public SocialLoginData(String type, String mobile_no, String email, String first_name, String last_name, String provider, String fcm_token, String referral_code, String countryName, String countryCode, String device_id, String network, String version_code, String app_version, String operating_system) {
        this.type = type;
        this.mobile_no = mobile_no;
        this.email = email;
        this.first_name = first_name;
        this.last_name = last_name;
        this.provider = provider;
        this.fcm_token = fcm_token;
        this.referral_code = referral_code;
        this.countryName = countryName;
        this.countryCode = countryCode;
        this.device_id = device_id;
        this.network = network;
        this.version_code = version_code;
        this.app_version = app_version;
        this.operating_system = operating_system;
    }
}
