package com.oyla.passenger.datamodels;

public class RatingPostModel {
    private String user_id;
    private String driver_id;
    private String rating;
    private String experience;
    private String booking_id;
    private String type;

    public RatingPostModel(String user_id, String driver_id, String rating, String experience, String booking_id, String type) {
        this.user_id = user_id;
        this.driver_id = driver_id;
        this.rating = rating;
        this.experience = experience;
        this.booking_id = booking_id;
        this.type = type;
    }
}
