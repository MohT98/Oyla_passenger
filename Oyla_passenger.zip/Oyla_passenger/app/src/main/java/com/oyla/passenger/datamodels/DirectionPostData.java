package com.oyla.passenger.datamodels;

public class DirectionPostData {
    String origin;
    String destination;
    String sensor;
    String mode;
    String key;

    public DirectionPostData(String origin, String destination, String sensor, String mode, String key) {
        this.origin = origin;
        this.destination = destination;
        this.sensor = sensor;
        this.mode = mode;
        this.key = key;
    }
}
