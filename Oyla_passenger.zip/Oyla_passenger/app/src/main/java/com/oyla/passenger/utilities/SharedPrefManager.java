package com.oyla.passenger.utilities;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

import com.oyla.passenger.MainApp;
import com.oyla.passenger.datamodels.SettingData;
import com.oyla.passenger.datamodels.usermodel.UserData;
import com.oyla.passenger.ui.activity.SplashActivity;

import java.util.Objects;

public class SharedPrefManager {

    private static SharedPrefManager mInstance;
    /*private static SharedPrefManager mInstance;*/
    /*private static Context mCtx;*/
    private final Context mCtx;

    public String SHARED_PREF_NAME = "login";
    public String SHARED_PREF_SETTING = "setting";
    public String SHARED_PREF_SOCIAL = "social_setting";
    public String SHARED_BOOKING_INFO = "booking_info";
    public String SHARED_LAT_LNG = "Lat_Lng";
    public String SHARED_FIRST_LOGIN = "first_login";


    private final String KEY_ID = "id";
    private final String KEY_FIRST_NAME = "first_name";
    private final String KEY_LAST_NAME = "last_name";
    private final String KEY_EMAIL = "email";
    private final int KEY_VERIFY = 0;
    private final String KEY_MOB_NO = "mobile_no";
    private final String KEY_PROFILE_PIC = "profile_picture";
    private final String KEY_PASSWORD = "password";
    private final String KEY_GENDER = "gender";
    private final String KEY_DOB = "DOB";
    private final String KEY_LANGUAGE = "language";
    private final boolean KEY_OYLA_PAY = false;
    private final boolean KEY_USE_CASH = true;
    private final boolean KEY_USE_CARD = false;
    private final boolean KEY_SOCIAL = false;
    private final String KEY_ACCESS_TOKEN = "accessToken";
    private final String KEY_BOOKING_INFO = "booking_data";
    private final double KEY_PICK_UP_LAT = 0.0;
    private final double KEY_PICK_UP_LNG = 0.1;
    private final double KEY_DROP_OFF_LAT = 0.2;
    private final double KEY_DROP_OFF_LNG = 0.3;
     private final boolean KEY_AUTO_START=false;
    private final boolean KEY_FIRST_LOGIN = false;



    private SharedPrefManager(Context context) {
        mCtx = context;
    }

    public static synchronized SharedPrefManager getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new SharedPrefManager(context);
        }
        return mInstance;
    }

    //this method will checker whether user is already logged in or not
    public boolean isLoggedIn() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getString(KEY_ID, null) != null;
    }

    //this method will logout the user
    public void logout() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
        MainApp.getInstance().setFireBaseToken(null);
        sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_SETTING, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
        sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_SOCIAL, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
        sharedPreferences = mCtx.getSharedPreferences(SHARED_FIRST_LOGIN, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
        mCtx.startActivity(new Intent(mCtx, SplashActivity.class));
    }

    //method to let the user login
    //this method will store the user data in shared preferences
    public void userInfo(String id, String accessToken) {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_ID, id);
        editor.putString(KEY_ACCESS_TOKEN, accessToken);
        editor.apply();
    }
  /*  public void userInfo(String id) {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_ID, id);
        editor.apply();
    }*/

    public UserData getUserInfo() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return new UserData(

                sharedPreferences.getString(KEY_ID, null),
                sharedPreferences.getString(KEY_ACCESS_TOKEN, null)


        );
    }

    public void userProfile(String id, String first_name, String last_name, String email, String mobile_no,
                            String profile_picture, int is_varified, String password, String gender, String DOB, String accessToken) {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString(KEY_ID, id);
        editor.putString(KEY_FIRST_NAME, first_name);
        editor.putString(KEY_LAST_NAME, last_name);
        editor.putString(KEY_EMAIL, email);
        editor.putString(KEY_MOB_NO, mobile_no);
        editor.putString(KEY_PROFILE_PIC, profile_picture);
        editor.putInt(String.valueOf(KEY_VERIFY), is_varified);
        editor.putString(KEY_ACCESS_TOKEN, accessToken);
        editor.apply();
    }

    //this method will give the logged in user
    public UserData getUser() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return new UserData(

                sharedPreferences.getString(KEY_ID, null),
                sharedPreferences.getString(KEY_FIRST_NAME, null),
                sharedPreferences.getString(KEY_LAST_NAME, null),
                sharedPreferences.getString(KEY_EMAIL, null),
                sharedPreferences.getString(KEY_MOB_NO, null),
                sharedPreferences.getString(KEY_PROFILE_PIC, null),
                sharedPreferences.getInt(String.valueOf(KEY_VERIFY), 0),
                sharedPreferences.getString(KEY_PASSWORD, null),
                sharedPreferences.getString(KEY_GENDER, null),
                sharedPreferences.getString(KEY_DOB, null),
                sharedPreferences.getString(KEY_ACCESS_TOKEN, null)


        );
    }

    public void setLanguage(String language) {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_SETTING, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_LANGUAGE, language);
        editor.apply();
    }

    public String getLanguage() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_SETTING, Context.MODE_PRIVATE);
        SettingData settingData = new SettingData();
        settingData.setLanguage(sharedPreferences.getString(KEY_LANGUAGE, null));
        return settingData.getLanguage();
    }


    public void setGender(String language) {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_SETTING, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_GENDER, language);
        editor.apply();
    }

    public String getGender() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_SETTING, Context.MODE_PRIVATE);
        SettingData settingData = new SettingData();
        settingData.setGender(sharedPreferences.getString(KEY_GENDER, null));
        return settingData.getGender();
    }

    public void setAutoStart(boolean autoStart) {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_SETTING, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(String.valueOf(KEY_AUTO_START), autoStart);
        editor.apply();
    }

    public boolean getAutoStart() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_SETTING, Context.MODE_PRIVATE);
        SettingData settingData = new SettingData();
        settingData.setAUTO_START(sharedPreferences.getBoolean(String.valueOf(KEY_AUTO_START), false));
        return settingData.isAUTO_START();
    }

    public void setOylaPay(boolean oylaPay) {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_SETTING, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(String.valueOf(KEY_OYLA_PAY), oylaPay);
        editor.apply();
    }

    public boolean getOylaPay() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_SETTING, Context.MODE_PRIVATE);
        SettingData settingData = new SettingData();
        settingData.setOYLA_PAY(sharedPreferences.getBoolean(String.valueOf(KEY_OYLA_PAY), false));
        return settingData.isOYLA_PAY();
    }

    public void setCash(boolean CASH) {
        Log.v("CASH", "CASH2 " + CASH);
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_SETTING, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(String.valueOf(KEY_USE_CASH), CASH);
        editor.apply();
    }

    public boolean getCash() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_SETTING, Context.MODE_PRIVATE);
        SettingData settingData = new SettingData();
        settingData.setUSE_CASH(sharedPreferences.getBoolean(String.valueOf(KEY_USE_CASH), false));
        return settingData.isUSE_CASH();
    }

    public void setCard(boolean CARD) {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_SETTING, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(String.valueOf(KEY_USE_CARD), CARD);
        editor.apply();
    }

    public boolean getCard() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_SETTING, Context.MODE_PRIVATE);
        SettingData settingData = new SettingData();
        settingData.setOYLA_PAY(sharedPreferences.getBoolean(String.valueOf(KEY_USE_CARD), false));
        return settingData.isUSE_CASH();
    }

    public void setSocialFlag(boolean social) {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_SOCIAL, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(String.valueOf(KEY_SOCIAL), social);
        editor.apply();
    }

    public boolean getSocialFlag() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_SOCIAL, Context.MODE_PRIVATE);
        UserData userData = new UserData();
        userData.setSocial_login(sharedPreferences.getBoolean(String.valueOf(KEY_SOCIAL), false));
        return userData.isSocial_login();
    }

    public void setBookingInfo(String json) {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_BOOKING_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_BOOKING_INFO, json);
        editor.apply();
    }

    public String getBookingInfo() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_BOOKING_INFO, Context.MODE_PRIVATE);
        SettingData settingData = new SettingData();
        settingData.setBookingInfo(sharedPreferences.getString(KEY_BOOKING_INFO, "empty"));
        return settingData.getBookingInfo();
    }

    public void removeBookingInfo() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_BOOKING_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
    }


    public void setPickLat(double d) {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_LAT_LNG, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putFloat(String.valueOf(KEY_PICK_UP_LAT), (float) d);
        editor.apply();
    }

    public double getPickLat() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_LAT_LNG, Context.MODE_PRIVATE);
        SettingData settingData = new SettingData();
        settingData.setKEY_PICK_UP_LAT(sharedPreferences.getFloat(String.valueOf(KEY_PICK_UP_LAT), 0));
        return settingData.getKEY_PICK_UP_LAT();
    }

    public void setPickLng(double d) {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_LAT_LNG, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putFloat(String.valueOf(KEY_PICK_UP_LNG), (float) d);
        editor.apply();
    }

    public double getPickLng() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_LAT_LNG, Context.MODE_PRIVATE);
        SettingData settingData = new SettingData();
        settingData.setKEY_PICK_UP_LNG(sharedPreferences.getFloat(String.valueOf(KEY_PICK_UP_LNG), 0));
        return settingData.getKEY_PICK_UP_LNG();
    }

    public void setDropLat(double d) {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_LAT_LNG, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putFloat(String.valueOf(KEY_DROP_OFF_LAT), (float) d);
        editor.apply();
    }

    public double getDropLat() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_LAT_LNG, Context.MODE_PRIVATE);
        SettingData settingData = new SettingData();
        settingData.setKEY_DROP_OFF_LAT(sharedPreferences.getFloat(String.valueOf(KEY_DROP_OFF_LAT), 0));
        return settingData.getKEY_DROP_OFF_LAT();
    }

    public void setDropLng(double d) {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_LAT_LNG, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putFloat(String.valueOf(KEY_DROP_OFF_LNG), (float) d);
        editor.apply();
    }

    public double getDropLng() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_LAT_LNG, Context.MODE_PRIVATE);
        SettingData settingData = new SettingData();
        settingData.setKEY_DROP_OFF_LNG(sharedPreferences.getFloat(String.valueOf(KEY_DROP_OFF_LNG), 0));
        return settingData.getKEY_DROP_OFF_LNG();
    }


    public void setFirstLogin(boolean flag) {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_FIRST_LOGIN, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(String.valueOf(KEY_FIRST_LOGIN),flag);
        editor.apply();
    }

    public boolean getFirstLogin() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_FIRST_LOGIN, Context.MODE_PRIVATE);
        SettingData settingData = new SettingData();
        //settingData.setKEY_FIRST_LOGIN(sharedPreferences.getFloat(String.valueOf(KEY_DROP_OFF_LNG), 0));
        settingData.setFIRST_LOGIN(sharedPreferences.getBoolean(String.valueOf(KEY_FIRST_LOGIN), false));
        return settingData.isFIRST_LOGIN();
    }
}