package com.oyla.passenger.ui.activity.packages;

import static com.facebook.FacebookSdk.getApplicationContext;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.oyla.passenger.R;
import com.oyla.passenger.adapter.ComplainListAdapter;
import com.oyla.passenger.adapter.PackagesListAdapter;
import com.oyla.passenger.databinding.ActivityPackagesListBinding;
import com.oyla.passenger.datamodels.packages.PackagesList;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.ui.activity.complain.ComplainListActivity;
import com.oyla.passenger.ui.activity.complain.SendComplainActivity;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.DialogBoxSingleton;
import com.oyla.passenger.utilities.SharedPrefManager;
import com.oyla.passenger.viewmodels.ComplainListViewModel;
import com.oyla.passenger.viewmodels.PackagesViewModel;

import java.util.List;

public class PackagesListActivity extends BaseActivity {
    private ActivityPackagesListBinding binding;
    private List<PackagesList> packagesListItems;
    private PackagesListAdapter mAdapter;
    private PackagesViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // setContentView(R.layout.activity_packages_list);
        hideAppBar(this);
        binding = setContentView(this, R.layout.activity_packages_list);
         viewModel = new ViewModelProvider(this).get(PackagesViewModel.class);
        binding.onBack.setOnClickListener(v -> onBackPressed());
        binding.recyclerView.setHasFixedSize(true);
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerView.setItemAnimator(new DefaultItemAnimator());
        Constants.Auth = Constants.Bearer + " " + SharedPrefManager.getInstance(getApplicationContext()).getUserInfo().getAccessToken();
        viewModel.sendPackageRequest();
        startLoader();
        viewModel.receivePackageRepose().observe(this, dataModelObject -> {
            stopLoader();
            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                packagesListItems=dataModelObject.getData().getPackages();
                mAdapter = new PackagesListAdapter(this, packagesListItems);

                binding.recyclerView.setAdapter(mAdapter);
                mAdapter.setOnItemClickListener(position -> {
                    Log.v("subscribe","name "+packagesListItems.get(position).getName());
                    /*Intent intent = new Intent(PackagesListActivity.this, SendComplainActivity.class);
                    intent.putExtra("id", complainItems.get(position).getId());
                    intent.putExtra("subjectName", complainItems.get(position).getName());
                    intent.putExtra("bookingId", getIntent().getStringExtra("bookingId"));
                    startActivity(intent);*/
                });
            }else {
                if(dataModelObject.getError().getMessage()!=null){
                    DialogBoxSingleton.getInstance().showErrorPopup(PackagesListActivity.this,dataModelObject.getError());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                }else if(dataModelObject.getError().getMessages()!=null){
                    // showToast(RideHistoryListActivity.this, dataModelObject.getError().getMessages().toString());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                }
            }

        });
    }
}