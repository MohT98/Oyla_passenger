package com.oyla.passenger.ui.activity.reward;

import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;
import android.util.Log;

import com.bumptech.glide.Glide;
import com.oyla.passenger.R;
import com.oyla.passenger.databinding.ActivityRewardDetailBinding;
import com.oyla.passenger.datamodels.redeemdata.RedeemListData;
import com.oyla.passenger.datamodels.usermodel.UserData;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.DialogBoxSingleton;
import com.oyla.passenger.utilities.SharedPrefManager;
import com.oyla.passenger.viewmodels.RewardViewModel;

public class RewardDetailActivity extends BaseActivity {

    private ActivityRewardDetailBinding binding;
    RedeemListData redeemListData;
    private RewardViewModel viewModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // setContentView(R.layout.activity_reward_detail);
        binding = setContentView(this, R.layout.activity_reward_detail);
        viewModel = new ViewModelProvider(RewardDetailActivity.this).get(RewardViewModel.class);
        hideAppBar(this);
        binding.onBack.setOnClickListener(v -> onBackPressed());
        redeemListData = getIntent().getParcelableExtra("Item");
        binding.description.setText(redeemListData.getDescription());
        binding.cancelButton.setOnClickListener(v -> onBackPressed());
        binding.redeemButton.setOnClickListener(v -> redeem());
        Glide
                .with(RewardDetailActivity.this)
                //.load("http://lead2need.ca/stagingadmin/public/vehicles/gallery/dummy.jpg"
                .load(Constants.ASSETS_BASE_URL +redeemListData.getBanner_image())
                // .centerCrop()
                .placeholder(R.drawable.maskgroup)
                .into(binding.banner);

    }
    private void redeem(){
        UserData  userData = SharedPrefManager.getInstance(this).getUserInfo();
        viewModel.redeemRequest(userData.getUserId() ,redeemListData.getId());
        startLoader();
        viewModel.redeemRepose().observe(RewardDetailActivity.this, dataModelObject -> {
            stopLoader();
            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                Log.v("TotalPoints", "TotalPoints frag " + dataModelObject.getData());
                showToast(RewardDetailActivity.this,getString(R.string.successfully_redeem_message));
                finish();

            } else {
                DialogBoxSingleton.getInstance().showErrorPopup(RewardDetailActivity.this, dataModelObject.getError());
                if (dataModelObject.getError().getMessage() != null) {
                    //showToast(MapActivity.this, dataModelObject.getError().getMessage());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                } else if (dataModelObject.getError().getMessages() != null) {
                    //showToast(MapActivity.this, dataModelObject.getError().getMessages().toString());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                }
            }
        });
    }
}