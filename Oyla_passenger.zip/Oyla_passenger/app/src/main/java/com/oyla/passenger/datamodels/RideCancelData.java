package com.oyla.passenger.datamodels;

public class RideCancelData {
    private String user_id;
    private String booking_id;
    private String descriptions;
    private String chat_messages;


    public RideCancelData(String user_id, String booking_id, String descriptions, String chat_messages) {
        this.user_id = user_id;
        this.booking_id = booking_id;
        this.descriptions = descriptions;
        this.chat_messages = chat_messages;
    }
}
