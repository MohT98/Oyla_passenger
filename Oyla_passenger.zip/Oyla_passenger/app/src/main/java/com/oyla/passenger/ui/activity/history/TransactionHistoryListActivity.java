package com.oyla.passenger.ui.activity.history;

import android.os.Bundle;
import android.util.Log;

import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.oyla.passenger.R;
import com.oyla.passenger.adapter.history.TransactionHistoryListAdapter;
import com.oyla.passenger.databinding.ActivityTransactionHistoryListActivtyBinding;
import com.oyla.passenger.datamodels.historydata.TransactionHistoryData;
import com.oyla.passenger.datamodels.usermodel.UserData;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.DialogBoxSingleton;
import com.oyla.passenger.utilities.SharedPrefManager;
import com.oyla.passenger.viewmodels.PayViewModel;

import java.util.List;

public class TransactionHistoryListActivity extends BaseActivity {
    private ActivityTransactionHistoryListActivtyBinding binding;
    private TransactionHistoryListAdapter mAdapter;
    private PayViewModel viewModel;
    //ArrayList<TransactionHistoryData> transactionItems;
    List<TransactionHistoryData> transactionItems;
    private UserData userData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        userData = SharedPrefManager.getInstance(this).getUserInfo();
        hideAppBar(this);
        binding = setContentView(this, R.layout.activity_transaction_history_list_activty);
        viewModel = new ViewModelProvider(this).get(PayViewModel.class);
        binding.onBack.setOnClickListener(v -> onBackPressed());

        // ArrayList<TransactionHistoryData> transactionItems = new ArrayList<TransactionHistoryData>();
        binding.recyclerViewTransaction.setHasFixedSize(true);
        binding.recyclerViewTransaction.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerViewTransaction.setItemAnimator(new DefaultItemAnimator());
        viewModel.sendTransactionHistoryRequest(userData.getUserId());
        startLoader();

        viewModel.receiveTransactionHistoryRepose().observe(this, dataModelObject -> {
            stopLoader();
            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                transactionItems = dataModelObject.getData().getNonCashTransaction();
                mAdapter = new TransactionHistoryListAdapter(this, transactionItems);
                binding.recyclerViewTransaction.setAdapter(mAdapter);
               /* mAdapter.setOnItemClickListener(position -> {
                    Intent intent = new Intent(TransactionHistoryListActivity.this, TransactionDetailActivity.class);
                    intent.putExtra("Item", transactionItems.get(position));
                    startActivity(intent);
                });*/
            } else {
                //showToast(this, dataModelObject.getError().getMessage());
                if(dataModelObject.getError().getMessage()!=null){
                    DialogBoxSingleton.getInstance().showErrorPopup(TransactionHistoryListActivity.this, dataModelObject.getError());
                    showToast(TransactionHistoryListActivity.this, dataModelObject.getError().getMessage());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                }else if(dataModelObject.getError().getMessages()!=null){
                    showToast(TransactionHistoryListActivity.this, dataModelObject.getError().getMessages().toString());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                }
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();

    }
}