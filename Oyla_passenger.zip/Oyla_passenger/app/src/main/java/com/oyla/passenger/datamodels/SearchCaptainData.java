package com.oyla.passenger.datamodels;

public class SearchCaptainData {
    private String vehicle_type_id;
    private String user_id;
    private String pickup_latitude;
    private String pickup_longitude;
    private String dropoff_latitude;
    private String dropoff_longitude;
    private String distance_kilomiters;
    private String estimate_minutes;
    private String amount;
    private String vehicle_type;
    private String vehicle_amount;
    private String oyla_pay;
    private String payment_type;
    private String peak_factor_rate;
    private String driver_initial_distance;
    private String min_ride_fares;
    private String pickup_address;
    private String dropoff_address;
    private int is_skip_dropoff;
    private String fcm_token;

    public SearchCaptainData(String vehicle_type_id, String user_id, String pickup_latitude, String pickup_longitude, String dropoff_latitude, String dropoff_longitude, String distance_kilomiters, String estimate_minutes, String amount, String vehicle_type, String vehicle_amount, String oyla_pay, String payment_type, String peak_factor_rate, String driver_initial_distance, String min_ride_fares, String pickup_address, String dropoff_address, int is_skip_dropoff, String fcm_token) {
        this.vehicle_type_id = vehicle_type_id;
        this.user_id = user_id;
        this.pickup_latitude = pickup_latitude;
        this.pickup_longitude = pickup_longitude;
        this.dropoff_latitude = dropoff_latitude;
        this.dropoff_longitude = dropoff_longitude;
        this.distance_kilomiters = distance_kilomiters;
        this.estimate_minutes = estimate_minutes;
        this.amount = amount;
        this.vehicle_type = vehicle_type;
        this.vehicle_amount = vehicle_amount;
        this.oyla_pay = oyla_pay;
        this.payment_type = payment_type;
        this.peak_factor_rate = peak_factor_rate;
        this.driver_initial_distance = driver_initial_distance;
        this.min_ride_fares = min_ride_fares;
        this.pickup_address = pickup_address;
        this.dropoff_address = dropoff_address;
        this.is_skip_dropoff = is_skip_dropoff;
        this.fcm_token = fcm_token;
    }
}
