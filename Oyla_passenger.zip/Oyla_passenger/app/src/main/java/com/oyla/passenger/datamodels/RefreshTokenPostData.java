package com.oyla.passenger.datamodels;

import android.os.Build;

import com.google.gson.annotations.SerializedName;

public class RefreshTokenPostData {
    String user_id;
    @SerializedName("sdk")
    public int SDK ;
    @SerializedName("model")// API Level// Device
    public String model ;
    @SerializedName("manufacturer")// Model
    public  String MANUFACTURER;
    @SerializedName("brand")
    public String BRAND;
    @SerializedName("android_version")
    public String ANDROIDVERSION;
    @SerializedName("phone")
    public String phone_number;
    public String app_version;

    public RefreshTokenPostData(String user_id, int SDK, String model, String MANUFACTURER, String BRAND, String ANDROIDVERSION, String phone_number, String app_version) {
        this.user_id = user_id;
        this.SDK = SDK;
        this.model = model;
        this.MANUFACTURER = MANUFACTURER;
        this.BRAND = BRAND;
        this.ANDROIDVERSION = ANDROIDVERSION;
        this.phone_number = phone_number;
        this.app_version = app_version;

    }
}
