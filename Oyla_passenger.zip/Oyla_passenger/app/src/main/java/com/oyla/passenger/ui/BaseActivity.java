package com.oyla.passenger.ui;

import android.Manifest;
import android.app.ActivityManager;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.provider.Settings;
import android.util.Base64;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;

import com.bumptech.glide.Glide;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.oyla.passenger.BroadcastReceiver.GpsChangeReceiver;
import com.oyla.passenger.BroadcastReceiver.InternetConnector_Receiver;
import com.oyla.passenger.R;
import com.oyla.passenger.services.location.LocationService;
import com.oyla.passenger.ui.activity.dahsboard.DashBoardActivity;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.DialogBoxSingleton;
import com.oyla.passenger.utilities.ExceptionHandler;
import com.oyla.passenger.utilities.Loading;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicReference;

import es.dmoral.toasty.Toasty;
import okhttp3.logging.HttpLoggingInterceptor;

import static com.oyla.passenger.utilities.Constants.ERROR_DIALOG_REQUEST;
import static com.oyla.passenger.utilities.Constants.GPS_DIALOG;
import static com.oyla.passenger.utilities.Constants.PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION;
import static com.oyla.passenger.utilities.Constants.PERMISSIONS_REQUEST_ENABLE_GPS;
import static com.oyla.passenger.utilities.Constants.WIFI_DIALOG;
import static com.oyla.passenger.utilities.Constants.firebaseAuth;
import static com.oyla.passenger.utilities.Constants.googleSignInClient;
import static com.oyla.passenger.utilities.Constants.mLocationPermissionGranted;


public class BaseActivity extends AppCompatActivity {

    private static final String TAG = "BaseActivity";
    private View progress;
    private View mainFrame;
    private TextView toolbarTitle;
    private NavigationView navigationView;
    public static HttpLoggingInterceptor loggingInterceptor;
    private static BaseActivity instance;
    private Dialog progressLoader;
    private GpsChangeReceiver m_gpsChangeReceiver;
    private InternetConnector_Receiver internetConnector_receiver;
    private Thread t;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));
        loggingInterceptor = new HttpLoggingInterceptor();
        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));
        //loggingInterceptor.redactHeader(Constants.Auth);
        instance = this;
        internetConnector_receiver = new InternetConnector_Receiver();
        IntentFilter filter = new IntentFilter();
        filter.addAction(getResources().getString(R.string.action_connectivity_change));
        registerReceiver(internetConnector_receiver, filter);
        Toasty.Config.getInstance()
                .tintIcon(true )
                .allowQueue(false)
                .apply();
        /*mReceiver = new PackageInstallReceiver();
        mReceiver.register(this);*/
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(newBase);
        //LocaleHelper.onAttach(newBase);
    }
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (getCurrentFocus() != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
        return super.dispatchTouchEvent(ev);
    }

    public static BaseActivity getInstance() {
        return instance;
    }

    public void hideAppBar(AppCompatActivity activity) {
        Objects.requireNonNull(activity.getSupportActionBar()).hide();
    }

    public void hideStatusBar(AppCompatActivity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            final WindowInsetsController insetsController = activity.getWindow().getInsetsController();
            if (insetsController != null) {
                insetsController.hide(WindowInsets.Type.statusBars());
            }
        } else {
            activity.getWindow().setFlags(
                    WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN
            );
        }
    }

    public void showError(String str, TextInputLayout inputLayout, EditText editText) {
        inputLayout.setError(str);
        editText.requestFocus();
    }

    public void removeError(TextInputLayout inputLayout) {
        inputLayout.setError(null);
        inputLayout.setErrorEnabled(false);
    }

    protected <T extends ViewDataBinding> T setContentView(AppCompatActivity activity, int layoutId) {
        return DataBindingUtil.setContentView(activity, layoutId);
    }

    public String getStringAddress(double latitude, double longitude) {
        Geocoder geocoder;
        List<Address> addresses;
            geocoder = new Geocoder(this, Locale.getDefault());
        Log.v("LatLoggetStringAddress", "latitude " + latitude);
        Log.v("LatLoggetStringAddress", "longitude " + longitude);

        if (latitude != 0.0 && longitude != 0.0) {
            String address;
            try {
                Log.v("LatLoggetStringAddress", "try ");
                if (geocoder.getFromLocation(latitude, longitude, 1) != null) {
                    addresses = geocoder.getFromLocation(latitude, longitude, 1);
                    if (!addresses.isEmpty()) {
                        address = addresses.get(0).getAddressLine(0);
                      //  Log.v("LatLoggetStringAddress", "address " + address);
                    } else {
                        address = "Finding Address...";
                    }
                } else {
                    address = "Finding Address...";
                }


                return address;
            } catch (IOException e) {
                Log.v("LatLoggetStringAddress", "catch "+e);
                e.printStackTrace();
                return "Finding Address...";
            }
        } else {
            return "Finding Address...";
        }
    }


    public List<Address> getStringAddress2(double latitude, double longitude) {
        Geocoder geocoder;
        List<Address> addresses;
        geocoder = new Geocoder(this, Locale.getDefault());
        Log.v("LatLog", "latitude " + latitude);
        Log.v("LatLog", "longitude " + longitude);
        if (latitude != 0.0 && longitude != 0.0) {
            try {
                if (geocoder.getFromLocation(latitude, longitude, 1) != null) {
                    addresses = geocoder.getFromLocation(latitude, longitude, 1);
                    Log.v("getStringAddress", "getSubLocality " + addresses.get(0).getSubLocality());
                    Log.v("getStringAddress", "getLocality " + addresses.get(0).getLocality());
                } else {
                    addresses = null;
                }

              /*  String address = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
                String city = addresses.get(0).getLocality();
                String state = addresses.get(0).getAdminArea();
                String country = addresses.get(0).getCountryName();
                String postalCode = addresses.get(0).getPostalCode();
                String knownName = addresses.get(0).getFeatureName();*/
                //  Log.v("getStringAddress","postalCode "+postalCode);

                return addresses;
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        } else {
            return null;
        }
    }

    public void nextActivity(Context context, Class<?> cls) {
        Intent i = new Intent(context, cls);
        startActivity(i);
    }

    public void showToast(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }
    public void showCustomSuccessToast(Context context, String message) {
        Toasty.success(context, message, Toast.LENGTH_SHORT, true).show();
    }
    public void showCustomWarningToast(Context context, String message) {
        Toasty.warning(context, message, Toast.LENGTH_SHORT, true).show();
    }
    public void showCustomErrorToast(Context context, String message) {
        Toasty.error(context, message, Toast.LENGTH_SHORT, true).show();
    }

    public void showToastLong(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_LONG).show();
    }

    public void retrofitOnFailure(Throwable t) {
        stopLoader();
        if (t instanceof IOException) {
        //    Toast.makeText(BaseActivity.this, ServerError, Toast.LENGTH_SHORT).show();
            // logging probably not necessary
        } else {
            // Toast.makeText(BaseActivity.this, " ", Toast.LENGTH_SHORT).show();
            // todo log to some central bug tracking service
        }
    }

    public void configureGoogleClient() {
        // Configure Google Sign In
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                // for the requestIdToken, this is in the values.xml file that
                // is generated from your google-services.json
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        // Build a GoogleSignInClient with the options specified by gso.
        googleSignInClient = GoogleSignIn.getClient(this, gso);
        // Set the dimensions of the sign-in button.
        //SignInButton signInButton = findViewById(R.id.sign_in_button);
        // signInButton.setSize(SignInButton.SIZE_WIDE);
        // Initialize Firebase Auth
        firebaseAuth = FirebaseAuth.getInstance();
    }

    /*public void helpLineDialog() {
        Log.v("emergencyIcon", "helpLineDialog");
        final int[] error_count = {0};
        final Dialog dialog = new Dialog(BaseActivity.this, R.style.full_screen_dialog);
        //final Dialog dialog = new Dialog(AddCreditActivity.this);
        //dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.help_line_dialog);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        EditText enterVoucherEdiText = dialog.findViewById(R.id.enterPromoEdiText);
        TextInputLayout enterVoucherTextInput = dialog.findViewById(R.id.enterPromoTextInput);
        dialog.findViewById(R.id.cancelButton).setOnClickListener(v -> dialog.dismiss());

        dialog.findViewById(R.id.activateCall).setOnClickListener(V -> {
            Constants.phoneCall(BaseActivity.this);
        });

        if (!(BaseActivity.this).isFinishing()) {
            //show dialog
            dialog.show();
        }

        Window window = dialog.getWindow();
        assert window != null;
        //window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        //window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setGravity(Gravity.BOTTOM);
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }*/

    public void snackMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    public String encodeTobase64(Bitmap image) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        image.compress(Bitmap.CompressFormat.PNG, 100, baos);
        byte[] b = baos.toByteArray();

        return Base64.encodeToString(b, Base64.DEFAULT);
    }

    public static Bitmap decodeBase64(String input) {
        byte[] decodedByte = Base64.decode(input, 0);
        return BitmapFactory
                .decodeByteArray(decodedByte, 0, decodedByte.length);
    }

    public void setImage(String image, ImageView imageView) {
        if (image != null) {
            if (!image.isEmpty()) {
                String pureBase64Encoded;
                byte[] decodedBytes;
                final Bitmap decodedBitmap;
                pureBase64Encoded = image.substring(image.indexOf(',') + 1);
                decodedBytes = Base64.decode(pureBase64Encoded, Base64.DEFAULT);
                decodedBitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
                imageView.setImageBitmap(decodedBitmap);
            }
        }
    }

    public void showError(String str, TextInputLayout inputLayout) {
        inputLayout.setError(str);
    }

    public void startLoader() {
        if (!isFinishing()) {
            progressLoader = Loading.makeDialog(BaseActivity.this);
        }
       // new Handler(Looper.getMainLooper()).post(() -> {
            Log.v("startLoader", "startLoader ");
           // progressLoader = Loading.makeDialog(BaseActivity.this);
        //});
    }

    public void stopLoader() {
        if (progressLoader != null) {
            progressLoader.dismiss();
            progressLoader = null;
        }
    }

    public void showError(String str, EditText editText) {
        editText.setError(str);
    }

    public void setGlideImage(Context context, String stringUrl, ImageView imageView, String baseUrl) {

        Log.v("setGlideImage", "stringUrl " + stringUrl);
        //stringUrl="http://storage.googleapis.com/"+stringUrl;
        stringUrl = baseUrl + stringUrl;
        Log.v("setGlideImage", "update stringUrl " + stringUrl);

        Glide
                .with(context)
                //.load("http://lead2need.ca/stagingadmin/public/vehicles/gallery/dummy.jpg")
                .load(stringUrl)
                .centerCrop()
                .placeholder(R.drawable.profile_update_icon)
                .into(imageView);
    }

    protected void setToolbar(Toolbar toolbar) {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
    }

    public void setToolbarTitleTextView(TextView toolbarTitle) {
        this.toolbarTitle = toolbarTitle;
    }

    public void setToolbarTitle(String title) {
        toolbarTitle.setText(title);
    }

    protected void setView(View viewMain, View viewProgress) {
        mainFrame = viewMain;
        progress = viewProgress;
    }

    public void showProgress() {
        mainFrame.setVisibility(View.INVISIBLE);
        progress.setVisibility(View.VISIBLE);
    }

    public void hideProgress() {
        progress.setVisibility(View.INVISIBLE);
        mainFrame.setVisibility(View.VISIBLE);
    }


    public void transparentBar() {
        Window w = getWindow();
        w.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
    }


    public void showErrorToast(String message) {
        Toast.makeText(BaseActivity.this, message, Toast.LENGTH_SHORT).show();
    }

    public void buildAlertMessageNoGps() {
        // Toast.makeText(BaseActivity.this, "GPS_DIALOG "+ GPS_DIALOG, Toast.LENGTH_SHORT).show();
        if (!GPS_DIALOG) {
            GPS_DIALOG = true;

            createLocationRequest();
        }
    }

    protected void createLocationRequest() {
        LocationRequest locationRequest = LocationRequest.create();
        locationRequest.setInterval(10000);
        locationRequest.setFastestInterval(5000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder().addLocationRequest(locationRequest);

        SettingsClient client = LocationServices.getSettingsClient(this);
        Task<LocationSettingsResponse> task = client.checkLocationSettings(builder.build());

        task.addOnSuccessListener(this, locationSettingsResponse -> {
            // All location settings are satisfied. The client can initialize
            // location requests here.
            // ...
            Toast.makeText(BaseActivity.this, "Gps already open", Toast.LENGTH_LONG).show();
            Log.d("GpsChangeReceiver", "location settings" + locationSettingsResponse.toString());
        });

        task.addOnFailureListener(this, e -> {
            if (e instanceof ResolvableApiException) {
                // Location settings are not satisfied, but this can be fixed
                // by showing the user a dialog.
                try {
                    // Show the dialog by calling startResolutionForResult(),
                    // and check the result in onActivityResult().
                    ResolvableApiException resolvable = (ResolvableApiException) e;
                    resolvable.startResolutionForResult(BaseActivity.this,
                            PERMISSIONS_REQUEST_ENABLE_GPS);
                } catch (IntentSender.SendIntentException sendEx) {
                    // Ignore the error.
                }
            }
        });
    }

    private boolean haveNetworkConnection(Context context) {
        boolean haveConnectedWifi = false;
        boolean haveConnectedMobile = false;

        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo[] netInfo = cm.getAllNetworkInfo();
        for (NetworkInfo ni : netInfo) {
            if (ni.getTypeName().equalsIgnoreCase("WIFI"))
                if (ni.isConnected())
                    haveConnectedWifi = true;
            if (ni.getTypeName().equalsIgnoreCase("MOBILE"))
                if (ni.isConnected())
                    haveConnectedMobile = true;
        }
        return haveConnectedWifi || haveConnectedMobile;
    }

    public void buildAlertMessageNoInterNet() {
        // Toast.makeText(BaseActivity.this, "GPS_DIALOG "+ GPS_DIALOG, Toast.LENGTH_SHORT).show();
        if (!WIFI_DIALOG) {
            WIFI_DIALOG = true;
            if ( !(BaseActivity.this).isFinishing() &&!haveNetworkConnection(BaseActivity.this)) {
                DialogBoxSingleton.getInstance().showInternetPopup(BaseActivity.this, "No Internet Available.....", false);
            }
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PERMISSIONS_REQUEST_ENABLE_GPS) {
            if (resultCode == RESULT_OK) {
                Toast.makeText(this, "Gps Enable", Toast.LENGTH_SHORT).show();
                mLocationPermissionGranted = true;
                startLocationService();
                //if user allows to open gps
               // Log.d("GpsChangeReceiver", "result ok " + data.toString());
            } else if (resultCode == RESULT_CANCELED) {
                Toast.makeText(this, "Enable Gps to continue ", Toast.LENGTH_SHORT).show();
                // in case user back press or refuses to open gps
                createLocationRequest();
              //  Log.d("GpsChangeReceiver", "result cancelled " + data.toString());
            }
        }
    }

    @Override
    protected void onResume() {
        m_gpsChangeReceiver = new GpsChangeReceiver();
        this.registerReceiver(m_gpsChangeReceiver, new IntentFilter(LocationManager.PROVIDERS_CHANGED_ACTION));

      /*  IntentFilter filter = new IntentFilter();
        filter.addAction(getResources().getString(R.string.action_connectivity_change));
        filter.addAction(getResources().getString(R.string.action_air_plane_mode));
        registerReceiver(internetConnector_receiver,filter);*/

        final Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if ( !(BaseActivity.this).isFinishing() &&!haveNetworkConnection(BaseActivity.this)) {

                    DialogBoxSingleton.getInstance().showInternetPopup(BaseActivity.this, "No Internet....", false);
                }
            }
        }, 3000);

        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (m_gpsChangeReceiver != null) {
            unregisterReceiver(m_gpsChangeReceiver);
        }
    }

    @Override
    protected void onDestroy() {
        unregisterReceiver(internetConnector_receiver);
        Log.d("topActivity", "onDestroy");
        // unregisterReceiver(m_gpsChangeReceiver);
        /*Log.d("topActivity", "onDestroy");
        new ListenActivities(BaseActivity.this).start();
        Toast.makeText(BaseActivity.this, "BaseActivity  Exiting Now", Toast.LENGTH_SHORT).show();*/
        super.onDestroy();
    }
  /*  public void setAppLanguage(String language){
        Log.v("setAppLanguage","setAppLanguage "+language);
        if(language.equalsIgnoreCase("English")) {
            language="en";
        }
        else if( language.equalsIgnoreCase("اردو")) {
            language="ur";
        }
        Log.v("setAppLanguage","setAppLanguage "+language);
        Locale locale = new Locale(language);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        Resources resources = getResources();
        config.locale = locale;
        //resources.updateConfiguration(config, resources.getDisplayMetrics());
        getBaseContext().getResources().updateConfiguration(config,
                getBaseContext().getResources().getDisplayMetrics());
      //  this.setContentView(R.layout.main);
      *//* BaseActivity.this.getBaseContext().getResources().updateConfiguration(config,
               BaseActivity.this.getBaseContext().getResources().getDisplayMetrics());
        Intent i = new Intent(BaseActivity.this, SplashActivity.class);
        startActivity(i);*//*
       *//* Intent i = new Intent(BaseActivity.this, SplashActivity.class);
        startActivity(i);*//*
        Intent intent = getIntent();
        //Intent intent = new Intent(getBaseContext(), DashBoardActivity.class);
        finish();
        startActivity(intent);
    }*/
    public void startLocationService() {
        Log.d("TAG1", "startLocationService isLocationServiceRunning "+isLocationServiceRunning());
        Log.d("getDeviceLocation", "startLocationService "+isLocationServiceRunning());
        if (!isLocationServiceRunning()) {
            Intent serviceIntent = new Intent(this, LocationService.class);
            serviceIntent.setAction(Constants.ACTION_START_FOREGROUND_SERVICE);
            Log.d("getDeviceLocation", "(android.os.Build.VERSION.SDK_INT "+android.os.Build.VERSION.SDK_INT);
            Log.d("getDeviceLocation", "(android.os.Build.VERSION.SDK_INT "+android.os.Build.VERSION_CODES.O);
            //startService(serviceIntent);
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }
        }
    }
    private boolean isLocationServiceRunning() {
        ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if ("com.oyla.passenger.services.location".equals(service.service.getClassName())) {
                Log.d(TAG, "isLocationServiceRunning: location service is already running.");
                return true;
            }
        }
        Log.d(TAG, "isLocationServiceRunning: location service is not running.");
        return false;
    }

 /*   @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        getBaseContext().getResources().updateConfiguration(newConfig, getBaseContext().getResources().getDisplayMetrics());
        setContentView(R.layout.activity_dash_board);
        setTitle(R.string.app_name);

        // Checks the active language
        if (newConfig.locale == Locale.ENGLISH) {
            Toast.makeText(this, "English", Toast.LENGTH_SHORT).show();
        } else if (newConfig.locale == Locale.FRENCH){
            Toast.makeText(this, "French", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(this, "urdu", Toast.LENGTH_SHORT).show();
        }
    }*/
 @Override
 protected void onStop() {
     super.onStop();
   //  Log.d("TAG1", "onStop: Count d");
   /*  if(!Constants.FIRE_BASE_NOTIFY){
         Intent myService = new Intent(BaseActivity.this, LocationService.class);
         myService.setAction(Constants.ACTION_STOP_FOREGROUND_SERVICE);
         stopService(myService);
     }*/
 }
    @Override
    protected void onStart() {
        super.onStart();


    }
    public void checkLocationPermission(){
        Log.v("PermissionGranted", "mLocationPermissionGranted "+mLocationPermissionGranted);
        Log.d("TAG1", "checkLoctionPermission: Count a");
      /*  if (isAutoStartAllowed()) {
            openAutoStartSettings();
        }*/
        if (checkMapServices()) {
            Log.d("TAG1", "mLocationPermissionGranted "+mLocationPermissionGranted);
            Log.d("TAG1", "checkMapServices "+checkMapServices());
            if (!mLocationPermissionGranted) {
                Log.v(TAG, "onResume: LocationPermissions");
                Log.d("TAG1", "checkLoctionPermission: Count b");
                getLocationPermission();
            }else {
                startLocationService();
                Log.d("TAG1", "checkLoctionPermission: Count c");
            }
        }
    }
    private boolean checkMapServices() {
        if (isServicesOK()) {
            return isMapsEnabled();
        }
        return false;
    }

    public boolean isServicesOK() {
        Log.d(TAG, "isServicesOK: checking google services version");

        int available = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(BaseActivity.this);

        if (available == ConnectionResult.SUCCESS) {
            //everything is fine and the user can make map requests
            Log.d(TAG, "isServicesOK: google Play Services is working");
            return true;
        } else if (GoogleApiAvailability.getInstance().isUserResolvableError(available)) {
            //an error occured but we can resolve it
            Log.d(TAG, "isServicesOK: an error occured but we can fix it");
            Dialog dialog = GoogleApiAvailability.getInstance().getErrorDialog(BaseActivity.this, available, ERROR_DIALOG_REQUEST);
            Objects.requireNonNull(dialog).show();
        } else {
            Toast.makeText(this, "You can't make map requests", Toast.LENGTH_SHORT).show();
        }
        return false;
    }

    public boolean isMapsEnabled() {
        final LocationManager manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        Log.v("PermissionGranted", "isMapsEnabled "+mLocationPermissionGranted);
        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            buildAlertMessageNoGps();
            return false;
        }
        return true;
    }
    private void getLocationPermission() {
        Log.v("PermissionGranted", "getLocationPermission "+mLocationPermissionGranted);
        if (ContextCompat.checkSelfPermission(this.getApplicationContext(),
                android.Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            mLocationPermissionGranted = true;
            Log.v("PermissionGranted", "if getLocationPermission "+mLocationPermissionGranted);
            startLocationService();

        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                    PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION);
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        mLocationPermissionGranted = false;
        if (requestCode == PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION) {// If request is cancelled, the result arrays are empty.
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                mLocationPermissionGranted = true;
                startLocationService();
            } else {
                //  finish();
                if (ActivityCompat.shouldShowRequestPermissionRationale(BaseActivity.this,
                        Manifest.permission.ACCESS_FINE_LOCATION)) {
                    //  mLocationPermissionGranted = false;
                    Log.d("TAG1", "onResume: Count b");
                    // now, user has denied permission (but not permanently!)
                    Log.v("PermissionGranted", "now, user has denied permission (but not permanently!) ");

                } else {
                    Log.d("TAG1", "onResume: Count c");
                    Log.v("PermissionGranted", "now, user has denied permission permanently");
                   /* ActivityCompat.requestPermissions(this,
                            new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                            PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION);*/
                 /*   if (!PERMENTALY_DENIED) {
                        PERMENTALY_DENIED = true;*/
                    mustShowLocationPermission();
                    // }
                }
            }
        }

    }
    public void mustShowLocationPermission() {
        AlertDialog alertDialog = new AlertDialog.Builder(this)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle("Location Permission")
                .setCancelable(false)
                .setMessage("Allow Gps Permission from Setting to continue ")
                .setPositiveButton("Yes", (dialogInterface, i) -> {
                    //set what would happen when positive button is clicked
                    Intent intent = new Intent();
                    intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    Uri uri = Uri.fromParts("package", getPackageName(), null);
                    intent.setData(uri);
                    startActivity(intent);
                    mLocationPermissionGranted = true;
                })
                .setNegativeButton("No", (dialogInterface, i) -> {
                    //Toast.makeText(getApplicationContext(),"Nothing Happened",Toast.LENGTH_LONG).show();
                    finish();
                })
                .show();
    }
}