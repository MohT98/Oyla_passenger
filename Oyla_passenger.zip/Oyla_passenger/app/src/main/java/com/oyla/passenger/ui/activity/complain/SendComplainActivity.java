package com.oyla.passenger.ui.activity.complain;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.Toast;
import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;
import com.oyla.passenger.MainApp;
import com.oyla.passenger.R;
import com.oyla.passenger.databinding.ActivitySendComplainBinding;
import com.oyla.passenger.datamodels.FileModel;
import com.oyla.passenger.datamodels.RegisterNewComplaintData;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.ui.activity.SettingActivity;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.SharedPrefManager;
import com.oyla.passenger.viewmodels.RegisterComplaintViewModel;
import com.oyla.passenger.viewmodels.UpdateProfileViewModel;

import java.io.File;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Objects;

public class SendComplainActivity extends BaseActivity {

    private ActivitySendComplainBinding binding;
    private PermissionListener permissionlistener;
    private int PICK_IMAGE = 123;
    private Bitmap profileBitmap;
    private String stringImage,imageName;
    private String complaintTypeId,subjectName,bookingId,complainDetail;
    private RegisterComplaintViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // setContentView(R.layout.activity_send_complain);
        hideAppBar(this);
        binding = setContentView(this, R.layout.activity_send_complain);
        viewModel = new ViewModelProvider(this).get(RegisterComplaintViewModel.class);
        complaintTypeId=getIntent().getStringExtra("id");
        subjectName=getIntent().getStringExtra("subjectName");
        bookingId=getIntent().getStringExtra("bookingId");
        binding.onBack.setOnClickListener(v->{
            onBackPressed();
        });
        binding.uploadImage.setOnClickListener(v->{
            getStoragePermission();
        });
        permissionlistener = new PermissionListener() {
            @Override
            public void onPermissionGranted() {
                Toast.makeText(SendComplainActivity.this, "Permission Granted", Toast.LENGTH_SHORT).show();
                showImagePickerDialog();
            }

            @Override
            public void onPermissionDenied(List<String> deniedPermissions) {
                Toast.makeText(SendComplainActivity.this, "Permission Denied\n" + deniedPermissions.toString(), Toast.LENGTH_SHORT).show();
            }


        };
        binding.submitButton.setOnClickListener(v->{
            if(TextUtils.isEmpty(binding.complainDetail.getText())) {
                binding.complainDetail.setError("This field must not be empty");
                return;
            }
            complainDetail=binding.complainDetail.getText().toString();
            updateImage();
        });
    }
    private void getStoragePermission() {
        TedPermission.with(this)
                .setPermissionListener(permissionlistener)
                .setDeniedMessage("If you reject permission,you can not use this service\n\nPlease turn on permissions at [Setting] > [Permission]")
                .setPermissions(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA)
                .check();

    }
    private void showImagePickerDialog() {
        final Dialog dialog = new Dialog(SendComplainActivity.this);
        dialog.setContentView(R.layout.image_picker_dialog);
        // if button is clicked, close the custom dialog
        dialog.findViewById(R.id.takePhoto).setVisibility(View.GONE);

        dialog.findViewById(R.id.choose).setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK);
            intent.setType("image/*");
           // startActivityForResult(intent, PICK_IMAGE);
            someActivityResultLauncher.launch(intent);

            dialog.dismiss();
        });
        dialog.show();
        Window window = dialog.getWindow();
        assert window != null;
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }
    // You can do the assignment inside onAttach or onCreate, i.e, before the activity is displayed
    ActivityResultLauncher<Intent> someActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK &&  result.getData()!=null) {
                        // There are no request codes
                        Intent data = result.getData();
                        FileModel fileModel;
                        Uri imageUri = data.getData();
                        fileModel = getFilePath(imageUri);
                        Log.v("someActivityResult", "getFileName " + fileModel.getFileName());
                        Log.v("someActivityResult", "getFilePath " + fileModel.getFilePath());
                        Log.v("someActivityResult", "imageUri " + imageUri);
                        stringImage = fileModel.getFilePath();
                        //updateImage(fileModel.getFileName());
                        /*binding.uploadImage.setText(stringImage);*/
                        binding.uploadImage.setText(fileModel.getFileName());
                    }
                }
            });
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            FileModel fileModel;
            if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && null != data) {
                Uri imageUri = data.getData();
                fileModel = getFilePath(imageUri);
                Log.v("setGlideImage", "getFileName " + fileModel.getFileName());
                Log.v("setGlideImage", "getFilePath " + fileModel.getFilePath());
                Log.v("setGlideImage", "imageUri " + imageUri);
                stringImage = fileModel.getFilePath();
                binding.uploadImage.setText(fileModel.getFileName());

            }

        } catch (Exception e) {
            stopLoader();
            Log.v("ExceptionException", "Exception " + e);
            Toast.makeText(this, "Something went wrong", Toast.LENGTH_LONG).show();
        }
        super.onActivityResult(requestCode, resultCode, data);

    }
    public FileModel getFilePath(Uri uri) {
        FileModel fileModel = new FileModel();
        String path = null;
        String selection = null;
        String[] selectionArgs = null;


        // Uri is different in versions after KITKAT (Android 4.4), we need to
        if (DocumentsContract.isDocumentUri(getApplicationContext(), uri)) {
            if (isExternalStorageDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                path = Environment.getExternalStorageDirectory() + "/" + split[1];
                //path =getExternalFilesDirs();
            } else if (isDownloadsDocument(uri)) {
                final String id = DocumentsContract.getDocumentId(uri);
                uri = ContentUris.withAppendedId(
                        Uri.parse("content://downloads/public_downloads"), Long.parseLong(id));
            } else if (isMediaDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];
                if ("image".equals(type)) {
                    uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(type)) {
                    uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(type)) {
                    uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }
                selection = "_id=?";
                selectionArgs = new String[]{
                        split[1]
                };
            }
        }
        if ("content".equalsIgnoreCase(uri.getScheme())) {


            if (isGooglePhotosUri(uri)) {
                path = uri.getLastPathSegment();
            }

            String[] projection = {
                    MediaStore.Images.Media.DATA
            };
            Cursor cursor = null;
            try {
                cursor = getContentResolver()
                        .query(uri, projection, selection, selectionArgs, null);
                int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                //get path
                if (cursor.moveToFirst()) {
                    path = cursor.getString(column_index);
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if ("file".equalsIgnoreCase(uri.getScheme())) {
            path = uri.getPath();
        }

        //set file path
        fileModel.setFilePath(path);
        //set file name
        fileModel.setFileName(getFileName(uri));

        File file = new File(path);
        long fileSizeInBytes = file.length();
        // Convert the bytes to Kilobytes (1 KB = 1024 Bytes)
        long fileSizeInKB = fileSizeInBytes / 1024;
        //
        fileModel.setFileSize(fileSizeInKB);
        return fileModel;
    }

    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

    public static boolean isGooglePhotosUri(Uri uri) {
        return "com.google.android.apps.photos.content".equals(uri.getAuthority());
    }

    public String getFileName(Uri uri) {
        String result = null;
        if (uri.getScheme().equals("content")) {
            try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    result = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                }
            }
        }
        return result;
    }

    private void updateImage() {
        String user_id = SharedPrefManager.getInstance(SendComplainActivity.this).getUserInfo().getUserId();
        RegisterNewComplaintData registerNewComplaintData=new RegisterNewComplaintData(user_id,bookingId,stringImage,complainDetail,complaintTypeId);
        viewModel.registerComplaintRequest(registerNewComplaintData);

        startLoader();


        viewModel.registerComplaintRepose().observe(this, dataModelObject -> {
            stopLoader();
            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                MainApp.getInstance().setUserData(dataModelObject.getData().getUser());
                showToast(SendComplainActivity.this, "Complain Upload SuccessFully");
                finish();
            } else {
                //showToast(SettingActivity.this, dataModelObject.getError().getMessage());
                if (dataModelObject.getError().getMessage() != null) {
                    showToast(SendComplainActivity.this, dataModelObject.getError().getMessage());
                    Log.v("setGlideImage", "getErrorMessage " + dataModelObject.getError().getMessage());
                } else if (dataModelObject.getError().getMessages() != null) {
                    showToast(SendComplainActivity.this, dataModelObject.getError().getMessages().toString());
                    Log.v("setGlideImage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                }
            }
        });
    }
}