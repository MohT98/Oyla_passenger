package com.oyla.passenger.ui.activity.authentication;


import android.app.Dialog;
import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.gms.auth.api.phone.SmsRetriever;
import com.google.android.gms.auth.api.phone.SmsRetrieverClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
/*import com.google.firebase.iid.FirebaseInstanceId;*/
import com.google.firebase.messaging.FirebaseMessaging;
import com.oyla.passenger.MainApp;
import com.oyla.passenger.utilities.DialogBoxSingleton;
import com.oyla.passenger.R;
import com.oyla.passenger.databinding.ActivitySignInBinding;
import com.oyla.passenger.databinding.ButtonBinding;
import com.oyla.passenger.datamodels.usermodel.UserData;
import com.oyla.passenger.services.LatestFirebaseMessagingService;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.ui.activity.LoginOptionActivity;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.Messages;
import com.oyla.passenger.utilities.SharedPrefManager;
import com.oyla.passenger.viewmodels.SignInViewModel;

import org.json.JSONException;

import java.util.Objects;

import static com.oyla.passenger.utilities.Constants.F_SIGN_IN;
import static com.oyla.passenger.utilities.Constants.G_SIGN_IN;
import static com.oyla.passenger.utilities.Constants.Token;
import static com.oyla.passenger.utilities.Constants.currentUser;
import static com.oyla.passenger.utilities.Constants.firebaseAuth;
import static com.oyla.passenger.utilities.Constants.referral_code;


public class SignInActivity extends BaseActivity  {
    //widget
    // private TextView countryCode, phoneNumber;

    private ActivitySignInBinding binding;
    private ButtonBinding buttonBinding;
    private SignInViewModel viewModel;
    private UserData userData;
    private int errorCount = 0;
    private String value;
    private String countryCode = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_sign_in);
        hideAppBar(this);
        viewModel = new ViewModelProvider(this).get(SignInViewModel.class);
        binding = setContentView(this, R.layout.activity_sign_in);

        if(SharedPrefManager.getInstance(SignInActivity.this).getFirstLogin()){
            binding.referralEnter.setVisibility(View.GONE);
        }


        binding.setViewModel(viewModel);
        userData = new UserData();
        binding.networkText.setText(Constants.NETWORK);
        binding.continueButtons.customButtonText.setText(getResources().getString(R.string.continue_text));
        //   binding.ccp.registerPhoneNumberTextView(binding.phoneNumberEditText);
        countryCode = getIntent().getStringExtra("countryCode");
        Log.v("countryCode", "countryCode " + countryCode);
        Log.v("G_SIGN_IN", "G_SIGN_IN " + G_SIGN_IN);
       // Log.v("G_SIGN_IN", "countryCode " + countryCode);
       // binding.ccp.setCountryForPhoneCode(Integer.parseInt(countryCode));
       // binding.ccp.setDefaultCountryUsingNameCode(countryCode);
        binding.ccp.setCountryForNameCode(countryCode);
        if (!G_SIGN_IN) {
            if (countryCode.equalsIgnoreCase("pk")) {
                //binding.continueMobile.customButtonText.setText(getResources().getString(R.string.continue_mobile));
                binding.mobileLayout.setVisibility(View.VISIBLE);
                binding.emailLayout.setVisibility(View.GONE);
            } else {
                //binding.continueMobile.customButtonText.setText(getResources().getString(R.string.continue_email));
                binding.emailLayout.setVisibility(View.VISIBLE);
                binding.mobileLayout.setVisibility(View.GONE);
                binding.heading.setText(getString(R.string.enter_email_heading));
                binding.subHeading.setText(getString(R.string.enter_email_login_subheading));
            }
        }

        // binding.continueButtons.button.setBackground(ContextCompat.getDrawable(SignInActivity.this, R.drawable.button_light));
        binding.ccp.setOnCountryChangeListener(selectedCountry -> {
            //Toast.makeText(SignInActivity.this, "Updated " + selectedCountry.getPhoneCode(), Toast.LENGTH_SHORT).show();
        });


        viewModel.getUserPhoneNumber().observe(this, s -> {
            if (s != null) {

                Log.v("hintLength", "s number length " + s.length());
                removeError(binding.phoneNumberTextInput);
                if (TextUtils.isEmpty(s)) {
                    showError(Messages.EmptyMessage, binding.phoneNumberTextInput, binding.phoneNumberEditText);
                    //userData.setUserName(null);
                } else if (s.length() < 10) {
                    if (errorCount > 0) {
                        showError(Messages.phoneNumberValidMessage, binding.phoneNumberTextInput, binding.phoneNumberEditText);
                    }
                    //userData.setUserName(s);
                } else {
                    //userData.setUserName(s);
                }


            } else {
                //showError(Messages.EmptyMessage, binding.uNameTextInput, binding.usame);
                //model.setUserName(null);
            }
        });


        binding.continueButtons.button.setOnClickListener(view -> {
            Log.v("hintLength", "continueButtons ");
            errorCount = 1;
            if(Constants.G_SIGN_IN ){
                numberVerify();
            } else if (countryCode.equalsIgnoreCase("pk") ) {
                numberVerify();
            } else {

                if (LatestFirebaseMessagingService.getToken(this).equalsIgnoreCase("empty") || LatestFirebaseMessagingService.getToken(this) == null) {
                  /*  showToast(this, "Please try Again");*/
                   /* String refreshedToken =FirebaseMessaging.getInstance().getToken().getResult();
                    Log.v("FirebaseMessaging", "refreshedToken "+refreshedToken);
                    if(refreshedToken == null || refreshedToken.isEmpty()){
                        *//*showToast(this, "Please try Again");*//*
                        showToast(this, "Problem with google services generated reinstall your App");
                        return;
                    }*/
                    recreateToken();
                    return;
                }
                value = Objects.requireNonNull(binding.emailEditText.getText()).toString();
                if (Objects.requireNonNull(value).trim().isEmpty()) {
                    showError(Messages.EmptyMessage, binding.emailTextInput);
                    showToast(SignInActivity.this,Messages.EmptyMessage);
                    return;
                } else if (!viewModel.validateUserEmail(value)) {
                    showToast(SignInActivity.this,Messages.emailValidMessage);
                     showError(Messages.emailValidMessage, binding.emailTextInput);
                    return;
                }
                Constants.NETWORK="";
                startLoader();
                viewModel.sendMob(value, LatestFirebaseMessagingService.getToken(this), referral_code, "email");
                mobileApiResponse();
            }
        });
        binding.backButton.setOnClickListener(view -> onBackPressed());
        binding.referralEnter.setPaintFlags( binding.referralEnter.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        binding.referralEnter.setOnClickListener(v -> {
            referralDialog();
        });
        binding.networkTextLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                networkDialog();
            }
        });

    }
    private void recreateToken(){
        //String refreshedToken = FirebaseInstanceId.getInstance().getToken();

        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
            /*String refreshedToken =String.valueOf(FirebaseMessaging.getInstance().getToken().getResult());*/
            String refreshedToken =task.getResult();
            if(refreshedToken.isEmpty()){
                showToast(SignInActivity.this, "Problem with google services generated reinstall your App or check your internet connection");
                return;
            }
            Log.v("TokenToken", "FirebaseMessaging refreshedToken Token " + refreshedToken);
            MainApp.getInstance().setFireBaseToken(refreshedToken);
            //((MainApp) this.getApplication()).setFireBaseToken(mToken);
            getSharedPreferences("_", MODE_PRIVATE).edit().putString("fb", refreshedToken).apply();
        });
    }


    private void numberEditDialog() {
        final Dialog dialog = new Dialog(SignInActivity.this);
        dialog.setContentView(R.layout.custom_dialog);
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        value = binding.ccp.getSelectedCountryCodeWithPlus() + "" + binding.phoneNumberEditText.getText();
        ((TextView) dialog.findViewById(R.id.textPhoneNumber)).setText(value);
        // if button is clicked, close the custom dialog
        dialog.findViewById(R.id.ok).setOnClickListener(v -> {
            //sendMobileNumber();
            if (G_SIGN_IN) {
                dialog.dismiss();
                registerSocial();
            } else {
                sendMob();
           /*     Intent i = new Intent(SignInActivity.this, NumberVerificationActivity.class);
                i.putExtra("mobileNumber", mobileNumber);
                startActivity(i);
                finish();*/
                dialog.dismiss();
            }
        });
        dialog.findViewById(R.id.edit).setOnClickListener(v -> dialog.dismiss());
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private void registerSocial() {
        startLoader();
        if(F_SIGN_IN){
            try {
                String first_name = Constants.facebookObject.getString("first_name");
                String email = Constants.facebookObject.getString("email");
                Log.d("fbRegister", "Currently Signed in registerSocial: " + email);
                registerSocialInfo(first_name,email,"facebook");

            }catch (JSONException e) {
                e.printStackTrace();
            }


        }else {
            currentUser = firebaseAuth.getCurrentUser();
            if (currentUser != null) {
                G_SIGN_IN = true;
                Log.d("GoogleSign", "Currently Signed in registerSocial: " + currentUser.getEmail());
                registerSocialInfo(currentUser.getDisplayName(),currentUser.getEmail(),"google");

            }
        }

    }

    private void registerSocialApiRepose() {
        Log.v("registerSocialApiRepose", "mobApiResponse");
        viewModel.registerSocialRepose().observe(this, dataModelObject -> {
            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                //stopLoader();
                Token = dataModelObject.getAccessToken();
                //userId = dataModelObject.getData().getUser().getUserId();
                Log.v("registerSocialApiRepose", "dataModelObject " + dataModelObject.getData().getUser());
                //Log.v("onChanged", "Mob number " + dataModelObject.getData().getUser().getUserMobNumber());
                //Log.v("onChanged", "User Id " + dataModelObject.getData().getUser().getUserId());
                if (dataModelObject.getData().getUser() != null) {

                /*    showToast(SignInActivity.this, Messages.SignInSuccess);
                    MainApp.getInstance().setUserData(dataModelObject.getData().getUser());
                    SharedPrefManager.getInstance(SignInActivity.this).
                            userInfo(
                                    dataModelObject.getData().getUser().getUserId(), dataModelObject.getAccessToken()
                            );*/
                  /*  SharedPrefManager.getInstance(SignInActivity.this).
                            userProfile(
                                    dataModelObject.getData().getUser().getUserId(),
                                    dataModelObject.getData().getUser().getUserFirstName(),
                                    dataModelObject.getData().getUser().getUserLastName(),
                                    dataModelObject.getData().getUser().getUserEmail(),
                                    dataModelObject.getData().getUser().getUserMobNumber(),
                                    dataModelObject.getData().getUser().getProfilePic(),
                                    dataModelObject.getData().getUser().getIsVERIFIED(),
                                    "-", "-", "-",
                                    dataModelObject.getAccessToken()
                            );*/
                    SharedPrefManager.getInstance(SignInActivity.this).setSocialFlag(true);
                    googleSignOut();
                    stopLoader();
                    G_SIGN_IN=false;
                    F_SIGN_IN=false;
                    Constants.SOCIAL=true;
                    //Intent i = new Intent(SignInActivity.this, DashBoardActivity.class);
                    Intent i = new Intent(SignInActivity.this, NumberVerificationActivity.class);
                    i.putExtra("value", value);
                    i.putExtra("userId", dataModelObject.getData().getUser().getUserId());
                    i.putExtra("AccessToken", dataModelObject.getAccessToken());
                    i.putExtra("countryCode", countryCode);
                    startActivity(i);
                    finish();

                } else {
                    stopLoader();
                    googleSignOut();
                   // showToast(SignInActivity.this, "Unable to SignIn");
                   /* if(dataModelObject.getError().getMessage()!=null){
                        showToast(SignInActivity.this, dataModelObject.getError().getMessage());
                    }else {
                        showToast(SignInActivity.this, dataModelObject.getError().getMessages().toString());
                    }*/

                }


            } else {
                stopLoader();
                googleSignOut();
                /*  showToast(SignInActivity.this, dataModelObject.getError().getMessage().toString());*/
               // showToast(SignInActivity.this, "Unable to SignIn");
                DialogBoxSingleton.getInstance().showErrorPopup(SignInActivity.this,dataModelObject.getError());
                if(dataModelObject.getError().getMessage()!=null){
                   // showToast(SignInActivity.this, dataModelObject.getError().getMessage());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                }else if(dataModelObject.getError().getMessages()!=null){
                    //showToast(SignInActivity.this, dataModelObject.getError().getMessages().toString());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                }
            }

        });
    }

    private void sendMob() {
        Log.v("newToken ", "sendMob FireBaseToken  " + LatestFirebaseMessagingService.getToken(this));
       /* if(MainApp.getInstance().getFireBaseToken().equalsIgnoreCase("empty") || MainApp.getInstance().getFireBaseToken() ==null){
            showToast(this, "Please try Again");
        }*/
        Log.v("TokenToken ", "dataModelObject Share pref--- " + LatestFirebaseMessagingService.getToken(this));
        if (LatestFirebaseMessagingService.getToken(this) == null || LatestFirebaseMessagingService.getToken(this).equalsIgnoreCase("empty") ) {
            showToast(this, "Please try Again Generating Token");
            recreateToken();
        } else {
           // MainApp.getInstance().getFireBaseToken();
            startLoader();
            viewModel.sendMob(value, LatestFirebaseMessagingService.getToken(this), referral_code,"mobile_no");
            //showToast(this, "Number sent for verification");
            mobileApiResponse();
        }
    }


    private void mobileApiResponse() {

        viewModel.mobApiResponse().observe(this, dataModelObject -> {
            // Log.v("mobileApiResponse", "dataModelObject.getStatus() "+dataModelObject.getStatus());
            stopLoader();
            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                MainApp.getInstance().setFireBaseToken(LatestFirebaseMessagingService.getToken(this));
                //showToast(NumberVerificationActivity.this, dataModelObject.getMsg());
                /*String content = "";
                content += "Msg: " +dataModelObject.getMsg() + "\n";
                content += "Status : "+dataModelObject.getStatus() + "\n";
                content += "AccessToken(): " +dataModelObject.getAccessToken() + "\n";
                content += "Token_type: " +dataModelObject.getToken_type() + "\n\n";
                Log.v("onChanged","content "+content);*/
                // Token = dataModelObject.getAccessToken();
                //  userId = dataModelObject.getData().getUser().getUserId();
             /*   SharedPrefManager.getInstance(SignInActivity.this).
                        userInfo(
                                dataModelObject.getData().getUser().getUserId(),dataModelObject.getAccessToken()
                        );*/
                Log.v("mobileApiResponse", "getAccessToken " + dataModelObject.getAccessToken());
                Log.v("mobileApiResponse", "Mob number " + dataModelObject.getData().getUser().getUserMobNumber());
                Log.v("mobileApiResponse", "User Id " + dataModelObject.getData().getUser().getUserId());
                Intent i = new Intent(SignInActivity.this, NumberVerificationActivity.class);
                i.putExtra("value", value);
                i.putExtra("userId", dataModelObject.getData().getUser().getUserId());
                i.putExtra("AccessToken", dataModelObject.getAccessToken());
                i.putExtra("countryCode", countryCode);

                startActivity(i);
                finish();
            } else {
                //showToast(SignInActivity.this, dataModelObject.getError().getMessage());
                DialogBoxSingleton.getInstance().showErrorPopup(SignInActivity.this,dataModelObject.getError());
                if(dataModelObject.getError().getMessage()!=null){
                   // showToast(SignInActivity.this, dataModelObject.getError().getMessage());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                }else if(dataModelObject.getError().getMessages()!=null){
                   // showToast(SignInActivity.this, dataModelObject.getError().getMessages().toString());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                }
            }

        });
    }
    public void startSMSListener() {
        SmsRetrieverClient mClient = SmsRetriever.getClient(this);
        Task<Void> mTask = mClient.startSmsRetriever();
        mTask.addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override public void onSuccess(Void aVoid) {
                // layoutInput.setVisibility(View.GONE);
                //  layoutVerify.setVisibility(View.VISIBLE);
                //Toast.makeText(SignInActivity.this, "SMS Retriever starts", Toast.LENGTH_LONG).show();
            }
        });
        mTask.addOnFailureListener(new OnFailureListener() {
            @Override public void onFailure(@NonNull Exception e) {
                //Toast.makeText(SignInActivity.this, "Error", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void googleSignOut() {
        // Firebase sign out
        Constants.firebaseAuth.signOut();
        G_SIGN_IN = false;
        // Google sign out

        Constants.googleSignInClient.signOut().addOnCompleteListener(this,
                task -> {
                    // Google Sign In failed, update UI appropriately
                    Log.w("GoogleSign", "Signed out of google");
                });
    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent(SignInActivity.this, LoginOptionActivity.class);
        i.putExtra("countryCode", countryCode);
        startActivity(i);
        finish();
        super.onBackPressed();
    }
    private void numberVerify(){
        if (Objects.requireNonNull(binding.phoneNumberEditText.getText()).toString().trim().isEmpty()) {
            Log.v("hintLength", "continueButtons isEmpty");
            showError(Messages.EmptyMessage, binding.phoneNumberTextInput, binding.phoneNumberEditText);
            return;
        } else if (String.valueOf(binding.phoneNumberEditText.getText()).length() < 10) {
            showError(Messages.phoneNumberValidMessage, binding.phoneNumberTextInput, binding.phoneNumberEditText);
            return;
        }
        startSMSListener();
        numberEditDialog();
    }
    private void registerSocialInfo(String name ,String email,String provider){
        viewModel.registerSocial(
                Constants.type, value,
                email,
                name, "_", provider,
                LatestFirebaseMessagingService.getToken(this), referral_code);
        // showToast(SignInActivity.this,"Wait for user verification");
        registerSocialApiRepose();
    }
    private void referralDialog() {

        final Dialog dialog = new Dialog(SignInActivity.this, R.style.full_screen_dialog);
        //final Dialog dialog = new Dialog(AddCreditActivity.this);
        //dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.add_referal_dialog);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;

        EditText enterVoucherEdiText = dialog.findViewById(R.id.enterPromoEdiText);
        TextInputLayout enterVoucherTextInput = dialog.findViewById(R.id.enterPromoTextInput);
        dialog.findViewById(R.id.cancelButton).setOnClickListener(v -> dialog.dismiss());
        //enterVoucherEdiText.setText(referral_code);
        dialog.findViewById(R.id.activateCode).setOnClickListener(V -> {

            if (enterVoucherEdiText.getText().toString().isEmpty()) {
                // userData.setUserPassword(null);
                //enterVoucherEdiText.setText(referral_code);
               // referral_code="empty";
            }else {
                referral_code=enterVoucherEdiText.getText().toString().trim();
            }
            dialog.dismiss();
        });

        if (!isFinishing()) {
            //show dialog
            dialog.show();
        }

        Window window = dialog.getWindow();
        assert window != null;
        //window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        //window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setGravity(Gravity.BOTTOM);
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private void networkDialog() {
        //final Dialog dialog = new Dialog(SignInActivity.this, R.style.full_screen_dialog);
        final Dialog dialog = new Dialog(SignInActivity.this);
        //dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.network_dialog);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        dialog.findViewById(R.id.jazzLayout).setOnClickListener(V -> {
            //Constants.NETWORK=((TextView)dialog.findViewById(R.id.jazzText)).getText().toString().toLowerCase();
            Constants.NETWORK="Mobilink";
            changeNetWork(Constants.NETWORK, R.drawable.jazz);
            dialog.dismiss();
        });
        dialog.findViewById(R.id.telenorLayout).setOnClickListener(V -> {
            Constants.NETWORK=((TextView)dialog.findViewById(R.id.telenorText)).getText().toString();
            changeNetWork(Constants.NETWORK, R.drawable.telenor);
            dialog.dismiss();
        });
        dialog.findViewById(R.id.ufoneLayout).setOnClickListener(V -> {
            Constants.NETWORK=((TextView)dialog.findViewById(R.id.ufoneText)).getText().toString();
            changeNetWork(Constants.NETWORK, R.drawable.ufone);
            dialog.dismiss();
        });
        dialog.findViewById(R.id.zongLayout).setOnClickListener(V -> {
            Constants.NETWORK=((TextView)dialog.findViewById(R.id.zongText)).getText().toString();
            changeNetWork(Constants.NETWORK, R.drawable.zong);
            dialog.dismiss();
        });
        if (!isFinishing()) {
            //show dialog
            dialog.show();
        }

        Window window = dialog.getWindow();
        assert window != null;
        window.setGravity(Gravity.CENTER);
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }
    private void changeNetWork(String network ,int drawable){
        binding.networkText.setText(network);
        binding.simLogo.setBackground(ContextCompat.getDrawable(this, drawable));
    }
}