package com.oyla.passenger.datamodels.usermodel;

import com.google.gson.annotations.SerializedName;

public class UserData  {
    @SerializedName("id")
    private String userId;

    @SerializedName("first_name")
    private String userFirstName;

    @SerializedName("last_name")
    private String userLastName;

    @SerializedName("email")
    private String userEmail;

    @SerializedName("mobile_no")
    private String userMobNumber;

    @SerializedName("profile_picture")
    private String profilePic;

    @SerializedName("is_varified")
    private int isVERIFIED;

    @SerializedName("password")
    private String userPassword;

    @SerializedName("gender")
    private String userGender;

    @SerializedName("date_of_birth")
    private String userDOB;

    private String accessToken;

    private String fcm_token;
    boolean social_login;
    private String provider;

    private String referral_id;

    private String points_category;


    public UserData() {
    }

    public UserData(String userId, String accessToken) {
        this.userId = userId;
        this.accessToken = accessToken;
    }

    public UserData(String userId, String userFirstName, String userLastName, String userEmail, String userMobNumber, String profilePic, int isVERIFIED, String userPassword, String userGender, String userDOB, String accessToken) {
        this.userId = userId;
        this.userFirstName = userFirstName;
        this.userLastName = userLastName;
        this.userEmail = userEmail;
        this.userMobNumber = userMobNumber;
        this.profilePic = profilePic;
        this.isVERIFIED = isVERIFIED;
        this.userPassword = userPassword;
        this.userGender = userGender;
        this.userDOB = userDOB;
        this.accessToken = accessToken;
    }

    public UserData(String userId, String userFirstName, String userLastName, String userEmail, String userMobNumber, String profilePic, int isVERIFIED, String userPassword, String userGender, String userDOB, String accessToken, String fcm_token, boolean social_login, String provider, String referral_id, String points_category) {
        this.userId = userId;
        this.userFirstName = userFirstName;
        this.userLastName = userLastName;
        this.userEmail = userEmail;
        this.userMobNumber = userMobNumber;
        this.profilePic = profilePic;
        this.isVERIFIED = isVERIFIED;
        this.userPassword = userPassword;
        this.userGender = userGender;
        this.userDOB = userDOB;
        this.accessToken = accessToken;
        this.fcm_token = fcm_token;
        this.social_login = social_login;
        this.provider = provider;
        this.referral_id = referral_id;
        this.points_category = points_category;
    }

    public String getPoints_category() {
        return points_category;
    }

    public void setPoints_category(String points_category) {
        this.points_category = points_category;
    }

    public String getReferral_id() {
        return referral_id;
    }

    public void setReferral_id(String referral_id) {
        this.referral_id = referral_id;
    }

    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }


    public boolean isSocial_login() {
        return social_login;
    }

    public void setSocial_login(boolean social_login) {
        this.social_login = social_login;
    }

    public String getFcm_token() {
        return fcm_token;
    }

    public void setFcm_token(String fcm_token) {
        this.fcm_token = fcm_token;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserFirstName() {
        return userFirstName;
    }

    public void setUserFirstName(String userFirstName) {
        this.userFirstName = userFirstName;
    }

    public String getUserLastName() {
        return userLastName;
    }

    public void setUserLastName(String userLastName) {
        this.userLastName = userLastName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserMobNumber() {
        return userMobNumber;
    }

    public void setUserMobNumber(String userMobNumber) {
        this.userMobNumber = userMobNumber;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public int getIsVERIFIED() {
        return isVERIFIED;
    }

    public void setIsVERIFIED(int isVERIFIED) {
        this.isVERIFIED = isVERIFIED;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getUserGender() {
        return userGender;
    }

    public void setUserGender(String userGender) {
        this.userGender = userGender;
    }

    public String getUserDOB() {
        return userDOB;
    }

    public void setUserDOB(String userDOB) {
        this.userDOB = userDOB;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }
}
