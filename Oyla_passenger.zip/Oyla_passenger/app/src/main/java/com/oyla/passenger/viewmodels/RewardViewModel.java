package com.oyla.passenger.viewmodels;

import android.app.Application;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;

import com.oyla.passenger.Repository.JsonRepository;
import com.oyla.passenger.datamodels.jsonreponsedatamodel.DataModelObject;

public class RewardViewModel extends SharedViewModel {

    private MutableLiveData<DataModelObject> mutableLiveData;
    private JsonRepository repository;

    public RewardViewModel(@NonNull Application application) {
        super(application);
    }

    public void rewardListRequest() {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.getRedeemPointsList("");
    }

    public MutableLiveData<DataModelObject> rewardListRepose() {
        return mutableLiveData;
    }

    public void redeemRequest(String user_id,String award_id) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.getRedeemPoints(user_id,award_id);
    }

    public MutableLiveData<DataModelObject> redeemRepose() {
        return mutableLiveData;
    }
}
