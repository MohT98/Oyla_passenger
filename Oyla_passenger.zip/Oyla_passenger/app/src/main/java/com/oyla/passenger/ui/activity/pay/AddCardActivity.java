package com.oyla.passenger.ui.activity.pay;

import android.content.res.ColorStateList;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.EditText;

import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.textfield.TextInputLayout;
import com.oyla.passenger.R;
import com.oyla.passenger.databinding.ActivityAddCardBinding;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.utilities.Messages;
import com.oyla.passenger.viewmodels.AddCardViewModel;

public class AddCardActivity extends BaseActivity {

    private ActivityAddCardBinding binding;
    private AddCardViewModel viewModel;
    private int dateCount =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        hideAppBar(this);
        viewModel = new ViewModelProvider(this).get(AddCardViewModel.class);
        binding=setContentView(this,R.layout.activity_add_card);
        binding.setViewModel(viewModel);
        binding.onBack.setOnClickListener(v-> onBackPressed());
        binding.addCardLayout.setOnClickListener(v->{ dateCount=1;});


        viewModel.getCardDate().observe(this, s -> {
            if (s != null) {
               // Log.v("hintLength", "s number length " + s);

                Log.v("hintLength", "s number length " + s.length());
                removeError(binding.expiryDateTextInput);
                if (TextUtils.isEmpty(s)) {
                    showError(Messages.EmptyMessage, binding.expiryDateTextInput, binding.expiryDateEditText);
                    //userData.setUserName(null);
                } else if (s.length() < 5) {
                    if (dateCount > 0) {
                        showError(Messages.phoneNumberValidMessage, binding.expiryDateTextInput, binding.expiryDateEditText);
                    }
                    //userData.setUserName(s);
                } else {
                    //s.append("-");
                }
            } else {
                //showError(Messages.EmptyMessage, binding.uNameTextInput, binding.usame);
                //model.setUserName(null);
            }
        });

        change( binding.cardNumberEditText,  binding.cardNumberTextInput);
        change( binding.expiryDateEditText,  binding.expiryDateTextInput);
        change( binding.cvcEditText,  binding.cvcTextInput);
        change( binding.holderNameEditText,  binding.holderNameTextInput);
    }

    void change(EditText edit, TextInputLayout inputLayout)
    {
        edit.setOnFocusChangeListener((v, hasFocus) -> {
            if(hasFocus){
                inputLayout.setHintTextColor(ColorStateList.valueOf(getResources().getColor(R.color.colorBlack2)));
            }
        });
    }
}