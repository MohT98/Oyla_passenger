package com.oyla.passenger.utilities;
import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import androidx.core.app.ActivityCompat;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.oyla.passenger.R;
import org.json.JSONObject;

public class Constants {
    public static final int ERROR_DIALOG_REQUEST = 9001;
    public static final int PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 9002;
    public static final int PERMISSIONS_REQUEST_ENABLE_GPS = 9003;
    public static final String MAP_VIEW_BUNDLE_KEY = "MapViewBundleKey";
    public static boolean mLocationPermissionGranted = false;
    public static boolean OPEN_RIDE_SHEET = false;
    public static final int DEFAULT_ZOOM = 15;
    public static int TRACK_ZOOM = 15;
    /*public static String MAP_KEY = "AIzaSyDsl1zsOxbyO0ipnqpr_S_EAts_y3XlGZ8";*/
    public static final LatLng defaultLocation = new LatLng(31.53181019695018, 74.34945769292364);
    //public static final String OylaError =  "/Download/OylaError/";
    public static final String OylaError =  "/OylaError/";
    public static final String ACTION_START_FOREGROUND_SERVICE = "ACTION_START_FOREGROUND_SERVICE";
    public static final String ACTION_STOP_FOREGROUND_SERVICE = "ACTION_STOP_FOREGROUND_SERVICE";
    public static String type = "1";
    public static String WALLET_AMOUNT = "0";
    public static String TOTAL_POINTS = "0";
    public static Boolean PROMO_ACTIVATE = false;

    /*------------------URL---------------*/

    /*--------- amazon server ---------*/
        public static String BASE_URL = "http://54.254.32.130/api/v1/";
        public static String ASSETS_BASE_URL = "http://54.254.32.130/";

    /*---------staging server 1 --------- */

   /* public static String BASE_URL = "https://lead2need.ca/api/v1/";
    public static String ASSETS_BASE_URL = "https://lead2need.ca/";*/

    /*--------- staging server 2 ---------*/
   /* public static String BASE_URL = "https://lead2need.ca/stagingadmin/public/api/v1/";
    public static String ASSETS_BASE_URL = "https://lead2need.ca/stagingadmin/public/";*/


    /*--------- staging server  ---------*/
    /*public static String BASE_URL = "http://13.213.132.157/api/v1/";
    public static String ASSETS_BASE_URL = "http://13.213.132.157/";*/
    /*--------- image base url ---------*/


    /*--------- image base url ---------*/
    public static String PROFILE_BASE_URL = "https://storage.googleapis.com/";
    public static String Bearer = "Bearer";
    public static String Token = "";
    public static String Auth = "";
    public static String SUCCESS_STATUS = "200";

    //Social sign in
    public static GoogleSignInClient googleSignInClient;
    public static FirebaseAuth firebaseAuth;
    public static final int RC_SIGN_IN = 1001;
    public static FirebaseUser currentUser;
    public static boolean G_SIGN_IN = false;
    public static boolean F_SIGN_IN = false;
    public static boolean SOCIAL = false;
    public static boolean LOGIN_SUCCESS = false;
    public static String referral_code = "Referral Code";
    public static String PHONE_CODE = "";
    public static String COUNTRY_NAME = "";
    public static JSONObject facebookObject;
//    public static InterstitialAd mInterstitialAd;
    public static boolean SING_IN_FIRST = false;
    public static boolean SPLASH = false;
    public static String NETWORK = "Mobilink";
    public static Boolean GPS_DIALOG=false;
    public static Boolean WIFI_DIALOG=false;
    public static Boolean FIRE_BASE_NOTIFY=false;
    public static int badgeCounter=0;

    public static void phoneCall(Activity activity){
        try {
            Intent intent = new Intent(Intent.ACTION_CALL);
            intent.setData(Uri.parse("tel:" + activity.getResources().getString(R.string.help_line)));
            activity.startActivity(intent);
        }
        catch (Exception ex)
        {
            ActivityCompat.requestPermissions(
                    activity,
                    new String[] {Manifest.permission.CALL_PHONE},
                    1
            );
        }
    }
}