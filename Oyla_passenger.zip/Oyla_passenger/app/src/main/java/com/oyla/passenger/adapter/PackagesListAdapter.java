package com.oyla.passenger.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.oyla.passenger.R;

import com.oyla.passenger.datamodels.packages.PackagesList;
import com.oyla.passenger.utilities.Constants;

import java.util.List;

public class PackagesListAdapter extends RecyclerView.Adapter<PackagesListAdapter.MyViewHolder> {

    private List<PackagesList> dataSet;
    private Context mCtx;
    private PackagesListAdapter.OnItemClickListener mListener;

    public void setOnItemClickListener(PackagesListAdapter.OnItemClickListener listener) {
        mListener = listener;
    }

    public PackagesListAdapter() {
    }

    public PackagesListAdapter(Context mCtx, List<PackagesList> data) {
        this.dataSet = data;
        this.mCtx = mCtx;
       /* Log.v("bookingId", "data size" + data.size());
        Log.v("bookingId", "data title" + data.get(0).getTitle());*/
    }


    @NonNull
    @Override
    public PackagesListAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_pacakge_list_adapter, parent, false);
        PackagesListAdapter.MyViewHolder myViewHolder = new PackagesListAdapter.MyViewHolder(view, mListener);

        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull PackagesListAdapter.MyViewHolder holder, int position) {
       Log.v("bookingId", "title " + dataSet.get(position).getName());
        holder.title.setText(dataSet.get(position).getName());
        holder.validity.setText("Validity : "+dataSet.get(position).getValidity()+" days");
        holder.charges.setText("Charges : "+dataSet.get(position).getPrice()+" PKR");
        holder.reward.setText("Free : "+dataSet.get(position).getKm_limit()+" KM");
      //  holder.points.setText(dataSet.get(position).getPoints_limit()+" "+mCtx.getResources().getString(R.string.point));
    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView title,validity,reward,charges;
        Button subscribe;


        public MyViewHolder(@NonNull View itemView, final PackagesListAdapter.OnItemClickListener listener) {
            super(itemView);
            title = itemView.findViewById(R.id.title);
            validity = itemView.findViewById(R.id.validity);
            charges = itemView.findViewById(R.id.charges);
            reward = itemView.findViewById(R.id.reward);
            subscribe = itemView.findViewById(R.id.subscribe);
            subscribe.setOnClickListener(v -> {
                if (listener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onItemClick(position);
                    }
                }
            });
        }
    }
}
