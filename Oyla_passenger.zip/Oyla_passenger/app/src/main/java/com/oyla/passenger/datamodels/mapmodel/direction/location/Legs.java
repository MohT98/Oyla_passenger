package com.oyla.passenger.datamodels.mapmodel.direction.location;

import java.util.List;

public class Legs {
    private Location start_location;
    private Location end_location;
    private Distance distance;
    private Duration duration;
    private List<Steps> steps;

    public Location getStart_location() {
        return start_location;
    }

    public Location getEnd_location() {
        return end_location;
    }

    public Duration getDuration() {
        return duration;
    }

    public void setDuration(Duration duration) {
        this.duration = duration;
    }

    public List<Steps> getSteps() {
        return steps;
    }

    public Distance getDistance() {
        return distance;
    }

    public void setDistance(Distance distance) {
        this.distance = distance;
    }
}
