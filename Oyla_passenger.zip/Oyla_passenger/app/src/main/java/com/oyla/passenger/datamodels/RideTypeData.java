package com.oyla.passenger.datamodels;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

public class RideTypeData implements Parcelable {
    private String id;
    @SerializedName("estimate_final_fare")
    private String fair;

    @SerializedName("name")
    private String carType;

    @SerializedName("type")
    private String vehicleType;
    @SerializedName("rate")
    private String vehicleRate;

    private String rate_per_kilometer;
    private String rate_per_minute;
    private String status;
    private String lat;
    private String lng;
    @SerializedName("timeFare1")
    private String time;
    private String  timeFare2;
    private String description;
    private int icon;
    @SerializedName("distanceFare2")
    private String distance;
    private String tax_percentage;
    private String partner_pickup_rate;
    @SerializedName("distanceFare1")
    private String partner_pickup_distance;
    private String waiting_price_per_minute;
    private String peak_rate;
    private String image_url;
    private String min_ride_fares;
    private String ride1_rate_per_kilometer;
    private String discount;

    protected RideTypeData(Parcel in) {
        id = in.readString();
        fair = in.readString();
        carType = in.readString();
        vehicleType = in.readString();
        vehicleRate = in.readString();
        rate_per_kilometer = in.readString();
        rate_per_minute = in.readString();
        status = in.readString();
        lat = in.readString();
        lng = in.readString();
        time = in.readString();
        timeFare2 = in.readString();
        description = in.readString();
        icon = in.readInt();
        distance = in.readString();
        tax_percentage = in.readString();
        partner_pickup_rate = in.readString();
        partner_pickup_distance = in.readString();
        waiting_price_per_minute = in.readString();
        peak_rate = in.readString();
        image_url = in.readString();
        min_ride_fares = in.readString();
        ride1_rate_per_kilometer = in.readString();
        discount = in.readString();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFair() {
        return fair;
    }

    public void setFair(String fair) {
        this.fair = fair;
    }

    public String getCarType() {
        return carType;
    }

    public void setCarType(String carType) {
        this.carType = carType;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getVehicleRate() {
        return vehicleRate;
    }

    public void setVehicleRate(String vehicleRate) {
        this.vehicleRate = vehicleRate;
    }

    public String getRate_per_kilometer() {
        return rate_per_kilometer;
    }

    public void setRate_per_kilometer(String rate_per_kilometer) {
        this.rate_per_kilometer = rate_per_kilometer;
    }

    public String getRate_per_minute() {
        return rate_per_minute;
    }

    public void setRate_per_minute(String rate_per_minute) {
        this.rate_per_minute = rate_per_minute;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getTimeFare2() {
        return timeFare2;
    }

    public void setTimeFare2(String timeFare2) {
        this.timeFare2 = timeFare2;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public String getTax_percentage() {
        return tax_percentage;
    }

    public void setTax_percentage(String tax_percentage) {
        this.tax_percentage = tax_percentage;
    }

    public String getPartner_pickup_rate() {
        return partner_pickup_rate;
    }

    public void setPartner_pickup_rate(String partner_pickup_rate) {
        this.partner_pickup_rate = partner_pickup_rate;
    }

    public String getPartner_pickup_distance() {
        return partner_pickup_distance;
    }

    public void setPartner_pickup_distance(String partner_pickup_distance) {
        this.partner_pickup_distance = partner_pickup_distance;
    }

    public String getWaiting_price_per_minute() {
        return waiting_price_per_minute;
    }

    public void setWaiting_price_per_minute(String waiting_price_per_minute) {
        this.waiting_price_per_minute = waiting_price_per_minute;
    }

    public String getPeak_rate() {
        return peak_rate;
    }

    public void setPeak_rate(String peak_rate) {
        this.peak_rate = peak_rate;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }

    public String getMin_ride_fares() {
        return min_ride_fares;
    }

    public void setMin_ride_fares(String min_ride_fares) {
        this.min_ride_fares = min_ride_fares;
    }

    public String getRide1_rate_per_kilometer() {
        return ride1_rate_per_kilometer;
    }

    public void setRide1_rate_per_kilometer(String ride1_rate_per_kilometer) {
        this.ride1_rate_per_kilometer = ride1_rate_per_kilometer;
    }

    public String getDiscount() {
        return discount;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }

    public static Creator<RideTypeData> getCREATOR() {
        return CREATOR;
    }

    public static final Creator<RideTypeData> CREATOR = new Creator<RideTypeData>() {
        @Override
        public RideTypeData createFromParcel(Parcel in) {
            return new RideTypeData(in);
        }

        @Override
        public RideTypeData[] newArray(int size) {
            return new RideTypeData[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(fair);
        dest.writeString(carType);
        dest.writeString(vehicleType);
        dest.writeString(vehicleRate);
        dest.writeString(rate_per_kilometer);
        dest.writeString(rate_per_minute);
        dest.writeString(status);
        dest.writeString(lat);
        dest.writeString(lng);
        dest.writeString(time);
        dest.writeString(timeFare2);
        dest.writeString(description);
        dest.writeInt(icon);
        dest.writeString(distance);
        dest.writeString(tax_percentage);
        dest.writeString(partner_pickup_rate);
        dest.writeString(partner_pickup_distance);
        dest.writeString(waiting_price_per_minute);
        dest.writeString(peak_rate);
        dest.writeString(image_url);
        dest.writeString(min_ride_fares);
        dest.writeString(ride1_rate_per_kilometer);
        dest.writeString(discount);
    }


   /* protected RideTypeData(Parcel in) {
        id = in.readString();
        fair = in.readString();
        carType = in.readString();
        vehicleType = in.readString();
        vehicleRate = in.readString();
        rate_per_kilometer = in.readString();
        rate_per_minute = in.readString();
        status = in.readString();
        lat = in.readString();
        lng = in.readString();
        time = in.readString();
        description = in.readString();
        icon = in.readInt();
        distance = in.readString();
        tax_percentage = in.readString();
        partner_pickup_rate = in.readString();
        partner_pickup_distance = in.readString();
        waiting_price_per_minute = in.readString();
        peak_rate = in.readString();
        image_url = in.readString();
        min_ride_fares = in.readString();
        ride1_rate_per_kilometer = in.readString();
        discount = in.readString();
    }

    public static final Creator<RideTypeData> CREATOR = new Creator<RideTypeData>() {
        @Override
        public RideTypeData createFromParcel(Parcel in) {
            return new RideTypeData(in);
        }

        @Override
        public RideTypeData[] newArray(int size) {
            return new RideTypeData[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(fair);
        dest.writeString(carType);
        dest.writeString(vehicleType);
        dest.writeString(vehicleRate);
        dest.writeString(rate_per_kilometer);
        dest.writeString(rate_per_minute);
        dest.writeString(status);
        dest.writeString(lat);
        dest.writeString(lng);
        dest.writeString(time);
        dest.writeString(description);
        dest.writeInt(icon);
        dest.writeString(distance);
        dest.writeString(tax_percentage);
        dest.writeString(partner_pickup_rate);
        dest.writeString(partner_pickup_distance);
        dest.writeString(waiting_price_per_minute);
        dest.writeString(peak_rate);
        dest.writeString(image_url);
        dest.writeString(min_ride_fares);
        dest.writeString(ride1_rate_per_kilometer);
        dest.writeString(discount);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFair() {
        return fair;
    }

    public void setFair(String fair) {
        this.fair = fair;
    }

    public String getCarType() {
        return carType;
    }

    public void setCarType(String carType) {
        this.carType = carType;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getVehicleRate() {
        return vehicleRate;
    }

    public void setVehicleRate(String vehicleRate) {
        this.vehicleRate = vehicleRate;
    }

    public String getRate_per_kilometer() {
        return rate_per_kilometer;
    }

    public void setRate_per_kilometer(String rate_per_kilometer) {
        this.rate_per_kilometer = rate_per_kilometer;
    }

    public String getRate_per_minute() {
        return rate_per_minute;
    }

    public void setRate_per_minute(String rate_per_minute) {
        this.rate_per_minute = rate_per_minute;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public String getTax_percentage() {
        return tax_percentage;
    }

    public void setTax_percentage(String tax_percentage) {
        this.tax_percentage = tax_percentage;
    }

    public String getPartner_pickup_rate() {
        return partner_pickup_rate;
    }

    public void setPartner_pickup_rate(String partner_pickup_rate) {
        this.partner_pickup_rate = partner_pickup_rate;
    }

    public String getPartner_pickup_distance() {
        return partner_pickup_distance;
    }

    public void setPartner_pickup_distance(String partner_pickup_distance) {
        this.partner_pickup_distance = partner_pickup_distance;
    }

    public String getWaiting_price_per_minute() {
        return waiting_price_per_minute;
    }

    public void setWaiting_price_per_minute(String waiting_price_per_minute) {
        this.waiting_price_per_minute = waiting_price_per_minute;
    }

    public String getPeak_rate() {
        return peak_rate;
    }

    public void setPeak_rate(String peak_rate) {
        this.peak_rate = peak_rate;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }

    public String getMin_ride_fares() {
        return min_ride_fares;
    }

    public void setMin_ride_fares(String min_ride_fares) {
        this.min_ride_fares = min_ride_fares;
    }

    public String getRide1_rate_per_kilometer() {
        return ride1_rate_per_kilometer;
    }

    public void setRide1_rate_per_kilometer(String ride1_rate_per_kilometer) {
        this.ride1_rate_per_kilometer = ride1_rate_per_kilometer;
    }

    public String getDiscount() {
        return discount;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }*/
}