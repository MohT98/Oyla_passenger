package com.oyla.passenger.viewmodels;

import android.app.Application;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;

import com.oyla.passenger.Repository.JsonRepository;
import com.oyla.passenger.datamodels.jsonreponsedatamodel.DataModelObject;

public class LocationViewModel extends SharedViewModel{

    private MutableLiveData<DataModelObject> mutableLiveData;
    private JsonRepository repository;

    public LocationViewModel(@NonNull Application application) {
        super(application);
    }
    public void sendPassengerLocation(String user_id, String lat, String lng, String city,String area_name) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
       // mutableLiveData = repository.setPassengerCoordinates(user_id, lat, lng,city,area_name);
    }
}
