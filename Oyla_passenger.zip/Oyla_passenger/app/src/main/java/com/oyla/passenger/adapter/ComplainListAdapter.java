package com.oyla.passenger.adapter;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.oyla.passenger.R;
import com.oyla.passenger.datamodels.ComplainData;

import java.util.List;


public class ComplainListAdapter extends RecyclerView.Adapter<ComplainListAdapter.MyViewHolder> {

    private List<ComplainData> dataSet;
    private Context mCtx;
    private ComplainListAdapter.OnItemClickListener mListener;

    public void setOnItemClickListener(ComplainListAdapter.OnItemClickListener listener) {
        mListener = listener;
    }

    public ComplainListAdapter() {
    }

    public ComplainListAdapter(Context mCtx, List<ComplainData> data) {
        this.dataSet = data;
        this.mCtx = mCtx;
        Log.v("bookingId", "data size" + data.size());
        Log.v("bookingId", "data title" + data.get(0).getName());
    }


    @NonNull
    @Override
    public ComplainListAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_complain_list_adapter, parent, false);
        ComplainListAdapter.MyViewHolder myViewHolder = new ComplainListAdapter.MyViewHolder(view, mListener);

        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ComplainListAdapter.MyViewHolder holder, int position) {
        Log.v("bookingId", "title " + dataSet.get(position).getName());
        holder.title.setText(dataSet.get(position).getName());
    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView title;


        public MyViewHolder(@NonNull View itemView, final ComplainListAdapter.OnItemClickListener listener) {
            super(itemView);
            title = itemView.findViewById(R.id.title);

            itemView.setOnClickListener(v -> {
                if (listener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onItemClick(position);
                    }
                }
            });
        }
    }
}