package com.oyla.passenger.datamodels;

public class JazzCashData {
    private String name;
    private String jazz_number;
    private String nic_number;
    private String amount;


    public JazzCashData(String name, String jazz_number, String nic_number, String amount) {
        this.name = name;
        this.jazz_number = jazz_number;
        this.nic_number = nic_number;
        this.amount = amount;
    }
}
