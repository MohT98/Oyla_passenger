package com.oyla.passenger.ui.activity.pay;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.oyla.passenger.R;
import com.oyla.passenger.databinding.ActivityEnterCardAmountBinding;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.utilities.NumberTextWatcher;

public class EnterCardAmountActivity extends BaseActivity {
    private ActivityEnterCardAmountBinding binding;
    private String amount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        hideAppBar(this);
        binding = setContentView(this, R.layout.activity_enter_card_amount);
        binding.onBack.setOnClickListener(v -> {
            onBackPressed();
        });
        binding.cardLayout.setOnClickListener(v -> {
            nextActivity(this, AddCardActivity.class);
        });
        binding.amountOneLayout.setOnClickListener(v -> {
            changeTextColor(binding.amountOneTextView, binding.amountTwoTextView, binding.amountThreeTextView, binding.amountFourTextView,false);
            changeLayoutColor(binding.amountOneLayout, binding.amountTwoLayout, binding.amountThreeLayout, binding.amountFourLayout);
        });
        binding.amountTwoLayout.setOnClickListener(v -> {
            changeTextColor(binding.amountTwoTextView, binding.amountOneTextView, binding.amountThreeTextView, binding.amountFourTextView,false);
            changeLayoutColor(binding.amountTwoLayout, binding.amountOneLayout, binding.amountThreeLayout, binding.amountFourLayout);
        });
        binding.amountThreeLayout.setOnClickListener(v -> {
            changeTextColor(binding.amountThreeTextView, binding.amountTwoTextView, binding.amountOneTextView, binding.amountFourTextView,false);
            changeLayoutColor(binding.amountThreeLayout, binding.amountTwoLayout, binding.amountOneLayout, binding.amountFourLayout);
        });
        binding.amountFourLayout.setOnClickListener(v -> {
            changeTextColor(binding.amountFourTextView, binding.amountTwoTextView, binding.amountThreeTextView, binding.amountOneTextView,true);
            changeLayoutColor(binding.amountFourLayout, binding.amountTwoLayout, binding.amountThreeLayout, binding.amountOneLayout);

            enterAmountDialog();


        });
    }

    private void changeTextColor(TextView whiteTextView1, TextView blackTextView2, TextView blackView3, TextView blackView4, boolean change) {
        amount = whiteTextView1.getText().toString();
        whiteTextView1.setTextColor(getResources().getColor(R.color.colorWhite));
        blackTextView2.setTextColor(getResources().getColor(R.color.colorBlack5));
        blackView3.setTextColor(getResources().getColor(R.color.colorBlack5));
        blackView4.setTextColor(getResources().getColor(R.color.colorBlack5));
        if (change)
            binding.amountEdit.setTextColor(getResources().getColor(R.color.colorWhite));
        else
            binding.amountEdit.setTextColor(getResources().getColor(R.color.colorBlack5));
    }

    private void changeLayoutColor(LinearLayout primaryLinearLayout1, LinearLayout blackLinearLayout, LinearLayout blackLinearLayout3, LinearLayout blackLinearLayout4) {
        primaryLinearLayout1.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
        blackLinearLayout.setBackgroundColor(getResources().getColor(R.color.colorGray3));
        blackLinearLayout3.setBackgroundColor(getResources().getColor(R.color.colorGray3));
        blackLinearLayout4.setBackgroundColor(getResources().getColor(R.color.colorGray3));
    }

    private void enterAmountDialog() {

        final Dialog dialog = new Dialog(EnterCardAmountActivity.this, R.style.full_screen_dialog);
        //final Dialog dialog = new Dialog(EnterCardAmountActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.enter_amount_dialog);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);

        EditText amountEditText = dialog.findViewById(R.id.amountEditText);
        amountEditText.addTextChangedListener(new NumberTextWatcher(amountEditText));
        amountEditText.requestFocus();
    /*
        TextInputLayout enterVoucherTextInput= dialog.findViewById(R.id.enterVoucherTextInput);*/
        dialog.findViewById(R.id.cancelButton).setOnClickListener(v -> {
            dialog.dismiss();
            closeKeyboard();
        });
        dialog.findViewById(R.id.continueButton).setOnClickListener(V -> {
            if (amountEditText.getText().toString().isEmpty()) {
                // userData.setUserPassword(null);
                showToast(EnterCardAmountActivity.this, "Enter Amount to continue");
                return;

            }
            amount = amountEditText.getText().toString();
            binding.amountFourTextView.setText(amount);
            dialog.dismiss();
            closeKeyboard();
        });
        dialog.show();
        showKeyboard();
        Window window = dialog.getWindow();
        assert window != null;
        // window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        //window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        //window.setGravity(Gravity.BOTTOM);
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);


    }
    public void showKeyboard(){
        InputMethodManager inputMethodManager = (InputMethodManager) EnterCardAmountActivity.this.getSystemService(Context.INPUT_METHOD_SERVICE);
        inputMethodManager.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
    }

    public void closeKeyboard(){
        InputMethodManager inputMethodManager = (InputMethodManager) EnterCardAmountActivity.this.getSystemService(Context.INPUT_METHOD_SERVICE);
        inputMethodManager.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
    }
}