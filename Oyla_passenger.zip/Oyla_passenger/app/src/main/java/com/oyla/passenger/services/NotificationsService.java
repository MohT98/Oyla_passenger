package com.oyla.passenger.services;

import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import com.oyla.passenger.R;

public class NotificationsService extends NotificationListenerService {
    Context context;

    @Override

    public void onCreate() {

        super.onCreate();
        context = getApplicationContext();

    }
    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        super.onNotificationPosted(sbn);
        String packageName = sbn.getPackageName();
        String nTicker ="";
        if(sbn.getNotification().tickerText !=null) {
            nTicker = sbn.getNotification().tickerText.toString();
        }

        Bundle extras = sbn.getNotification().extras;
      //  String title = extras.getString("android.title");
       /* String text = extras.getCharSequence("android.text").toString();
        int id1 = extras.getInt(Notification.EXTRA_SMALL_ICON);
        Bitmap id = sbn.getNotification().largeIcon;*/

        //Toast.makeText(context,title,Toast.LENGTH_SHORT).show();
      //  Log.i("NotificationsService","Package "+packageName);

       // Log.i("NotificationsService","Ticker "+nTicker);
        //Log.i("NotificationsService","Title "+title);
        //Log.i("NotificationsService","Text "+text);
        if(packageName.equalsIgnoreCase("com.oyla.passenger")){
            /*Intent   i = new Intent(context, MapActivity.class);
            startActivity(i);*/
            AudioManager am =
                    (AudioManager) getSystemService(Context.AUDIO_SERVICE);

            am.setStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    am.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
                    0);
            MediaPlayer mp = MediaPlayer.create(this, R.raw.app_raw);

            mp.setLooping(false);
          //  mp.start();
          //  Toast.makeText(context,title + "\n"+packageName,Toast.LENGTH_SHORT).show();
        }
        //Toast.makeText(context,packageName,Toast.LENGTH_SHORT).show();


        Intent msgInfo = new Intent("Msg");
        msgInfo.putExtra("package", packageName);
       // msgInfo.putExtra("nTicker", nTicker);
      //  msgInfo.putExtra("title", title);
      /*  msgInfo.putExtra("text", text);
        if(id != null) {
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            id.compress(Bitmap.CompressFormat.PNG, 100, stream);
            byte[] byteArray = stream.toByteArray();
            msgInfo.putExtra("icon",byteArray);
        }*/
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        super.onNotificationRemoved(sbn);
    }
}
