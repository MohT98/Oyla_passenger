package com.oyla.passenger.viewmodels;

import android.app.Application;
import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;

import com.oyla.passenger.Repository.JsonRepository;
import com.oyla.passenger.datamodels.jsonreponsedatamodel.DataModelObject;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.SharedPrefManager;

public class UpdateProfileViewModel extends SharedViewModel {

    private MutableLiveData<String> UserPhoneNumber = new MutableLiveData<>();
    private MutableLiveData<String> userEmail = new MutableLiveData<>();
    private MutableLiveData<String> userName = new MutableLiveData<>();
    private MutableLiveData<String> userPassword = new MutableLiveData<>();
    private MutableLiveData<String> userGender = new MutableLiveData<>();
    private MutableLiveData<String> userDOB = new MutableLiveData<>();
    private MutableLiveData<String> countryCode = new MutableLiveData<>();
    private MutableLiveData<String> CurrentPassword = new MutableLiveData<>();
    private MutableLiveData<String> NewPassword = new MutableLiveData<>();
    private MutableLiveData<String> ConfirmPassword = new MutableLiveData<>();

    private MutableLiveData<DataModelObject> mutableLiveData;
    private JsonRepository repository;

    public UpdateProfileViewModel(@NonNull Application application) {
        super(application);
    }

    public MutableLiveData<String> getNewPassword() {
        if (NewPassword == null) {
            NewPassword = new MutableLiveData<>();
        }
        return NewPassword;
    }

    public MutableLiveData<String> getConfirmPassword() {
        if (ConfirmPassword == null) {
            ConfirmPassword = new MutableLiveData<>();
        }
        return ConfirmPassword;
    }

    public MutableLiveData<String> getCurrentPassword() {
        if (CurrentPassword == null) {
            CurrentPassword = new MutableLiveData<>();
        }
        return CurrentPassword;
    }

    public MutableLiveData<String> getCountryCode() {
        if (countryCode == null) {
            countryCode = new MutableLiveData<>();
        }
        return countryCode;
    }

    public MutableLiveData<String> getUserPhoneNumber() {
        if (UserPhoneNumber == null) {
            UserPhoneNumber = new MutableLiveData<>();
        }
        return UserPhoneNumber;
    }

    public MutableLiveData<String> getUserEmail() {
        if (userEmail == null) {
            userEmail = new MutableLiveData<>();
        }
        return userEmail;
    }

    public MutableLiveData<String> getUserName() {
        if (userName == null) {
            userName = new MutableLiveData<>();
        }
        return userName;
    }

    public MutableLiveData<String> getUserPassword() {
        if (userPassword == null) {
            userPassword = new MutableLiveData<>();
        }
        return userPassword;
    }

    public MutableLiveData<String> getUserGender() {
        if (userGender == null) {
            userGender = new MutableLiveData<>();
        }
        return userGender;
    }

    public MutableLiveData<String> getUserDOB() {
        if (userDOB == null) {
            userDOB = new MutableLiveData<>();
        }
        return userDOB;
    }
    public boolean validatePassword(String str) {
        return str.length() < 8;
    }

    public TextWatcher onCurrentPasswordChanged = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void afterTextChanged(Editable s) {
            CurrentPassword.setValue(s.toString());
        }
    };

    public TextWatcher onNewPasswordChanged = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void afterTextChanged(Editable s) {
            NewPassword.setValue(s.toString());
        }
    };

    public TextWatcher onConfirmPasswordChanged = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void afterTextChanged(Editable s) {
            ConfirmPassword.setValue(s.toString());
        }
    };


    public TextWatcher onCountryCodeChanged = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            countryCode.setValue(s.toString());
        }
    };

    public TextWatcher onUserNameChanged = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            userName.setValue(s.toString());
        }
    };

    public TextWatcher onUserPhoneNumberChanged = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
           /* if(charSequence.length() >=10){
                continueButton.setBackground(ContextCompat.getDrawable(SignInActivity.this, R.drawable.button));
            }
            if(charSequence.length() < 10){
                continueButton.setBackground(ContextCompat.getDrawable(SignInActivity.this,R.drawable.button_light));
            }*/

        }

        @Override
        public void afterTextChanged(Editable s) {
            if (s.toString().length() == 1 && s.toString().startsWith("0")) {
                s.clear();
            }
            UserPhoneNumber.setValue(s.toString());
        }
    };

    public TextWatcher onUserEmailChanged = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            userEmail.setValue(s.toString());
        }
    };

    public TextWatcher onUserPasswordChanged = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            userName.setValue(s.toString());
        }
    };

    public boolean validateUserName(String str) {
        return str.length() < 3;
    }
    public boolean validateUserEmail(String str){
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
        return  str.matches(emailPattern);
    }

    public void updateProfileRequest(String user_id, String attribute, String value, Context context) {
        Constants.Auth = Constants.Bearer + " " +  SharedPrefManager.getInstance(context).getUserInfo().getAccessToken();
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.updateProfile(user_id,attribute,value);
    }

    public MutableLiveData<DataModelObject> updateProfileRepose() {
        return mutableLiveData;
    }

    public void updateProfileImageRequest(String user_id,String stringImage,String imageName, Context context) {
        Constants.Auth = Constants.Bearer + " " +  SharedPrefManager.getInstance(context).getUserInfo().getAccessToken();
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.updateProfileImage(user_id,stringImage,imageName);
    }

    public MutableLiveData<DataModelObject> updateProfileImageRepose() {
        return mutableLiveData;
    }

    public void sendMob(String value, String fb_token, String referral_code, String identity) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.sendMobNumber(value, fb_token, referral_code, identity);
    }

    public MutableLiveData<DataModelObject> mobApiResponse() {
        return mutableLiveData;
    }

    public void sendOtp(String userId, String otpCode) {
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();

        }
        repository = new JsonRepository();
        mutableLiveData = repository.verifyOTP(userId, otpCode);

    }

    public MutableLiveData<DataModelObject> receiveOtpRepose() {
        return mutableLiveData;
    }

    public void resendOTP(String userId, String mobNumber, String network) {
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();

        }
        repository = new JsonRepository();
        mutableLiveData = repository.resendOTP(userId, mobNumber,network);

    }

    public MutableLiveData<DataModelObject> resendOTPRepose() {
        return mutableLiveData;
    }


    public void verifyOtpUpdateMobile(String userId, String mobileNumber, String network,String otp_code) {
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();

        }
        repository = new JsonRepository();
        mutableLiveData = repository.verifyOtpUpdateMobile(userId, mobileNumber, network,otp_code);

    }

    public MutableLiveData<DataModelObject> verifyOtpUpdateMobileRepose() {
        return mutableLiveData;
    }

}
