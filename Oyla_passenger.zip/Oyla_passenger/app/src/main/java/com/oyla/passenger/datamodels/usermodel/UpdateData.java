package com.oyla.passenger.datamodels.usermodel;

public class UpdateData {
    private String user_id;
    private String attribute;
    private String value;
    private String profile_picture;

    public UpdateData(String user_id, String attribute, String value) {
        this.user_id = user_id;
        this.attribute = attribute;
        this.value = value;
    }

    public UpdateData(String user_id, String profile_picture) {
        this.user_id = user_id;
        this.profile_picture = profile_picture;
    }
}
