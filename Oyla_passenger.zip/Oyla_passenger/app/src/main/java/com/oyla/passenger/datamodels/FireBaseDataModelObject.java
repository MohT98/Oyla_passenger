package com.oyla.passenger.datamodels;

import com.oyla.passenger.datamodels.usermodel.ErrorList;

public class FireBaseDataModelObject {


    private String status;
    private String msg;
    private String token_type;
    private String accessToken;

    private String data;
    private ErrorList error;
    private String notification_type;

    public String getData() {
        return data;
    }

    public ErrorList getError() {
        return error;
    }


    public String getStatus() {
        return status;
    }

    public String getMsg() {
        return msg;
    }

    public String getToken_type() {
        return token_type;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public String getNotification_type() {
        return notification_type;
    }

}
