package com.oyla.passenger.viewmodels;

import android.app.Application;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;

import com.oyla.passenger.Repository.JsonRepository;
import com.oyla.passenger.datamodels.RegisterNewComplaintData;
import com.oyla.passenger.datamodels.jsonreponsedatamodel.DataModelObject;

public class RegisterComplaintViewModel extends SharedViewModel {

    private MutableLiveData<DataModelObject> mutableLiveData;
    private JsonRepository repository;

    public RegisterComplaintViewModel(@NonNull Application application) {
        super(application);
    }

    public void registerComplaintRequest(RegisterNewComplaintData registerNewComplaintData) {
        Log.v("jsonData", "init");
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.registerNewComplaint(registerNewComplaintData);
    }

    public MutableLiveData<DataModelObject> registerComplaintRepose() {
        return mutableLiveData;
    }
}
