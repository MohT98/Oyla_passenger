package com.oyla.passenger.ui.activity;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.lifecycle.ViewModelProvider;

import com.android.installreferrer.api.InstallReferrerClient;
import com.android.installreferrer.api.InstallReferrerStateListener;
import com.android.installreferrer.api.ReferrerDetails;
/*import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.RequestConfiguration;*/
import com.google.android.material.snackbar.Snackbar;
import com.google.android.play.core.appupdate.AppUpdateInfo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.install.InstallStateUpdatedListener;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.InstallStatus;
import com.google.android.play.core.install.model.UpdateAvailability;
import com.google.android.play.core.tasks.Task;
import com.oyla.passenger.MainApp;
import com.oyla.passenger.R;
import com.oyla.passenger.datamodels.usermodel.UserData;
import com.oyla.passenger.services.LatestFirebaseMessagingService;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.ui.activity.dahsboard.DashBoardActivity;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.SharedPrefManager;
import com.oyla.passenger.viewmodels.RefreshTokenViewModel;


import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Locale;

public class SplashActivity extends BaseActivity implements InstallReferrerStateListener {

    private static final String TAG = "SplashActivity";
    RefreshTokenViewModel viewModel;
    UserData userData;
    private String driverStatus = "0";
    private String rideStatus = "0";
    //InstallReferrerClient mReferrerClient;
    private InstallReferrerClient mReferrerClient;
    View parentLayout;
    private final int REQ_CODE_VERSION_UPDATE = 530;
    private AppUpdateManager appUpdateManager;
    private InstallStateUpdatedListener installStateUpdatedListener;
    private int REFRESH_TOKEN_COUNTER = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        Constants.SPLASH = true;
        hideAppBar(this);
        hideStatusBar(this);
        mReferrerClient = InstallReferrerClient.newBuilder(this).build();
        mReferrerClient.startConnection(this);
        parentLayout = findViewById(android.R.id.content);
        viewModel = new ViewModelProvider(this).get(RefreshTokenViewModel.class);
        /*userData = SharedPrefManager.getInstance(this).getUser();*/
        userData = SharedPrefManager.getInstance(this).getUserInfo();
        setAppLanguage2("");
       // Log.v("TokenToken ", "dataModelObject Share pref--- " + LatestFirebaseMessagingService.getToken(this));

      /*  Intent i = new Intent("com.android.vending.INSTALL_REFERRER");
        //Set Package name
        i.setPackage("com.oyla.passenger");
        //referrer is a composition of the parameter of the campaing
        i.putExtra("referrer", "oylap0005");
        sendBroadcast(i);*/


    /*    MobileAds.initialize(this, initializationStatus -> {
        });
        List<String> testDevices = new ArrayList<>();
        testDevices.add(AdRequest.DEVICE_ID_EMULATOR);
        //testDevices.add( "CE9BDE81FEFC9E0812F4B21410087461");

        RequestConfiguration requestConfiguration
                = new RequestConfiguration.Builder()
                .setTestDeviceIds(testDevices)
                .build();
        MobileAds.setRequestConfiguration(requestConfiguration);*/
//        mInterstitialAd = new InterstitialAd(this);
        //mInterstitialAd.setAdUnitId("ca-app-pub-3940256099942544/1033173712");
//        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial_id));
        // mInterstitialAd.loadAd(new AdRequest.Builder().build());

        /*mReferrerClient = InstallReferrerClient.newBuilder(this).build();
        mReferrerClient.startConnection(new InstallReferrerStateListener() {
            @Override
            public void onInstallReferrerSetupFinished(int responseCode) {
                switch (responseCode) {
                    case InstallReferrerClient.InstallReferrerResponse.OK:
                        // Connection established
                        try {
                            ReferrerDetails response =
                                    mReferrerClient.getInstallReferrer();
                            if (!response.getInstallReferrer().contains("utm_source")){
                                Log.v("PRferelCode","PRferelCode "+response.getInstallReferrer());
                                Constants.referral_code=response.getInstallReferrer();
                               //showToast(SplashActivity.this,"response.getInstallReferrer() "+response.getInstallReferrer());
                            }else {
                                Log.v("PRferelCode"," else PRferelCode "+response.getInstallReferrer());
                                //showToast(SplashActivity.this,"response.getInstallReferrer() else ");
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        mReferrerClient.endConnection();
                        break;
                    case
                            InstallReferrerClient.InstallReferrerResponse.FEATURE_NOT_SUPPORTED:
                        // API not available on the current Play Store app
                        break;
                    case
                            InstallReferrerClient.InstallReferrerResponse.SERVICE_UNAVAILABLE:
                        // Connection could not be established
                        break;
                }
            }

            @Override
            public void onInstallReferrerServiceDisconnected() {
                // Try to restart the connection on the next request to
                // Google Play by calling the startConnection() method.
            }
        });*/

        checkForAppUpdate();
        // nextActivity();

    }

    private void nextActivity() {
        /* DialogBoxSingleton.getInstance().showPopup(SplashActivity.this, "You has been Login on other device " ,true);*/

        // Log.v("TokenToken ","token "+MainApp.getInstance().getFireBaseToken());
        // Check if user is signed in (non-null) and update UI accordingly.
        // nextActivity(SplashActivity.this, DashBoardActivity.class);
        if (SharedPrefManager.getInstance(this).isLoggedIn()) {
            if (userData != null) {
                if(SharedPrefManager.getInstance(getApplicationContext()).getUserInfo().getAccessToken()!=null && !SharedPrefManager.getInstance(getApplicationContext()).getUserInfo().getAccessToken() .isEmpty() ){
                    Constants.Auth = Constants.Bearer + " " + SharedPrefManager.getInstance(getApplicationContext()).getUserInfo().getAccessToken();
                }
                //Log.v("TokenToken ", " Share pref getAccessToken--- " + SharedPrefManager.getInstance(getApplicationContext()).getUserInfo().getAccessToken());
                viewModel.sendRefreshTokenRequest(userData.getUserId());
                startLoader();
                viewModel.receiveRefreshTokenRepose().observe(this, dataModelObject -> {
                    if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                        stopLoader();
                      //  Log.v("TokenToken ", "dataModelObject database--- " + dataModelObject.getData().getUser().getFcm_token());
                       // Log.v("TokenToken ", "dataModelObject Main app--- " + MainApp.getInstance().getFireBaseToken());


                        if (dataModelObject.getData().getUser().getFcm_token() != null &&
                                !dataModelObject.getData().getUser().getFcm_token().isEmpty()) {
                           // Log.v("TokenToken ", "dataModelObject token empty--- " + dataModelObject.getData().getUser().getFcm_token().isEmpty());
                          //  Log.v("TokenToken ", "dataModelObject Share pref--- " + LatestFirebaseMessagingService.getToken(this));
                          /*  if (dataModelObject.getData().getUser().getFcm_token().equalsIgnoreCase(MainApp.getInstance().getFireBaseToken())) {*/
                            if (dataModelObject.getData().getUser().getFcm_token().equalsIgnoreCase(LatestFirebaseMessagingService.getToken(this))) {
                                MainApp.getInstance().setUserData(dataModelObject.getData().getUser());
                                if(SharedPrefManager.getInstance(getApplicationContext()).getUserInfo().getAccessToken()==null && SharedPrefManager.getInstance(getApplicationContext()).getUserInfo().getAccessToken() .isEmpty() ){
                                     SharedPrefManager.getInstance(SplashActivity.this).
                                        userInfo(dataModelObject.getData().getUser().getUserId(), dataModelObject.getAccessToken());
                                }
                               // Log.v("TokenToken ", " dataModelObject  getAccessToken--- " + dataModelObject.getAccessToken());
                               // Log.v("TokenToken ", " Share pref getAccessToken 2nd --- " + SharedPrefManager.getInstance(getApplicationContext()).getUserInfo().getAccessToken());
                                Constants.SING_IN_FIRST = false;
                                finish();
                                nextActivity(SplashActivity.this, DashBoardActivity.class);
                            } else {
                                showPopup(SplashActivity.this, "You has been Login on other device" ,true);
                                //showToast(SplashActivity.this, "You has been Login on other device");
                                //SharedPrefManager.getInstance(this).logout();
                            }
                        } else {
                            showPopup(SplashActivity.this, "You has been Logout from this  device", true);
                            //showToast(SplashActivity.this, "You has been Logout from this  device");
                           // SharedPrefManager.getInstance(this).logout();
                        }

                    } else {
                        stopLoader();
                        //DialogBoxSingleton.getInstance().showErrorPopup(SplashActivity.this, dataModelObject.getError());
                        if (dataModelObject.getError().getMessage() != null) {
                            //  showToast(SplashActivity.this, dataModelObject.getError().getMessage());
                            Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                        } else if (dataModelObject.getError().getMessages() != null) {
                            // showToast(SettingActivity.this, dataModelObject.getError().getMessages().toString());
                            Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                        }

                        //SharedPrefManager.getInstance(this).logout();
                        if (REFRESH_TOKEN_COUNTER < 5) {
                            REFRESH_TOKEN_COUNTER++;
                            nextActivity();
                        } else {
                            REFRESH_TOKEN_COUNTER = 0;
                           // showToast(SplashActivity.this, "Your session has been expire Login Again");
                            showPopup(SplashActivity.this, "Your session has been expire Login Again", true);
                            /*SharedPrefManager.getInstance(this).logout();*/
                        }
                    }
                });
            }
        } else {
            //showToast(SplashActivity.this, "You are no longer Login on this device");
            nextActivity(SplashActivity.this, SelectCountryActivity.class);
            finish();
        }

          /*   currentUser = firebaseAuth.getCurrentUser();
            if (currentUser != null) {
                Constants.G_SIGN_IN=true;
                Log.d("GoogleSign", "Currently Signed in: " + currentUser.getEmail());
                Log.d("GoogleSign", "Currently Signed in: " + currentUser.getDisplayName());
                nextActivity(SplashActivity.this, DashBoardActivity.class);
                finish();
            }else {
                Constants.G_SIGN_IN=false;
                if (SharedPrefManager.getInstance(this).isLoggedIn()) {
                    nextActivity(SplashActivity.this, DashBoardActivity.class);
                }else {
                    nextActivity(SplashActivity.this, LoginOptionActivity.class);
                }
                finish();
            }*/


    }


    @Override
    public void onInstallReferrerSetupFinished(int responseCode) {
        switch (responseCode) {
            case InstallReferrerClient.InstallReferrerResponse.OK:
                // Connection established

                try {
                    getReferralUser();
                } catch (RemoteException e) {
                    e.printStackTrace();
                }

                break;
            case InstallReferrerClient.InstallReferrerResponse.FEATURE_NOT_SUPPORTED:
                // API not available on the current Play Store app
                break;
            case InstallReferrerClient.InstallReferrerResponse.SERVICE_UNAVAILABLE:
                // Connection could not be established
                break;
            case InstallReferrerClient.InstallReferrerResponse.DEVELOPER_ERROR:
                break;
            case InstallReferrerClient.InstallReferrerResponse.SERVICE_DISCONNECTED:
                break;
        }
    }

    private void getReferralUser() throws RemoteException {
        ReferrerDetails response = mReferrerClient.getInstallReferrer();
        String referrerData = response.getInstallReferrer();
        Log.e("InstallReferrerReceiver", "Install referrer:" + response.getInstallReferrer());


        // for utm terms
        HashMap<String, String> values = new HashMap<>();
        if (values.containsKey("utm_medium") && values.containsKey("utm_term")) {
            try {
                if (referrerData != null) {
                    String referrers[] = referrerData.split("&");

                    for (String referrerValue : referrers) {
                        String keyValue[] = referrerValue.split("=");
                        values.put(URLDecoder.decode(keyValue[0], "UTF-8"), URLDecoder.decode(keyValue[1], "UTF-8"));
                    }

                    Log.e("TAG", "UTM medium:" + values.get("utm_medium"));
                    Log.e("TAG", "UTM term:" + values.get("utm_term"));

                }
            } catch (Exception e) {

            }
        }
    }

    @Override
    public void onInstallReferrerServiceDisconnected() {

    }


    private void checkForAppUpdate() {
        // Creates instance of the manager.
        appUpdateManager = AppUpdateManagerFactory.create(SplashActivity.this);

        // Returns an intent object that you use to check for an update.
        Task<AppUpdateInfo> appUpdateInfoTask = appUpdateManager.getAppUpdateInfo();
        Log.v("CheckUpdate", "appUpdateManager.getAppUpdateInfo() " + appUpdateManager.getAppUpdateInfo());

       /* appUpdateInfoTask.addOnSuccessListener(result -> {
            Log.v("CheckUpdate","on Success ") ;

            if(result.updateAvailability()==UpdateAvailability.UPDATE_AVAILABLE && result.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)){
                Log.v("CheckUpdate","if") ;
                try {
                    Log.v("CheckUpdate","try") ;
                    appUpdateManager.startUpdateFlowForResult(result,AppUpdateType.IMMEDIATE,SplashActivity.this,REQ_CODE_VERSION_UPDATE);
                } catch (IntentSender.SendIntentException e) {
                    Log.v("CheckUpdate","catch "+e) ;
                    e.printStackTrace();
                }
            }else {
                Log.v("CheckUpdate","else ") ;
            }
        });
        appUpdateInfoTask.addOnFailureListener(e -> {
            Log.v("CheckUpdate","on Failure ") ;
        });*/


        // Create a listener to track request state updates.
        installStateUpdatedListener = installState -> {
            // Show module progress, log state, or install the update.
            Log.v("CheckUpdate", "installState.installStatus() " + installState.installStatus());
            Log.v("CheckUpdate", "InstallStatus.DOWNLOADED " + InstallStatus.DOWNLOADED);
            if (installState.installStatus() == InstallStatus.DOWNLOADED)
                // After the update is downloaded, show a notification
                // and request user confirmation to restart the app.
                popupSnackBarForCompleteUpdateAndUnregister();
        };


        // Checks that the platform will allow the specified type of update.
        appUpdateInfoTask.addOnSuccessListener(appUpdateInfo -> {
            Log.v("CheckUpdate", "appUpdateInfoTask ");
            Log.v("CheckUpdate", "appUpdateInfo.updateAvailability() " + appUpdateInfo.updateAvailability());
            Log.v("CheckUpdate", "appUpdateInfoTask updateAvailability " + UpdateAvailability.UPDATE_AVAILABLE);
            Log.v("CheckUpdate", "AppUpdateType.FLEXIBLE " + AppUpdateType.FLEXIBLE);
            Log.v("CheckUpdate", "AppUpdateType.FLEXIBLE " + AppUpdateType.IMMEDIATE);
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE) {
                // Request the update.
                showToast(SplashActivity.this, "Making the update request");
                if (appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.FLEXIBLE)) {

                    // Before starting an update, register a listener for updates.
                    appUpdateManager.registerListener(installStateUpdatedListener);
                    // Start an update.
                    startAppUpdateFlexible(appUpdateInfo);
                } else if (appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)) {
                    // Start an update.
                    startAppUpdateImmediate(appUpdateInfo);
                }
            } else {
                // startLoader();
                nextActivity();
            }
        });
        appUpdateInfoTask.addOnFailureListener(e -> {
            Log.v("CheckUpdate", "onFailure");

            nextActivity();
        });
    }

    @Override
    public void onActivityResult(int requestCode, final int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        if (requestCode == REQ_CODE_VERSION_UPDATE) {
            if (resultCode != RESULT_OK) { //RESULT_OK / RESULT_CANCELED / RESULT_IN_APP_UPDATE_FAILED
                Log.d("CheckUpdate", "Update flow failed! Result code: " + resultCode);
                // If the update is cancelled or fails,
                // you can request to start the update again.
                //  unregisterInstallStateUpdListener();
                showToast(SplashActivity.this, "Update failed!");
                finish();
            }
        }
    }

    private void startAppUpdateImmediate(AppUpdateInfo appUpdateInfo) {
        try {
            appUpdateManager.startUpdateFlowForResult(
                    appUpdateInfo,
                    AppUpdateType.IMMEDIATE,
                    // The current activity making the update request.
                    this,
                    // Include a request code to later monitor this update request.
                    REQ_CODE_VERSION_UPDATE);
        } catch (IntentSender.SendIntentException e) {
            e.printStackTrace();
        }
    }

    private void startAppUpdateFlexible(AppUpdateInfo appUpdateInfo) {
        try {
            appUpdateManager.startUpdateFlowForResult(
                    appUpdateInfo,
                    AppUpdateType.FLEXIBLE,
                    // The current activity making the update request.
                    this,
                    // Include a request code to later monitor this update request.
                    REQ_CODE_VERSION_UPDATE);
        } catch (IntentSender.SendIntentException e) {
            e.printStackTrace();
            unregisterInstallStateUpdListener();
        }
    }

    /**
     * Displays the snackbar notification and call to action.
     * Needed only for Flexible app update
     */
    private void popupSnackBarForCompleteUpdateAndUnregister() {
        Snackbar snackbar =
                Snackbar.make(parentLayout, getString(R.string.update_downloaded), Snackbar.LENGTH_INDEFINITE);
        snackbar.setAction(R.string.restart, view -> appUpdateManager.completeUpdate());
        snackbar.setActionTextColor(getResources().getColor(R.color.colorPrimary));
        snackbar.show();

        unregisterInstallStateUpdListener();
    }

    /**
     * Checks that the update is not stalled during 'onResume()'.
     * However, you should execute this check at all app entry points.
     */


    /**
     * Needed only for FLEXIBLE update
     */
    private void unregisterInstallStateUpdListener() {
        if (appUpdateManager != null && installStateUpdatedListener != null)
            appUpdateManager.unregisterListener(installStateUpdatedListener);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // checkNewAppVersionState();
    }

    @Override
    protected void onDestroy() {
        // unregisterInstallStateUpdListener();
        super.onDestroy();
    }

    public void showPopup(Context context, String message, Boolean bol) {
        final Dialog dialog = new Dialog(context);
        dialog.setContentView(R.layout.error_popup);
        //dialog.setCancelable(false);
        dialog.setCancelable(bol);
        //dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        TextView errorBody = dialog.findViewById(R.id.errorBody);
        errorBody.setText(message != null ? message : context.getString(R.string.error));
        Button okay = dialog.findViewById(R.id.next);
        okay.setOnClickListener(v ->
                {
                    SharedPrefManager.getInstance(this).logout();
                    dialog.dismiss();
                    finish();
                }
        );
        /*okay.setOnClickListener(v -> dialog.dismiss());*/
        dialog.show();
        Window window = dialog.getWindow();
        assert window != null;
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }
    public void setAppLanguage2(String language){
        if (SharedPrefManager.getInstance(SplashActivity.this).getLanguage() == null) {
            language = getResources().getString(R.string.english);
        } else {
            language = SharedPrefManager.getInstance(SplashActivity.this).getLanguage();
        }
        Log.v("setAppLanguage","setAppLanguage "+language);
        if(language.equalsIgnoreCase("English")) {
            language="en";
        }
        else if( language.equalsIgnoreCase("اردو")) {
            language="ur";
        }
        Log.v("setAppLanguage","setAppLanguage "+language);
        Locale locale = new Locale(language);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        Resources resources = getResources();
        config.locale = locale;
        //resources.updateConfiguration(config, resources.getDisplayMetrics());
        getBaseContext().getResources().updateConfiguration(config,
                getBaseContext().getResources().getDisplayMetrics());
    }

}