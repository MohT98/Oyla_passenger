package com.oyla.passenger.adapter.ridetype;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.google.maps.GeoApiContext;
import com.oyla.passenger.R;
import com.oyla.passenger.datamodels.RideTypeData;
import com.oyla.passenger.utilities.Constants;
import java.util.List;

import static com.facebook.FacebookSdk.getApplicationContext;

public class SelectRideItemAdapter extends RecyclerView.Adapter<SelectRideItemAdapter.MyViewHolder> {

    private final List<RideTypeData> dataSet;
    private int rowIndex = -1;
    private final Context mCtx;
    private OnRideItemClickListener mListener;
    private final int totalMint;
    private final double totalDistance;
    GeoApiContext mGeoApiContext;
    private double passengerLatitude, passengerLongitude;
    private String rideTime = " ";
    private String vehicleType;
    private Animation animEnter,animExit;
    private int SKIP_DROP_OFF;

    public void setRideItemClickListener(OnRideItemClickListener listener) {
        mListener = listener;
    }

    public SelectRideItemAdapter(Context mCtx, List<RideTypeData> dataSet, int totalMint, double totalDistance, GeoApiContext mGeoApiContext, double passengerLatitude, double passengerLongitude, String vehicleType,int SKIP_DROP_OFF) {
        this.dataSet = dataSet;
        this.mCtx = mCtx;
        this.totalMint = totalMint;
        this.totalDistance = totalDistance;
        this.mGeoApiContext = mGeoApiContext;
        this.passengerLatitude = passengerLatitude;
        this.passengerLongitude = passengerLongitude;
        //  this.rideTimeCalListner = this;
        this.vehicleType = vehicleType;
        animEnter = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.animation_enter);
        animExit = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slide_in_right);
        this.SKIP_DROP_OFF=SKIP_DROP_OFF;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.ride_type_list_item, parent, false);
        //view.setOnClickListener(SelectRideBottomSheetDialog.myOnClickListener);
        return new MyViewHolder(view, mListener);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int listPosition) {
        if (dataSet != null) {
            holder.typeName.setText(dataSet.get(listPosition).getCarType());

            if (dataSet.get(listPosition).getImage_url().isEmpty() || dataSet.get(listPosition).getImage_url() == null) {
                holder.carIcon.setImageResource(R.drawable.go_plus);
            } else {
                Log.v("vehicleURL", "getImage_url " + dataSet.get(listPosition).getImage_url());
                Glide
                        .with(mCtx)
                        .load(Constants.ASSETS_BASE_URL + dataSet.get(listPosition).getImage_url())
                        .centerCrop()
                        .placeholder(R.drawable.go_plus)
                        .into(holder.carIcon);
            }
           // if (SKIP_DROP_OFF == 0) {
            holder.rideFairText.setText(mCtx.getResources().getString(R.string.currency_text)+ " " +
                    dataSet.get(listPosition).getFair() );
               /* holder.rideFairText.setText(mCtx.getResources().getString(R.string.currency_text)
                        + " " + fareCalculation(
                        Double.parseDouble(dataSet.get(listPosition).getRide1_rate_per_kilometer()),
                        Double.parseDouble(dataSet.get(listPosition).getRate_per_kilometer()),
                        Double.parseDouble(dataSet.get(listPosition).getRate_per_minute()),
                        Double.parseDouble(dataSet.get(listPosition).getVehicleRate()), listPosition,
                        Double.parseDouble(dataSet.get(listPosition).getTax_percentage()),
                        dataSet.get(listPosition).getTime(),
                        dataSet.get(listPosition).getPartner_pickup_distance(),
                        dataSet.get(listPosition).getPartner_pickup_rate(),
                        dataSet.get(listPosition).getPeak_rate(),
                        dataSet.get(listPosition).getMin_ride_fares(),
                        dataSet.get(listPosition).getCarType()
                ));*/
            //}

            if(dataSet.get(listPosition).getDiscount()!=null && !dataSet.get(listPosition).getDiscount().isEmpty()){
                holder.discountText.setText(dataSet.get(listPosition).getDiscount());
            }else{
                holder.discountText.setText("");
            }
            holder.typeDescription.setText(dataSet.get(listPosition).getDescription());
            // Log.d("calculateTime", "calculateTime rideTime: " + calculateTime(dataSet.get(listPosition).getLat(),dataSet.get(listPosition).getLng()));
            // holder.rideTime.setText(calculateTime(dataSet.get(listPosition).getLat(),dataSet.get(listPosition).getLng()));
            //   Log.v("rideTime","rideTime" +dataSet.get(listPosition).getTime());
            //  holder.rideTime.setText(dataSet.get(listPosition).getTime() + " min");
           // if (dataSet.get(listPosition).getId().equalsIgnoreCase("1")) {
                holder.rideTime.setText(dataSet.get(listPosition).getTime()+" min");
          /*  holder.rideTime.setText(dataSet.get(listPosition).getTime());*/
                Log.v("SelectRideItemAdapter2", "getTime " + dataSet.get(listPosition).getTime());
                Log.v("SelectRideItemAdapter2", "getPartner_pickup_distance " + dataSet.get(listPosition).getPartner_pickup_distance());
          /*  } else {
                holder.rideTime.setText(" ");
            }*/
            //holder.rideTime.setText(time2(Double.valueOf(dataSet.get(listPosition).getLat()),Double.valueOf(dataSet.get(listPosition).getLng())));
            if (rowIndex == listPosition) {
                setCardMargin(holder.rideCardView, 5, 20, 30, 30, holder.rideFairText, mCtx.getResources().getColor(R.color.colorPrimary));
            } else {
                setCardMargin(holder.rideCardView, 0, 0, 0, 0, holder.rideFairText, mCtx.getResources().getColor(R.color.colorBlack2));
            }
        }
    }



    @Override
    public int getItemCount() {
        return dataSet.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView rideFairText, rideTime, typeName, typeDescription,discountText;
        CardView rideCardView;
        ImageView carIcon;
        LinearLayout topLayout;


        public MyViewHolder(View itemView, OnRideItemClickListener listener) {
            super(itemView);
            rideFairText = itemView.findViewById(R.id.rideFairText);
            rideCardView = itemView.findViewById(R.id.rideCardView);
            rideTime = itemView.findViewById(R.id.rideTime);
            typeName = itemView.findViewById(R.id.typeName);
            discountText = itemView.findViewById(R.id.discountText);
            typeDescription = itemView.findViewById(R.id.typeDescription);
            carIcon = itemView.findViewById(R.id.carIcon);
            topLayout = itemView.findViewById(R.id.topLayout);


            itemView.setOnClickListener(v -> {
                if (listener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onItemClick(position);
                        rowIndex = position;
                        notifyDataSetChanged();
                        rideCardView.setCardElevation(5);
                    }
                }
            });


        }
    }

    private void setCardMargin(CardView cardView, float elevation, float radius, int marginRight, int marginLeft, TextView textView, int color) {
        ViewGroup.MarginLayoutParams cardViewMarginParams = (ViewGroup.MarginLayoutParams) cardView.getLayoutParams();
        cardViewMarginParams.setMargins(marginLeft, 0, marginRight, 0);
        cardView.requestLayout();
        cardView.setCardElevation(elevation);
        cardView.setRadius(radius);
        textView.setTextColor(color);
    }

    public interface OnRideItemClickListener {
        void onItemClick(int position);

    }


    private String fareCalculation(double ride1_rate_per_kilometer,double perKM, double perMint,
                                   double vehicleRate, int i, double tax_percentage,
                                   String pickUpTime, String pickUpDistance, String Partner_pickup_rate,
                                   String peakRate,String minRideFares,String CarType) {
        Log.v("fareCalculation","getVehicleType "+CarType);
        Log.v("fareCalculation","getMin_ride_fares "+minRideFares);
        Log.v("fareCalculation", " fare 2 totalMint  " + totalMint);
        Log.v("fareCalculation", " fare 2 totalDistance  " + totalDistance);
        Log.v("fareCalculation", "ride1_rate_per_kilometer  " + ride1_rate_per_kilometer);
        int pickupTime = getTripTime(pickUpTime);
        double pickupDistance = getTripDestination(pickUpDistance);
        Log.v("fareCalculation","pickupDistance "+pickupDistance);
        Log.v("fareCalculation", "pickupTime  " + pickupTime);
        double pickup_rate = Double.parseDouble(Partner_pickup_rate);
        Log.v("fareCalculation", "pickup_rate  " + pickup_rate);
        double price1 = (ride1_rate_per_kilometer * pickupDistance) + (pickup_rate * pickupTime) ;
       /* Log.v("selectRideType", "vehicleRate  " + vehicleRate);
        Log.v("calculateTime", "totalDistance  " + totalDistance);*/
        double price2 = (perKM * totalDistance) + (perMint * totalMint) ;
        Log.v("fareCalculation", "perKM  " + perKM);
        Log.v("fareCalculation", "perMint  " + perMint);
        price2*= Double.parseDouble(peakRate);
        // DecimalFormat twoDForm = new DecimalFormat("#.##");


        Log.v("fareCalculation", "price1 " + price1);
        Log.v("fareCalculation", "price2 " + price2);
        double totalPrice = price1 + price2;

        Log.v("fareCalculation", "price1 + price2= " +  totalPrice);
        Log.v("fareCalculation", "vehicleRate  " + vehicleRate);

        totalPrice=totalPrice+vehicleRate;
        Log.v("fareCalculation", "totalPrice *vehicleRate " + totalPrice);
       // totalPrice*= Double.parseDouble(peakRate);



        double fair = (int) totalPrice;
        double taxPrice = (tax_percentage / 100) * fair;
        Log.v("fareCalculation", "taxPrice " + taxPrice);
        double finalPrice = fair + taxPrice;
        //finalPrice *= Double.parseDouble(peakRate);
        double minFares= Double.parseDouble(minRideFares);
        String fair1;
        Log.v("fareCalculation", "finalPrice " + finalPrice);
        Log.v("fareCalculation", "minFares " + minFares);

        if(finalPrice<minFares){
            fair1 = String.valueOf(Math.round(minFares));
        }else {
            fair1 = String.valueOf(Math.round(finalPrice));
        }
        int balance=Integer.parseInt(String.valueOf(Math.round(Double.parseDouble(Constants.WALLET_AMOUNT))));
        //int balance=Integer.parseInt(Constants.WALLET_AMOUNT);
        if(balance<0){
            fair1=String.valueOf(Integer.parseInt(fair1)-balance);
        }
        Log.v("balance", "fair1 " + fair1);
        Log.v("fareCalculation", "fair1 " + fair1);
        Log.v("fareCalculation", "-------- " );

        dataSet.get(i).setFair(fair1);
        return fair1;
    }


    /* @Override
     public void onCalReceive(String rideTime) {
         Log.e("calculateTime", "onCalReceive " + rideTime);
     }*/
    private int getTripTime(String duration) {
        String addHours = "0";
        String addMinutes = "0";
        boolean HOUR = false;
        if (duration.contains("hours")) {
            duration = duration.replace("hours", ":");
            HOUR = true;

        } else if (duration.contains("hour")) {
            duration = duration.replace("hour", ":");
            HOUR = true;

        }

        if (duration.contains("mins")) {
            duration = duration.replace("mins", "");
            addMinutes = duration;

        }

        if (HOUR) {
            String[] splitTime = duration.split(":");
            addHours = splitTime[0].trim();
            addMinutes = splitTime[1].trim();
        }


        //  Log.v("selectRideType", "finalDistance  " + finalDistance);
        addHours = addHours.replace(" ", "");
        addMinutes = addMinutes.replace(" ", "");

        // int finalTotalMint =Integer.valueOf(durationMint);
        int finalTotalHour = Integer.parseInt(addHours);
        finalTotalHour = finalTotalHour * 60;
        int tripTime = Integer.parseInt(addMinutes) + finalTotalHour;
        Log.v("selectRideType", "tripTime  " + tripTime);
        // double tripTimeDistance1 = finalDistance;
        return tripTime;
    }


    private double getTripDestination(String distance) {
        double finalDistance = 0;
        if (distance.contains("km")) {
          //  Log.v("fareCalculation", "Distance in km");
            distance = distance.replace("km", "");
            distance = distance.replace(" ", "");
            if (distance.contains(",")) {
                distance = distance.replace(",", "");
            }
            finalDistance = Double.parseDouble(distance);
        } else if (distance.contains("m")) {
            Log.v("fareCalculation", "Distance in meter");
            distance = distance.replace("m", "");
            distance = distance.replace(" ", "");
            if (distance.contains(",")) {
                distance = distance.replace(",", "");
            }
            finalDistance = Double.parseDouble(distance);
            finalDistance = finalDistance / 1000;
        }

        return finalDistance;
    }

}
