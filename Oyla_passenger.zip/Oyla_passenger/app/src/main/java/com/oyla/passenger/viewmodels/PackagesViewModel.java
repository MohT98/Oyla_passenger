package com.oyla.passenger.viewmodels;

import android.app.Application;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;

import com.oyla.passenger.Repository.JsonRepository;
import com.oyla.passenger.datamodels.jsonreponsedatamodel.DataModelObject;

public class PackagesViewModel extends SharedViewModel{
    private MutableLiveData<DataModelObject> mutableLiveData;
    private JsonRepository repository;

    public PackagesViewModel(@NonNull Application application) {
        super(application);
    }

    public void sendPackageRequest() {

        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        repository = new JsonRepository();
        mutableLiveData = repository.getPackages();
    }

    public MutableLiveData<DataModelObject> receivePackageRepose() {
        return mutableLiveData;
    }
}
