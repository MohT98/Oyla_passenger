package com.oyla.passenger.utilities;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Window;

import com.oyla.passenger.R;


public class Loading {

    public static Dialog makeDialog(Context con) {
        final Dialog dialog = new Dialog(con);
            //Log.d("UI thread", "I am the UI thread");
          //  Log.v("startLoader", "startLoader Dialog " );
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView(R.layout.loader);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
            // set the custom dialog components - text, image
            // and button
            dialog.setCanceledOnTouchOutside(false);
            dialog.setCancelable(false);
            dialog.show();
        return dialog;
    }
}
