package com.oyla.passenger.ui.activity.history;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.oyla.passenger.MainApp;
import com.oyla.passenger.R;
import com.oyla.passenger.databinding.ActivityTransactionDetailBinding;
import com.oyla.passenger.datamodels.historydata.RideHistoryData;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.ui.activity.CaptainReviewActivity;
import com.oyla.passenger.ui.activity.WebPageActivity;
import com.oyla.passenger.utilities.Constants;

public class RideDetailActivity extends BaseActivity {
    private ActivityTransactionDetailBinding binding;
    RideHistoryData rideHistoryData;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        hideAppBar(this);
        binding = setContentView(this, R.layout.activity_transaction_detail);
        Intent intent = getIntent();
        rideHistoryData = intent.getParcelableExtra("Item");
        Log.v("Item", "Item " + rideHistoryData.getDriver_name());
        binding.captainInfo.setOnClickListener(v -> {
            if(Float.parseFloat(rideHistoryData.getBooking_rating())<1){
                Intent i = new Intent(RideDetailActivity.this, CaptainReviewActivity.class);
                i.putExtra("bookingId", rideHistoryData.getId());
                i.putExtra("passengerId", rideHistoryData.getPassenger_id());
                i.putExtra("driverId", rideHistoryData.getDriver_id());
                startActivity(i);
                finish();
            }

        });
        binding.onBack.setOnClickListener(v -> {
            onBackPressed();
        });
        binding.getSupportLayout.setOnClickListener(v -> {
            Intent i = new Intent(RideDetailActivity.this, WebPageActivity.class);
            i.putExtra("pageName","getHelp");
            startActivity(i);
        });
        Log.v("Item", "name " + MainApp.getInstance().getUserData().getUserFirstName());
        binding.userNameText.setText(MainApp.getInstance().getUserData().getUserFirstName());
        binding.rideTypeText.setText(rideHistoryData.getVehicle_type() + "(" + rideHistoryData.getVehicle_name() + ")");
        binding.captainNameText.setText(getResources().getString(R.string.your_trip_with)+" "+ rideHistoryData.getDriver_name());
        binding.ratingBar.setRating(Float.parseFloat(rideHistoryData.getBooking_rating()));
        //binding.walletAmount.setText(getResources().getString(R.string.currency_text)+" "+"0");
        binding.paymentType.setText(rideHistoryData.getPayment_type());
        setGlideImage(getApplicationContext(), rideHistoryData.getDriver_profile_picture(),binding.captainProfileIcon, Constants.PROFILE_BASE_URL);



        //if(transactionHistoryData.getFine_user_type()!=null){

            Log.v("Fine_user_type","Cancel_fine_amount() "+ rideHistoryData.getCancel_fine_amount());
        Log.v("Fine_user_type","getStatus() "+ rideHistoryData.getStatus());
            //if(transactionHistoryData.getFine_user_type().equalsIgnoreCase("Passenger")){
            if(!rideHistoryData.getStatus().equalsIgnoreCase("4") /*||
                    !transactionHistoryData.getStatus().equalsIgnoreCase("1")||
                    !transactionHistoryData.getStatus().equalsIgnoreCase("4")*/){
                binding.amountChargedLayout.setVisibility(View.GONE);
                binding.amountChargedText.setText(getResources().getString(R.string.ride_cancel));
                binding.amountChargedText.setTextColor(getResources().getColor(R.color.red));
                if(rideHistoryData.getCancel_fine_amount()==null ||
                        rideHistoryData.getCancel_fine_amount().equalsIgnoreCase("0") &&
                                !rideHistoryData.getCancel_fine_amount().equalsIgnoreCase("4")){

                    binding.tripFair.setText(getResources().getString(R.string.currency_text)+" 0" );
                    binding.finalTotalAmountText.setText(getResources().getString(R.string.currency_text)+" 0");
                    binding.cashAmount.setText(getResources().getString(R.string.currency_text)+" 0");
                    binding.finalTotalAmountText.setText(getResources().getString(R.string.currency_text)+" 0");
                }else {
                    binding.tripFair.setText(getResources().getString(R.string.currency_text)+" -"+ Math.round(Float.parseFloat(rideHistoryData.getCancel_fine_amount())));
                    binding.finalTotalAmountText.setText(getResources().getString(R.string.currency_text)+" -"+ rideHistoryData.getCancel_fine_amount() );

                    binding.cashAmount.setText(getResources().getString(R.string.currency_text)+" -"+ Math.round(Float.parseFloat(rideHistoryData.getCancel_fine_amount())));
                    binding.finalTotalAmountText.setText(getResources().getString(R.string.currency_text)+" -"+ rideHistoryData.getCancel_fine_amount() );
                }

               // if(!transactionHistoryData.getStatus().equalsIgnoreCase("0") ||
                      //  !transactionHistoryData.getStatus().equalsIgnoreCase("1")){
                    binding.totalTime.setVisibility(View.GONE);
                    binding.totalDistance.setVisibility(View.GONE);
                    binding.walletLayout.setVisibility(View.GONE);
                //}

            }else {
                setAmount();
            }
       /* }else {
            setAmount();
        }*/
        String currentString = rideHistoryData.getCreated_at();
        String[] timeDate = currentString.split("T");
        //String timeDate2 = timeDate[1];
        //Log.v("timeDate2","timeDate2 "+timeDate2);
      //  String[] timeDate3 = timeDate2.split("\\.");
       // Log.v("timeDate2","timeDate3 "+timeDate3[0]);
       // Log.v("timeDate2","getRide_complete_time "+transactionHistoryData.getRide_complete_time());
        //binding.dateTimeText.setText( timeDate[0]+" | "+ timeDate3[0]);
        binding.dateTimeText.setText( timeDate[0]);
        if(rideHistoryData.getDriver_initial_distance()!=null && rideHistoryData.getDistance_kilomiters()!=null){

            Log.v("timeDate2","getDriver_initial_distance "+ rideHistoryData.getDriver_initial_distance());
            Log.v("timeDate2","getDistance_kilomiters "+ rideHistoryData.getDistance_kilomiters());
            double distance=Double.parseDouble(rideHistoryData.getDriver_initial_distance())+
                    Double.parseDouble(rideHistoryData.getDistance_kilomiters());
            binding.totalDistance.setText(getResources().getString(R.string.total_distance)+" "+ String.format("%.2f", distance)+" "+ getResources().getString(R.string.km));
            Log.v("timeDate2","distance "+distance);
        }

        binding.totalTime.setText(getResources().getString(R.string.total_time)+" "+ rideHistoryData.getRide_complete_time()+" "+ getResources().getString(R.string.min));


        if(rideHistoryData.getRide_complete_time()==null || rideHistoryData.getRide_complete_time().isEmpty()){
            binding.totalTime.setText(getResources().getString(R.string.total_time)+"0 "+ getResources().getString(R.string.min));
        }


        binding.pickUpText.setText(getStringAddress(
                Double.parseDouble(rideHistoryData.getPickup_latitude()),
                Double.parseDouble(rideHistoryData.getPickup_longitude())
                )
        );

        binding.dropOffText.setText(getStringAddress(
                Double.parseDouble(rideHistoryData.getDropoff_latitude()),
                Double.parseDouble(rideHistoryData.getDropoff_longitude())
                )
        );


    }
    private void setAmount(){
        //binding.tripFair.setText(getResources().getString(R.string.currency_text)+" "+ Math.round(Float.parseFloat(transactionHistoryData.getFinal_amount())));
        binding.tripFair.setText(getResources().getString(R.string.currency_text)+" "+ Math.round(Float.parseFloat(rideHistoryData.getPassenger_cash_paid())));
        binding.walletAmount.setText(getResources().getString(R.string.currency_text)+" "+ Math.round(Float.parseFloat(rideHistoryData.getWallet_pay_amount())));
        binding.tripFair.setText(getResources().getString(R.string.currency_text)+" "+ Math.round(Float.parseFloat(rideHistoryData.getPassenger_cash_paid())));
        binding.finalTotalAmountText.setText(getResources().getString(R.string.currency_text)+" "+ rideHistoryData.getFinal_amount() );
        binding.cashAmount.setText(getResources().getString(R.string.currency_text)+" "+ Math.round(Float.parseFloat(rideHistoryData.getFinal_amount())));
        binding.finalTotalAmountText.setText(getResources().getString(R.string.currency_text)+" "+ rideHistoryData.getFinal_amount() );
    }
}