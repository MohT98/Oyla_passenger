package com.oyla.passenger.ui.activity.pay;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.lifecycle.ViewModelProvider;

import com.oyla.passenger.datamodels.JazzCashData;
import com.oyla.passenger.ui.activity.dahsboard.DashBoardActivity;
import com.oyla.passenger.utilities.DialogBoxSingleton;
import com.oyla.passenger.R;
import com.oyla.passenger.databinding.ActivityJazzCashBinding;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.Messages;
import com.oyla.passenger.utilities.SharedPrefManager;
import com.oyla.passenger.viewmodels.JazzCashViewModel;

import java.util.Objects;

public class  JazzCashActivity extends BaseActivity {

    private JazzCashViewModel viewModel;
    private ActivityJazzCashBinding binding;
    private int nameErrorCount = 0;
    private int mobErrorCount = 0;
    private int cnicErrorCount = 0;
    private int amountErrorCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = setContentView(this, R.layout.activity_jazz_cash);
        hideAppBar(this);
        viewModel = new ViewModelProvider(this).get(JazzCashViewModel.class);
        binding.setViewModel(viewModel);
        binding.onBack.setOnClickListener(v -> {
            onBackPressed();
        });

        viewModel.getUserName().observe(this, s -> {
            if (s != null) {
                removeError(binding.nameTextInput);
                if (TextUtils.isEmpty(s)) {
                    showError(Messages.EmptyMessage, binding.nameTextInput, binding.nameEditText);
                    //userData.setUserName(null);
                } else if (viewModel.validateUserName(s)) {
                    if (nameErrorCount > 0) {
                        showError(Messages.userNameShortMessage, binding.nameTextInput, binding.nameEditText);
                    }
                    //userData.setUserName(s);
                }
            }
        });

        viewModel.getUserPhoneNumber().observe(this, s -> {
            if (s != null) {

                removeError(binding.jazzTextInput);
                if (TextUtils.isEmpty(s)) {
                    showError(Messages.EmptyMessage, binding.jazzTextInput, binding.jazzEditText);
                    //userData.setUserName(null);
                } else if (s.length() < 11) {
                    Log.v("hintLength", "s number length " + s.length());
                    if (mobErrorCount > 0) {
                        showError(Messages.phoneNumberValidMessage2, binding.jazzTextInput, binding.jazzEditText);
                    }
                }
            }
        });

        viewModel.getUserCNIC().observe(this, s -> {
            if (s != null) {
                removeError(binding.cnicTextInput);
                if (TextUtils.isEmpty(s)) {
                    showError(Messages.EmptyMessage, binding.cnicTextInput, binding.cnicEditText);
                    //userData.setUserName(null);
                } else if (s.length() < 6) {
                    if (cnicErrorCount > 0) {
                        showError(Messages.cnicMessage, binding.cnicTextInput, binding.cnicEditText);
                    }
                    //userData.setUserName(s);
                } else {
                    //userData.setUserName(s);
                }
            } else {
                //showError(Messages.EmptyMessage, binding.uNameTextInput, binding.usame);
                //model.setUserName(null);
            }
        });

        viewModel.getUserAmount().observe(this, s -> {
            if (s != null) {
                removeError(binding.amountTextInput);
                if (TextUtils.isEmpty(s)) {
                    showError(Messages.EmptyMessage, binding.amountTextInput, binding.amountEditText);
                    //userData.setUserName(null);
                }
            }
        });


        binding.sendAmount.setOnClickListener(v -> {
            nameErrorCount = 1;
            cnicErrorCount = 1;
            mobErrorCount = 1;
            removeError(binding.jazzTextInput);
            removeError(binding.cnicTextInput);
            removeError(binding.nameTextInput);
            removeError(binding.amountTextInput);

            if (Objects.requireNonNull(binding.nameEditText.getText()).toString().trim().isEmpty()) {
                showError(Messages.EmptyMessage, binding.nameTextInput, binding.nameEditText);
                return;
            } else if (viewModel.validateUserName(binding.nameEditText.getText().toString())) {
                showError(Messages.userNameShortMessage, binding.nameTextInput, binding.nameEditText);
                return;
            }

            if (Objects.requireNonNull(binding.jazzEditText.getText()).toString().trim().isEmpty()) {
                showError(Messages.EmptyMessage, binding.jazzTextInput, binding.jazzEditText);
                return;
            } else if (viewModel.validateUserName(binding.jazzEditText.getText().toString())) {
                showError(Messages.phoneNumberValidMessage2, binding.jazzTextInput, binding.jazzEditText);
                return;
            }

            if (Objects.requireNonNull(binding.cnicEditText.getText()).toString().trim().isEmpty()) {
                showError(Messages.EmptyMessage, binding.cnicTextInput, binding.cnicEditText);
                return;
            } else if (viewModel.validateUserName(binding.jazzEditText.getText().toString())) {
                showError(Messages.cnicMessage, binding.cnicTextInput, binding.cnicEditText);
                return;
            }

            if (Objects.requireNonNull(binding.amountEditText.getText()).toString().trim().isEmpty()) {
                showError(Messages.EmptyMessage, binding.amountTextInput, binding.amountEditText);
                return;
            }
            Constants.Auth = Constants.Bearer + " " + SharedPrefManager.getInstance(getApplicationContext()).getUserInfo().getAccessToken();
            startLoader();
            JazzCashData jazzCashData = new JazzCashData(
                    (binding.nameEditText.getText()).toString().trim(),
                    (binding.jazzEditText.getText()).toString().trim(),
                    (binding.cnicEditText.getText()).toString().trim(),
                    (binding.amountEditText.getText()).toString().trim()
            );
            viewModel.jazzCashPayRequest(jazzCashData);
            viewModel.jazzCashPayRepose().observe(JazzCashActivity.this, dataModelObject -> {
                stopLoader();
                if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                    Log.v("jazzCashPayRepose", "jazzCashPayRepose " + dataModelObject);
                   // showToast(JazzCashActivity.this, "Thank you for Using JazzCash, your transaction was successful.");
                    showPopup(JazzCashActivity.this,"Thank you for Using JazzCash, Your transaction was successful.");
                    //DialogBoxSingleton.getInstance().showPopup(JazzCashActivity.this,"Thank you for Using JazzCash, Your transaction was successful.",false);
                    //finish();
                } else {
                    DialogBoxSingleton.getInstance().showErrorPopup(JazzCashActivity.this, dataModelObject.getError());
                    if (dataModelObject.getError().getMessage() != null) {
                        //showToast(JazzCashActivity.this, dataModelObject.getError().getMessage());
                        Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                    } else if (dataModelObject.getError().getMessages() != null) {
                       // showToast(JazzCashActivity.this, dataModelObject.getError().getMessages().toString());
                        Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                    }
                }
            });
        });
    }

    public void showPopup(Context context,String message) {


        final Dialog dialog = new Dialog(context);
        dialog.setContentView(R.layout.error_popup);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(true);
        TextView errorBody = dialog.findViewById(R.id.errorBody);
        errorBody.setText(message!=null?message:context.getString(R.string.error));
        Button okay = dialog.findViewById(R.id.next);
        okay.setOnClickListener(v -> {
            dialog.dismiss();
           Intent i = new Intent(JazzCashActivity.this, DashBoardActivity.class);
            startActivity(i);
            finish();
        });
        /*okay.setOnClickListener(v -> dialog.dismiss());*/

        dialog.show();
        Window window = dialog.getWindow();
        assert window != null;
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

}