package com.oyla.passenger.BroadcastReceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.location.LocationManager;
import android.util.Log;
import android.widget.Toast;

import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.utilities.Constants;

import static com.oyla.passenger.utilities.Constants.PERMISSIONS_REQUEST_ENABLE_GPS;

public class GpsChangeReceiver extends BroadcastReceiver {
    Context mContext;
    String TAG="GpsChangeReceiver";
    boolean flag=true;
    @Override
    public void onReceive(Context context, Intent intent ) {
       // Toast.makeText(context, "onReceive ---- ", Toast.LENGTH_SHORT).show();
        mContext=context;
        Log.d(TAG, "onReceive");
        final LocationManager manager = (LocationManager) context.getSystemService( Context.LOCATION_SERVICE );
        if (manager.isProviderEnabled( LocationManager.GPS_PROVIDER ) ) {
            //do something
           // Toast.makeText(context, "GPS enabled - ", Toast.LENGTH_SHORT).show();
            //Constants.GPS_DIALOG=true;
            flag=true;
            Log.d(TAG, "GPS enabled");
        }
        else {
          // Toast.makeText(context, "GPS disable ---- ", Toast.LENGTH_SHORT).show();
            Log.d(TAG, "GPS disable");
           // Constants.mLocationPermissionGranted=false;
            //Constants.GPS_DIALOG=false;
            if(flag){
                Constants.GPS_DIALOG=false;
                flag=false;
                BaseActivity.getInstance().buildAlertMessageNoGps();
            }

        }
    }
/*
    public void buildAlertMessageNoGps() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
        builder.setMessage("This application requires GPS to work properly, do you want to enable it?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(@SuppressWarnings("unused") final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        Intent enableGpsIntent = new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        startActivityForResult(enableGpsIntent, PERMISSIONS_REQUEST_ENABLE_GPS);
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }*/

}