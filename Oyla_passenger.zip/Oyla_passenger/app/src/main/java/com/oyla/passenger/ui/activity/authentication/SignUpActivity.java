package com.oyla.passenger.ui.activity.authentication;


import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;

import androidx.lifecycle.ViewModelProvider;

import com.oyla.passenger.MainApp;
import com.oyla.passenger.utilities.DialogBoxSingleton;
import com.oyla.passenger.R;
import com.oyla.passenger.databinding.ActivitySignUpBinding;
import com.oyla.passenger.databinding.PasswordLayoutBinding;
import com.oyla.passenger.databinding.UserNameLayoutBinding;
import com.oyla.passenger.datamodels.usermodel.UserData;
import com.oyla.passenger.ui.BaseActivity;
import com.oyla.passenger.ui.activity.dahsboard.DashBoardActivity;
import com.oyla.passenger.utilities.Constants;
import com.oyla.passenger.utilities.Messages;
import com.oyla.passenger.utilities.SharedPrefManager;
import com.oyla.passenger.viewmodels.SignUpViewModel;

public class SignUpActivity extends BaseActivity {

    private ActivitySignUpBinding binding;
    private SignUpViewModel viewModel;
    private UserData userData;
    private int errorCount = 0, layoutCount = 0;
    private PasswordLayoutBinding passwordLayoutBinding;
    private UserNameLayoutBinding userNameLayoutBinding;
    private String userId,accessToken,countryCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        hideAppBar(this);
        userId = getIntent().getStringExtra("userId");
        countryCode = getIntent().getStringExtra("countryCode");
        accessToken = getIntent().getStringExtra("accessToken");
        binding = setContentView(this, R.layout.activity_sign_up);
        viewModel = new ViewModelProvider(this).get(SignUpViewModel.class);
        passwordLayoutBinding = binding.passwordLayout;
        userNameLayoutBinding = binding.userNameLayout;
        passwordLayoutBinding.setViewModel(viewModel);
        userNameLayoutBinding.setViewModel(viewModel);
        userData = new UserData();
        binding.continueButtons.customButtonText.setText(getResources().getString(R.string.continue_text));

        viewModel.getPassword().observe(this, s -> {
            if (s != null) {
                removeError(passwordLayoutBinding.passwordTextInput);
                if (TextUtils.isEmpty(s)) {
                    showError(Messages.EmptyMessage, passwordLayoutBinding.passwordTextInput, passwordLayoutBinding.password);
                    userData.setUserPassword(null);
                } else if (viewModel.validatePassword(s)) {
                    if (errorCount > 0) {
                        showError(Messages.passwordShortMessage, passwordLayoutBinding.passwordTextInput, passwordLayoutBinding.password);
                    }
                    userData.setUserPassword(s);
                } else {
                    userData.setUserPassword(s);

                }
            } else {
                showError(Messages.EmptyMessage, passwordLayoutBinding.passwordTextInput, passwordLayoutBinding.password);
                userData.setUserPassword(null);
            }
        });

        viewModel.getUserName().observe(this, s -> {
            if (s != null) {
                removeError(userNameLayoutBinding.userNameTextInput);
                if (TextUtils.isEmpty(s)) {
                    showError(Messages.EmptyMessage, userNameLayoutBinding.userNameTextInput, userNameLayoutBinding.userNameEditText);
                    userData.setUserFirstName(null);
                } else if (viewModel.validateUserName(s)) {
                    if (errorCount > 0) {
                        showError(Messages.userNameShortMessage, userNameLayoutBinding.userNameTextInput, userNameLayoutBinding.userNameEditText);
                    }
                    userData.setUserFirstName(s);
                } else {
                    userData.setUserFirstName(s);
                }
            } else {
                if (errorCount > 0) {
                    showError(Messages.EmptyMessage, passwordLayoutBinding.passwordTextInput, passwordLayoutBinding.password);
                }
                userData.setUserFirstName(null);
            }
        });

        passwordLayoutBinding.layout1.setVisibility(View.GONE);
        userNameLayoutBinding.layout2.setVisibility(View.VISIBLE);
        layoutCount = 1;
        Log.v("layoutCount","layoutCount "+layoutCount);

        binding.continueButtons.button.setOnClickListener(view -> {
            Log.v("layoutCount","layoutCount "+layoutCount);
            if (layoutCount == 0) {
                errorCount = 1;
                if (TextUtils.isEmpty(userData.getUserPassword())) {
                    showError(Messages.EmptyMessage, passwordLayoutBinding.passwordTextInput, passwordLayoutBinding.password);
                    return;
                } else if (viewModel.validatePassword(userData.getUserPassword())) {
                    showError(Messages.passwordShortMessage, passwordLayoutBinding.passwordTextInput, passwordLayoutBinding.password);
                    return;
                }
                passwordLayoutBinding.layout1.setVisibility(View.GONE);
                userNameLayoutBinding.layout2.setVisibility(View.VISIBLE);
                layoutCount = 1;
                errorCount = 0;
            } else if (layoutCount == 1) {
                errorCount = 1;
                Log.v("layoutCount","errorCount "+errorCount);
                if (TextUtils.isEmpty(userData.getUserFirstName())) {
                    Log.v("layoutCount","empty");
                    showError(Messages.EmptyMessage, userNameLayoutBinding.userNameTextInput, userNameLayoutBinding.userNameEditText);
                    return;
                } else if (viewModel.validateUserName(userData.getUserFirstName())) {
                    Log.v("layoutCount","validateUserName");
                    showError(Messages.userNameShortMessage, userNameLayoutBinding.userNameTextInput, userNameLayoutBinding.userNameEditText);
                    return;
                }

                // layout=0;
               // if (viewModel.isModel(userData)) {
                    //proceed();
                    //Toast.makeText(SignUpActivity.this, "Proceed", Toast.LENGTH_SHORT).show();
                    startLoader();
                    Constants.Auth = Constants.Bearer + " " +accessToken;
                    viewModel.sendSignUpData(
                            userId,
                            userNameLayoutBinding.userNameEditText.getText().toString(),
                            "_",
                           "12345678"
                           /* passwordLayoutBinding.password.getText().toString()*/);
                    //Intent i = new Intent(SignUpActivity.this, DashBoardActivity.class);
                    //startActivity(i);
                    showToast(SignUpActivity.this,"Wait for user verification");
                    signUpRepose();
               // }
            }
            Log.v("isModel", "isModel " + viewModel.isModel(userData));
            // Log.v("isModel", "isModel " + userData.getUserPassword());
        });
        binding.backButton.setOnClickListener(v -> onBackPressed());
    }

    private void signUpRepose() {
        viewModel.receiveOtpRepose().observe(this, dataModelObject -> {
            stopLoader();
            Log.v("jsonData", "signUpRepose ");
            if (dataModelObject.getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
              /*  String content = "";
                content += "Msg: " +dataModelObject.getMsg() + "\n";
                content += "Status : "+dataModelObject.getStatus() + "\n";
                content += "getUserPhoneNumber: " +dataModelObject.getData().getUser().getUserPhoneNumber() + "\n\n";
                content += "getUserId: " +dataModelObject.getData().getUser().getUserId() + "\n\n";
                content += "isVERIFIED: " +dataModelObject.getData().getUser().getIsVERIFIED() + "\n\n";
                Log.v("content","content "+content);*/
                if (dataModelObject.getData().getUser().getIsVERIFIED() == 2) {
                  //  showToast(SignUpActivity.this, Messages.SignOutSuccess);
                    SharedPrefManager.getInstance(SignUpActivity.this).
                            userInfo(userId,accessToken);
                   // showToast(SignUpActivity.this, "Sign In SuccessFull");
                    MainApp.getInstance().setUserData( dataModelObject.getData().getUser());
                    Constants.LOGIN_SUCCESS=true;
                    Constants.SOCIAL=false;
                   /* SharedPrefManager.getInstance(SignUpActivity.this).
                            userInfo(
                                    dataModelObject.getData().getUser().getUserId(),dataModelObject.getAccessToken()
                            );*/
                  /*  SharedPrefManager.getInstance(SignUpActivity.this).
                            userProfile(
                                    dataModelObject.getData().getUser().getUserId(),
                                    dataModelObject.getData().getUser().getUserFirstName(),
                                    dataModelObject.getData().getUser().getUserLastName(),
                                    dataModelObject.getData().getUser().getUserEmail(),
                                    dataModelObject.getData().getUser().getUserMobNumber(),
                                    dataModelObject.getData().getUser().getProfilePic(),
                                    dataModelObject.getData().getUser().getIsVERIFIED(),
                                    "-", "-", "-",Token
                            );*/
                    Intent i = new Intent(SignUpActivity.this, DashBoardActivity.class);
                    startActivity(i);
                    Constants.SING_IN_FIRST=true;
                    finish();
                } else {
                   // showToast(SignUpActivity.this, "Sign Up Un-SuccessFull");
                }
            } else {
                //showToast(SignUpActivity.this, dataModelObject.getMsg());
               // showToast(SignUpActivity.this, "Sign Up Un-SuccessFull");
                DialogBoxSingleton.getInstance().showErrorPopup(SignUpActivity.this,dataModelObject.getError());
                if(dataModelObject.getError().getMessage()!=null){
                   // showToast(SignUpActivity.this, dataModelObject.getError().getMessage());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessage());
                }else if(dataModelObject.getError().getMessages()!=null){
                  //  showToast(SignUpActivity.this, dataModelObject.getError().getMessages().toString());
                    Log.v("getErrorMessage", "getErrorMessage " + dataModelObject.getError().getMessages().toString());
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
       /* if (layoutCount == 1) {
            passwordLayoutBinding.layout1.setVisibility(View.VISIBLE);
            userNameLayoutBinding.layout2.setVisibility(View.GONE);
            layoutCount = 0;
        } else if (layoutCount == 0) {*/
            Intent i = new Intent(this, SignInActivity.class);
            i.putExtra("countryCode",countryCode);
            startActivity(i);
            finish();
            super.onBackPressed();
       // }
    }
}