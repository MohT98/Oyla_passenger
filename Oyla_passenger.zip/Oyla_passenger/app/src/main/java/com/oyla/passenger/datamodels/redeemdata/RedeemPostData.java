package com.oyla.passenger.datamodels.redeemdata;

public class RedeemPostData {
    private String user_id,award_id;

    public RedeemPostData(String user_id) {
        this.user_id = user_id;
    }

    public RedeemPostData(String user_id, String award_id) {
        this.user_id = user_id;
        this.award_id = award_id;
    }
}
