package com.oyla.passenger.datamodels.chat;

import android.os.Parcel;
import android.os.Parcelable;

public class BookingFCM implements Parcelable {
    private String booking_id;
    private String fcm1;
    private String fcm2;
    public BookingFCM() {

    }

    public BookingFCM(String fcm1) {
        this.fcm1 = fcm1;
    }
    public BookingFCM(String booking_id, String fcm1) {
        this.booking_id = booking_id;
        this.fcm1 = fcm1;
    }

    public String getBooking_id() {
        return booking_id;
    }

    public void setBooking_id(String booking_id) {
        this.booking_id = booking_id;
    }

    public String getFcm1() {
        return fcm1;
    }

    public void setFcm1(String fcm1) {
        this.fcm1 = fcm1;
    }

    public String getFcm2() {
        return fcm2;
    }

    public void setFcm2(String fcm2) {
        this.fcm2 = fcm2;
    }

    public static Creator<BookingFCM> getCREATOR() {
        return CREATOR;
    }

    protected BookingFCM(Parcel in) {
        booking_id = in.readString();
        fcm1 = in.readString();
        fcm2 = in.readString();
    }

    public static final Creator<BookingFCM> CREATOR = new Creator<BookingFCM>() {
        @Override
        public BookingFCM createFromParcel(Parcel in) {
            return new BookingFCM(in);
        }

        @Override
        public BookingFCM[] newArray(int size) {
            return new BookingFCM[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(booking_id);
        dest.writeString(fcm1);
        dest.writeString(fcm2);
    }
}
