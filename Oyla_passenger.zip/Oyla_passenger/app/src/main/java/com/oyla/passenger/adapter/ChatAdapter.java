package com.oyla.passenger.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.oyla.passenger.R;
import com.oyla.passenger.datamodels.chat.ChatDataModel;

import java.util.List;

public class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.MyViewHolder> {

    //  private ArrayList<ChatDataModel> dataSet;
    private final List<ChatDataModel> dataSet;
    private final Context mCtx;
    private ChatAdapter.OnItemClickListener mListener;
    String amount;
    String currency;

    public void setOnItemClickListener(ChatAdapter.OnItemClickListener listener) {
        mListener = listener;
    }
    public ChatAdapter(Context mCtx, List<ChatDataModel> data) {
        this.dataSet = data;
        this.mCtx = mCtx;
    }
    @NonNull
    @Override
    public ChatAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_list_item, parent, false);
        return new ChatAdapter.MyViewHolder(view, mListener);
    }

    @SuppressLint({"SetTextI18n", "UseCompatLoadingForDrawables"})
    @Override
    public void onBindViewHolder(final ChatAdapter.MyViewHolder holder, final int listPosition) {
       /* holder.message.setText(toTitleCase(dataSet.get(listPosition).getMessage()));*/
        holder.message.setText(dataSet.get(listPosition).getMessage());
      /*  if(dataSet.get(listPosition).getPassenger_id()!=null && !dataSet.get(listPosition).getPassenger_id().isEmpty()){*/
        if(dataSet.get(listPosition).getType().equals("1")){
            //Log.v("Passenger_id","Passenger_id "+dataSet.get(listPosition).getPassenger_id() +" ="+dataSet.get(listPosition).getMessage());
            holder.mainLayout.setGravity(Gravity.END);
            holder.message.setGravity(Gravity.START);
            holder.bubbleLayout.setBackground(mCtx.getResources().getDrawable(R.drawable.shape_bg_outgoing_bubble,mCtx.getTheme()));
            RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                    RelativeLayout.LayoutParams.WRAP_CONTENT,
                    RelativeLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(120, 30, 30, 0);
            holder.bubbleLayout.setLayoutParams(params);
        }else {
            holder.mainLayout.setGravity(Gravity.START);
            holder.message.setGravity(Gravity.START);
            holder.bubbleLayout.setBackground(mCtx.getResources().getDrawable(R.drawable.shape_bg_incoming_bubble,mCtx.getTheme()));
            RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                    RelativeLayout.LayoutParams.WRAP_CONTENT,
                    RelativeLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(30, 30, 120, 0);
            holder.bubbleLayout.setLayoutParams(params);
        }
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView message;
        RelativeLayout mainLayout;
        LinearLayout bubbleLayout;
        public MyViewHolder(@NonNull View itemView, final ChatAdapter.OnItemClickListener listener) {
            super(itemView);
            message = itemView.findViewById(R.id.message);
            mainLayout = itemView.findViewById(R.id.mainLayout);
            bubbleLayout= itemView.findViewById(R.id.bubbleLayout);
          /*  itemView.setOnClickListener(v -> {
                if (listener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onItemClick(position);
                    }
                }
            });*/
        }
    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }
}
