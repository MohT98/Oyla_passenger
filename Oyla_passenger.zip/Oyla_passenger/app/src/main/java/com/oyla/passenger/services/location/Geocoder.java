package com.oyla.passenger.services.location;

import android.app.Service;
import android.content.Intent;
import android.location.Address;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

import com.oyla.passenger.utilities.Constants;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import static com.oyla.passenger.ui.activity.cabbooking.MapActivity.PICK_UP_TRACKING;

public class Geocoder extends Service {

    private static final String TAG = "Geocoder";

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    @Override
    public void onCreate() {
        super.onCreate();
    }
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, TAG+"  onStartCommand: called.");

        if (intent.getAction().equals(Constants.ACTION_START_FOREGROUND_SERVICE)) {
            Log.i(TAG, TAG+" Start Foreground Intent ");
            // your start service code

            String latitude = intent.getStringExtra("latitude");
            String longitude = intent.getStringExtra("longitude");
            getStringAddress(Double.parseDouble(latitude), Double.parseDouble(longitude));
        } else if (intent.getAction().equals(Constants.ACTION_STOP_FOREGROUND_SERVICE)) {
            Log.i(TAG, TAG+"  Stop Foreground Intent");
            //your end servce code
            stopForeground(true);
            stopSelfResult(startId);
            PICK_UP_TRACKING = false;
        }
        return START_STICKY;
    }

        public String getStringAddress(double latitude, double longitude) {
        android.location.Geocoder geocoder;
        List<Address> addresses;
        geocoder = new android.location.Geocoder(this, Locale.getDefault());
        Log.v(TAG, "latitude " + latitude);
        Log.v(TAG, "longitude " + longitude);

        if (latitude != 0.0 && longitude != 0.0) {
            String address;
            try {
                Log.v(TAG, "try ");
                if (geocoder.getFromLocation(latitude, longitude, 1) != null) {
                    addresses = geocoder.getFromLocation(latitude, longitude, 1);
                    if (!addresses.isEmpty()) {
                        address = addresses.get(0).getAddressLine(0);
                    } else {
                        address = "Finding Address...";
                    }
                } else {
                    address = "Finding Address...";
                }


                return address;
            } catch (IOException e) {
                Log.v(TAG, "catch "+e);
                e.printStackTrace();
                return "Finding Address...";
            }
        } else {
            return "Finding Address...";
        }
    }
    @Override
    public void onDestroy() {
        Log.i(TAG, "NearestDriverCoordinates onCreate() , service stopped...");

        // disposable.dispose();
    }
}
