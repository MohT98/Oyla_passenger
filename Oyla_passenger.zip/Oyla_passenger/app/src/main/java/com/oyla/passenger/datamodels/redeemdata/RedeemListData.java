package com.oyla.passenger.datamodels.redeemdata;

import android.os.Parcel;
import android.os.Parcelable;

public class RedeemListData implements Parcelable {
    private String id;
    private String title;
    private String description;
    private String thumb_image;
    private String banner_image;
    private String points_limit;
    private String reward;

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getThumb_image() {
        return thumb_image;
    }

    public String getBanner_image() {
        return banner_image;
    }

    public String getPoints_limit() {
        return points_limit;
    }

    public String getReward() {
        return reward;
    }

    protected RedeemListData(Parcel in) {
        id = in.readString();
        title = in.readString();
        description = in.readString();
        thumb_image = in.readString();
        banner_image = in.readString();
        points_limit = in.readString();
        reward = in.readString();
    }

    public static final Creator<RedeemListData> CREATOR = new Creator<RedeemListData>() {
        @Override
        public RedeemListData createFromParcel(Parcel in) {
            return new RedeemListData(in);
        }

        @Override
        public RedeemListData[] newArray(int size) {
            return new RedeemListData[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(title);
        dest.writeString(description);
        dest.writeString(thumb_image);
        dest.writeString(banner_image);
        dest.writeString(points_limit);
        dest.writeString(reward);
    }
}
